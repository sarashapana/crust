var crustAdmin = crustAdmin || {};

(function ($, wp) {

    "use strict";

    crustAdmin.init = {

        crust_core_image_upload: function () {

            if ($('.crust-image-upload').length) {

                $('.crust-image-upload').each(function () {
                    var th      = $(this),
                        parnt   = th.parent(),
                        txtb    = parnt.prev();

                    if (txtb.val() !== '') {
                        th.prev('.crust-clear-img').addClass('upload-has-image');
                    } else {
                        th.prev('.crust-clear-img').removeClass('upload-has-image');
                    }

                    th.on('click', function (e) {
                        e.preventDefault();
                        wp.media.editor.send.attachment = function (props, attachment) {
                            txtb.val(attachment.id).trigger('change');

                            th.prev(".crust-clear-img").addClass('upload-has-image').css('background-image','url('+attachment.url+')');

                            parnt.find('a.crust-remove-img').show();

                            parnt.find('a.crust-remove-img').on('click', function (e) {
                                e.preventDefault();
                                txtb.val('').trigger('change');
                                parnt.find('.crust-clear-img').remove();
                                $(this).parents('.crust-tab-panel').find('.customize-control[id*="_bg_"]').find('select').val('').trigger('change');
                                $(this).remove();
                            });

                        };
                        wp.media.editor.open(this);
                        if( $('.crust-page-field').length ){
                            crustAdmin.init.crust_core_dependency();
                        }
                        return false;
                    });

                    parnt.find('a.crust-remove-img').on('click', function (e) {
                        e.preventDefault();
                        txtb.val('').trigger('change');
                        parnt.find('.crust-clear-img').remove();
                        $(this).parents('.crust-tab-panel').find('.customize-control[id*="_bg_"]').find('select').val('').trigger('change');
                        $(this).remove();
                    });

                });

            }

        },

        crust_core_media_upload: function () {

            if ($('.crust-file-upload').length) {

                $('.crust-file-upload').each(function () {
                    var th      = $(this),
                        parnt   = th.parent(),
                        txtb    = parnt.find('.crust-media-input');

                    th.on('click', function (e) {
                        e.preventDefault();
                        wp.media.editor.send.attachment = function (props, attachment) {
                            txtb.val(attachment.url).trigger('change');
                            parnt.find('a.crust-remove-file').show();

                            parnt.find('a.crust-remove-file').on('click', function (e) {
                                e.preventDefault();
                                txtb.val('').trigger('change');
                                $(this).remove();
                            });

                        };
                        wp.media.editor.open(this);
                        //return false;
                    });

                    parnt.find('a.crust-remove-file').on('click', function (e) {
                        e.preventDefault();
                        txtb.val('').trigger('change');
                        $(this).remove();
                    });

                });

            }

        },

        crust_core_globals: function () {
            if( $('.crust-alpha-color').length > 0 ){
                $('.crust-alpha-color').wpColorPicker();
            }
        },

        crust_core_import_demo: function(){
            /* ================== Import Demo Data. ================= */

            $('.crust-import-btn').each(function () {

                var $btn = $( this ),
                    $import_true    = '',
                    _attachment 	= $btn.parent().parent().find('.crust_import_data'),
                    $demo           = $btn.data('demo'),
                    _is_attachment  = null;

                $btn.on('click', function(e){
                    e.preventDefault();
                    $import_true = confirm('Are you sure ? This will overwrite the existing data!');
                    if($import_true === false) return;

                    if( _attachment.is(':checked') ) {
                        _is_attachment = true;
                    }

                    $('.crust-top-import-icons').fadeIn();
                    $('.crust-demo-loading-notice').fadeIn();
                    $('.crust-demo-loader').fadeIn();
                    $('.crust-import-attachments').fadeOut();

                    $.ajax({
                        type  : 'POST',
                        url   : ajaxurl,
                        data  : { action: 'crust_import_demo_' + $demo, attachment: _is_attachment },
                        success : function( data ) {
                            $('.crust-demo-loader').fadeOut();
                            $('.crust-top-import-icons').fadeOut();
                            $('.crust-demo-loading-notice').fadeOut();
                            $('.crust-import-success').fadeIn();
                            window.location.reload(true);
                        },
                        error: function () {
                            $('.crust-import-message').html('<span>There is a problem importing Data.</span>');
                        }
                    });
                });

            });


        },

        crust_core_dependency: function(){

            $(".crust-page-field[data-dep]").removeClass('active-dep');

            $('.dep-field').each(function(){
                var t 		= $(this),
                    vl 		= t.val(),
                    deps 	= t.parents('.crust-page-field').data('id');

                    $("[data-dep='"+deps+"']").removeClass('active-dep');
                    $("[data-dep='"+deps+"'][data-vl='"+vl+"']").addClass('active-dep');

                    t.on('change input keyup keypress paste',function(){
                        var vl2 = t.val();
                        $("[data-dep='"+deps+"']").removeClass('active-dep');
                        $("[data-dep='"+deps+"'][data-vl='"+vl2+"']").addClass('active-dep');
                    });


            });
        },

    };

    crustAdmin.docLoad = {
        init: function () {
            crustAdmin.init.crust_core_globals();
            crustAdmin.init.crust_core_image_upload();
            crustAdmin.init.crust_core_media_upload();
            crustAdmin.init.crust_core_import_demo();
            crustAdmin.init.crust_core_dependency();
        }
    };

    /* ================ Window.Load Functions. ================ */
    $(window).on('load', crustAdmin.docLoad.init);

    /* ================ AjaxComplete Functions. ================ */
    if (!$('.menu-edit .menu li').length) {
        $(document).unbind('ajaxComplete').bind('ajaxComplete', function () {
            crustAdmin.init.crust_core_image_upload();
        });
    }

})(jQuery, wp);