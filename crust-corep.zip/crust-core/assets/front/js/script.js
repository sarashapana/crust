let crustCore = {};

(function ($) {

    "use strict";

    crustCore.init = {

        crust_globals() {

            // Tilt Effect
            if( $('.js-tilt').length > 0 ){
                $('.js-tilt').tilt({
                    maxTilt: 10,
                    speed: 1000,
                    perspective: 800
                });
            }

            let split_tilt = $(".js-tilt-split");
            if( split_tilt.length > 0 ){
                split_tilt.each(function(){
                    $(this).tilt( {
                        transition: true,
                        'mouse-event-element': $(this).parents('.crust-splitter')
                    });
                });
            }

            if( $('.crust-search-dropdown select').length ){
                $('.crust-search-dropdown select').select2();
            }

            $('.crust-post-paleo .crust-entry-content').each(function() {
                let height = parseInt( $( this ).find('.crust-post-excerpt').outerHeight(), 10 );
                $( this ).parent().parent().parent().attr('data-height', height + 'px');
            });

            if( $( '.crust-parallax-section .crust-inner-bg' ).length ){
                setTimeout(function (){
                    jarallax(document.querySelectorAll('.crust-parallax-section .crust-inner-bg'));
                }, 2000);
            }

            if( $('.crust-rotate-section-bg').length ){
                $('.crust-rotate-section-bg').each(function (){
                    let th = $(this),
                        dur = th.data('rotate-duration'),
                        src = th.data('source'),
                        $dur = ( typeof dur !== 'undefined' && dur ) ? ' style="animation-duration: '+dur+'s;-webkit-animation-duration: '+dur+'s"' : '';
                    th.prepend('<div class="crust-rotate-object"'+$dur+'><img alt="" src="'+src+'" /></div>');
                });
            }

            if( $('.crust-play-media').length ){
                $('.crust-play-media a').each(function (){
                    let typ = $(this).data('pop-type');
                    $(this).magnificPopup({
                        disableOn: 700,
                        type: typ,
                        mainClass: 'mfp-with-anim',
                        removalDelay: 160,
                        preloader: true,
                        fixedContentPos: true,
                        callbacks: {
                            beforeOpen: function() {
                                this.st.mainClass = this.st.el.attr('data-effect');
                            }
                        },
                    });
                });
            }

            if( $('.crust-magnific-link').length ){
                $('.crust-magnific-link').on('click', function (){
                    return false;
                });
                $('.crust-magnific-link').magnificPopup({
                    midClick: true,
                    type: 'image',
                    gallery:{
                        enabled:true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300, // duration of the effect, in milliseconds
                        easing: 'ease-in-out', // CSS transition easing function
                        opener: function(openerElement) {
                            return openerElement.is('a') ? openerElement : openerElement.parents('.crust-gallery-item');
                        }
                    }
                });
            }

            if( $('.crust-zoom-link').length ){
                $('.crust-zoom-link').magnificPopup({
                    midClick: true,
                    type: 'image',
                    gallery:{
                        enabled:true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300, // duration of the effect, in milliseconds
                        easing: 'ease-in-out', // CSS transition easing function
                        opener: function(openerElement) {
                            return openerElement.is('a') ? openerElement : openerElement.parents('.crust-image');
                        }
                    }
                });
            }

            if( $('.crust-splash-screen').length ) {

                $('.crust-splash-screen').each(function () {

                    let $this = $(this),
                        $close = $this.find('.crust-close-splash'),
                        $show = ($this.data('time') !== undefined) ? $this.data('time') : '',
                        $name = ($this.data('name') !== undefined) ? $this.data('name') : '',
                        $days = ($this.data('days') !== undefined) ? $this.data('days') : 10;

                    if( $show ){
                        setTimeout(function () {
                            $this.addClass('crust-show-in');
                        }, $show);
                    }

                    if ($name && Cookies.get('crust-splash-done-' + $name) === 'true') {
                        $this.remove();
                    }

                    $close.on('click', function (e) {
                        e.preventDefault();
                        $this.addClass('crust-gone');
                        setTimeout(function () {
                            $this.remove();
                        }, 250);
                        if ($name) {
                            Cookies.set("crust-splash-done-" + $name, 'true', {expires: $days});
                        }
                    });

                });

            }

            /* slideshow compatibility support */
            document.documentElement.className = "js";
            var supportsCssVars = function supportsCssVars() {
                var e,
                    t = document.createElement("style");
                return t.innerHTML = "root: { --tmp-var: bold; }", document.head.appendChild(t), e = !!(window.CSS && window.CSS.supports && window.CSS.supports("font-weight", "var(--tmp-var)")), t.parentNode.removeChild(t), e;
            };
            supportsCssVars() || alert("Please view this site in a modern browser that supports CSS Variables.");

        },

        crust_dark_mode(){
            if( $('.crust-switch-dark').length ){
                if ( Cookies.get('crust-dark') === 'on' ){
                    $('body').addClass('crust-dark');
                    $('.crust-switch-dark').prop('checked', true);
                }
                $('.crust-switch-dark').on('click', function() {
                    if ($(this).is (':checked')){
                        $('body').addClass('crust-dark');
                        Cookies.set("crust-dark", 'on');
                    } else {
                        $('body').removeClass('crust-dark');
                        Cookies.set("crust-dark", null);
                    }
                });
            }

        },

        crust_scroll_to_id() {
            let crust_head = $('.crust-main-wrap > header');
            if (crust_head.length > 0) {
                if ($(".crust-site-navigation a[href*='#']:not([href='#'])").length) {
                    $(".crust-site-navigation a[href*='#']:not([href='#'])").each(function (){
                        let el = $(this).attr('href');
                        $(this).on('click', function () {
                            $.smoothScroll({
                                speed: 1200,
                                scrollTarget: $(el)
                            });
                            return false;
                        });
                    });
                }

            }

            if( $('.crust-smooth-scroll-click').length > 0 ){
                $(".crust-smooth-scroll-click").each(function (){
                    let el = $(this).attr('href');
                    $(this).on('click', function () {
                        $.smoothScroll({
                            speed: 1000,
                            scrollTarget: $(el)
                        });
                        return false;
                    });
                });

            }
        },

        crust_social_share() {

            if( $(".crust_single_share").length > 0 ){
                $(".crust_single_share").each(function(){
                    var th 		= $(this),
                        $url 	= $(location).attr("href"),
                        $soc 	= th.data('share-on').split(',');
                    th.jsSocials({
                        url: $url,
                        showLabel: true,
                        showCount: true,
                        shares: $soc
                    });
                });
            }

            let $url = window.location.href;
            $('.crust-share-permalink').val($url);
            $('.crust-copy-permalink').on('click', function (e) {
                e.preventDefault();
                let copyText = $('.crust-share-permalink');
                copyText.select();
                document.execCommand("copy");
                $('.crust-copied').fadeIn().delay(1500).queue(function(n) {
                    $(this).fadeOut();
                    n();
                });
            });

        },

        crust_core_tweets() {
            if($('.crust-tweets-wrap').length){
                document.querySelectorAll('.crust-tweets-wrap').forEach(el => {
                    let vis = el.getAttribute('data-visible-tweets'),
                        max = el.getAttribute('data-max-tweets');

                    $(el).prepend('<div class="crust-preloader"><i class="fad fa-circle-notch"></i></div>');
                    setTimeout(function () {
                        let _html = $(el).next('iframe').contents().find("body").html();
                        $(el).append(_html);
                        $(el).find('.timeline-Tweet-media,.timeline-Header,.timeline-Tweet-actions,.timeline-Footer,.timeline-LoadMore,.timeline-Tweet-brand,.new-tweets-bar,.timeline-Tweet-retweetCredit').remove();
                        $(el).find('.timeline-Tweet-text br').replaceWith(' ');
                        $(el).find('.crust-preloader').hide();
                        $(el).find('.timeline-Viewport').addClass('swiper-container');
                        $(el).find('.timeline-TweetList').addClass('swiper-wrapper');
                        $(el).find('.timeline-TweetList').after('<div class="swiper-pagination crust-slide-pagination"></div>');
                        $(el).find('.timeline-TweetList li').addClass('swiper-slide');
                        if (vis < max) {
                            let $crustTwitterOptions = {
                                slidesPerView: vis,
                                pagination: {
                                    el: '.crust-slide-pagination',
                                    clickable: true,
                                },
                                autoHeight: true,
                                paginationClickable: true,
                                spaceBetween: 10,
                                grabCursor: true,
                            };
                            let mySwiper = new Swiper(el.querySelector('.timeline-Viewport'), $crustTwitterOptions);
                        }

                    }, 1500);
                    $(el).next('iframe').fadeOut(0);
                });
            }
        },

        crust_core_flickr() {
            if ($('.crust-flick-feed').length > 0) {
                $('.crust-flick-feed').each(function () {
                    var th = $(this),
                        thisID = th.attr('id'),
                        thisLmt = th.data('limit'),
                        thisFlick = th.data('flickr'),
                        cols = th.data('columns'),
                        wdt = parseInt(th.outerWidth(), 10);
                    th.jflickrfeed({
                        limit: thisLmt,
                        qstrings: {
                            id: thisFlick
                        },
                        itemTemplate: '<a href="{{image_b}}" target="_blank"><img src="{{image_s}}" alt="{{title}}" /></a>',
                    });
                });
            }
        },

        crust_particles() {

            document.querySelectorAll('.crust-particles-section').forEach(el => {

                let $id = el.getAttribute('data-id'),
                    $colors = el.getAttribute('data-particles-color'),
                    $number = el.getAttribute('data-particles-number'),
                    $shape = el.getAttribute('data-particles-shape'),
                    $mode = el.getAttribute('data-particles-mode'),
                    $img = el.getAttribute('data-particles-image'),
                    $wid = el.getAttribute('data-particles-width'),
                    $hit = el.getAttribute('data-particles-height'),
                    $size = el.getAttribute('data-particles-size'),
                    $line = el.getAttribute('data-particles-line-color');

                $( el ).append( $('<div class="crust-particles" id="particles-' + $id + '"></div>') );

                let id = 'particles-' + $id,
                    color_type = 'random_colors',
                    colors = ( $colors ) ? $colors.replace(/\s/g, '') : '',
                    number = ( $number ) ? $number : 20,
                    shape = ( $shape ) ? $shape : 'circle',
                    mode = ( $mode ) ? $mode : 'grab',
                    img = ( $img ) ? $img : '',
                    wid = ( $wid ) ? $wid : '100',
                    hit = ( $hit ) ? $hit : '100',
                    size = ( $size ) ? $size : '',
                    line = ( $line ) ? $line : '#fff';

                if ( color_type == 'random_colors' ) {
                    colors = colors.split(',');
                    if( line !== $line ){
                        line = colors[0];
                    }
                }

                var nb_num = 0;
                switch ( shape ) {
                    case 'triangle':
                        nb_num = 3;
                        break;
                    case "edge":
                        nb_num = 4;
                        break;
                    case "star":
                        nb_num = 5;
                        break;
                    case "polygon":
                        nb_num = 6;
                        break;
                    default:
                        nb_num = 0;
                }

                setTimeout(function (){

                    particlesJS(
                        id, {
                            "particles":{
                                "number":{
                                    "value": number,
                                    "density":{
                                        "enable": true,
                                        "value_area": 800
                                    }
                                },
                                "color":{
                                    "value": colors
                                },
                                "shape":{
                                    "type": shape,
                                    "polygon": {
                                        "nb_sides": nb_num
                                    },
                                    "image": {
                                        "src": img,
                                        "width": wid,
                                        "height": hit
                                    }
                                },
                                "opacity":{
                                    "value": 1,
                                    "random": true,
                                    "anim":{
                                        "enable": false,
                                        "speed": 1,
                                        "opacity_min": .6,
                                        "sync": false
                                    }
                                },
                                "size":{
                                    "value": size,
                                    "random": true,
                                    "anim":{
                                        "enable": false,
                                        "speed": 40,
                                        "size_min": .6,
                                        "sync": false
                                    }
                                },
                                "line_linked":{
                                    "enable": true,
                                    "distance": 150,
                                    "color": line,
                                    "opacity": 0,
                                    "width": 1
                                },
                                "move":{
                                    "enable": true,
                                    "speed": 2,
                                    "direction": "none",
                                    "random": false,
                                    "straight": false,
                                    "out_mode": "out",
                                    "bounce": false,
                                    "attract":{
                                        "enable": false,
                                        "rotateX": 600,
                                        "rotateY": 1200
                                    }
                                }
                            },
                            "interactivity":{
                                "detect_on":"canvas",
                                "events":{
                                    "onhover":{
                                        "enable": true,
                                        "mode": mode
                                    },
                                    "onclick":{
                                        "enable": true,
                                        "mode":"push"
                                    },
                                    "resize": true
                                },
                                "modes":{
                                    "grab":{
                                        "distance": 150,
                                        "line_linked":{
                                            "opacity": 1
                                        }
                                    },
                                    "bubble":{
                                        "distance": 150,
                                        "size": 40,
                                        "duration": 2,
                                        "opacity": 8,
                                        "speed": 3
                                    },
                                    "repulse":{
                                        "distance": 90,
                                        "duration": 0.4
                                    },
                                    "push":{
                                        "particles_nb": 4
                                    },
                                    "remove":{
                                        "particles_nb": 2
                                    }
                                }
                            },
                            //"retina_detect":true
                        });

                    var update;
                    update = function() {
                        requestAnimationFrame(update);
                    };
                    requestAnimationFrame(update);

                }, 400);

            });

        },

        crust_masonry_layout() {

            if( $('.crust-review-masonry').length ){
                $('.crust-review-masonry').each(function (){
                    $(this).masonry({
                        isOriginLeft: false,
                    });
                });
            }

            if( $('.crust-archive-wrapper.masonry').length || $( '.crust-portfolio-archive-wrapper .crust-portfolio-archive-list.masonry' ).length ){
                if( $('body').hasClass('rtl') ){
                    if( $('.crust-archive-wrapper.masonry').length ) {
                        $('.crust-archive-wrapper.masonry .crust-archive-list-wrap').masonry({
                            isOriginLeft: false,
                        });
                    }

                    if( $('.crust-portfolio-archive-wrapper').length ) {
                        $('.crust-portfolio-archive-wrapper .crust-portfolio-archive-list.masonry').masonry({
                            isOriginLeft: false,
                        });
                    }

                } else {

                    if( $('.crust-archive-wrapper.masonry').length ) {
                        $('.crust-archive-wrapper.masonry .crust-archive-list-wrap').masonry();
                    }

                    if( $('.crust-portfolio-archive-wrapper').length ) {
                        $('.crust-portfolio-archive-wrapper .crust-portfolio-archive-list.masonry').masonry();
                    }

                }

            }

        },

        crust_loadmore() {
            var n 		= 1,
                pgnum 	= $('.loadmore .pgnum').text(),
                url 	= window.location.href,
                paged 	= $('.blgurl').attr('data-pag'),
                $cont 	= $('.crust-archive-list-wrap');

            var lasHash = url.substr(url.length - 1);

            url = ( lasHash == '#' ) ? url.replace(lasHash, '') : url;

            $('.loadmore a').on('click', function(e){
                e.preventDefault();
                if (n < pgnum) {

                    $('.loadmore .crust_preloader').fadeIn(100);

                    var stick = parseInt($('.crust-site-header.crust-sticky-head').outerHeight(),10) + 10,
                        thOff = $cont.find('.crust-post-item:last-child').offset().top,
                        finH = parseInt($cont.find('.crust-post-item:last-child').outerHeight(),10) + thOff - stick;

                    setTimeout(function () {
                        var response;
                        $.ajax({ type: "GET",
                            url: url+paged+n,
                            async: false,
                            success : function(text){
                                response= text;
                                var $result = $( response ).find('.crust-archive-list-wrap').html();
                                $cont.append( $result );
                                if($cont.parent().is('.masonry')){
                                    $cont.masonry('destroy');
                                    crustCore.init.crust_masonry_layout();
                                }
                                $('body, html').animate({ scrollTop: finH }, 500);
                                $('.loadmore .crust_preloader').fadeOut();
                            }
                        });
                    }, 300);
                } else {
                    $('.loadmore .load_msg').fadeIn(500,function(){
                        setTimeout(function () {
                            $('.loadmore .load_msg').fadeOut();
                        }, 3000);
                    });
                }
                n++;
            });
        },

        isInViewport(node) {
            var rect = node.getBoundingClientRect()
            return (
                (rect.height > 0 || rect.width > 0) &&
                rect.bottom >= 0 &&
                rect.right >= 0 &&
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.left <= (window.innerWidth || document.documentElement.clientWidth)
            )
        },

        crust_popup(){
            let btn   = $( '.crust-modal-btn' ),
                overlay = $( '.crust-modal-overlay' ),
                mod = $( '.crust-modal' ),
                wrap = $( '.crust-modal-content' ),
                close = $( '.crust-close-modal' );

            btn.each( function () {

                $( this ).on( 'click', function( e ) {
                    e.preventDefault();
                    let animation = $( this ).data( 'modal-animation' ),
                        style = $( this ).data( 'modal-style' ),
                        modal_text = $( this ).data( 'modal-text' ),
                        prim_temp = $( this ).data( 'modal-temp' ),
                        id = $( this ).data( 'modal-id' ),
                        editor = $( this ).data( 'editor' ),
                        content_type = $( this ).data( 'modal-type' );

                    overlay.addClass( 'crust-show-wrap crust-mod-loading' );
                    mod.addClass(animation);
                    wrap.attr('style', style);
                    wrap.addClass(id);

                    $.ajax({
                        type: 'POST',
                        url: crust_core.ajaxurl,
                        data: {action: "crust_popup_modal", id: id, animation: animation, prim_temp: prim_temp, style: style, modal_text: modal_text,content_type: content_type, editor: editor},
                        success: function(data) {

                            setTimeout(function (){
                                overlay.removeClass('crust-mod-loading');
                                close.addClass( 'crust-show-close' );
                                mod.addClass('crust-show-modal');

                            }, 300);

                            if( content_type === 'template' && prim_temp !== null ){
                                wrap.html(data);
                            } else {
                                wrap.html(modal_text);
                            }

                            close.add( overlay ).on( 'click', function( ev ) {
                                ev.preventDefault();
                                ev.stopPropagation();
                                close.removeClass( 'crust-show-close' );
                                mod.removeClass( 'crust-show-modal' );
                                setTimeout(function () {
                                    mod.removeClass(animation);
                                    overlay.removeClass( 'crust-show-wrap' );
                                    wrap.removeAttr('style');
                                    wrap.html('');
                                    wrap.removeClass(id);
                                }, 200);

                            });

                        }
                    });

                } );

            });
        },

        crust_login_popup(){

            if( $('.crust-element .crust-login-btn').length ){
                $('.crust-element .crust-login-btn').each(function () {
                    let $this = $(this);

                    $this.on( 'click', function(e) {
                        e.preventDefault();

                        let pop = $this.next('.crust-login-popup');
                        $('.crust-login-popup').removeClass('crust-open-login');
                        pop.toggleClass('crust-open-login');

                        pop.find('a.crust-close-login').on( 'click', function(e) {
                            e.preventDefault();
                            pop.removeClass('crust-open-login');
                        });

                    });
                });
            }

        },

        crust_sticky_submenu(){

            $('.crust-sticky-menu').each(function (){
                let nav = $(this),
                    sticky = nav.offset().top,
                    head = 0,
                    before = 0,
                    header = $('header.crust-site-header[data-sticky]'),
                    fix = $('.crust-fixed-head'),
                    fixed = ( fix.length ) ? parseInt(fix.outerHeight()) : 0,
                    adm = ( $('#wpadminbar').length ) ? parseInt($('#wpadminbar').outerHeight()) : 0;

                if( header.length ){
                    if( $('header.crust-site-header .crust-before-header').length ){
                        before = parseInt($('header.crust-site-header .crust-before-header').outerHeight());
                    }
                }

                $(window).on('scroll', function (){
                    let hdheight = header.outerHeight();
                    if( !header.hasClass('crust-sticky-head') ){
                        hdheight = 0;
                    }
                    head = parseInt(hdheight) + fixed + adm - before;
                    crustCore.init.crust_sticky_submenu_scroll(sticky, nav, head);
                });
            });
        },

        crust_sticky_submenu_scroll(sticky, nav, head){

            if( head > 0 ){
                sticky = sticky - head;
            }

            if ($(window).scrollTop() >= sticky) {
                nav.parent().addClass("crust-sticky-active");
                nav.parent().css('top', head + 'px');
            } else {
                nav.parent().removeClass("crust-sticky-active");
                nav.parent().removeAttr('style');
            }

        },

        crust_fixed_footer(){
            if( $('.crust-fixed-wrap').length ){
                var fix = $('.crust-fixed-footer').outerHeight();
                $('.crust-fixed-wrap').css('margin-bottom', fix + 'px');
            }

        },

        crust_mouse_parallax(){
            let w = $(window).width(),
                h = $(window).height(),
                offsetX = 0.5 - e.pageX / w,
                offsetY = 0.5 - e.pageY / h;

            $(".crust-mouse-parallax").each(function(i, el) {
                let offset = parseInt($(el).data('offset')),
                    translate = "translate3d(" + Math.round(offsetX * offset) + "px," + Math.round(offsetY * offset) + "px, 0px)";

                $(el).css({
                    '-webkit-transform': translate,
                    'transform': translate,
                    'moz-transform': translate
                });
            });
        },

        crust_cursor(){
            const cursor = document.querySelector('#cursor');
            if( cursor ){
                const cursorCircle = cursor.querySelector('.cursor__circle');
                const cursorText = cursor.querySelector('.cursor__text');
                const mouse = { x: -100, y: -100 };
                const pos = { x: 0, y: 0 };
                const speed = 0.1;

                const updateCoordinates = e => {
                    mouse.x = e.clientX;
                    mouse.y = e.clientY;
                }

                window.addEventListener('mousemove', updateCoordinates);
                function getAngle(diffX, diffY) {
                    return Math.atan2(diffY, diffX) * 180 / Math.PI;
                }

                function getSqueeze(diffX, diffY) {
                    const distance = Math.sqrt(
                        Math.pow(diffX, 2) + Math.pow(diffY, 2)
                    );
                    const maxSqueeze = 0.15;
                    const accelerator = 1500;
                    return Math.min(distance / accelerator, maxSqueeze);
                }

                const updateCursor = () => {
                    const diffX = Math.round(mouse.x - pos.x);
                    const diffY = Math.round(mouse.y - pos.y);

                    pos.x += diffX * speed;
                    pos.y += diffY * speed;

                    const angle = getAngle(diffX, diffY);
                    const squeeze = getSqueeze(diffX, diffY);

                    const scale = 'scale(' + (1 + squeeze) + ', ' + (1 - squeeze) +')';
                    const rotate = 'rotate(' + angle +'deg)';
                    const translate = 'translate3d(' + pos.x + 'px ,' + pos.y + 'px, 0)';

                    cursor.style.transform = translate;
                    cursorCircle.style.transform = rotate + scale;
                };

                function loop() {
                    updateCursor();
                    requestAnimationFrame(loop);
                }

                requestAnimationFrame(loop);
                const cursorModifiers = document.querySelectorAll('[data-cursor-class]');
                cursorModifiers.forEach(curosrModifier => {
                    curosrModifier.addEventListener('mouseenter', function() {
                        const className = this.getAttribute('data-cursor-class');
                        const text = this.getAttribute('data-cursor-text');
                        cursor.classList.add(className);
                        cursorText.innerHTML = text;
                    });
                    curosrModifier.addEventListener('mouseleave', function() {
                        const className = this.getAttribute('data-cursor-class');
                        cursor.classList.remove(className);
                        cursorText.innerHTML = '';
                    });
                });
            }
        }

    };

    /* ================ Window.Load Functions. ================ */
    $(window).on('load', function (){
        crustCore.init.crust_globals();
        crustCore.init.crust_dark_mode();
        crustCore.init.crust_social_share();
        crustCore.init.crust_core_tweets();
        crustCore.init.crust_core_flickr();
        crustCore.init.crust_masonry_layout();
        crustCore.init.crust_loadmore();
        crustCore.init.crust_particles();
        crustCore.init.crust_popup();
        crustCore.init.crust_login_popup();
        crustCore.init.crust_sticky_submenu();
        crustCore.init.crust_fixed_footer();
        crustCore.init.crust_cursor();
        crustCore.init.crust_scroll_to_id();
    });

    if( $(".crust-mouse-parallax").length ){
        $(window).on('mousemove', function(e) {
            crustCore.init.crust_mouse_parallax();
        });
    }


})(jQuery);