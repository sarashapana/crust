var crustIcons = crustIcons || {};

(function ($, wp) {

    "use strict";

    crustIcons.init = {

        icons_init: function () {

            if ($('.crust-icon-input').length) {

                $('.crust-icon-input').each(function () {
                    if ($(this).val() != '') {
                        $(this).next('.icon-remove').fadeIn(0).css('display', 'inline-block');
                        $(this).parent().find('.crust-current-icon').addClass('active-icon');
                        var ic = $(this).val(),
                            ico = $(this).parent().find('.crust-current-icon');
                        $(this).parent().find('.crust-current-icon').addClass(ic);
                        $(this).parent().find('.crust-choose-icon').text('Change Icon');
                    } else {
                        $(this).next('.icon-remove').fadeOut(0);
                        $(this).parent().find('.crust-current-icon').removeClass('active-icon');
                    }
                    crustIcons.init.click_icons();
                });
                if( ! $('.crust-icons-set > div').hasClass('shown-set') && ! $('.crust-select-icons li').hasClass('active') ){
                    $('.crust-icons-set > div').eq(0).addClass('shown-set');
                    $('.crust-select-icons li').eq(0).addClass('active');
                }

            }

        },

        load_icons: function () {

            if ($('.crust-choose-icon').length) {

                var iconsurl = crust_localize_icons.CRUST_CORE_URI + 'assets/icons/json/',
                    icsArr = [ 'fa-regular', 'fa-solid', 'fa-brands', 'duotone', 'uicons' ];

                $('.crust-choose-icon').on('click', function (e) {

                    e.preventDefault();
                    var th = $(this);
                    $.each(icsArr, function (index, value) {

                        var iconlink = iconsurl + value + '.json';
                        var $wrap    = $('.crust-icons-item.' + value);

                        $.ajax({
                            url: iconlink,
                            contentType: false,
                            dataType: 'json',
                            cache: false,
                            success: function (data) {
                                var output = '';
                                if( $wrap.html() == '' ){
                                    $.each(data.items, function (key, val) {
                                        output += '<a href="#" ><i class="' + val + '"></i></a>';
                                    });
                                    $wrap.html( output );
                                }

                                crustIcons.init.click_icons();
                                $('.crust-icons-popup').fadeIn(300);
                                $('.crust-choose-icon').removeClass('clicked');
                                th.addClass('clicked');

                                $('.crust-icons-set a').each(function () {
                                    $(this).on('click', function (e) {
                                        e.preventDefault();
                                        var icon = $(this).find('> i').attr('class');

                                        $('.crust-choose-icon.clicked').next('.crust-icon-input').val(icon).trigger('change');
                                        $('.crust-choose-icon.clicked').prev('.crust-current-icon').removeAttr('class').addClass('active-icon crust-current-icon ' + icon);
                                        $('.crust-icons-popup').fadeOut(200);
                                        th.parent().find('.icon-remove').fadeIn().css('display', 'inline-block');
                                        th.text('Change Icon');
                                        th.removeClass('clicked');
                                    });
                                });

                            }
                        });
                    });

                });

                var iconSearch = $('.iconSearch'),
                    iconLoad = $('.crust-icons-set > div');
                iconSearch.on('keyup change input', function () {
                    var $this = $(this),
                        val = $this.val(),
                        list_icon = iconLoad.find('a');
                    list_icon.each(function () {
                        var $ico = $(this).find('> i').attr('class');
                        if ($ico.search(new RegExp(val, "i")) < 0) {
                            $(this).hide();
                        } else {
                            $(this).show();
                        }
                    });
                });

            }

        },

        click_icons: function () {

            $('.crust-icons-popup .close-box').on('click', function (e) {
                e.preventDefault();
                $('.crust-choose-icon').removeClass('clicked');
                $('.crust-icons-popup').fadeOut(400);
                return false;
            });

            $('.icon-remove').each(function () {
                $(this).on('click', function (e) {
                    e.preventDefault();
                    $(this).parent().find('.crust-icon-input').val('').trigger('change');
                    $(this).parent().find('.crust-current-icon').removeAttr('class').addClass('crust-current-icon');
                    $(this).fadeOut(200);
                    $(this).parent().find('.crust-current-icon').removeClass('active-icon');
                    $(this).parent().find('.crust-choose-icon').html('<i class="fa fa-plus"></i> Add Icon');
                });
            });

            $('.crust-select-icons a').each(function () {
                $(this).on('click',function () {
                    var thisVal = $(this).attr('class');
                    $('.crust-select-icons li').removeClass('active');
                    $(this).parent().addClass('active');
                    $('.crust-icons-set > div').removeClass('shown-set');
                    $('.crust-icons-set').find('> div.' + thisVal).addClass('shown-set');
                });
            });
        },

    };

})(jQuery, wp);
