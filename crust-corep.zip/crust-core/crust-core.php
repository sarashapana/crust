<?php
/**
 * Plugin Name: Crust Core
 * Plugin URI: https://winsomethemes.com
 * Description: Crust core plugin for crust theme.
 * Version: 1.1.3
 * Author: winsomethemes
 * Author URI: https://winsomethemes.com
 * Text Domain: crust-core
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Crust_Core
{

	private static $instance = null;

	public function __construct()
	{

		$this->define_constants();

		add_action( 'crust_init',            [ $this, 'init' ], 5 );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );

	}

	public static function get_instance()
	{
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function define_constants()
	{
		defined( 'CRUST_CORE_DIR' ) or define( 'CRUST_CORE_DIR', plugin_dir_path(__FILE__) );
		defined( 'CRUST_CORE_URI' ) or define( 'CRUST_CORE_URI', plugin_dir_url(__FILE__) );
		defined( 'CRUST_API_URL' ) or define( 'CRUST_API_URL', 'https://dev.winsomethemes.com/crust' );
		defined( 'CRUST_DIR' ) or define( 'CRUST_DIR', get_template_directory() );
		defined( 'CRUST_URI' ) or define( 'CRUST_URI', get_template_directory_uri() );
		defined( 'CRUST_PORTFOLIO' ) or define( 'CRUST_PORTFOLIO', 'portfolio' );
		defined( 'CRUST_TAB' ) or define( 'CRUST_TAB', '992px' );
		defined( 'CRUST_MOB' ) or define( 'CRUST_MOB', '576px' );
	}

	public static function load_files( $files = [] )
	{
		foreach ( $files as $file ) {
			$path = CRUST_CORE_DIR . 'includes/' . $file . '.php';
			if ( file_exists( $path ) ) {
				include_once( $path );
			}
		}
	}

	public function init()
	{

		self::load_files([
			'functions',
			'front/modules',
			'front/front',
			'front/breadcrumbs',
		]);

		// Plugin localization...
		$domain  = 'crust-core';
		$mo_file = CRUST_CORE_DIR . '/languages/' . get_locale() . '.mo';
		load_textdomain( $domain, $mo_file );
		load_plugin_textdomain( $domain, false, CRUST_CORE_DIR . '/languages/' );

		if (!function_exists('is_plugin_active')) {
			include_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}

		if ( function_exists( 'crust_core_get_option') ){

			// Customizer
			if ( crust_core_get_option('crust_customizer_option') == 'yes' ) {
				self::load_files( [ 'customizer/init' ] );
			}

			// wpbakery...
			if( is_plugin_active( 'js_composer/js_composer.php' ) && crust_core_get_option('crust_wpbackery_option' ) === 'yes' ) {
				self::load_files( ['wpbakery/wpb'] );
			}

			// Elementor...
			if ( is_plugin_active( 'elementor/elementor.php' ) && crust_core_get_option('crust_elementor_option' ) === 'yes' ) {
				self::load_files( ['elementor/autoload'] );
				$GLOBALS['crust_core_config'] = require_once CRUST_CORE_DIR . 'includes/elementor/config.php';
				\Crust_Core\Classes\Elementor::instance();
			}

			// Portfolio Custom Post Type...
			if ( crust_core_get_option('crust_portfolio_option') == 'yes' ) {
				self::load_files( ['portfolio/init'] );
			}

			// Menus...
			if ( crust_core_get_option('crust_menus_option') == 'yes' ) {
				self::load_files( ['menu/menu'] );
			}

			// Widgets...
			if ( crust_core_get_option('crust_widgets_option') == 'yes' ) {
				self::load_files( ['widgets/widgets-area'] );
			}

			// Custom Meta Boxes...
			if ( crust_core_get_option('crust_page_settings_option') == 'yes' && crust_edit_page() ) {
				self::load_files( ['meta/init'] );
			}

		}

		if( $GLOBALS['pagenow'] === 'wp-login.php' && crust_mod('custom_login') == '1' ){
			add_action( 'login_enqueue_scripts', [ $this, 'crust_login_styles' ] );
			add_filter( 'login_headerurl', [ $this, 'crust_login_logo_url' ] );
		}

		// Control panel...
		if ( class_exists('Crust_Admin_Panel') && is_admin() ) {
			self::load_files( ['admin/init'] );
		}

		if( is_plugin_active( 'bbpress/bbpress.php' ) ){
			self::load_files( [ 'compatibility/bbpress' ] );
		}

		if( class_exists('Tribe__Events__Main') ){
			self::load_files( [ 'compatibility/events' ] );
		}

	}

	public function admin_enqueue_scripts()
	{
		wp_enqueue_media();
		wp_enqueue_style( 'crust-core',      CRUST_CORE_URI . 'assets/admin/css/style.css', '', null );
		wp_enqueue_script( 'crust-core',     CRUST_CORE_URI . 'assets/admin/js/script.js', [ 'jquery' ], null, true );
	}

	public function crust_login_styles()
	{
		wp_enqueue_style( 'crust-login', CRUST_CORE_URI . 'assets/admin/css/login.css', '', null );
		$CSS    = '';
		$logo   = wp_get_attachment_url( crust_mod("login_logo") );
		$width  = crust_mod("login_logo_width");
		$height = crust_mod("login_logo_height");
		$bg     = crust_mod("login_bg_color");
		$bg1    = crust_mod("login_bg_color_first");
		$bg2    = crust_mod("login_bg_color_second");

		$CSS .= '<style>';
		$CSS .= 'body.login { ';
		$CSS .= ( $bg != '' ) ? 'background-color: ' . $bg . ' !important;' : '';
		$CSS .= ( $bg1 != '' && $bg2 != '' ) ? 'background: -webkit-linear-gradient(-135deg,'.$bg1.','.$bg2.');background: linear-gradient(-135deg,'.$bg1.','.$bg2.');' : '';
		$CSS .= '}';
		$CSS .= 'h1 a { ';
		$CSS .= ( $logo != '' ) ? 'background-image: url(' . $logo . ') !important;' : '';
		$CSS .= ( $width != '' ) ? 'width:' . $width . 'px !important;' : '';
		$CSS .= ( $height != '' ) ? 'height: ' . $height . 'px !important;' : '';
		$CSS .= ( $width != '' || $height != '' ) ? 'background-size: 100% !important;' : '';
		$CSS .= '}';
		$CSS .= '</style>';

		echo $CSS;

	}

	public function crust_login_logo_url() {
		return home_url();
	}

	public function admin_notice_elementor()
	{
		if ( isset( $_GET[ 'activate' ] ) ) {
			unset( $_GET[ 'activate' ] );
		}

		$message = sprintf(
			esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'crust-core'),
			'<strong>' . esc_html__('Crust Core', 'crust-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'crust-core') . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

}

function crust_core() {
	return Crust_Core::get_instance();
}

crust_core();
