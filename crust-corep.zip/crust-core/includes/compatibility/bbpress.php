<?php
if ( ! defined( 'ABSPATH' ) ) exit( 'Access Denied.' );


if( crust_mod( 'show_bbp_message', '1' ) == '1' ){
	add_action('bbp_template_before_forums_index', 'crust_bbp_message');
}
function crust_bbp_message(){
	$html = '<div class="crust-welcome-bbp">';
		$html .= '<i class="fad fa-megaphone hint main-color"></i>';
        $html .= '<div class="crust-bbp-message">'. wp_kses(crust_mod('welcome_bb'),crust_allowed_tags())  .'</div>';
	$html .= '</div>';
	echo $html;
}
if( crust_mod( 'show_bbp_stats', '1' ) == '1' ){
	add_action( 'bbp_template_after_forums_index', 'crust_bbp_stats' );
}
function crust_bbp_stats(){
	$stats = bbp_get_statistics();

	$html = '<ul class="bbp-forums forum-stats">';
	    $html .= '<li class="stats-header"><h6>'. esc_html__("What's Going On?", 'crust-core') .'</h6></li>';
		$html .= '<li class="stats-inner">';
			do_action( 'bbp_before_statistics' );

			$html .= esc_html__("Our users have posted a total of: ", 'crust-core') .'<br>';
				$html .= '<strong>'. esc_html( $stats['topic_count'] ) .' </strong>'. esc_html__( 'Topics', 'crust-core' ) . '<br>' . esc_html__("In", 'crust-core'). ' <strong>'. esc_html( $stats['forum_count'] ) .' </strong>';
				$html .= esc_html__( 'Forums', 'crust-core' ) . '<br>';


			$html .= esc_html__("We have", 'crust-core') .' <strong>'. esc_html( $stats['user_count'] ).' </strong>'. esc_html__( 'Registered Users', 'crust-core' ) . '<br>';

			$html .= esc_html__("Number of total replies on all forums is", 'crust-core').' <strong>'. esc_html( $stats['reply_count'] ) .' </strong>'. esc_html__( 'Replies', 'crust-core' );

			$html .= ( isset($stats["topic_tag_count"]) ) ? esc_html__( "Topic Tags:" , "crust-core" ) .'<strong>'.esc_html( $stats["topic_tag_count"] ) .'</strong>' : '';

			if ( !empty( $stats['empty_topic_tag_count'] ) ) {
				$html .= esc_html__( 'Empty Topic Tags', 'crust-core' ) .' : <strong>'. esc_html( $stats['empty_topic_tag_count'] ) .'</strong>';
			}

			if ( !empty( $stats['topic_count_hidden'] ) ) {

				$html .= '<dt>'. esc_html__( 'Hidden Topics', 'crust-core' ).'</dt>';
				$html .= '<dd>';
					$html .= '<strong>';
						$html .= '<abbr title="'. esc_attr( $stats['hidden_topic_title'] ) .'">'. esc_html( $stats['topic_count_hidden'] ) .'</abbr>';
					$html .= '</strong>';
				$html .= '</dd>';

			}

			if ( !empty( $stats['reply_count_hidden'] ) ) {

				$html .= '<dt>'. esc_html__( 'Hidden Replies', 'crust-core' ) .'</dt>';
				$html .= '<dd>';
					$html .= '<strong>';
						$html .= '<abbr title="'. esc_attr( $stats['hidden_reply_title'] ) .'">'. esc_html( $stats['reply_count_hidden'] ) .'</abbr>';
					$html .= '</strong>';
				$html .= '</dd>';

			}
		$html .= '</li>';
		do_action( 'bbp_after_statistics' );

	$html .= '</ul>';

	echo $html;

}

function crust_bbp_no_breadcrumb ($param) {
	return true;
}
add_filter ('bbp_no_breadcrumb', 'crust_bbp_no_breadcrumb');
