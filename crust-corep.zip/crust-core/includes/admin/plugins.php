<?php

if ( ! defined('ABSPATH')) {
    exit('Access Denied.');
}

class Crust_Plugins
{

    public function get_plugins()
    {
        $plugins = [

            // Crust Core
            [
                'name'    => 'Crust Core',
                'slug'    => 'crust-core',
                'source'  => 'http://wp.it-rays.net/plugins/crust_core.zip',
                'desc'    => esc_html__('Adding Core functionality for Crust theme such as Customizer options, Elementor support, Custom Menus options, Widgets, etc.', 'crust-core'),
                'icon'    => CRUST_URI . '/lib/admin/assets/img/plugins/crust.png'
            ],

            // Elementor
            [
                'name'    => 'Elementor',
                'slug'    => 'elementor',
                'desc'    => esc_html__('The most advanced frontend drag & drop page builder. Create high-end, pixel perfect websites at record speeds.', 'crust-core'),
                'icon'    => CRUST_URI . '/lib/admin/assets/img/plugins/elementor.png'
            ],

            // Visual Composer : Page Builder
            [
                'name'    => 'WPBakery Page Builder',
                'slug'    => 'js_composer',
                'source'  => 'http://wp.it-rays.net/plugins/js_composer.zip',
                'desc'    => esc_html__('Drag and drop page builder for WordPress. Take full control over your WordPress site, build any layout you can imagine.', 'crust-core'),
                'icon'    => CRUST_URI . '/lib/admin/assets/img/plugins/js_composer.png'
            ],

            // Slider Revolution
            [
                'name'    => 'Slider Revolution',
                'slug'    => 'revslider',
                'source'  => 'http://wp.it-rays.net/plugins/revslider.zip',
                'desc'    => esc_html__('Create outstanding, professional content modules with no coding experience required.', 'crust-core'),
                'icon'    => CRUST_URI . '/lib/admin/assets/img/plugins/revslider.png'
            ],

            // WooCommerce
            [
                'name'    => 'WooCommerce',
                'slug'    => 'woocommerce',
                'desc'    => esc_html__('The most popular eCommerce platform on the web (stats from Builtwith), so you can rest assured youre in good company', 'crust-core'),
                'icon'    => CRUST_URI . '/lib/admin/assets/img/plugins/woo.png'
            ],

        ];

        return $plugins;
    }

}