<?php
if ( ! defined( 'ABSPATH' ) ) exit( 'Access Denied.' );

class Crust_Demo_Importer {

	public static $templates = [];

	public function __construct()
	{

		$this->include_files();
		$this->get_templates();
		$this->import_templates();

	}

	public function check_import()
	{
	    require_once CRUST_CORE_DIR . 'includes/admin/importer/wordpress-importer/wordpress-importer.php';
	}

	public function include_files()
	{

		Crust_Core::load_files([
			'admin/importer/includes/customizer',
			'admin/importer/includes/widgets'
		]);

	}

	public function get_templates()
	{

		//$response = wp_remote_get( CRUST_API_URL . '/api.json' );
		$response = wp_remote_get( CRUST_CORE_URI . '/includes/admin/importer/api.json' );
		if( is_wp_error( $response ) ) {

		}

		$body     = wp_remote_retrieve_body($response);
		$result   = json_decode( $body, true );

		self::$templates = ( $result ) ? $result[ 'templates' ] : '';
		if( self::$templates && is_array( self::$templates ) ){
			return self::$templates;
		} else {
			return [];
		}

	}

	public function import_templates()
	{
		if( self::$templates ){
			foreach ( self::$templates as $template ) {
				add_action( 'wp_ajax_crust_import_demo_' . $template[ 'name' ], [ $this, 'crust_import_demo_' . $template[ 'name' ] ] );
				add_action( 'wp_ajax_crust_import_demo_' . $template[ 'name' ] . '_elementor', [ $this, 'crust_import_demo_' . $template[ 'name' ] . '_elementor' ] );
			}
		}

	}

	public function add_templates_markup()
	{

		foreach ( self::$templates as $template ) {
			$slug = $template['slug'];

			echo '<div class="crust-import-inner-box">';
				echo '<span class="crust-demo-text">'. $template['title'] .'</span>';
				echo '<div class="crust-demo-btns">';
					if ( did_action('elementor/loaded') ) {
						$elementor_btn = ( defined( 'WPB_VC_VERSION' )) ? esc_html__('Elementor', 'crust') : esc_html__('Import', 'crust');
						echo '<a class="crust-button sm-btn crust-import-btn" href="#" data-demo="'.esc_attr( $template['name'] ).'_elementor">'.$elementor_btn.'</a>';
					}

					if( defined( 'WPB_VC_VERSION' )){
						$wpb_btn = ( did_action('elementor/loaded')) ? esc_html__('WPBackery', 'crust') : esc_html__('Import', 'crust');
						echo '<a class="crust-button sm-btn crust-import-btn" href="#" data-demo="'.esc_attr( $template['name'] ).'">'.$wpb_btn.'</a>';
					}
				echo '</div>';
				echo '<img src="'.CRUST_API_URL.'/demos/images/'.$slug.'.jpg" />';
				$clas = 'crust-import-overlay';
				$clas .= ( is_plugin_active( 'js_composer/js_composer.php' ) && is_plugin_active( 'elementor/elementor.php' ) ) ? ' both-builders' : '';
				echo '<div class="'.esc_attr($clas).'">';
					echo '<a class="crust-button sm-btn crust-preview-demo" href="https://crust.it-rays.net/'.$slug.'" target="_blank">'.esc_html__('Preview', 'crust').'</a>';
					echo '<div class="crust-import-attachments"><input type="checkbox" name="crust_import_data" class="crust_import_data" />  '.esc_html__('Attachments!', 'crust').'</div>';
				echo '</div>';
			echo '</div>';

		}

	}

	public function crust_import_conent( $key )
	{

		ob_start();

		wp_delete_nav_menu( 'primary' );
		wp_delete_nav_menu( 'Footer 1' );
		wp_delete_nav_menu( 'Footer 2' );
		wp_delete_nav_menu( 'Footer 3' );

        $this->check_import();

		$import_filepath  = CRUST_CORE_DIR . '/includes/admin/importer/demos/' . $key . '/content.xml';
		//$import_filepath  = CRUST_API_URL . '/demos/content/' . $key . '/content.xml';
		$menu             = CRUST_CORE_DIR . 'includes/admin/importer/misc/crust-menu.xml';
		$attachment       = !empty( $_POST['attachment'] );
		$crust_wp_import  = new WP_Import();

		$crust_wp_import->fetch_attachments = $attachment;
		$crust_wp_import->import( $import_filepath );
		$crust_wp_import->import( $menu );

		$this->crust_main_options( $key );

		ob_get_clean();

	}

	public function crust_main_options( $key )
	{

		/* setting menu */
		$menu       = get_term_by( 'name', esc_html__( 'Primary Menu', 'crust-core' ), 'nav_menu' );
		$locations  = [
			'primary' => $menu->term_id,
		];
		set_theme_mod( 'nav_menu_locations', $locations );

		/* setting home-page */
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', crust_get_id_by_slug( 'home-'. $key ) );

	}

	public function crust_import_customizer( $key )
	{

		global $wp_customize;
		$template = get_template();

		$opts_file = CRUST_API_URL . '/demos/content/' . $key . '/options.json';
		$raw       = file_get_contents( $opts_file );
		$data      = @unserialize( $raw );

		if ( 'array' != gettype( $data ) ) {
			return;
		}

		if ( ! isset( $data['template'] ) || ! isset( $data['mods'] ) ) {
			return;
		}

		if ( $data['template'] != $template ) {
			return;
		}

		$data['mods'] = self::_import_images( $data['mods'] );

		// Import custom options.
		if ( isset( $data['options'] ) ) {

			if ( ! class_exists( '\WP_Customize_Setting' ) ) {
				require_once ABSPATH . 'wp-includes/class-wp-customize-setting.php';
			}

			remove_theme_mods();

			foreach ( $data['options'] as $option_key => $option_value ) {

				$option = new Crust_Import_Option( $wp_customize, $option_key, array(
					'default'		=> '',
					'type'			=> 'option',
					'capability'	=> 'edit_theme_options'
				) );

				$option->import( $option_value );
			}
		}

		// Call the customize_save action.
		do_action( 'customize_save', $wp_customize );

		// Loop through the mods.
		foreach ( $data['mods'] as $key => $val ) {

			// Call the customize_save_ dynamic action.
			do_action( 'customize_save_' . $key, $wp_customize );

			// Save the mod.
			set_theme_mod( $key, $val );
		}

	}

	static private function _import_images( $mods )
	{
		foreach ( $mods as $key => $val ) {

			if ( self::_is_image_url( $val ) ) {

				$data = self::_sideload_image( $val );

				if ( ! is_wp_error( $data ) ) {

					$mods[ $key ] = $data->url;

					// Handle header image controls.
					if ( isset( $mods[ $key . '_data' ] ) ) {
						$mods[ $key . '_data' ] = $data;
						update_post_meta( $data->attachment_id, '_wp_attachment_is_custom_header', get_stylesheet() );
					}
				}
			}
		}

		return $mods;
	}

	static private function _sideload_image( $file )
	{
		$data = new stdClass();

		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
		}
		if ( ! empty( $file ) ) {

			// Set variables for storage, fix file filename for query strings.
			preg_match( '/[^\?]+\.(jpe?g|jpe|gif|png)\b/i', $file, $matches );
			$file_array = array();
			$file_array['name'] = basename( $matches[0] );

			// Download file to temp location.
			$file_array['tmp_name'] = download_url( $file );

			// If error storing temporarily, return the error.
			if ( is_wp_error( $file_array['tmp_name'] ) ) {
				return $file_array['tmp_name'];
			}

			// Do the validation and storage stuff.
			$id = media_handle_sideload( $file_array, 0 );

			// If error storing permanently, unlink.
			if ( is_wp_error( $id ) ) {
				@unlink( $file_array['tmp_name'] );
				return $id;
			}

			// Build the object to return.
			$meta					= wp_get_attachment_metadata( $id );
			$data->attachment_id	= $id;
			$data->url				= wp_get_attachment_url( $id );
			$data->thumbnail_url	= wp_get_attachment_thumb_url( $id );
			$data->height			= $meta['height'];
			$data->width			= $meta['width'];
		}

		return $data;
	}

	static private function _is_image_url( $string = '' )
	{
		if ( is_string( $string ) ) {

			if ( preg_match( '/\.(jpg|jpeg|png|gif)/i', $string ) ) {
				return true;
			}
		}

		return false;
	}

	public function crust_import_sliders( $key )
	{

		if (class_exists('RevSlider')) {

			$rev_files = [ CRUST_CORE_DIR . 'includes/admin/importer/demos/' . $key . '/' . $key . '-slider' . '.zip' ];

			foreach ( $rev_files as $rev_file ) {
				$_FILES['import_file']['tmp_name'] = $rev_file;
				$slider = new RevSlider();
				$slider->importSliderFromPost(true, 'none');
			}

		}

	}

	public function crust_import_widgets( $key )
	{

		// Unregister All Widgets to prevent duplications...
		update_option( 'sidebars_widgets', [] );

		// Add our own Sidebars...
		$sidebars = [
			'sidebar-1'      => esc_html__('Primary SideBar', 'crust-core'),
			'sidebar-2'      => esc_html__('Secondary SideBar', 'crust-core'),
			'footer-widgets' => esc_html__('Footer Widgets', 'crust-core'),
			'sub-footer'     => esc_html__('Sub Footer', 'crust-core'),
		];

		foreach ($sidebars as $sidebar => $value) {
			register_sidebar(
				[
					'name'          => $value,
					'id'            => sanitize_title($sidebar),
					'before_widget' => '<div class="crust-widget %2$s">',
					'after_widget'  => '</div>',
				]
			);
		}

		// Add data to widgets...
		$widgets_file   = CRUST_CORE_URI .'includes/admin/importer/demos/' . $key . '/widgets.json';
		$widgets_json   = wp_remote_get( $widgets_file );
		$widget_data    = $widgets_json[ 'body' ];
		crust_import_widget_data( $widget_data );
		die();
	}

	public function crust_import_demo_original()
	{

		// Import theme options...
		$this->crust_import_customizer('original');

		//Import Content...
		$this->crust_import_conent('original');

		//Add sidebar widget areas
		$this->crust_import_widgets('original');

	}

	public function crust_import_demo_pages()
	{

		//Import Content...
		$this->crust_import_conent('pages');

	}

	public function crust_import_demo_modern()
	{

		// Import theme options...
		$this->crust_import_customizer('modern');

		//Import Content...
		$this->crust_import_conent('modern');

		//Add sidebar widget areas
		$this->crust_import_widgets('modern');

	}

    public function crust_import_demo_business()
    {

        // Import theme options...
        $this->crust_import_customizer('business');

        //Import Content...
        $this->crust_import_conent('business');

    }

	public function crust_import_demo_corporate()
	{

		// Import theme options...
		$this->crust_import_customizer('corporate');

		//Import Content...
		$this->crust_import_conent('corporate');

	}

	public function crust_import_demo_creative()
	{

        // Import theme options...
        $this->crust_import_customizer('creative');

		//Import Content...
		$this->crust_import_conent('creative');

	}

	public function crust_import_demo_agency()
	{

        // Import theme options...
        $this->crust_import_customizer('agency');

		//Import Content...
		$this->crust_import_conent('agency');

	}

	public function crust_import_demo_construction()
	{

		// Import theme options...
		$this->crust_import_customizer('construction');

		//Import Content...
		$this->crust_import_conent('construction');

	}

	public function crust_import_demo_restaurant()
	{

		// Import theme options...
		$this->crust_import_customizer('restaurant');

		//Import Content...
		$this->crust_import_conent('restaurant');

	}

	public function crust_import_demo_seo()
	{

		// Import theme options...
		$this->crust_import_customizer('seo');

		//Import Content...
		$this->crust_import_conent('seo');

	}

	public function crust_import_demo_influencer()
	{

		// Import theme options...
		$this->crust_import_customizer('influencer');

		//Import Content...
		$this->crust_import_conent('influencer');

	}

	public function crust_import_demo_marketing()
	{

		// Import theme options...
		$this->crust_import_customizer('marketing');

		//Import Content...
		$this->crust_import_conent('marketing');

	}

	public function crust_import_demo_photography()
	{

		// Import theme options...
		$this->crust_import_customizer('photography');

		//Import Content...
		$this->crust_import_conent('photography');

	}

	public function crust_import_demo_beauty()
	{

		// Import theme options...
		$this->crust_import_customizer('beauty');

		//Import Content...
		$this->crust_import_conent('beauty');

	}

	public function crust_import_demo_education()
	{

		// Import theme options...
		$this->crust_import_customizer('education');

		//Import Content...
		$this->crust_import_conent('education');

	}

	public function crust_import_demo_covid_19()
	{

		// Import theme options...
		$this->crust_import_customizer('covid-19');

		//Import Content...
		$this->crust_import_conent('covid-19');

	}

	public function crust_import_demo_shoe_store()
	{

		// Import theme options...
		$this->crust_import_customizer('shoe-store');

		//Import Content...
		$this->crust_import_conent('shoe-store');

	}

	public function crust_import_demo_gym()
	{

		// Import theme options...
		$this->crust_import_customizer('gym');

		//Import Content...
		$this->crust_import_conent('gym');

	}

	public function crust_import_demo_cargo()
	{

		// Import theme options...
		$this->crust_import_customizer('cargo');

		$this->crust_import_sliders('cargo');

		//Import Content...
		$this->crust_import_conent('cargo');

	}

	public function crust_import_demo_car_rent()
	{

		// Import theme options...
		$this->crust_import_customizer('car-rent');

		//Import Content...
		$this->crust_import_conent('car-rent');

	}

	public function crust_import_demo_furniture()
	{

		// Import theme options...
		$this->crust_import_customizer('furniture');

		//Import Content...
		$this->crust_import_conent('furniture');

	}

	public function crust_import_demo_landing()
	{

		// Import theme options...
		$this->crust_import_customizer('landing');

		//Import Content...
		$this->crust_import_conent('landing');

	}

	public function crust_import_demo_hotel()
	{

		// Import theme options...
		$this->crust_import_customizer('hotel');

		//Import Content...
		$this->crust_import_conent('hotel');

	}

	public function crust_import_demo_medical()
	{

        // Import theme options...
        $this->crust_import_customizer('medical');

		//Import Content...
		$this->crust_import_conent('medical');

	}

	public function crust_import_demo_news_magazine()
	{

        // Import theme options...
        $this->crust_import_customizer('news-magazine');

		//Import Content...
		$this->crust_import_conent('news-magazine');

		//Add sidebar widget areas
		$this->crust_import_widgets('news-magazine');

	}

	// Elementor Functions...
	public function crust_import_demo_original_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('original-elementor');

		//Import Content...
		$this->crust_import_conent('original-elementor');

		//Add sidebar widget areas
		$this->crust_import_widgets('original-elementor');

	}

	public function crust_import_demo_modern_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('modern-elementor');

		//Import Content...
		$this->crust_import_conent('modern-elementor');

		//Add sidebar widget areas
		$this->crust_import_widgets('modern-elementor');

	}

	public function crust_import_demo_business_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('business-elementor');

		//Import Content...
		$this->crust_import_conent('business-elementor');

	}

	public function crust_import_demo_corporate_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('corporate-elementor');

		//Import Content...
		$this->crust_import_conent('corporate-elementor');

	}

	public function crust_import_demo_creative_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('creative-elementor');

		//Import Content...
		$this->crust_import_conent('creative-elementor');

	}

	public function crust_import_demo_agency_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('agency-elementor');

		//Import Content...
		$this->crust_import_conent('agency-elementor');

	}

	public function crust_import_demo_construction_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('construction-elementor');

		//Import Content...
		$this->crust_import_conent('construction-elementor');

	}

	public function crust_import_demo_restaurant_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('restaurant-elementor');

		//Import Content...
		$this->crust_import_conent('restaurant-elementor');

	}

	public function crust_import_demo_seo_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('seo-elementor');

		//Import Content...
		$this->crust_import_conent('seo-elementor');

	}

	public function crust_import_demo_influencer_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('influencer-elementor');

		//Import Content...
		$this->crust_import_conent('influencer-elementor');

	}

	public function crust_import_demo_marketing_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('marketing-elementor');

		//Import Content...
		$this->crust_import_conent('marketing-elementor');

	}

	public function crust_import_demo_photography_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('photography-elementor');

		//Import Content...
		$this->crust_import_conent('photography-elementor');

	}

	public function crust_import_demo_beauty_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('beauty-elementor');

		//Import Content...
		$this->crust_import_conent('beauty-elementor');

	}

	public function crust_import_demo_education_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('education-elementor');

		//Import Content...
		$this->crust_import_conent('education-elementor');

	}

	public function crust_import_demo_covid_19_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('covid-19-elementor');

		//Import Content...
		$this->crust_import_conent('covid-19-elementor');

	}

	public function crust_import_demo_shoe_store_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('shoe-store-elementor');

		//Import Content...
		$this->crust_import_conent('shoe-store-elementor');

	}

	public function crust_import_demo_gym_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('gym-elementor');

		//Import Content...
		$this->crust_import_conent('gym-elementor');

	}

	public function crust_import_demo_cargo_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('cargo-elementor');

		$this->crust_import_sliders('cargo');

		//Import Content...
		$this->crust_import_conent('cargo-elementor');

	}

	public function crust_import_demo_car_rent_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('car-rent-elementor');

		//Import Content...
		$this->crust_import_conent('car-rent-elementor');

	}

	public function crust_import_demo_furniture_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('furniture-elementor');

		//Import Content...
		$this->crust_import_conent('furniture-elementor');

	}

	public function crust_import_demo_landing_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('landing-elementor');

		//Import Content...
		$this->crust_import_conent('landing-elementor');

	}

	public function crust_import_demo_hotel_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('hotel-elementor');

		//Import Content...
		$this->crust_import_conent('hotel-elementor');

	}

	public function crust_import_demo_medical_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('medical-elementor');

		//Import Content...
		$this->crust_import_conent('medical-elementor');

	}

	public function crust_import_demo_news_magazine_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('news-magazine-elementor');

		//Import Content...
		$this->crust_import_conent('news-magazine-elementor');

		//Add sidebar widget areas
		$this->crust_import_widgets('news-magazine-elementor');

	}

	public function crust_import_demo_original_dark()
	{

		// Import theme options...
		$this->crust_import_customizer('original-dark');

		//Import Content...
		$this->crust_import_conent('original-dark');

		//Add sidebar widget areas
		$this->crust_import_widgets('original-dark');

	}

	public function crust_import_demo_original_dark_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('original-dark-elementor');

		//Import Content...
		$this->crust_import_conent('original-dark-elementor');

		//Add sidebar widget areas
		$this->crust_import_widgets('original-dark-elementor');

	}

	public function crust_import_demo_classic_business()
	{

		// Import theme options...
		$this->crust_import_customizer('classic-business');

		//Import Content...
		$this->crust_import_conent('classic-business');

	}

	public function crust_import_demo_classic_business_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('classic-business-elementor');

		//Import Content...
		$this->crust_import_conent('classic-business-elementor');

	}

	public function crust_import_demo_onepage()
	{

		// Import theme options...
		$this->crust_import_customizer('onepage');

		//Import Content...
		$this->crust_import_conent('onepage');

	}

	public function crust_import_demo_onepage_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('onepage-elementor');

		//Import Content...
		$this->crust_import_conent('onepage-elementor');

	}

	public function crust_import_demo_lawyer()
	{

		// Import theme options...
		$this->crust_import_customizer('lawyer');

		$this->crust_import_sliders('lawyer');

		//Import Content...
		$this->crust_import_conent('lawyer');

	}

	public function crust_import_demo_lawyer_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('lawyer-elementor');

		$this->crust_import_sliders('lawyer');

		//Import Content...
		$this->crust_import_conent('lawyer-elementor');

	}

	public function crust_import_demo_marketplace()
	{

		// Import theme options...
		$this->crust_import_customizer('marketplace');

		//Import Content...
		$this->crust_import_conent('marketplace');

	}

	public function crust_import_demo_marketplace_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('marketplace-elementor');

		//Import Content...
		$this->crust_import_conent('marketplace-elementor');

	}

	public function crust_import_demo_saas()
	{

		// Import theme options...
		$this->crust_import_customizer('saas');

		//Import Content...
		$this->crust_import_conent('saas');

	}

	public function crust_import_demo_saas_elementor()
	{

		// Import theme options...
		$this->crust_import_customizer('saas-elementor');

		//Import Content...
		$this->crust_import_conent('saas-elementor');

	}

}

new Crust_Demo_Importer();
