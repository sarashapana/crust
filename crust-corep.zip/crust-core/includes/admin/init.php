<?php

if ( ! defined('ABSPATH')) {
    die('-1');
}

class Crust_Core_Admin extends Crust_Admin_Panel
{

    public function __construct()
    {

        parent::__construct();
        add_action( 'wp_ajax_deactivate_plgn', [$this, 'deactivate_plgn'] );

	    // Add Custom image to categories...
	    add_action( 'category_add_form_fields',  [ $this, 'add_category_image' ], 10, 2 );
	    add_action( 'created_category',          [ $this, 'save_category_image' ], 10, 2 );
	    add_action( 'category_edit_form_fields', [ $this, 'update_category_image' ], 10, 2 );
	    add_action( 'edited_category',           [ $this, 'updated_category_image' ], 10, 2 );
	    add_action( 'show_user_profile',         [ $this, 'crust_extra_profile_fields' ] );
	    add_action( 'edit_user_profile',         [ $this, 'crust_extra_profile_fields' ] );
	    add_action( 'personal_options_update',   [ $this, 'crust_update_profile_fields' ] );
	    add_action( 'edit_user_profile_update',  [ $this, 'crust_update_profile_fields' ] );

    }

    public function init()
    {

        parent::init();

        // Extend the init function...
        Crust_Core::load_files([
        	'admin/options',
	        'admin/importer/import'
        ]);

        $options        = new Crust_Core_Settings();
        $newfields      = $options->options();
        $this->settings = array_merge( $this->fields, $newfields );
        $this->sections['tools'] = '<i class="dashicons dashicons-admin-settings"></i>' . esc_html__('Settings', 'crust-core');

    }

    public function admin_page()
    {

        $name = esc_html__("Crust", "crust-core");
        $title = esc_html__("Crust Dashboard", "crust-core");
        remove_submenu_page('themes.php', 'crust-options');
        add_menu_page( $name, $name, 'manage_options', 'crust-options', '', 'dashicons-star-empty', 30 );
        add_submenu_page( 'crust-options', $title, $title, 'manage_options', 'crust-options', [$this, 'display_page'] );
        add_submenu_page( 'crust-options', 'Customize', 'Theme Options', 'manage_options', admin_url( 'customize.php' ), '' );
    }

    public function crust_customizer_link()
    {
	    wp_redirect( admin_url( 'customize.php' ) );
	    exit;
    }

    public function deactivate_plgn()
    {
        $plugin = $_POST['slug'];

        if (isset($plugin)) {
            deactivate_plugins($plugin . '/' . $plugin . '.php');
        }
    }

	public function add_category_image ( $taxonomy ) {

		echo "<div class='form-field term-group'>";

			echo '<div class="crust-img-upload">';
				echo '<input type="hidden" id="crust-category-image" name="crust-category-image" class="crust-up-input" value="" />';
				echo '<div class="crust-up-wrap">';
					echo '<span class="crust-clear-img"></span>';
					echo '<a href="#" class="crust-image-upload"></a>';
					echo '<a class="crust-remove-img" href="#" title="'. esc_attr__('Remove', 'crust-core') .'"></a>';
					echo '<span class="crust-upload-text">'.esc_html__('Choose Image', 'crust-core').'</span>';
				echo '</div>';
			echo '</div>';

		echo "</div>";

	}

	public function save_category_image ( $term_id, $tt_id ) {
		if( isset( $_POST['crust-category-image'] ) && '' !== $_POST['crust-category-image'] ){
			$image = $_POST['crust-category-image'];
			add_term_meta( $term_id, 'crust-category-image', $image, true );
		}
	}

	public function update_category_image ( $term, $taxonomy ) {

		echo "<tr class='form-field term-group'>";

			echo '<th scope="row"><label for="description">'. esc_html__( 'Category Image', 'crust-core') .'</label></th>';

			$image_id = get_term_meta( $term->term_id, 'crust-category-image', true );
			$img      = esc_url( wp_get_attachment_url( $image_id ) );
			echo '<td class="crust-img-upload">';
				echo '<input type="hidden" id="crust-category-image" name="crust-category-image" class="crust-up-input" value="'. $image_id .'" />';
				echo '<div class="crust-up-wrap">';
					echo '<span class="crust-clear-img" style="background-image: url(' . esc_url( $img ) . ')"></span>';
					echo '<a href="#" class="crust-image-upload"></a>';
					echo '<a class="crust-remove-img" href="#" title="'. esc_attr__('Remove', 'crust-core') .'"></a>';
					echo '<span class="crust-upload-text">'.esc_html__('Choose Image', 'crust-core').'</span>';
				echo '</div>';

			echo "</td>";

		echo "</tr>";

	}

	public function updated_category_image ( $term_id, $tt_id ) {
		if( isset( $_POST['crust-category-image'] ) && '' !== $_POST['crust-category-image'] ){
			$image = $_POST['crust-category-image'];
			update_term_meta ( $term_id, 'crust-category-image', $image );
		} else {
			update_term_meta ( $term_id, 'crust-category-image', '' );
		}
	}

	public function crust_extra_profile_fields( $user ) {
		?>
		<h3><?php esc_html_e( 'Social Profiles', 'crust-core' ); ?></h3>
		<?php
		$fb_crust = get_the_author_meta( 'fb_crust', $user->ID );
		$tw_crust = get_the_author_meta( 'tw_crust', $user->ID );
		$yt_crust = get_the_author_meta( 'yt_crust', $user->ID );
		$ln_crust = get_the_author_meta( 'ln_crust', $user->ID );
		$in_crust = get_the_author_meta( 'in_crust', $user->ID );
		?>

		<table class="form-table">
			<tr>
				<th><label for="fb_crust"><?php esc_html_e( 'Facebook', 'crust-core' ); ?></label></th>
				<td><input type="text" id="fb_crust" name="fb_crust" value="<?php echo esc_attr( $fb_crust ); ?>" class="regular-text" /></td>
			</tr>
			<tr>
				<th><label for="tw_crust"><?php esc_html_e( 'Twitter', 'crust-core' ); ?></label></th>
				<td><input type="text" id="tw_crust" name="tw_crust" value="<?php echo esc_attr( $tw_crust ); ?>" class="regular-text" /></td>
			</tr>
			<tr>
				<th><label for="yt_crust"><?php esc_html_e( 'Youtube', 'crust-core' ); ?></label></th>
				<td><input type="text" id="yt_crust" name="yt_crust" value="<?php echo esc_attr( $yt_crust ); ?>" class="regular-text" /></td>
			</tr>
			<tr>
				<th><label for="in_crust"><?php esc_html_e( 'Instagram', 'crust-core' ); ?></label></th>
				<td><input type="text" id="in_crust" name="in_crust" value="<?php echo esc_attr( $in_crust ); ?>" class="regular-text" /></td>
			</tr>
			<tr>
				<th><label for="ln_crust"><?php esc_html_e( 'Linkedin', 'crust-core' ); ?></label></th>
				<td><input type="text" id="ln_crust" name="ln_crust" value="<?php echo esc_attr( $ln_crust ); ?>" class="regular-text" /></td>
			</tr>
		</table>
		<?php
	}

	function crust_update_profile_fields( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return false;
		}

		if ( ! empty( $_POST['fb_crust'] ) ) {
			update_user_meta( $user_id, 'fb_crust', $_POST['fb_crust'] );
			update_user_meta( $user_id, 'tw_crust', $_POST['tw_crust'] );
			update_user_meta( $user_id, 'yt_crust', $_POST['yt_crust'] );
			update_user_meta( $user_id, 'ln_crust', $_POST['ln_crust'] );
			update_user_meta( $user_id, 'in_crust', $_POST['in_crust'] );
		}
	}

}

new Crust_Core_Admin();
