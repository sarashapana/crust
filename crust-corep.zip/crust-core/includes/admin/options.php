<?php

if ( ! defined('ABSPATH')) {
    exit('Access Denied.');
}

class Crust_Core_Settings extends Crust_Panel_Settings
{

    public function __construct()
    {

        Crust_Core::load_files([
            'admin/plugins'
        ]);

    }

    public static function options()
    {

        parent::options();
        $plgn = new Crust_Plugins();
        $settings = [

            // Plugins...
            [
                'id'      => 'crust_core_plugins',
                'type'    => 'plugins',
                'section' => 'plugins',
                'class'   => 'no-shadow lg-section',
                'choices' => $plgn->get_plugins()
            ],

            // Demo Import...
            [
                'id'      => 'crust_core_templates',
                'type'    => 'templates',
                'section' => 'templates',
                'class'   => 'no-shadow lg-section crust-templates-section',
            ],

            // Tools...
            [
                'id'      => 'crust_customizer_option',
                'title'   => esc_html__('Crust Customizer ?', 'crust-core'),
                'desc'    => esc_html__('Choose to Enable / Disable the custom customizer functionality that Crust adds in the customizer page and show the built-in Customizer settings.', 'crust-core'),
                'type'    => 'checkbox',
                'section' => 'tools',
                'class'   => 'three-section simple-section',
                'std'     => 'yes'
            ],
            [
                'id'      => 'crust_menus_option',
                'title'   => esc_html__('Crust Menus ?', 'crust-core'),
                'desc'    => esc_html__('Choose to Enable / Disable custom menu functionality that Crust adds in the Nav menu page (This will remove the custom menu fields and location features).', 'crust-core'),
                'type'    => 'checkbox',
                'section' => 'tools',
                'class'   => 'three-section simple-section',
                'std'     => 'yes'
            ],
            [
                'id'      => 'crust_widgets_option',
                'title'   => esc_html__('Crust Widgets ?', 'crust-core'),
                'desc'    => esc_html__('Choose to Enable / Disable custom widgets that Crust adds and only show the default wordpress widgets.', 'crust-core'),
                'type'    => 'checkbox',
                'section' => 'tools',
                'class'   => 'three-section simple-section',
                'std'     => 'yes'
            ],
            [
                'id'      => 'crust_elementor_option',
                'title'   => esc_html__('Crust Elementor ?', 'crust-core'),
                'desc'    => esc_html__('Choose to Enable / Disable custom widgets that Crust adds to elementor editor and only use the original built-in Elementor widgets.', 'crust-core'),
                'type'    => 'checkbox',
                'section' => 'tools',
                'class'   => 'three-section simple-section',
                'std'     => 'yes'
            ],
            [
                'id'      => 'crust_wpbackery_option',
                'title'   => esc_html__('Crust WPBakery ?', 'crust-core'),
                'desc'    => esc_html__('Choose to Enable / Disable custom Shortcodes that Crust adds to WPBakery editor and only use the original built-in WPBakery Shortcodes.', 'crust-core'),
                'type'    => 'checkbox',
                'section' => 'tools',
                'class'   => 'three-section simple-section',
                'std'     => 'yes'
            ],
	        [
		        'id'      => 'crust_page_settings_option',
		        'title'   => esc_html__('Custom Page Settings ?', 'crust-core'),
		        'desc'    => esc_html__('Choose to Enable / Disable custom page options that Crust adds to each page individually, each page can have its own settings separatly.', 'crust-core'),
		        'type'    => 'checkbox',
		        'section' => 'tools',
		        'class'   => 'three-section simple-section',
		        'std'     => 'yes'
	        ],
	        [
		        'id'      => 'crust_portfolio_option',
		        'title'   => esc_html__('Crust Portfolio ?', 'crust-core'),
		        'desc'    => esc_html__('Choose to Enable / Disable portfolio custom post type to add extra new different portfolio projects to your website.', 'crust-core'),
		        'type'    => 'checkbox',
		        'section' => 'tools',
		        'class'   => 'three-section simple-section',
		        'std'     => 'yes'
	        ],

        ];

        return $settings;

    }

}
