<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Icon_Radio extends Crust_Control
{

    public $type = 'crust-icon-radio';

    protected function control_template()
    {
        ?>
        <div class="crust-icon-radio">
            <div class="crust-radio-buttons">
                <# _.each( data.choices, function( label, choice ) { #>
                <label class="crust-radio-label">
                    <input type="radio" name="{{ data.id }}" value="{{ choice }}" {{{ data.link }}} <# if ( choice === data.value ) { #> checked <# } #> />
                    <i class="{{ label }}"></i>
                </label>
                <# } ) #>
            </div>
        </div>
        <?php
    }

}