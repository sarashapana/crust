<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Box_Shadow extends Crust_Control
{

    public $type = 'crust-box-shadow';

    protected function control_template()
    {
        ?>
        <div class="crust-shadow-wrapper">

            <a href="#" class="crust-shadow-reset" title="<?php esc_attr_e('Reset', 'crust-core'); ?>"><i class="dashicons dashicons-image-rotate"></i></a>

            <a href="#" class="crust-shadow-btn"><i class="dashicons dashicons-edit"></i></a>

            <div class="crust-shadow-control-wrap">

                <div class="crust-shadow-input-wrp flex-row">
                    <span><?php esc_html_e('Position', 'crust-core'); ?></span>
                    <select class="crust-shadow-input" data-shadow="position">
                        <option value=""><?php esc_html_e('-- Select --', 'crust-core'); ?></option>
                        <option value="outset" selected="selected"><?php esc_html_e('Outline', 'crust-core'); ?></option>
                        <option value="inset"><?php esc_html_e('Inset', 'crust-core'); ?></option>
                    </select>
                </div>

                <div class="crust-shadow-input-wrp">
                    <span><?php esc_html_e('Horizontal', 'crust-core'); ?><i><?php esc_html_e( ' - ex: 10px', 'crust-core') ?></i></span>
                    <input type="text" value="0" class="crust-shadow-input crust-slider-value"/>
                </div>

                <div class="crust-shadow-input-wrp">
                    <span><?php esc_html_e('Vertical', 'crust-core'); ?><i><?php esc_html_e( ' - ex: 10px', 'crust-core') ?></i></span>
                    <input type="text" value="0" class="crust-shadow-input crust-slider-value"/>
                </div>

                <div class="crust-shadow-input-wrp">
                    <span><?php esc_html_e('Blur', 'crust-core'); ?><i><?php esc_html_e( ' - ex: 10px', 'crust-core') ?></i></span>
                    <input type="text" value="0" class="crust-shadow-input crust-slider-value"/>
                </div>

                <div class="crust-shadow-input-wrp">
                    <span><?php esc_html_e('Spread', 'crust-core'); ?><i><?php esc_html_e( ' - ex: 10px', 'crust-core') ?></i></span>
                    <input type="text" value="0" class="crust-shadow-input crust-slider-value"/>
                </div>

                <div class="crust-shadow-input-wrp flex-row">
                    <span><?php esc_html_e('Color', 'elementor'); ?></span>
                    <input class="crust-shadow-input crust-shadow-color" type="text" data-alpha="true" data-palette="true" value="" />
                </div>

            </div>

            <input class="crust-shadow-control crust-shadow-{{ data.id }}" id="{{ data.id }}" type="hidden" value="{{ data.value }}" data-customize-setting-link="{{ data.id }}"/>

        </div>

        <?php
    }

}
