<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Tab extends Crust_Control
{

    public $type = 'crust-tab';
    public $title;

    protected function control_template()
    {
        ?>
        <a data-id="customize-control-{{data.id}}" class="crust-field-tab" href="#"></a>
        <ul class="crust-fields-tab">
        </ul>
        <?php
    }

}