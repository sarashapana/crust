<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Checkbox extends Crust_Control
{

    public $type = 'crust-checkbox';

    protected function control_template()
    {
        ?>

        <div class="crust-default-checkbox">
            <label class="checkbox-label">
                <input type="checkbox" id="_customize-input-{{ data.id }}" name="{{ data.id }}" class="crust-checkbox" value="{{ data.value }}" {{{ data.link }}} <# if ( true === data.value ) { #> checked <# } #> />
                <span class="checkmark"></span>
                {{{ data.label }}}
            </label>
        </div>

        <?php
    }

}