<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Number extends Crust_Control
{

    public $type = 'crust-number';

    protected function control_template()
    {
        echo '<input type="number" class="customize-control-number" id="{{ data.id }}" value="{{ data.value }}" name="{{ data.id }}" {{{ data.link }}} />';
    }

}