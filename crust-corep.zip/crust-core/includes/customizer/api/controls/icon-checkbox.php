<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Icon_Checkbox extends Crust_Control
{

    public $type = 'crust-icon-checkbox';

    protected function control_template()
    {
        ?>

        <div class="crust-multicheckbox icon-check">
            <# if ( ! _.isEmpty( data.choices ) ) { #>
                <div class="crust-multicheck">
                    <# _.each( data.choices, function( label, choice ) { #>
                    <div class="crust-default-checkbox">
                        <label class="crust-checkbox-label" for="{{data.id}}-{{ choice }}">
                            <input type="checkbox" name="{{data.id}}" id="{{data.id}}-{{ choice }}" class="crust-checkbox multi-checkbox" value="{{ choice }}" <# if ( data.value.indexOf( choice ) >= 0 ) { #> checked <# } #> />
                            <span class="checkmark"></span>
                            <span class="crust-multi-lbl">{{ label }}</span>
                        </label>
                    </div>
                    <# } ) #>
                </div>
            <# } #>
            <input type="hidden" {{{ data.link }}} value="<?php echo $this->value(); ?>"" />
        </div>

        <?php
    }

}