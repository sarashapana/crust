<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Image_Radio extends Crust_Control
{

    public $type = 'crust-image-radio';

    protected function control_template()
    {
        ?>
        <div class="crust-image-radio">
            <div class="crust-radio-buttons">
                <# _.each( data.choices, function( label, choice ) { #>
                <label class="crust-radio-label">
                    <input type="radio" name="{{ data.id }}" value="{{ choice }}" {{{ data.link }}} <# if ( choice === data.value ) { #> checked <# } #> />
                    <img src="{{ label }}" alt="{{ label }}" title="{{ label }}"/>
                    <span class="crust-indicator"></span>
                </label>
                <# } ) #>
            </div>
        </div>
        <?php
    }

}