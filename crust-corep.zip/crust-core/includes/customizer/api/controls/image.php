<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Image extends Crust_Control
{

    public $type = 'crust-image';

    public function to_json()
    {
        parent::to_json();
        $this->json['url'] = ( $this->value() !== '' ) ? esc_url( wp_get_attachment_url( $this->value() ) ) : '';
    }

    protected function control_template()
    {
        ?>
            <div class="crust-img-upload">
                <input type="hidden" id="{{ data.id }}" class="crust-up-input" value="{{ data.value }}" {{{ data.link }}}/>
                <div class="crust-up-wrap">
                    <span class="crust-clear-img" style="background-image: url('{{data.url}}')"></span>
                    <a href="#" class="crust-image-upload"></a>
                    <a class="crust-remove-img" href="#" title="<?php echo esc_attr__('Remove', 'crust-core'); ?>"></a>
                    <span class="crust-upload-text"><?php echo esc_html__('Choose Image', 'crust-core'); ?></span>
                </div>
            </div>
        <?php
    }

}