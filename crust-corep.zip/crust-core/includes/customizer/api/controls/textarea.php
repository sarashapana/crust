<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Textarea extends Crust_Control
{

    public $type = 'crust-textarea';

    public function control_template()
    {
        ?>
        <div class="crust-textarea">
            <textarea id="{{ data.id }}" name="{{ data.id }}" class="customize-control-textarea" {{{ data.link }}}>{{ data.value }}</textarea>
        </div>
        <?php
    }

}