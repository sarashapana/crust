<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Label extends Crust_Control
{

    public $type = 'crust-label';

    protected function control_template() { }

}