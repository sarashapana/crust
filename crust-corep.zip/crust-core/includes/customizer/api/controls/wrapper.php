<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Wrapper extends Crust_Control
{

    public $type = 'crust-wrapper';
    public $title;

    protected function control_template()
    {
        ?>
        <ul class="crust-fields-wrap">
            <li class="crust-pop-title"><span></span><a href="#" class="close-box"><?php esc_html_e('Close', 'crust-core'); ?></a></li>
        </ul>
        <?php
    }

}