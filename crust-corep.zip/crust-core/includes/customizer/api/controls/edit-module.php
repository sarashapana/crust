<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}

class Crust_Control_Edit_Module extends Crust_Control {

	public $type = 'crust-edit-module';

	protected function control_template() {
		?>

        <div class="dropdown_select_control">
            <select class="customize-control-select" id="{{ data.id }}" value="{{ data.value }}" name="{{ data.id }}" {{{ data.link }}}>
                <# _.each( data.choices, function( label, choice ) { #>
                <option value="{{ choice }}" <# if ( choice === data.value ) { #> selected="selected" <# } #>>{{ label }}</option>
                <# } ) #>
            </select>

            <div class="crust-custom-pop">
            <a href="#" class="crust-btn-model" data-mod="{{ data.mod_type }}" data-temp="{{data.id}}" data-edit="<?php echo esc_html__('Edit', 'crust-core') ?>" data-add="<?php echo esc_html__('Add', 'crust-core') ?>"></a>

            <!-- The Modal -->
            <div class="crust-custom-modal">
                <!-- Modal content -->
                <div class="crust-custom-modal-content">
                    <span class="crust-custom-modal-close">&times;</span>
                    <iframe class="elementor-model" src=""></iframe>
                </div>

            </div>
        </div>

        </div>
		<?php
	}

}
