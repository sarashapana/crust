<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Tab_List extends Crust_Control
{

    public $type = 'crust-tab-list';
    public $title;

    protected function control_template()
    {
        ?>
        <div class="crust-list-wrp"></div>
        <?php
    }

}