<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Gradient extends Crust_Control
{

    public $type = 'crust-gradient';

    protected function control_template() {

	    ?>

	    <div class="crust-gradient-control">
		    
		    <div class="crust-grad-block">
			    <div class="grad-lbl">Angle</div>
			    <div class="edit_form_line">
				    <input type="number" class="crust-grad-field" data-index="0" value="90" />
			    </div>
		    </div>
		    <div class="crust-grad-block">
			    <div class="grad-lbl">First Color</div>
			    <div class="edit_form_line">
				    <input type="text" class="crust-grad-field crust-grad-color" data-index="1" data-alpha="true" />
			    </div>
		    </div>
		    <div class="crust-grad-block">
			    <div class="grad-lbl">Location</div>
			    <div class="edit_form_line">
				    <input type="number" class="crust-grad-field" value="0" data-index="2" />
			    </div>
		    </div>
		    <div class="crust-grad-block">
			    <div class="grad-lbl">Second Color</div>
			    <div class="edit_form_line">
				    <input type="text" class="crust-grad-field crust-grad-color" data-index="3" data-alpha="true" />
			    </div>
		    </div>
		    <div class="crust-grad-block">
			    <div class="grad-lbl">Location</div>
			    <div class="edit_form_line">
				    <input type="number" class="crust-grad-field" value="100" data-index="4" />
			    </div>
		    </div>
		    <input type="text" id="_customize-input-{{ data.id }}" name="{{ data.id }}" class="crust-grad-control hidden" value="{{ data.value }}" {{{ data.link }}} />
	    </div>

	    <?php
    	
    }

}