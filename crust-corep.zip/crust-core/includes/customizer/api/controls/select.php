<?php
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return NULL;
}
class Crust_Control_Select extends Crust_Control
{

    public $type = 'crust-select';

    protected function control_template()
    {
        ?>
        <div class="dropdown_select_control">
            <select class="customize-control-select" id="{{ data.id }}" value="{{ data.value }}" name="{{ data.id }}" {{{ data.link }}}>
                <# _.each( data.choices, function( label, choice ) { #>
                    <option value="{{ choice }}" <# if ( choice === data.value ) { #> selected="selected" <# } #>>{{ label }}</option>
                <# } ) #>
            </select>
        </div>
        <?php
    }

}