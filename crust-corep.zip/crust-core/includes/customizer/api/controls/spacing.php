<?php

class Crust_Control_Spacing extends Crust_Control
{

    public $type = 'crust-spacing';

	public $directions  = [
		'top'    => '',
		'right'  => '',
		'bottom' => '',
		'left'   => ''
	];


	public function to_json()
	{
		parent::to_json();

		$this->json['directions'] = $this->directions;
		$this->json['labels']     = [
			'top'    => esc_html__( 'Top'),
			'right'  => esc_html__( 'Right'),
			'bottom' => esc_html__( 'Bottom'),
			'left'   => esc_html__( 'Left')
		];

	}

    protected function control_template()
    {
	    ?>
        <div class="crust-spacing-wrapper" data-element="{{ data.id }}">

            <div class="crust-spacing-control-wrap">

                <# for ( choiceKey in data.directions ) { #>
                    <div class="crust-spacing-input-wrp">

                        <# var val = ( ! _.isUndefined( data.value ) && ! _.isUndefined( data.value[ choiceKey ] ) ) ? data.value[ choiceKey ].toString().replace( '%%', '%' ) : ''; #>
                        <input class="crust-spacing-input" placeholder="-" {{{ data.inputAttrs }}} type="number" data-direction="{{ choiceKey }}" value="{{ val }}"/>

                        <span>
                            <# if ( ! _.isUndefined( data.labels ) && ! _.isUndefined( data.labels[ choiceKey ] ) ) { #>
                                {{ data.labels[ choiceKey ] }}
                            <# } else { #>
                                {{ choiceKey }}
                            <# } #>
                        </span>

                    </div>
                <# } #>

                <div class="crust-spacing-units">
                    <# _.each( data.units, function ( unit ) { #>
                    <input type="radio" id="{{ data.id }}-{{ unit }}" name="{{ data.id }}-units" value="{{ unit }}" />
                    <label for="{{ data.id }}-{{ unit }}">{{ unit }}</label>
                    <# } ) #>
                </div>

            </div>

            <input class="crust-spacing-control crust-spacing-{{ data.id }}" id="{{ data.id }}" type="hidden" value="{{ data.value }}" data-customize-setting-link="{{ data.id }}"/>

        </div>
	    <?php
    }

}
