<?php

defined('ABSPATH') || die();

class Crust_Section extends WP_Customize_Section
{

    public $section;

    public $type = 'kirki-tab-section';

    public $tabs = [];

    public $preview_link = '';

    public function json()
    {
        $array                   = wp_array_slice_assoc( (array)$this, [ 'id', 'description', 'priority', 'panel', 'type', 'description_hidden' ] );
        $array['title']          = html_entity_decode( $this->title, ENT_QUOTES, get_bloginfo('charset') );
        $array['content']        = $this->get_content();
        $array['active']         = $this->active();
        $array['instanceNumber'] = $this->instance_number;
        $array['tabs']           = $this->tabs;
        $array['preview_link']   = $this->preview_link;

        foreach ( $array['tabs'] as $key => $tab ) {

            if( is_array( $tab ) ){

		        $array[ 'tabs' ][ $key ] = [
                    'label' => $tab['name'],
                    'preview' => $tab['slug']
                ];
		        continue;

	        } else {
	            if ( is_string( $tab ) ) {
		            $array[ 'tabs' ][ $key ] = [ 'label' => $tab ];
		            continue;
	            }
            }

        }

        return $array;
    }

    protected function render_template()
    {

        ?>
        <li id="crust-section-{{ data.id }}" class="accordion-section control-section crust-tabbed-section">
            <h3 class="accordion-section-title" tabindex="0">
                 {{ data.title }}
                <span class="screen-reader-text"><?php esc_html_e('Press return or enter to open this section', 'crust-core'); ?></span>
            </h3>
            <ul class="accordion-section-content">
                <li class="customize-section-description-container section-meta <# if ( data.description_hidden ) { #>customize-info<# } #>">
                    <div class="crust-section-title customize-section-title">
                        {{ data.title }}<a href="#" class="crust-section-back" tabindex="-1"><?php esc_html_e('Close', 'crust-core'); ?></a>
                    </div>
                </li>
                <?php $this->content_template(); ?>
            </ul>
        </li>
        <?php
    }

    protected function content_template()
    {
        ?>
        <li class="crust-tabbed-section">
            <# if ( data.tabs ) { #>
            <# count = 0; pane = 0 #>
            <ul class="crust-tabs-list">
                <# _.each( data.tabs, function( tab, tabId ) { #>
                <li><a class="{{data.id}}-{{tabId}}<# if( count == 0 ){ #> active <# } #>" href="#{{ tabId }}" data-tab-link="{{ tabId }}" data-preview="{{ tab.preview }}">{{{ tab.label }}}</a></li>
                <# count++; #>
                <# }) #>
            </ul>
            <# } #>
            <div class="crust-tabs-pane">
                <# _.each( data.tabs, function( tab, tabId ) { #>
                <ul class="crust-tab-panel<# if( pane == 0 ){ #> active-pane <# } #>" data-parent-tab="{{ tabId }}"></ul>
                <# pane++; #>
                <# }) #>
            </div>
        </li>
        <?php
    }

}
