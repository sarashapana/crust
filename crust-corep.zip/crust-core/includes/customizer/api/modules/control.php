<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

defined('ABSPATH') || die();

class Crust_Control extends Kirki_Control_Base
{

    public $responsive = false;
    public $class      = '';
    public $tab        = '';
	public $url        = '';
    public $units      = [
        'px'  => 'px',
        '%'   => '%',
        'rem' => 'rem',
        'em'  => 'em'
    ];

    public $mod_type = '';

    public function to_json()
    {
        parent::to_json();

        $this->json['tab']        = $this->tab;
        $this->json['units']      = $this->units;
        $this->json['mod_type']      = $this->mod_type;
        $this->json['class']      = (isset($this->class)) ? $this->class : '';

    }

	protected function render_content()
	{

		?>

        <script type="text/html" id="tmpl-customize-control-<?php echo esc_attr( $this->type ); ?>-content">

            <#
            devices = ['global']
            if ( data.responsive ) {
            devices = [ 'desktop', 'tablet', 'mobile' ]
            values = {
                link:   data.link,
                id:     data.id,
                value:  data.value || {}
            } #>
            <div class="control-title-wrap">
                <# }

                if ( data.label ) { #>
                <span class="customize-control-title">{{ data.label }}</span>
                <# }

                if ( data.description ) { #>
                <span class="description customize-control-description">{{{ data.description }}}</span>
                <# }

                if ( data.responsive ) { #>
                <div class="crust-responsive-switcher">
                    <div class="crust-responsive-switcher-buttons">
                        <# _.each( devices, function ( device ) { devc = ( device == 'mobile' ) ? 'smartphone' : device #>
                        <a class="crust-responsive-switcher-button crust-responsive-switcher-{{ device }}" data-device="{{ device }}">
                            <span class="crust-responsive-switcher-icon"><i class="dashicons dashicons-{{devc}}"></i></span>
                        </a>
                        <# } ) #>
                    </div>
                </div>
            </div>
            <# }
            if ( data.responsive ) { #>
                <div class="crust-responsive-control">
            <# }
                _.each( devices, function ( device ) {
                    if ( data.responsive ) {
                        if( device === 'desktop' ){
                            data.link   = ' data-customize-setting-link="'+ values.id +'"'
                            data.id     = values.id
                            data.value  = values.value || ''
                        } else {
                            data.link   = ' data-customize-setting-link="'+ values.id +'_'+ device +'"'
                            data.id     = values.id + '_' + device
                            data.value  = values.value[device] || ''
                        } #>
                        <div class="crust-devices crust-devices-{{ device }}">
                    <# } #>
                    <?php $this->control_template(); ?>
                    <# if ( data.responsive ) { #>
                        </div>
                    <# }
                })
            if ( data.responsive ) { #>
                </div>
            <# } #>

        </script>

		<?php

	}

	protected function control_template() {}

}