<?php

use Soderlind\Customizer\Polylang\Customizer_Polylang;

if ( ! function_exists( 'pll_current_language' ) && ! class_exists( 'SitePress' ) ) {
    return;
}


class Crust_Customizer_Multilingual
{

    public static function init() {
        $self = new self();

        add_filter( 'pll_preferred_language', '__return_false' );

        /**
         * Force "The language is set from content" (in Language->Settings->URL modifications)
         */
        $options = get_option( 'polylang' );
        if ( isset( $options['force_lang'] ) && 0 !== $options['force_lang'] ) {
            $options['force_lang'] = 0;
            update_option( 'polylang', $options );
        }

        add_action( 'customize_controls_enqueue_scripts', [ $self, 'add_lang_to_customizer_previewer' ], 9 );
        add_action( 'wp_before_admin_bar_render', [ $self, 'on_wp_before_admin_bar_render' ], 100 );
        add_action( 'admin_menu', [ $self, 'on_admin_menu' ], 100 );

        $theme_slug = get_option( 'stylesheet' );
        $option_types = [ 'blogname', 'blogdescription', 'site_icon' ];

        // Get theme mod options.
        add_filter( 'option_theme_mods_' . $theme_slug, [ $self, 'on_option_theme_mods_get' ], 10, 1 );
        // Update theme mod options.
        add_filter( 'pre_update_option_theme_mods_' . $theme_slug, [ $self, 'on_option_theme_mods_update' ], 10, 2 );

        foreach ( $option_types as $option_type ) {
            add_filter( 'pre_option_' . $option_type, [ $self, 'on_wp_option_get' ], 10, 3 ); // get_option hook.
            add_filter( 'pre_update_option_' . $option_type, [ $self, 'on_wp_option_update' ], 10, 3 ); // update_option hook.
        }

        return $self;

    }

    public function __construct() {}

    public static function get_language() {
        if ( function_exists( 'pll_current_language' ) ) {
            $language = pll_current_language();

            if ( ! $language ) {
                $language = pll_default_language();
            }

            return $language;
        }

        if ( class_exists( 'SitePress' ) && defined( 'ICL_LANGUAGE_CODE' ) ) {
            return ICL_LANGUAGE_CODE;
        }

        return false;
    }

    public static function get_option_key() {
        if ( function_exists( 'pll_current_language' ) ) {
            return '_customizer_polylang_settings_';
        }

        if ( class_exists( 'SitePress' ) && defined( 'ICL_LANGUAGE_CODE' ) ) {
            return '_customizer_wpml_settings_';
        }

        return false;
    }

    protected function get_custom_customizer_option() {
        $current_language = self::get_language();
        $theme_slug       = get_option( 'template' );
        $option_prefix    = str_replace( '-', '_', $theme_slug );
        $option_name      = $option_prefix . self::get_option_key() . $current_language;

        return get_option( $option_name, false );
    }

    protected function update_custom_customizer_option( $data ) {
        $current_language = self::get_language();
        $theme_slug       = get_option( 'template' );
        $option_prefix    = str_replace( '-', '_', $theme_slug );
        $option_name      = $option_prefix . self::get_option_key() . $current_language;

        return update_option( $option_name, $data );
    }

    public static function get_languages_list() {
        if ( function_exists( 'pll_current_language' ) ) {
            return get_option( '_transient_pll_languages_list' );
        }

        if ( class_exists( 'SitePress' ) && defined( 'ICL_LANGUAGE_CODE' ) ) {
            $list      = icl_get_languages( 'skip_missing=1' );
            $languages = [];

            foreach ( $list as $language ) {
                $temp         = [];
                $temp['name'] = $language['native_name'];
                $temp['slug'] = $language['code'];
                $languages[]  = $temp;
            }

            return $languages;
        }

        return false;
    }

    public function on_wp_option_get( $pre_option, $option, $default ) {

        // If not the default language, then skip the custom check and wp will the use default options.
        if ( $this->current_lang_not_default() ) {
            $data = $this->get_custom_customizer_option();

            // Found the custom option. Move on.
            if ( is_array( $data ) && isset( $data['options'] ) && isset( $data['options'][ $option ] ) ) {
                return $data['options'][ $option ];
            }
        }

        return $default;
    }

    public function on_wp_option_update( $value, $old_value, $option ) {
        // Fetch custom option db field.
        $data       = $this->get_custom_customizer_option();
        $theme_slug = get_option( 'template' );
        // If false, the field hasn't been created yet, so it must be created.
        if ( false === $data ) {
            $data = [
                'template' => $theme_slug,
                'mods'     => [],
                'options'  => [],
            ];
        }

        // Make sure the options array exists. We are going to use it soon.
        if ( ! isset( $data['options'] ) ) {
            $data['options'] = [];
        }

        $data['options'][ $option ] = $value;

        // Update option value in custom db field. (Not necessary to save for default language since it uses default wp option fields for values when get option).
        $this->update_custom_customizer_option( $data );

        // If the current language is not the default language, prevent saving to option table by passing the old value back. It will then exit after the filter.
        if ( $this->current_lang_not_default() ) {
            return $old_value;
        }

        return $value;
    }
    
    protected function current_lang_not_default() {
        if ( class_exists( 'SitePress' ) ) {
            global $sitepress;
            return $sitepress->get_current_language() !== $sitepress->get_default_language();
        }

        return pll_current_language() !== pll_default_language();
    }

    public function on_option_theme_mods_get( $value ) {

        $data = $this->get_custom_customizer_option();

        if ( isset( $data['mods'] ) && is_array( $data['mods'] ) && ! empty( $data['mods'] ) ) {
            $value = wp_parse_args( $data['mods'], $value );
        }

        // Remove members with integer key from mods.
        foreach ( $value as $key => $mod ) {
            if ( is_numeric( $key ) ) {
                unset( $value[ $key ] );
            }
        }

        return $value;

    }

    public function on_option_theme_mods_update( $value, $old_value ) {

        $current_data = $this->get_custom_customizer_option();
        $theme_slug   = get_option( 'template' );

        $data = [
            'template' => $theme_slug,
            'mods'     => isset( $current_data['mods'] ) ? $current_data['mods'] : [],
            'options'  => isset( $current_data['options'] ) ? $current_data['options'] : [],
        ];

        if ( is_array( $value ) && ! empty( $value ) ) {
            foreach ( $value as $key => $val ) {
                $data['mods'][ $key ] = $val;
            }
        }
        $this->update_custom_customizer_option( $data );

        if ( $this->current_lang_not_default() ) {
            return $old_value;
        }

        return $value;
    }

    public static function get_home_url( $language ) {
        if ( function_exists( 'pll_current_language' ) ) {
            return pll_home_url( $language );
        }

        if ( class_exists( 'SitePress' ) ) {
            global $sitepress;
            return $sitepress->language_url( $language );
        }

        return false;
    }

    public static function add_lang_to_customizer_previewer() {
        $languages = self::get_languages_list();

        $handle    = 'dss-add-lang-to-template';
        $src       = CRUST_CORE_URI . '/includes/customizer/assets/js/customizer-multilingual.js';
        $deps      = [ 'customize-controls' ];
        $version   = rand();
        $in_footer = 1;
        wp_enqueue_script( $handle, $src, $deps, $version, $in_footer );
        $language = ( empty( $_REQUEST['lang'] ) ) ? self::get_language() : $_REQUEST['lang'];

        if ( empty( $language ) ) {
            $language = self::default_language();
        }

        if ( ! empty( $_REQUEST['url'] ) ) {
            $current_url = add_query_arg( 'lang', $language, $_REQUEST['url'] );
        } else {
            $current_url = add_query_arg( 'lang', $language, self::get_home_url( $language ) );
        }
        wp_add_inline_script(
            $handle,
            sprintf(
                'CrustCustomizerMultilingual.init( %s );',
                wp_json_encode(
                    [
                        'url'              => $current_url,
                        'languages'        => $languages,
                        'current_language' => $language,
                        'switcher_text'    => __( 'Language:', 'crust-core' ),
                    ]
                )
            ),
            'after'
        );

    }

    public static function on_wp_before_admin_bar_render() {
        global $wp_admin_bar;
        $customize_node = $wp_admin_bar->get_node( 'customize' );
        if ( ! empty( $customize_node ) ) {
            $customize_node->href = add_query_arg( 'lang', self::get_language(), $customize_node->href );
            $wp_admin_bar->add_node( $customize_node );
        }
    }

    public static function on_admin_menu() {
        global $menu, $submenu;
        $parent = 'themes.php';
        if ( ! isset( $submenu[ $parent ] ) ) {
            return;
        }
        foreach ( $submenu[ $parent ] as $k => $d ) {
            if ( 'customize' === $d['1'] ) {
                $submenu[ $parent ][ $k ]['2'] = add_query_arg( 'lang', self::get_language(), $submenu[ $parent ][ $k ]['2'] ); // @phpcs:ignore
                break;
            }
        }
    }

}

Crust_Customizer_Multilingual::init();

if ( class_exists( 'WP_Customize_Setting' ) ) {

    final class Customizermultilingialoption extends \WP_Customize_Setting {

        public function import( $value ) {
            $this->update( $value );
        }
    }
}
