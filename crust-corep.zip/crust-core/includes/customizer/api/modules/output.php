<?php

defined('ABSPATH') || die();

class Crust_Extend_Kirki_Output extends Kirki_Output {

	protected function process_output( $output, $value ) {
		if ( ! isset( $this->field['responsive'] ) ) {
			$this->apply_output( $output, $value );
		}

		if ( isset( $this->field['responsive'] ) && $this->field['responsive'] ) {
			$this->responsive_output( $output, $value );
		}
	}

	protected function apply_output( $output, $value ) {
		parent::process_output( $output, $value );
	}

	protected function responsive_output( $output, $value ) {
		foreach ( Crust_Customizer::$responsive_devices as $device => $media_query ) {
			if ( ! isset( $value[ $device ] ) ) {
				continue;
			}

			$device_output = array_merge( [ 'media_query' => $media_query ], $output );

			$device_value = $value[ $device ];

			$this->apply_output( $device_output, $device_value );
		}
	}
}
