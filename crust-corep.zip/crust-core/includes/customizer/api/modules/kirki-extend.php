<?php

defined('ABSPATH') || die();

class Crust_Kirki_Extend
{

	public function __construct() {
		add_filter( 'kirki_crust_config_output_control_classnames', [ $this, 'add_control_outputs' ] );
	}

	public function add_control_outputs() {
		$outputs = [];

		$controls = Crust_Customizer::$control_types;

		foreach ( $controls as $control => $class ) {
			$outputs[ $control ] = 'Crust_Extend_Kirki_Output';
		}

		return $outputs;
	}

}
