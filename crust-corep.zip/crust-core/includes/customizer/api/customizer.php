<?php

defined('ABSPATH') || die();

class Crust_Customizer
{

	public static $config_id = 'crust_config';

	public static $section_types = [
		'kirki-tab-section' => 'Crust_Section',
	];

	public static $control_types = [
		'crust-box-shadow'     => 'Crust_Control_Box_Shadow',
		'crust-checkbox'       => 'Crust_Control_Checkbox',
		//'crust-edit-module'    => 'Crust_Control_Edit_Module',
		'crust-gradient'       => 'Crust_Control_Gradient',
		'crust-icon-checkbox'  => 'Crust_Control_Icon_Checkbox',
		'crust-icon-radio'     => 'Crust_Control_Icon_Radio',
		'crust-image'          => 'Crust_Control_Image',
		'crust-image-radio'    => 'Crust_Control_Image_Radio',
		'crust-label'          => 'Crust_Control_Label',
		'crust-number'         => 'Crust_Control_Number',
		'crust-select'         => 'Crust_Control_Select',
		'crust-spacing'        => 'Crust_Control_Spacing',
		'crust-tab'            => 'Crust_Control_Tab',
		'crust-tab-list'       => 'Crust_Control_Tab_List',
		'crust-textarea'       => 'Crust_Control_Textarea',
		'crust-wrapper'        => 'Crust_Control_Wrapper',

	];

	public static function add_section( $id, $args = [] )
	{
		Kirki::add_section( $id, $args );
	}

	public static function add_field( $args = [] )
	{
		//if ( isset( $args['type'] ) && isset( $args['settings'] ) ) {
			Kirki::add_field( self::$config_id, $args);
		//}
	}

}
