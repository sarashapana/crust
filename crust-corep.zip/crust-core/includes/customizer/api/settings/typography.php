<?php

defined('ABSPATH') || die();

$section = 'typography';

// ====================== TYPOGRAPGHY ==========================
// Body..
Crust_Customizer::add_field([
	'label'           => esc_html__('Body Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'settings'        => 'body_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => 'Google Fonts',
    'section'  => $section,
    'tab'      => 'body',
    'settings' => 'body_typo',
    'class'    => 'crust-pop-field',
    'default'     => [
	    'font-family'    => '',
	    'variant'        => '',
	    'font-size'      => '',
	    'line-height'    => '',
	    'letter-spacing' => '',
	    'color'          => '',
	    'text-transform' => '',
	    'text-align'     => '',
    ],
    'transport'   => 'auto',
    'output'      => [
	    [
		    'element' => 'body',
	    ],
    ],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Text Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'settings'        => 'body_dark_text_color',
	'type'            => 'color',
	'class'           => 'block-row crust-pop-field',
	'output'      => [
		[
			'element' => 'body.crust-dark, body.crust-dark .crust-main-wrap, body.crust-dark .swiper-pagination-fraction, body.crust-dark .crust-input-wrp:before',
			'property' => 'color'
		],
	],

	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'        => 'body_custom_font',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'default'         => 'objektiv-mk1, sans-serif',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'body_custom_font_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'body_custom_font',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'body',
			'property' => 'font-weight',
		],
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'body_custom_style',
	'label'           => esc_html__('Font Style', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'body_custom_font',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_font_style_choices(),
	'output'      => [
		[
			'element' => 'body',
			'property' => 'font-style',
		],
	],
] );

// Buttons
Crust_Customizer::add_field([
	'label'           => esc_html__('Buttons Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'settings'        => 'button_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => 'Google Fonts',
    'section'  => $section,
    'tab'      => 'body',
    'settings' => 'button_typo',
    'class'    => 'crust-pop-field',
    'default'     => [
        'font-family'    => 'Lexend',
        'variant'        => '',
        'font-size'      => '',
        'line-height'    => '',
        'letter-spacing' => '',
        'color'          => '',
        'text-transform' => '',
        'text-align'     => '',
    ],
    'transport'   => 'auto',
    'output'      => [
        [
            'element' => '.btn,.wp-block-search__button,.crust-btn,.crust-btn-underline,.wpcf7-submit',
        ],
    ],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Button Text Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'settings'        => 'button_dark_text_color',
	'type'            => 'color',
	'class'           => 'block-row crust-pop-field',
	'output'      => [
		[
			'element' => 'body.crust-dark .btn,body.crust-dark .wp-block-search__button,body.crust-dark .crust-btn,body.crust-dark .crust-btn-underline,body.crust-dark .wpcf7-submit',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );
Crust_Customizer::add_field([
	'settings'        => 'button_custom_typo',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'button_custom_typo_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'button_custom_typo',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => '.btn,.wp-block-search__button,.crust-btn',
			'property' => 'font-weight',
		],
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'button_custom_style',
	'label'           => esc_html__('Font Style', 'crust-core'),
	'section'         => $section,
	'tab'             => 'body',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'body_custom_typo',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_font_style_choices(),
	'output'      => [
		[
			'element' => '.btn,.wp-block-search__button,.crust-btn,.crust-btn-underline,.wpcf7-submit',
			'property' => 'font-style',
		],
	],
] );

// Headings..
Crust_Customizer::add_field([
	'label'           => esc_html__('All Headings Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'all_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => 'Lexend',
		'variant'        => '600',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h1, h2, h3, h4, h5, h6,h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,.woocommerce ul.products li.product .price, .woocommerce div.product p.price, 
			.woocommerce div.product span.price,.crust_woo_quick_view .woocommerce-Price-amount,.crust-hotspot-Title',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h1, body.crust-dark h2, body.crust-dark h3, body.crust-dark h4, body.crust-dark h5, body.crust-dark h6,
			body.crust-dark h1 a, body.crust-dark h2 a, body.crust-dark h3 a, body.crust-dark h4 a, body.crust-dark h5 a, body.crust-dark h6 a,
			body.crust-dark .woocommerce ul.products li.product .price, body.crust-dark .woocommerce div.product p.price, body.crust-dark .woocommerce div.product span.price,
			body.crust-dark .crust_woo_quick_view .woocommerce-Price-amount,body.crust-dark .crust-hotspot-Title',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'all_head_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'all_head_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'all_head_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h1, h2, h3, h4, h5, h6,.woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price,
			.crust_woo_quick_view .woocommerce-Price-amount,.crust-hotspot-Title',
			'property' => 'font-weight',
		],
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'all_head_custom_style',
	'label'           => esc_html__('Font Style', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'all_head_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_font_style_choices(),
	'output'      => [
		[
			'element' => 'h1, h2, h3, h4, h5, h6,.woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price,
			.crust_woo_quick_view .woocommerce-Price-amount,.crust-hotspot-Title',
			'property' => 'font-style',
		],
	],
] );

// H1 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H1 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h1_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H1 Typography',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h1_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h1',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h1_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h1',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h1_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h1_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h1_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h1',
			'property' => 'font-weight',
		],
	],
] );

// H2 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H2 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h2_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H2 Typography',
	'settings' => 'h2_typo',
	'section'  => $section,
	'tab'      => 'head',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h2',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h2_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h2',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h2_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h2_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h2_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h2',
			'property' => 'font-weight',
		],
	],
] );

// H3 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H3 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h3_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H3 Typography',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h3_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h3,.woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price,.crust_woo_quick_view .woocommerce-Price-amount,
			.crust-nav-single > div > a .post-title',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h3_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h3,body.crust-dark .woocommerce ul.products li.product .price, body.crust-dark .woocommerce div.product p.price,
			 body.crust-dark .woocommerce div.product span.price,body.crust-dark .crust_woo_quick_view .woocommerce-Price-amount,
			 body.crust-dark .crust-nav-single > div > a .post-title',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h3_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h3_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h3_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h3,.woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price,.crust_woo_quick_view .woocommerce-Price-amount,
			.crust-nav-single > div > a .post-title',
			'property' => 'font-weight',
		],
	],
] );

// H4 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H4 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h4_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H4 Typography',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h4_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h4',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h4_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h4',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h4_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h4_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h4_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h4',
			'property' => 'font-weight',
		],
	],
] );

// H5 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H5 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h5_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H5 Typography',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h5_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h5',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h5_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h5',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h5_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h5_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h5_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h5',
			'property' => 'font-weight',
		],
	],
] );

// H6 Typo
Crust_Customizer::add_field([
	'label'           => esc_html__('H6 Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h6_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'H6 Typography',
	'section'  => $section,
	'tab'      => 'head',
	'settings' => 'h6_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'h6,.bbp-forum-title,.crust-hotspot-Title',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'head',
	'settings'        => 'h6_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark h6,body.crust-dark .bbp-forum-title,body.crust-dark .crust-hotspot-Title',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'h6_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'h6_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'head',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'h6_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => 'h6,.bbp-forum-title,.crust-hotspot-Title',
			'property' => 'font-weight',
		],
	],
] );

// Page Title..
Crust_Customizer::add_field([
	'label'           => esc_html__('Title Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'settings'        => 'titl_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'titl',
	'settings' => 'title_typo',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'class'    => 'crust-pop-field',
	'output'      => [
		[
			'element' => '.crust-title-heading',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'titl',
	'settings'        => 'titl_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-title-heading',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'title_typo_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'title_typo_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'title_typo_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => '.crust-title-heading',
			'property' => 'font-weight',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Subtitle Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'settings'        => 'subtitl_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'titl',
	'settings' => 'subtitle_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-subtitle',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'titl',
	'settings'        => 'subtitle_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-subtitle',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'subtitle_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'subtitle_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'titl',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'subtitle_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => '.crust-subtitle',
			'property' => 'font-weight',
		],
	],
] );

if( class_exists( 'Tribe__Events__Main' ) ) {

	Crust_Customizer::add_field([
		'label'           => esc_html__('Body Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_body_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'Google Fonts',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_body_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => 'Manrope',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => 'body,.tribe-common .tribe-common-b2,.tribe-events .tribe-events-c-view-selector__list-item-text,.tribe-common .tribe-common-c-btn, .tribe-common a.tribe-common-c-btn,
				.tribe-common .tribe-common-c-btn-border-small, .tribe-common a.tribe-common-c-btn-border-small,.tribe-common--breakpoint-medium.tribe-common .tribe-common-form-control-text__input, 
				.tribe-common .tribe-common-form-control-text__input,.tribe-common .tribe-common-h7, .tribe-common .tribe-common-h8,.tribe-events .tribe-events-calendar-list__event-date-tag-weekday',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_custom_font',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_custom_font_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_custom_font',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common .tribe-common-b2,.tribe-events .tribe-events-c-view-selector__list-item-text,.tribe-common .tribe-common-c-btn, .tribe-common a.tribe-common-c-btn,
				.tribe-common .tribe-common-c-btn-border-small, .tribe-common a.tribe-common-c-btn-border-small,.tribe-common--breakpoint-medium.tribe-common .tribe-common-form-control-text__input, 
				.tribe-common .tribe-common-form-control-text__input,.tribe-common .tribe-common-h7, .tribe-common .tribe-common-h8,.tribe-events .tribe-events-calendar-list__event-date-tag-weekday',
				'property' => 'font-weight',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_custom_style',
		'label'           => esc_html__('Font Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_custom_font',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_font_style_choices(),
		'output'      => [
			[
				'element' => 'body',
				'property' => 'font-style',
			],
		],
	] );

// Headings..
	Crust_Customizer::add_field([
		'label'           => esc_html__('All Headings Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_all_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'Google Fonts',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => 'Poppins',
			'variant'        => '600',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h1,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h2,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h3,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h4,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h5,.tribe-common .tribe-events-calendar-list__month-separator-text,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h6,.tribe-common .tribe-common-b3,.tribe-events .tribe-events-c-ical__link,.tribe-events-calendar-day__type-separator-text.tribe-common-h6--min-medium',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_all_head_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_all_head_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_all_head_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h1,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h2,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h3,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h4,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h5,.tribe-common .tribe-events-calendar-list__month-separator-text,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h6,.tribe-common .tribe-common-b3,.tribe-events .tribe-events-c-ical__link,.tribe-events-calendar-day__type-separator-text.tribe-common-h6--min-medium',
				'property' => 'font-weight',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_all_head_custom_style',
		'label'           => esc_html__('Font Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_all_head_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_font_style_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h1,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h2,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h3,.tribe-common--breakpoint-medium.tribe-common .tribe-common-h4,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h5,.tribe-common .tribe-events-calendar-list__month-separator-text,
			.tribe-common--breakpoint-medium.tribe-common .tribe-common-h6,.tribe-common .tribe-common-b3,.tribe-events .tribe-events-c-ical__link,.tribe-events-calendar-day__type-separator-text.tribe-common-h6--min-medium',
				'property' => 'font-style',
			],
		],
	] );

// H1 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H1 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h1_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H1 Typography',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h1_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h1',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h1_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h1_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h1_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h1',
				'property' => 'font-weight',
			],
		],
	] );

// H2 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H2 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h2_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H2 Typography',
		'settings' => 'events_h2_typo',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h2',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h2_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h2_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h2_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h2',
				'property' => 'font-weight',
			],
		],
	] );

// H3 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H3 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h3_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H3 Typography',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h3_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h3',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h3_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h3_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h3_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h3',
				'property' => 'font-weight',
			],
		],
	] );

// H4 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H4 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h4_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H4 Typography',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h4_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h4',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h4_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h4_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h4_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h4',
				'property' => 'font-weight',
			],
		],
	] );

// H5 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H5 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h5_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H5 Typography',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h5_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h5,.tribe-common .tribe-events-calendar-list__month-separator-text',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h5_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h5_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h5_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h5,.tribe-common .tribe-events-calendar-list__month-separator-text',
				'property' => 'font-weight',
			],
		],
	] );

// H6 Typo
	Crust_Customizer::add_field([
		'label'           => esc_html__('H6 Typography', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'settings'        => 'events_h6_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => 'H6 Typography',
		'section'  => $section,
		'tab'      => 'eventstypo',
		'settings' => 'events_h6_typo',
		'class'    => 'crust-pop-field',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h6,.tribe-common .tribe-common-b3,.tribe-events .tribe-events-c-ical__link,.tribe-events-calendar-day__type-separator-text.tribe-common-h6--min-medium',
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h6_custom',
		'label'           => esc_html__('Custom Font', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'choices'         => crust_custom_fonts(),
	] );

	Crust_Customizer::add_field([
		'settings'        => 'events_h6_custom_weight',
		'label'           => esc_html__('Font Weight', 'crust-core'),
		'section'         => $section,
		'tab'             => 'eventstypo',
		'type'            => 'select',
		'class'           => 'block-row crust-pop-field',
		'active_callback' => [
			[
				'setting'  => 'events_h6_custom',
				'operator' => '!==',
				'value'    => '',
			]
		],
		'choices'  => crust_weight_choices(),
		'output'      => [
			[
				'element' => '.tribe-common--breakpoint-medium.tribe-common .tribe-common-h6,.tribe-common .tribe-common-b3,.tribe-events .tribe-events-c-ical__link,.tribe-events-calendar-day__type-separator-text.tribe-common-h6--min-medium',
				'property' => 'font-weight',
			],
		],
	] );
}
