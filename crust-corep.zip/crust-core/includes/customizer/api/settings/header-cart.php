<?php

defined('ABSPATH') || die();

$section = 'header';

if( class_exists( 'Woocommerce') ){

	Crust_Customizer::add_field([
		'settings'        => 'cart_padding',
		'type'            => 'crust-spacing',
		'label'           => esc_html__('Padding', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart',
				'property' => 'padding'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'cart_margin',
		'type'            => 'crust-spacing',
		'label'           => esc_html__('Margin', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart',
				'property' => 'margin'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_overlay_shape',
		'label'    => esc_html__('Box Shape ?', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'type'     => 'switch',
		'default'  => '1',
		'class'    => 'block-row'
	] );

	// Normal
	Crust_Customizer::add_field([
		'label'           => '',
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_tab_list',
		'type'            => 'crust-tab-list',
		'class'           => 'crust-tab-list',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Normal', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_normal',
		'type'            => 'crust-tab',
		'class'           => 'crust-tabs-head active',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart svg path',
				'property' => 'fill'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_number_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart b.cart-num,.crust-header-cart b.yith-num',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_number_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart b.cart-num,.crust-header-cart b.yith-num',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'border-width'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_border_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'border-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'type'     => 'select',
		'settings' => 'cart_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'border-style'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'border-radius'
			]
		],

	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'block-row crust-tabs-element bottom-shadow',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-header-cart > a',
				'property' => 'box-shadow'
			]
		],
	] );

	// Sticky
	Crust_Customizer::add_field([
		'label'           => esc_html__('Sticky', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky',
		'type'            => 'crust-tab',
		'class'           => 'crust-tabs-head',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart svg path',
				'property' => 'fill'
			]
		],

	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_number_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart b.cart-num',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_number_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart b.cart-num',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_sticky_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'border-width'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_border_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'border-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'type'     => 'select',
		'settings' => 'cart_sticky_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'border-style'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_sticky_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'border-radius'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_sticky_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'block-row crust-tabs-element bottom-shadow',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'box-shadow'
			]
		],

	] );

	// Hover
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover',
		'type'            => 'crust-tab',
		'class'           => 'crust-tabs-head',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover svg path','.crust-site-header.crust-sticky-head .crust-header-cart:hover svg path'],
				'property' => 'fill',
				'suffix' => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head:hover .crust-header-cart > a'],
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_number_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover b.cart-num','.crust-site-header.crust-sticky-head:hover .crust-header-cart b.cart-num'],
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_number_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover b.cart-num','.crust-site-header.crust-sticky-head:hover .crust-header-cart b.cart-num'],
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_hover_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'border-width'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_border_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'border-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'type'     => 'select',
		'settings' => 'cart_hover_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'border-style'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_hover_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'crust-tabs-element',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'border-radius'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'cart_hover_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'cart',
		'class'    => 'block-row crust-tabs-element bottom-shadow',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['.crust-header-cart:hover > a','.crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'box-shadow'
			]
		],
	] );

	//dark
	Crust_Customizer::add_field([
		'label'           => esc_html__('Dark Mode colors', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_normal_dark_head',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
		'active_callback' => [
			[
				'setting'  => 'dark_mode',
				'operator' => '===',
				'value'    => true,
			]
		]
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Normal', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'normal_cart_dark_head',
		'type'            => 'crust-label',
		'class'           => 'crust-pop-field',
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-header-cart svg path',
				'property' => 'fill'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_bg_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-header-cart > a',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_number_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-header-cart b.cart-num,.crust-header-cart b.yith-num',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_number_bg_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-header-cart b.cart-num,.crust-header-cart b.yith-num',
				'property' => 'background-color'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_border_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-header-cart > a',
				'property' => 'border-color'
			]
		]
	] );
///sticky dark
	Crust_Customizer::add_field([
		'label'           => esc_html__('Sticky', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'sticky_cart_dark_head',
		'type'            => 'crust-label',
		'class'           => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart svg path',
				'property' => 'fill'
			]
		],

	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_bg_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_number_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart b.cart-num',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_number_bg_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart b.cart-num',
				'property' => 'background-color'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_sticky_border_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart > a',
				'property' => 'border-color'
			]
		],
	] );
//hover dark
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'hover_cart_dark_head',
		'type'            => 'crust-label',
		'class'           => 'crust-pop-field',

	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['body.crust-dark .crust-header-cart:hover svg path','body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart:hover svg path'],
				'property' => 'fill',
				'suffix' => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_bg_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['body.crust-dark .crust-header-cart:hover > a','body.crust-dark .crust-site-header.crust-sticky-head:hover .crust-header-cart > a'],
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_number_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['body.crust-dark .crust-header-cart:hover b.cart-num','body.crust-dark .crust-site-header.crust-sticky-head:hover .crust-header-cart b.cart-num'],
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Number BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_number_bg_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['body.crust-dark .crust-header-cart:hover b.cart-num','body.crust-dark .crust-site-header.crust-sticky-head:hover .crust-header-cart b.cart-num'],
				'property' => 'background-color'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'cart',
		'settings'        => 'cart_hover_border_dark_color',
		'type'            => 'color',
		'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => ['body.crust-dark .crust-header-cart:hover > a','body.crust-dark .crust-site-header.crust-sticky-head .crust-header-cart:hover > a'],
				'property' => 'border-color'
			]
		],
	] );

}
