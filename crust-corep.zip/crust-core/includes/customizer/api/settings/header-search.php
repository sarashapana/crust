<?php

defined('ABSPATH') || die();

$section = 'header';

Crust_Customizer::add_field([
	'settings'        => 'search_margin',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Margin', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search',
			'property' => 'margin'
		],
		[
			'element' => '.crust-search-box',
			'property' => 'margin'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'search_padding',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Padding', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search > a',
			'property' => 'padding'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Icon Size ( PX )', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'srch_size',
	'type'            => 'crust-number',
	'class'           => 'block-row',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search svg',
			'property' => 'width',
			'suffix' => 'px'
		],
	]
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Overlay Settings', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'srch_over_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );


Crust_Customizer::add_field([
	'type'     => 'radio-buttonset',
	'settings' => 'crust_search_type',
	'label'    => esc_html__('Overlay Type', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'flex-row crust-pop-field',
	'default'  => 'creative',
	'choices'  => [
		'default' => esc_html__('Default', 'crust-core'),
		'creative'  => esc_html__('Creative', 'crust-core'),
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_overlay_shape',
	'label'    => esc_html__('Shape ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'crust_search_type',
			'operator' => '==',
			'value'    => 'default',
		]
	],
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'search_overlay_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'search',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'search_overlay_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'class'           => 'crust-pop-field',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'search_overlay_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-default-search-box .crust-search-box-wrap, .crust-creative-search-box',
			'property' => 'background-image',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'search_overlay_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'search',
	'class'       => 'crust-pop-field',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-default-search-box .crust-search-box-wrap, .crust-creative-search-box',
			'suffix'   => ' !important'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'search_overlay_bg_type',
			'operator' => '==',
			'value'    => 'image',
		],
	],
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Animated Shape Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'animated_srch_shape_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'crust_search_type',
			'operator' => '==',
			'value'    => 'creative',
		]
	],
	'output'   => [
		[
			'element' => '.crust-creative-search-overlay .crust-search-overlay-path',
			'property' => 'fill'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Custom Height ( % )', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'cusom_over_height',
	'type'            => 'slider',
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 100,
		'step' => 1,
	],
	'class'         => 'crust-pop-field',
	'output'        => [
		[
			'element' => '.crust-default-search-box .crust-search-box',
			'property' => 'height',
			'units'    => 'vh'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'crust_search_type',
			'operator' => '==',
			'value'    => 'default',
		]
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings' => 'search_overlay_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Padding', 'crust-core'),
	'transport' => 'auto',
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
		'%' => '%',
	],
	'output'   => [
		[
			'element' => '.crust-search-box-wrap',
			'property' => 'padding'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_overlay_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'transport' => 'auto',
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
		'%' => '%',
	],
	'output'   => [
		[
			'element' => '.crust-search-box-wrap',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_overlay_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'block-row crust-pop-field bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-search-box-wrap',
			'property' => 'box-shadow'
		]
	],
] );
//dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field'
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'search_overlay_bg_dark_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'search',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'search_overlay_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'class'           => 'crust-pop-field',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'search_overlay_bg_dark_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-default-search-box .crust-search-box-wrap,body.crust-dark .crust-creative-search-box',
			'property' => 'background-image',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'search_overlay_dark_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'search',
	'class'       => 'crust-pop-field',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-default-search-box .crust-search-box-wrap, body.crust-dark .crust-creative-search-box',
			'suffix'   => ' !important'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'search_overlay_bg_dark_type',
			'operator' => '==',
			'value'    => 'image',
		],
	],
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Animated Shape Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'animated_srch_shape_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'crust_search_type',
			'operator' => '==',
			'value'    => 'creative',
		]
	],
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-creative-search-overlay .crust-search-overlay-path',
			'property' => 'fill'
		]
	],
] );
////
Crust_Customizer::add_field([
	'label'           => esc_html__('Close Box Button Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'top_search_btn_close_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-tabs-element',
	'output'   => [
		[
			'element' => '.crust-search-box .crust-close-search',
			'property' => 'color'
		]
	],
] );
///dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Close Box Button Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'top_search_btn_close_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-tabs-element',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-search-box .crust-close-search',
			'property' => 'color'
		]
	],
] );
// Normal
Crust_Customizer::add_field([
	'label'           => '',
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_tab_list',
	'type'            => 'crust-tab-list',
	'class'           => 'crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_normal',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head active',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'search',
    'settings'        => 'search_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker crust-tabs-element',
    'transport'       => 'auto',
    'output'   => [
    	[
		    'element' => '.crust-site-header:not(.crust-sticky-head) .crust-header-search svg path',
		    'property' => 'fill'
	    ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'search',
    'settings'        => 'search_bg_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 crust-tabs-element',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust-header-search > a',
		    'property' => 'background-color'
	    ]
    ]
] );

Crust_Customizer::add_field([
	'settings' => 'search_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search > a',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Border Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'search',
    'settings'        => 'search_border_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust-header-search > a',
		    'property' => 'border-color'
	    ]
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'type'     => 'select',
	'settings' => 'search_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search > a',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search > a',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-search > a',
			'property' => 'box-shadow'
		]
	],
] );

// Sticky
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search svg path',
			'property' => 'fill'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_sticky_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'type'     => 'select',
	'settings' => 'search_sticky_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_sticky_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_sticky_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'box-shadow'
		]
	],
] );

// Hover
Crust_Customizer::add_field([
	'label'           => esc_html__('Hover', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header:not(.crust-sticky-head) .crust-header-search:hover svg path',
			'property' => 'fill',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_hover_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'type'     => 'select',
	'settings' => 'search_hover_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_hover_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'search_hover_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'search',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-header-search > a:hover','.crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'box-shadow'
		]
	],
] );
///dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_normal_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'normal_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header:not(.crust-sticky-head) .crust-header-search svg path',
			'property' => 'fill'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-header-search > a',
			'property' => 'background-color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_border_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-header-search > a',
			'property' => 'border-color'
		]
	],
] );
///sticky dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'sticky_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-search svg path',
			'property' => 'fill'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'background-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_sticky_border_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-header-search > a',
			'property' => 'border-color'
		]
	],
] );
//hover dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Hover', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'hover_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',

] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header:not(.crust-sticky-head) .crust-header-search:hover svg path',
			'property' => 'fill',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-header-search > a:hover','body.crust-dark .crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'background-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'search',
	'settings'        => 'search_hover_border_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-header-search > a:hover','body.crust-dark .crust-site-header.crust-sticky-head .crust-header-search > a:hover'],
			'property' => 'border-color'
		]
	],
] );