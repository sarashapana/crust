<?php

defined('ABSPATH') || die();

$section = 'title';

// ==================== PAGE TITLE ========================
Crust_Customizer::add_field([
    'settings' => 'show_title',
    'label'    => esc_html__('Show Page Title', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'type'     => 'switch',
    'class'    => 'block-row',
    'default'  => true,
] );

Crust_Customizer::add_field([
	'settings'        => 'before_title_template',
	'label'           => esc_html__('Content Before', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'select',
	'class'           => 'block-row',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
    'type'     => 'radio-buttonset',
    'settings' => 'title_type',
    'label'    => esc_html__('Type', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'class'    => 'flex-row',
    'default'  => 'default',
    'transport'=> 'auto',
    'choices'  => [
        'default' => esc_html__('Default', 'crust-core'),
        'custom'  => esc_html__('Custom', 'crust-core'),
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'title_template',
    'label'           => esc_html__('Choose Template', 'crust-core'),
    'section'         => $section,
    'tab'             => 'settings',
    'type'            => 'select',
    'class'           => 'block-row',
    'choices'         => crust_post_type_posts( 'crust_modules' ),
    'active_callback' => [
	    [
		    'setting'  => 'title_type',
		    'operator' => '==',
		    'value'    => 'custom',
	    ]
    ]
] );

$default_title = [
	[
		'setting'  => 'title_type',
		'operator' => '==',
		'value'    => 'default',
	]
];

Crust_Customizer::add_field([
    'type'            => 'crust-icon-radio',
    'settings'        => 'title_align',
    'label'           => esc_html__('Alignment', 'crust-core'),
    'section'         => $section,
    'class'           => 'block-row',
    'tab'             => 'settings',
    'default'         => 'center',
    'choices'         => [
        ''       => 'dashicons dashicons-editor-alignleft',
        'center' => 'dashicons dashicons-editor-aligncenter',
        'right'  => 'dashicons dashicons-editor-alignright',
    ],
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'settings' => 'title_components',
    'label'    => esc_html__('Components', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'type'     => 'crust-label',
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'settings' => 'title_on',
    'label'    => esc_html__('Title', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'type'     => 'checkbox',
    'default'  => '1',
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'settings' => 'subtitle_on',
    'label'    => esc_html__('Subtitle', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'type'     => 'checkbox',
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'settings' => 'breadcrumbs_on',
    'label'    => esc_html__('Breadcrumbs', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'type'     => 'checkbox',
    'default'  => '1',
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'title_tag',
	'label'           => esc_html__('Title Tag', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'default'         => 'h1',
	'choices'         => [
		'h1'  => esc_html__('H1', 'crust-core'),
		'h2'  => esc_html__('H2', 'crust-core'),
		'h3'  => esc_html__('H3', 'crust-core'),
		'h4'  => esc_html__('H4', 'crust-core'),
		'h5'  => esc_html__('H5', 'crust-core'),
		'h6'  => esc_html__('H6', 'crust-core'),
		'p'   => esc_html__('p', 'crust-core'),
		'div' => esc_html__('div', 'crust-core'),
	],
	'class'           => 'block-row',
	'active_callback' => $default_title
] );

Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'subtitle_tag',
	'label'           => esc_html__('SubTitle Tag', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'default'         => 'h3',
	'choices'         => [
		'h1'  => esc_html__('H1', 'crust-core'),
		'h2'  => esc_html__('H2', 'crust-core'),
		'h3'  => esc_html__('H3', 'crust-core'),
		'h4'  => esc_html__('H4', 'crust-core'),
		'h5'  => esc_html__('H5', 'crust-core'),
		'h6'  => esc_html__('H6', 'crust-core'),
		'p'   => esc_html__('p', 'crust-core'),
		'div' => esc_html__('div', 'crust-core'),
	],
	'class'           => 'block-row',
	'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'type'     => 'radio-buttonset',
    'settings' => 'title_height',
    'label'    => esc_html__('Height', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'class'    => 'block-row',
    'choices'  => [
	    '' => esc_html__('Auto', 'crust-core'),
        'custom' => esc_html__('Custom', 'crust-core'),
        'full'   => esc_html__('Full', 'crust-core'),
    ],
    'active_callback' => $default_title
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Custom Height (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'settings',
    'settings'        => 'cusom_title_height',
    'type'            => 'slider',
    'active_callback' => [
	    [
		    'setting'  => 'title_height',
		    'operator' => '==',
		    'value'    => 'custom',
	    ]
    ],
    'input_attrs'     => [
        'min'  => 0,
        'max'  => 1200,
        'step' => 1,
    ],
    'output'      => [
	    [
		    'element' => ' .crust-page-title > .container',
		    'property' => 'min-height',
		    'units'    => 'px',
		    'suffix' => ' !important'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings' => 'custom_title_shape',
	'label'    => esc_html__('Custom Title Shape ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'class'    => 'block-row',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Base color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'title_base_color',
	'type'     => 'color',
	'class'    => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'custom_title_shape',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-title .crust-title-svg .crust-base-fill',
			'property' => 'fill',
		],
	],
] );
//dark
Crust_Customizer::add_field([
	'label'    => esc_html__('Dark Base color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'title_base_dark_color',
	'type'     => 'color',
	'class'    => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'custom_title_shape',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title .crust-title-svg .crust-base-fill',
			'property' => 'fill',
		],
	],
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Layer color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'title_layer_color',
	'type'     => 'color',
	'class'    => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'custom_title_shape',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-title .crust-title-gradient',
			'property' => 'fill',
		],
	],
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Dark Layer color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'title_layer_dark_color',
	'type'     => 'color',
	'class'    => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'custom_title_shape',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title .crust-title-gradient',
			'property' => 'fill',
		],
	],
] );

Crust_Customizer::add_field([
    'settings'        => 'after_title_template',
    'label'           => esc_html__('Content After', 'crust-core'),
    'section'         => $section,
    'tab'             => 'settings',
    'type'            => 'select',
    'class'           => 'block-row',
    'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
	'settings' => 'disable_default_bg',
	'label'    => esc_html__('Disable Default Background', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'type'     => 'switch',
	'class'    => 'block-row',
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'title_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'styling',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'active_callback' => $default_title
] );

Crust_Customizer::add_field([
	'settings'        => 'title_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'title_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-title',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'title_bg',
	'label'       => '',
	'section'  => $section,
	'tab'      => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-title',
			'suffix'   => ' !important'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'title_bg_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
]);

Crust_Customizer::add_field([
	'settings' => 'title_parallax',
	'label'    => esc_html__('Parallax Image ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'type'     => 'checkbox',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Image', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'title_parallax_image',
	'type'            => 'crust-image',
	'active_callback' => [
		[
			'setting'  => 'title_parallax',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Opacity (0-1)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'parallax_opacity',
	'type'            => 'crust-number',
	'active_callback' => [
		[
			'setting'  => 'title_parallax_image',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'default'          => .5,
	'class'    => 'block-row',
	'output'      => [
		[
			'element' => '.crust-page-title > .crust-section-bg',
			'property' => 'opacity',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'settings' => 'title_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'output'      => [
	    [
		    'element' => '.crust-page-title',
		    'property' => 'margin'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'settings'    => 'title_padding',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'tab'         => 'styling',
    'input_attrs' => [
        'min' => 0,
    ],
    'output'      => [
	    [
		    'element' => '.crust-page-title > .container',
		    'property' => 'padding',
		    'suffix' => ' !important'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'    => 'title_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border Width', 'crust-core'),
	'section'     => $section,
	'tab'         => 'styling',
	'transport'   => 'auto',
	'input_attrs' => [
		'min' => 0,
	],
	'output'   => [
		[
			'element' => '.crust-page-title',
			'property' => 'border-width'
		]
	]
] );


Crust_Customizer::add_field([
	'settings' => 'title_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'transport' => 'auto',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
		'%' => '%',
	],
	'output'   => [
		[
			'element' => '.crust-page-title',
			'property' => 'border-radius'
		]
	],
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'colums2 bottom-picker',
	'settings' => 'title_border_color',
	'transport' => 'auto',
	'type'     => 'color',
	'output'   => [
		[
			'element' => '.crust-page-title',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'type'     => 'select',
	'settings' => 'title_border_type',
	'choices'  => crust_border_type(),
	'transport' => 'auto',
	'class'    => 'colums2',
	'output'   => [
		[
			'element' => '.crust-page-title',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'title_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'transport' => 'auto',
	'class'    => 'block-row bottom-shadow',
	'output'   => [
		[
			'element' => '.crust-page-title',
			'property' => 'box-shadow'
		]
	],
] );
//dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'page_title_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'title_bg_dark_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'styling',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'active_callback' => $default_title
] );

Crust_Customizer::add_field([
	'settings'        => 'title_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-gradient',
	'class'    => 'crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'title_bg_dark_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'title_dark_bg',
	'label'       => '',
	'section'  => $section,
	'class'    => 'crust-pop-field',
	'tab'      => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title',
			'suffix'   => ' !important'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'title_bg_dark_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'block-row bottom-picker crust-pop-field',
	'settings' => 'title_border_dark_color',
	'transport' => 'auto',
	'type'     => 'color',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-page-title',
			'property' => 'border-color'
		]
	]
] );
// Breadcrumbs...
Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Typography',
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'settings' => 'breadcrumbs_typo',
	'class'    => 'crust-pop-typo',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs',
		],
	],
] );

//dark typo
Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Dark Typography',
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'settings' => 'breadcrumbs_dark_typo',
	'class'    => 'crust-pop-field',
	'type'     => 'color',
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title .crust-breadcrumbs',
			'property' => 'color'
		],
	],
] );
///
Crust_Customizer::add_field([
    'type'     => 'text',
    'settings' => 'crumbs_prefix',
    'label'    => esc_html__('Prefix', 'crust-core'),
    'section'  => $section,
    'class'    => 'block-row',
    'tab'      => 'breadcrumbs',
] );

Crust_Customizer::add_field([
    'type'     => 'text',
    'settings' => 'crumbs_suffix',
    'label'    => esc_html__('Suffix', 'crust-core'),
    'section'  => $section,
    'class'    => 'block-row',
    'tab'      => 'breadcrumbs',
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Position', 'crust-core'),
    'section'  => $section,
    'tab'      => 'breadcrumbs',
    'type'     => 'select',
    'settings' => 'crumbs_position',
    'choices'  => [
        'static' => esc_html__('Default', 'crust-core'),
        'absolute' => esc_html__('Absolute', 'crust-core')
    ],
    'class'    => 'block-row',
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => '.crust-page-title .crust-breadcrumbs',
            'property' => 'position'
        ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Top (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'breadcrumbs',
    'settings'        => 'breadcrumbs_top',
    'type'            => 'crust-number',
    'active_callback' => [
        [
            'setting'  => 'crumbs_position',
            'operator' => '==',
            'value'    => 'absolute',
        ]
    ],
    'class'    => 'block-row',
    'output'      => [
        [
            'element' => '.crust-page-title .crust-breadcrumbs',
            'property' => 'top',
            'units'    => 'px'
        ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Right (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'breadcrumbs',
    'settings'        => 'breadcrumbs_right',
    'type'            => 'crust-number',
    'active_callback' => [
        [
            'setting'  => 'crumbs_position',
            'operator' => '==',
            'value'    => 'absolute',
        ]
    ],
    'class'    => 'block-row',
    'output'      => [
        [
            'element' => '.crust-page-title .crust-breadcrumbs',
            'property' => 'right',
            'units'    => 'px'
        ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Bottom (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'breadcrumbs',
    'settings'        => 'breadcrumbs_bottom',
    'type'            => 'crust-number',
    'active_callback' => [
        [
            'setting'  => 'crumbs_position',
            'operator' => '==',
            'value'    => 'absolute',
        ]
    ],
    'class'    => 'block-row',
    'output'      => [
        [
            'element' => '.crust-page-title .crust-breadcrumbs',
            'property' => 'bottom',
            'units'    => 'px'
        ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Left (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'breadcrumbs',
    'settings'        => 'breadcrumbs_left',
    'type'            => 'crust-number',
    'active_callback' => [
        [
            'setting'  => 'crumbs_position',
            'operator' => '==',
            'value'    => 'absolute',
        ]
    ],
    'class'    => 'block-row',
    'output'      => [
        [
            'element' => '.crust-page-title .crust-breadcrumbs',
            'property' => 'left',
            'units'    => 'px'
        ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Background Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'class'    => 'block-row',
	'settings' => 'crumbs_bg_color',
	'transport'   => 'auto',
	'type'     => 'color',
	'output'   => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs > ul',
			'property' => 'background-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'settings' => 'crumbs_link_color',
	'type'     => 'color',
	'class'    => 'block-row',
	'output'      => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs a',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'    => 'crumbs_padding',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Padding', 'crust-core'),
	'section'     => $section,
	'tab'         => 'breadcrumbs',
	'input_attrs' => [
		'min' => 0,
	],
	'transport'   => 'auto',
	'output'   => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs > ul',
			'property' => 'padding'
		]
	]
] );

Crust_Customizer::add_field([
	'settings'    => 'crumbs_margin',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Margin', 'crust-core'),
	'section'     => $section,
	'tab'         => 'breadcrumbs',
	'transport'   => 'auto',
	'output'   => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs > ul',
			'property' => 'margin'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crumbs_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'transport'   => 'auto',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-page-title .crust-breadcrumbs > ul',
			'property' => 'border-radius'
		]
	],
] );
//dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'breadcrumbs',
	'settings'        => 'breadcrumbs_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Background Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'class'    => 'block-row column2 crust-pop-field',
	'settings' => 'crumbs_bg_dark_color',
	'transport'   => 'auto',
	'type'     => 'color',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-page-title .crust-breadcrumbs > ul',
			'property' => 'background-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'breadcrumbs',
	'settings' => 'crumbs_link_dark_color',
	'type'     => 'color',
	'class'    => 'block-row column2 crust-pop-field',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-title .crust-breadcrumbs a',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );
Crust_Customizer::add_field([
    'settings' => 'crumbs_tablet_off',
    'label'    => esc_html__('Hide on tablet', 'crust-core'),
    'section'  => $section,
    'tab'      => 'breadcrumbs',
    'type'     => 'switch',
    'class'    => 'colums2',
] );

Crust_Customizer::add_field([
    'settings' => 'crumbs_mobile_off',
    'label'    => esc_html__('Hide on mobile', 'crust-core'),
    'section'  => $section,
    'tab'      => 'breadcrumbs',
    'type'     => 'switch',
    'class'    => 'colums2',
] );
