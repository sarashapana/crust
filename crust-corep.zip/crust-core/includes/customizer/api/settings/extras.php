<?php

defined('ABSPATH') || die();

if( function_exists('is_bbpress') ){
	Crust_Customizer::add_field([
		'settings' => 'show_bbp_message',
		'label'    => esc_html__('Show Welcome Message', 'crust-core'),
		'section'  => 'crust-bbpress',
		'tab'      => 'general',
		'class'    => 'block-row',
		'type'     => 'switch',
		'default'  => '1',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'welcome_bb',
		'label'           => esc_html__('Copyrights', 'crust-core'),
		'section'         => 'crust-bbpress',
		'tab'             => 'general',
		'type'            => 'textarea',
		'default'         => 'Welcome to our Forums! We love to have you part of our friendly community, discovering the best in everything. As a member, the system will remember where you left off in threads and with sufficient post count.',
		'input_attrs'     => array(
			'toolbar1'     => 'bold italic bullist numlist alignleft aligncenter alignright link',
			'mediaButtons' => true,
		),
		'active_callback' => [
			[
				'setting'  => 'show_bbp_message',
				'operator' => '==',
				'value'    => '1',
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'show_bbp_stats',
		'label'    => esc_html__('Show Bottom Stats', 'crust-core'),
		'section'  => 'crust-bbpress',
		'tab'      => 'general',
		'class'    => 'block-row',
		'type'     => 'switch',
		'default'  => '1',
	] );
}

