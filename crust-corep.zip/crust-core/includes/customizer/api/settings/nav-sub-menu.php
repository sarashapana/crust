<?php

defined('ABSPATH') || die();

$section = 'navmenu';

Crust_Customizer::add_field([
	'label'           => esc_html__('Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_typo_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'settings' => 'submenu_typo',
	'tab'      => 'submenu',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'class'    => 'crust-pop-field',
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-site-navigation ul.sub-menu li > a',
		],
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'submenu_typo_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

/* Wrapper */
Crust_Customizer::add_field([
	'label'           => esc_html__('Wrapper', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'sub_menu_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Menu Item Width (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'men_item_width',
	'type'            => 'number',
	'class'           => 'crust-pop-field block-row',
	'output'      => [
		[
			'element' => '.crust-site-navigation .crust-submenu-wrap',
			'property' => 'width',
			'units'    => 'px',
			'suffix' => ' !important'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'        => 'mega_full',
	'label'           => esc_html__('Full Width Mega Menu', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'type'            => 'switch',
	'class'           => 'crust-pop-field block-row',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Mega Menu Max Width', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'mega_menu_width',
	'type'            => 'slider',
	'class'           => 'crust-pop-field',
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 1920,
		'step' => 1,
	],
	'output'      => [
		[
			'element' => '.crust-site-navigation li.mega-menu > .crust-submenu-wrap',
			'property' => 'width',
			'units'    => 'px',
			'suffix' => ' !important'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'        => 'submenu_wrap_margin',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Margin', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'class'           => 'crust-pop-field',
	'units'           => [
		'px' => 'px',
		'%' => '%',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-navigation .crust-submenu-box',
			'property' => 'margin'
		]
	],

] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Background Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_wrap_bg_color',
	'type'            => 'color',
	'class'           => 'block-row crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'background-color'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_wrapper_border',
	'type'     => 'crust-spacing',
	'class'    => 'crust-pop-field',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_wrapper_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-pop-field right-picker bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'type'     => 'select',
	'settings' => 'submenu_wrapper_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_wrapper_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Wrapper Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_wrapper_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-site-navigation .crust-submenu-box','.crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'box-shadow'
		]
	],

] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_wrap_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Background Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_dark_wrap_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-site-navigation .crust-submenu-box','body.crust-dark .crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'background-color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_dark_wrapper_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-pop-field right-picker bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-site-navigation .crust-submenu-box','body.crust-dark .crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu'],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'submenu_margin',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Margin', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'units'           => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-navigation ul.sub-menu li',
			'property' => 'margin'
		]
	],

] );

Crust_Customizer::add_field([
	'settings'        => 'submenu_padding',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Padding', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'units'           => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-navigation ul.sub-menu li',
			'property' => 'padding'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Mega Menu Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'mega_headings_color',
	'type'            => 'color',
	'class'           => 'block-row',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation > ul > li.mega-menu > .crust-submenu-wrap > .crust-submenu-box > ul.sub-menu > li > a'
			],
			'property' => 'color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mega Menu Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'mega_dark_headings_color',
	'type'            => 'color',
	'class'           => 'block-row',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation > ul > li.mega-menu > .crust-submenu-wrap > .crust-submenu-box > ul.sub-menu > li > a'
			],
			'property' => 'color'
		]
	],
] );

// Normal
Crust_Customizer::add_field([
	'label'           => '',
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_tab_list',
	'type'            => 'crust-tab-list',
	'class'           => 'crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_normal',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head active',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'submenu',
    'settings'        => 'submenu_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker crust-tabs-element',
    'transport'       => 'auto',
    'output'   => [
    	[
		    'element' => [
		        '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
		    'property' => 'color'
	    ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'submenu',
    'settings'        => 'submenu_bg_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 crust-tabs-element',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => [
		        '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
		    'property' => 'background-color'
	    ]
    ]
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Border Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'submenu',
    'settings'        => 'submenu_border_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => [
		        '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
		    'property' => 'border-color'
	    ]
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'type'     => 'select',
	'settings' => 'submenu_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-navigation li ul.sub-menu li a',
                '.crust-site-navigation li .mega-content li a'
            ],
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_normal_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_normal_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation li ul.sub-menu li a',
				'body.crust-dark .crust-site-navigation li .mega-content li a'
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_normal_dark_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation li ul.sub-menu li a',
				'body.crust-dark .crust-site-navigation li .mega-content li a'
			],
			'property' => 'background-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_normal_dark_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation li ul.sub-menu li a',
				'body.crust-dark .crust-site-navigation li .mega-content li a'
			],
			'property' => 'border-color'
		]
	],
] );

// Sticky
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'          => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'          => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_sticky_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'type'     => 'select',
	'settings' => 'submenu_sticky_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_sticky_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_sticky_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
			    '.crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
                '.crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
            ],
			'property' => 'box-shadow'
		]
	],

] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'          => [
		[
			'element' => [
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_dark_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'          => [
		[
			'element' => [
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
			],
			'property' => 'background-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_sticky_dark_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li ul.sub-menu',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation li .mega-content'
			],
			'property' => 'border-color'
		]
	],
] );

// Hover
Crust_Customizer::add_field([
	'label'           => esc_html__('Hover', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a > span',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a > span',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a > span',
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_hover_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'type'     => 'select',
	'settings' => 'submenu_hover_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_hover_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'submenu_hover_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'submenu',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li:hover > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'.crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation ul.sub-menu li:hover > a > span',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-parent > a > span',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-item > a > span',
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_dark_bg_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation ul.sub-menu li:hover > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li:hover > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'submenu',
	'settings'        => 'submenu_hover_dark_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-navigation ul.sub-menu li:hover > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li:hover > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-parent > a',
				'body.crust-dark .crust-site-navigation ul.sub-menu li.current-menu-item > a',
			],
			'property' => 'border-color'
		]
	],
] );
