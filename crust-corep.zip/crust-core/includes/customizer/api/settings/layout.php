<?php

defined('ABSPATH') || die();

$section = 'layout';

// ==================== Sidebars ========================
Crust_Customizer::add_field([
	'settings'        => 'layout_content',
	'label'           => esc_html__('Content Wrapper', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-label',
] );

Crust_Customizer::add_field([
	'settings' => 'container_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Main Container Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body:not(.elementor_library-template-default) .site-main.crust-content-wrap',
			'property' => 'margin',
		],
	],
]);

Crust_Customizer::add_field([
	'settings' => 'content_wrap_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Wrapper Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'margin',
		],
	],
]);

Crust_Customizer::add_field([
	'settings'    => 'content_wrap_padding',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Padding', 'crust-core'),
	'section'     => $section,
	'tab'         => 'styling',
	'input_attrs' => [
		'min' => 0,
	],
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'padding',
		],
	],
	'transport'   => 'auto',
]);

// Boxed Styles...
Crust_Customizer::add_field([
	'settings' => 'content_wrap_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'border-width',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'colums2 right-picker block-row',
	'settings' => 'content_wrap_border_color',
	'type'     => 'color',
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'border-color',
		],
	],
	'transport'   => 'auto',
]);
//dark
Crust_Customizer::add_field([
	'label'    => esc_html__('Dark Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'colums2 right-picker block-row',
	'settings' => 'content_wrap_border_dark_color',
	'type'     => 'color',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-archive-wrapper', 'body.crust-dark .crust-single-wrapper', 'body.crust-dark .crust-post-wrapper'],
			'property' => 'border-color',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'type'     => 'crust-select',
	'settings' => 'content_wrap_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row',
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'border-style',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'settings' => 'content_wrap_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'units'    => [
		'px' => 'px',
	],
	'transport' => 'auto',
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'border-radius',
		],
	],
]);

Crust_Customizer::add_field([
	'settings' => 'content_wrap_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'block-row',
	'output'   => [
		[
			'element' => ['.crust-archive-wrapper', '.crust-single-wrapper', '.crust-post-wrapper'],
			'property' => 'box-shadow',
		],
	],
	'transport'   => 'auto',
]);

// Sidebars...
Crust_Customizer::add_field([
	'settings'        => 'sticky_sidebar',
	'label'           => esc_html__('Sticky ?', 'crust-core'),
	'section'         => $section,
	'tab'             => 'sidebars',
	'type'            => 'switch',
	'class'           => 'block-row'
] );

Crust_Customizer::add_field([
	'settings'    => 'sidebar_width',
	'label'       => esc_html__('Sidebar Width (%)', 'crust-core'),
	'section'     => $section,
	'tab'         => 'sidebars',
	'type'        => 'slider',
	'default'     => 25,
	'input_attrs' => [
		'min'  => 0,
		'max'  => 100,
		'step' => 1,
	],
	'output'   => [
		[
			'element'  => '.crust-sidebar',
			'property' => 'max-width',
			'units' => '%',
		],
		[
			'element' => '.crust-sidebar',
			'property' => 'flex',
			'units' => '%',
		],
		[
			'element' => ['.crust-archive-wrapper:not(.col-lg-12)', '.crust-portfolio-archive-wrapper:not(.col-lg-12)', '.crust-single-wrapper:not(.col-lg-12)', '.crust-post-wrapper:not(.col-lg-12)'],
			'property' => 'flex',
			'value_pattern' => '0 0 calc(100% - $%)',
		],
		[
			'element' => ['.crust-archive-wrapper:not(.col-lg-12)', '.crust-portfolio-archive-wrapper:not(.col-lg-12)', '.crust-single-wrapper:not(.col-lg-12)', '.crust-post-wrapper:not(.col-lg-12)'],
			'property' => 'max-width',
			'value_pattern' => 'calc(100% - $%)',
		]
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'settings' => 'sidebar_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Sidebar Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'sidebars',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar',
			'property' => 'margin',
		],
	],
]);
Crust_Customizer::add_field([
    'label'    => esc_html__('Archive Sidebar', 'crust-core'),
    'section'  => $section,
    'tab'      => 'sidebars',
    'type'     => 'crust-image-radio',
    'default'  => 'right',
    'settings' => 'archive_sidebar',
    'choices'  => [
        'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
        'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
        'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Single Sidebar', 'crust-core'),
    'section'  => $section,
    'tab'      => 'sidebars',
    'type'     => 'crust-image-radio',
    'default'  => 'right',
    'settings' => 'single_sidebar',
    'choices'  => [
        'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
        'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
        'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Page Sidebar', 'crust-core'),
    'section'  => $section,
    'tab'      => 'sidebars',
    'type'     => 'crust-image-radio',
    'default'  => 'none',
    'settings' => 'page_sidebar',
    'choices'  => [
        'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
        'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
        'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
    ]
] );

// Headings
Crust_Customizer::add_field([
	'label'           => esc_html__('Widget Heading', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'wid_heading_opts',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Typography',
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_head_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
		],
	],
] );
//dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Typography Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'crst_widget_head_dark_typo',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_head_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'class'    => 'crust-pop-field',
	'tab'      => 'widgets',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'margin'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_head_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Padding', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'padding'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_head_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'crust-pop-field',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_head_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'settings' => 'crst_widget_head_color',
    'class'    => 'colums3 block-row right-picker crust-pop-field bottom-picker',
    'type'     => 'color',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-sidebar .crust-widget h2.widgettitle',
		    'property' => 'color'
	    ]
    ],
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('BG Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'settings' => 'crst_widget_head_bg_color',
    'class'    => 'colums3 block-row crust-pop-field bottom-picker',
    'type'     => 'color',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-sidebar .crust-widget h2.widgettitle',
		    'property' => 'background-color'
	    ]
    ],
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'settings' => 'crst_widget_head_border_color',
    'class'    => 'colums3 block-row crust-pop-field bottom-picker',
    'type'     => 'color',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-sidebar .crust-widget h2.widgettitle',
		    'property' => 'border-color'
	    ]
    ],
] );


Crust_Customizer::add_field([
	'settings' => 'crst_widget_head_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'box-shadow'
		]
	],
] );
///dark

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'widgets_dark_head',
	'type'            => 'crust-label',
	'class'    => 'crust-pop-field',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_head_dark_color',
	'class'    => 'crust-pop-field colums3 block-row right-picker crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('BG Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_head_bg_dark_color',
	'class'    => 'crust-pop-field colums3 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_head_border_dark_color',
	'class'    => 'crust-pop-field colums3 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget h2.widgettitle',
			'property' => 'border-color'
		]
	],
] );

// Content
Crust_Customizer::add_field([
	'label'           => esc_html__('Content', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'widget_opts',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Typography',
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar .crust-widget',
		],
	],
] );
//dark typography

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Typography Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'crst_widget_dark_typo',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'class'    => 'crust-pop-field',
	'tab'      => 'widgets',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'margin',
			'suffix' => '!important'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'crust-pop-field',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'border-width',
			'suffix' => '!important'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'class'    => 'crust-pop-field',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget,.crust-sidebar .crust-widget .banner_img',
			'property' => 'border-radius',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'type'     => 'select',
	'settings' => 'crst_widget_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'border-style',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Background Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_bg_color',
	'class'    => 'block-row colums2 crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'background-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Links Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'settings' => 'crst_widget_link_color',
    'class'    => 'colums3 block-row crust-pop-field right-picker bottom-picker',
    'type'     => 'color',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-sidebar .crust-widget a',
		    'property' => 'color',
		    'suffix' => '!important'
	    ]
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_border_color',
	'class'    => 'colums3 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Dividers Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_dividers_color',
	'class'    => 'colums3 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-sidebar .crust-widget ul li',
			'property' => 'border-top-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'crst_widget_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sidebar .crust-widget',
			'property' => 'box-shadow',
			'suffix' => '!important'
		]
	],
] );
//dark

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'menu_dark_widget_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field'
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Background Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_bg_dark_color',
	'class'    => 'crust-pop-field block-row colums2 crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget',
			'property' => 'background-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_link_dark_color',
	'class'    => 'crust-pop-field colums2 block-row crust-pop-field right-picker bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget a',
			'property' => 'color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_border_dark_color',
	'class'    => 'crust-pop-field colums2 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Dividers Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'settings' => 'crst_widget_dividers_dark_color',
	'class'    => 'crust-pop-field colums2 block-row crust-pop-field bottom-picker',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sidebar .crust-widget ul li',
			'property' => 'border-top-color',
			'suffix' => '!important'
		]
	],
] );
Crust_Customizer::add_field([
	'settings'    => 'limit_tags',
	'label'       => esc_html__('Tags Limit', 'crust-core'),
	'section'     => $section,
	'tab'         => 'widgets',
	'type'        => 'slider',
	'default'     => '20',
	'input_attrs' => [
		'min'  => 0,
		'max'  => 500,
		'step' => 1,
	],
]);


