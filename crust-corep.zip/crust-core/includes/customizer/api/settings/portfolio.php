<?php

defined('ABSPATH') || die();

$section = 'portfolio';

if ( crust_core_get_option('crust_portfolio_option') == 'yes') {

	Crust_Customizer::add_field([
		'type'            => 'radio-buttonset',
		'settings'        => 'portfolio_archive_style',
		'label'           => esc_html__('Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'default'         => 'grid',
		'choices'         => [
			'grid'    => esc_html__('Grid', 'crust-core'),
			'masonry' => esc_html__('Masonry', 'crust-core'),
			//'classic' => esc_html__('Classic', 'crust-core'),
			//'list'    => esc_html__('List', 'crust-core'),
		],
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_pages_num',
		'label'           => esc_html__('Posts Per Page', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'number',
		'default'         => '10',
		'class'           => 'block-row'
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_columns',
		'label'           => esc_html__('Columns', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'radio-buttonset',
		'default'         => '3',
		'choices'         => [
			'2'    => esc_html__('2 Columns', 'crust-core'),
			'3'    => esc_html__('3 Columns', 'crust-core'),
			'4'    => esc_html__('4 Columns', 'crust-core'),
			'5'    => esc_html__('5 Columns', 'crust-core'),
			'6'    => esc_html__('6 Columns', 'crust-core'),
		],
		'active_callback' => [
			[
				'setting'  => 'portfolio_archive_style',
				'operator' => 'contains',
				'value'    => ['grid','masonry'],
			],
		]
	] );

	Crust_Customizer::add_field( [
		'label'    => esc_html__( 'Portfolio Archive Sidebar', 'crust-core' ),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'crust-image-radio',
		'default'  => 'none',
		'settings' => 'portfolio_archive_sidebar',
		'choices'  => [
			'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
			'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
			'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
		]
	] );

	// Portfolio Item Styling...
	Crust_Customizer::add_field([
		'label'           => esc_html__('Item Box Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_style_wrap',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_item_style',
		'label'           => esc_html__('Item Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'select',
		'default'         => 'card',
		'class'           => 'block-row crust-pop-field',
		'choices'         => [
			'card'          => esc_html__('Card', 'crust-core'),
			'card classic'  => esc_html__('Card Classic', 'crust-core'),
			'hoverer'       => esc_html__('Overlay', 'crust-core'),
			'tilt'          => esc_html__('Tilt Effect', 'crust-core'),
		]
	] );

	Crust_Customizer::add_field([
		'type'            => 'crust-icon-radio',
		'settings'        => 'portfolio_item_align',
		'label'           => esc_html__('Alignment', 'crust-core'),
		'section'         => $section,
		'class'           => 'crust-pop-field block-row',
		'tab'             => 'archive',
		'transport'       => 'auto',
		'default'         => 'center',
		'choices'         => [
			''       => 'dashicons dashicons-editor-alignleft',
			'center' => 'dashicons dashicons-editor-aligncenter',
			'right'  => 'dashicons dashicons-editor-alignright',
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_components',
		'label'    => esc_html__('Components', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'crust-label',
		'class'    => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_item_title_on',
		'label'           => esc_html__('Title', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'crust-checkbox',
		'default'         => '1',
		'class'           => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_item_cat_on',
		'label'           => esc_html__('Category', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'crust-checkbox',
		'default'         => '1',
		'class'           => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_item_link_on',
		'label'           => esc_html__('Link', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'crust-checkbox',
		'default'         => '1',
		'class'           => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_item_zoom_on',
		'label'           => esc_html__('Zoom', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'type'            => 'crust-checkbox',
		'default'         => '1',
		'class'           => 'crust-pop-field',
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_padding',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Padding', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'padding',
				'suffix'   => '!important'
			],
		],
	] );

	// Normal
	Crust_Customizer::add_field([
		'label'           => '',
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_tab_list',
		'type'            => 'crust-tab-list',
		'class'           => 'crust-pop-field crust-tab-list',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Normal', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_normal',
		'type'            => 'crust-tab',
		'class'           => 'crust-pop-field crust-tabs-head active',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Overlay Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-media:before',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field crust-tabs-element',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_item_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field crust-tabs-element',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item,.crust-portfolio-archive-list.hoverer .crust-portfolio-item .crust-post-media,.crust-portfolio-archive-list.tilt .crust-portfolio-item .crust-post-media',
				'property' => 'border-radius'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field block-row crust-tabs-element bottom-shadow',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'box-shadow'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Dark Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_dark_normal',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Overlay Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-media:before',
				'property' => 'background-color'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	// Hover
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_hover',
		'type'            => 'crust-tab',
		'class'           => 'crust-pop-field crust-tabs-head',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Overlay Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_hover_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover .crust-post-media:before',
				'property' => 'background-color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_hover_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field crust-tabs-element',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_hover_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_item_hover_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_hover_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-tabs-element crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover,.crust-portfolio-archive-list .crust-portfolio-item:hover .crust-post-media',
				'property' => 'border-radius'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_item_hover_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'block-row crust-tabs-element crust-pop-field bottom-shadow',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item:hover',
				'property' => 'box-shadow'
			]
		],
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Dark Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_dark_hover',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Overlay Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_hover_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 crust-tabs-element',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item:hover .crust-post-media:before',
				'property' => 'background-color'
			]
		],
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_item_hover_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	// Item Title Style
	Crust_Customizer::add_field([
		'label'           => esc_html__('Title Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_style_wrap',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => esc_html__('Typography', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'settings' => 'portfolio_title_typo',
		'class'    => 'crust-pop-field crust-pop-typo',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title,.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
			],
		],
	] );
	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_margin',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Margin', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title',
				'property' => 'margin',
				'suffix'   => '!important'
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_padding',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Padding', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'padding',
				'suffix'   => '!important'
			],
		],
	] );

	// Normal
	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_title_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'border-radius'
			]
		],
	] );


	// Hover
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a:hover',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_hover_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Hover Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_title_hover_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_title_hover_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'border-radius'
			]
		],
	] );


	// Item Category Style
	Crust_Customizer::add_field([
		'label'           => esc_html__('Categories Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_style_wrap',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	Crust_Customizer::add_field([
		'type'     => 'typography',
		'label'    => esc_html__('Typography', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'settings' => 'portfolio_cat_typo',
		'class'    => 'crust-pop-field crust-pop-typo',
		'default'     => [
			'font-family'    => '',
			'variant'        => '',
			'font-size'      => '',
			'line-height'    => '',
			'letter-spacing' => '',
			'color'          => '',
			'text-transform' => '',
			'text-align'     => '',
		],
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'suffix'   => '!important'
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_margin',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Margin', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'margin',
				'suffix'   => '!important'
			],
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_padding',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Padding', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'transport'       => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'padding',
				'suffix'   => '!important'
			],
		],
	] );

	// Normal
	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_cat_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'border-radius'
			]
		],
	] );

	// Hover
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_hover_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Hover Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_cat_hover_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_cat_hover_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'border-radius'
			]
		],
	] );

	// Box links Style
	Crust_Customizer::add_field([
		'label'           => esc_html__('Icons Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_style_wrap',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );

	// Normal
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'background-color',
				'suffix' => '!important'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_icons_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_icons_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_icons_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i',
				'property' => 'border-radius'
			]
		],
	] );

	// Hover
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_bg_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'background-color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_icons_hover_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'border-width',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_border_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'    => esc_html__('Hover Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'type'     => 'select',
		'settings' => 'portfolio_icons_hover_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'border-style',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_icons_hover_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Hover Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'archive',
		'class'    => 'crust-pop-field',
		'direction'=> [
			'top'   => 'top-left',
			'right' => 'top-right',
			'bottom'=> 'bottom-right',
			'left'  => 'bottom-left'
		],
		'units'    => [
			'px' => 'px',
		],
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-hover-box > a i:hover',
				'property' => 'border-radius'
			]
		],
	] );
	///*dark*///
	Crust_Customizer::add_field([
		'label'           => esc_html__('Dark Mode Style', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_hover_dark_style_wrap',
		'type'            => 'crust-wrapper',
		'class'           => 'crust-pop-head',
	] );
		Crust_Customizer::add_field([
		'label'           => esc_html__('Normal Title', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_dark_colors',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'background-color'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 bottom-picker ',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Title', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_hover_dark_color',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a:hover',
				'property' => 'background-color'
			]
		]
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_hover_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title:hover a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );
		Crust_Customizer::add_field([
		'label'           => esc_html__('typo Title Color', 'elementor'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_title_style_dark_wrap',
		'type'            => 'color',
		'transport'       => 'auto',
		'class'           => 'block-row colums2 crust-pop-field',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title,body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-post-title a',
				'property' => 'color'
			]
		],
		'active_callback' => [
			[
				'setting'  => 'dark_mode',
				'operator' => '===',
				'value'    => true,
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('typo Category Color', 'elementor'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_dark_typo',
		'type'            => 'color',
		'transport'       => 'auto',
		'class'           => 'block-row colums2  right-picker crust-pop-field',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'suffix'   => '!important'
			]
		],
		'active_callback' => [
			[
				'setting'  => 'dark_mode',
				'operator' => '===',
				'value'    => true,
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Normal Categories Title', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_bg_dark_colors',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'background-color'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Categories Title', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_dark_colors',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'color',
				'suffix'   => '!important'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'background-color'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_cat_hover_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-archive-list .crust-portfolio-item .crust-portfolio-cat a:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Normal Icon', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_dark_colors',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i',
				'property' => 'color'
			]
		]
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_bg_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i',
				'property' => 'background-color',
				'suffix' => '!important'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Hover Icon', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_dark_colors',
		'type'            => 'crust-label',
		'class'            => 'crust-pop-field crust-tabs-element',
	] );
	Crust_Customizer::add_field([
		'label'           => esc_html__('Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i:hover',
				'property' => 'color'
			]
		],
	] );

	Crust_Customizer::add_field([
		'label'           => esc_html__('BG Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_bg_dark_color',
		'type'            => 'color',
		'class'           => 'right-picker crust-pop-field block-row colums2',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i:hover',
				'property' => 'background-color'
			]
		]
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Border Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'archive',
		'settings'        => 'portfolio_icons_hover_border_dark_color',
		'type'            => 'color',
		'class'           => 'crust-pop-field block-row colums2 right-picker bottom-picker',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-hover-box > a i:hover',
				'property' => 'border-color',
				'suffix'   => '!important'
			]
		],
	] );

	// Single Portfolio settings...
	Crust_Customizer::add_field( [
		'label'    => esc_html__( 'Portfolio Single Sidebar', 'crust-core' ),
		'section'  => $section,
		'tab'      => 'single',
		'type'     => 'crust-image-radio',
		'default'  => 'none',
		'settings' => 'portfolio_sidebar',
		'choices'  => [
			'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
			'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
			'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
		]
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_full',
		'label'    => esc_html__('Full Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'type'     => 'switch',
		'class'    => 'block-row',
		'active_callback' => [
			[
				'setting'  => 'portfolio_sidebar',
				'operator' => '==',
				'value'    => 'none',
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_single_media',
		'type'     => 'switch',
		'label'    => esc_html__('Show Featured Image', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'default'  => true,
	]);

	Crust_Customizer::add_field([
		'settings'        => 'portfolio_layout_content',
		'label'           => esc_html__('Content Wrapper', 'crust-core'),
		'section'         => $section,
		'tab'             => 'single',
		'type'            => 'crust-label',
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_content_wrap_margin',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Wrapper Margin', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'units'    => [
			'px' => 'px',
			'%'  => '%',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'margin',
			],
		],
	]);

	Crust_Customizer::add_field([
		'settings'    => 'portfolio_content_wrap_padding',
		'type'        => 'crust-spacing',
		'label'       => esc_html__('Padding', 'crust-core'),
		'section'     => $section,
		'tab'         => 'single',
		'input_attrs' => [
			'min' => 0,
		],
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'padding',
			],
		],
		'transport'   => 'auto',
	]);

	Crust_Customizer::add_field([
		'label'           => esc_html__('Background Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'single',
		'settings'        => 'portfolio_content_wrap_bg',
		'type'            => 'color',
		'class'    => 'colums2 right-picker block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'background-color',
			]
		],
	] );Crust_Customizer::add_field([
		'label'           => esc_html__('Bg Dark Color', 'crust-core'),
		'section'         => $section,
		'tab'             => 'single',
		'settings'        => 'portfolio_content_wrap_dark_bg',
		'type'            => 'color',
		'class'    => 'colums2 bottom-picker block-row',
		'transport'       => 'auto',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'background-color',
			]
		],
	] );

	Crust_Customizer::add_field([
		'settings' => 'portfolio_content_wrap_border',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Width', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'units'    => [
			'px' => 'px',
		],
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'border-width',
			],
		],
		'transport'   => 'auto',
	]);

	Crust_Customizer::add_field([
		'label'    => esc_html__('Color', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'class'    => 'colums2 right-picker block-row',
		'settings' => 'portfolio_content_wrap_border_color',
		'type'     => 'color',
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'border-color',
			],
		],
		'transport'   => 'auto',
	]);Crust_Customizer::add_field([
		'label'    => esc_html__('Dark Color', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'class'    => ' block-row colums2 bottom-picker block-row',
		'settings' => 'portfolio_content_wrap_border_dark_color',
		'type'     => 'color',
		'output'   => [
			[
				'element' => 'body.crust-dark .crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'border-color',
			],
		],
		'transport'   => 'auto',
	]);

	Crust_Customizer::add_field([
		'label'    => esc_html__('Style', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'type'     => 'crust-select',
		'settings' => 'portfolio_content_wrap_border_type',
		'choices'  => crust_border_type(),
		'class'    => 'colums2 block-row',
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'border-style',
			],
		],
		'transport'   => 'auto',
	]);

	Crust_Customizer::add_field([
		'settings' => 'portfolio_content_wrap_border_radius',
		'type'     => 'crust-spacing',
		'label'    => esc_html__('Border Radius', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'units'    => [
			'px' => 'px',
		],
		'transport' => 'auto',
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'border-radius',
			],
		],
	]);

	Crust_Customizer::add_field([
		'settings' => 'portfolio_content_wrap_shadow',
		'type'     => 'crust-box-shadow',
		'label'    => esc_html__('Box Shadow', 'crust-core'),
		'section'  => $section,
		'tab'      => 'single',
		'class'    => 'block-row',
		'output'   => [
			[
				'element' => '.crust-portfolio-wrap .crust-post-wrapper .crust-single-content',
				'property' => 'box-shadow',
			],
		],
		'transport'   => 'auto',
	]);

}
