<?php

defined('ABSPATH') || die();

$section = 'blog';

Crust_Customizer::add_field([
    'type'            => 'radio-buttonset',
    'settings'        => 'archive_style',
    'label'           => esc_html__('Style', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'transport'       => 'auto',
    'default'         => 'classic',
    'choices'         => [
        'classic' => esc_html__('Classic', 'crust-core'),
        'list'    => esc_html__('List', 'crust-core'),
        'grid'    => esc_html__('Grid', 'crust-core'),
        'masonry' => esc_html__('Masonry', 'crust-core'),
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'blog_columns',
    'label'           => esc_html__('Columns', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'transport'       => 'auto',
    'type'            => 'radio-buttonset',
    'default'         => '2',
    'choices'         => [
        '2'    => esc_html__('2 Columns', 'crust-core'),
        '3'    => esc_html__('3 Columns', 'crust-core'),
        '4'    => esc_html__('4 Columns', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'archive_style',
		    'operator' => 'contains',
		    'value'    => ['grid','masonry'],
	    ],
    ]
] );

Crust_Customizer::add_field([
    'settings'        => 'archive_opts',
    'label'           => esc_html__('Post Settings', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-label',
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_media_on',
	'label'           => esc_html__('Media', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => true,
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_date_on',
	'label'           => esc_html__('Date', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => true,
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_cat_on',
	'label'           => esc_html__('Category', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => true,
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_author_on',
	'label'           => esc_html__('Author', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => true,
] );

Crust_Customizer::add_field([
    'settings'        => 'arc_titl_on',
    'label'           => esc_html__('Title', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-checkbox',
    'default'         => true,
] );

Crust_Customizer::add_field([
    'settings'        => 'arc_icon_on',
    'label'           => esc_html__('Icon', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-checkbox',
    'default'         => false,
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_comments_on',
	'label'           => esc_html__('Comments', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => true,
] );

Crust_Customizer::add_field([
	'settings'        => 'arc_format_on',
	'label'           => esc_html__('Format', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'type'            => 'crust-checkbox',
	'default'         => false,
] );

Crust_Customizer::add_field([
    'settings'        => 'arc_excerpt_on',
    'label'           => esc_html__('Excerpt', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-checkbox',
    'default'         => true,
    'active_callback' => [
	    [
		    'setting'  => 'arc_format_on',
		    'operator' => '==',
		    'value'    => true,
	    ],
    ]
] );

Crust_Customizer::add_field([
    'settings'        => 'arc_more_on',
    'label'           => esc_html__('More', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-checkbox',
    'default'         => true,
    'active_callback' => [
	    [
		    'setting'  => 'arc_format_on',
		    'operator' => '==',
		    'value'    => false,
	    ],
	    [
		    'setting'  => 'arc_excerpt_on',
		    'operator' => '==',
		    'value'    => true,
	    ],
    ]
] );

Crust_Customizer::add_field([
    'type'            => 'slider',
    'settings'        => 'arc_excerpt_length',
    'label'           => esc_html__('Excerpt Length', 'crust-core'),
    'section'         => $section,
    'class'           => 'top-border',
    'tab'             => 'archive',
    'default'         => 35,
    'input_attrs'     => [
        'min'  => 0,
        'max'  => 500,
        'step' => 1,
    ],
    'active_callback' => [
	    [
		    'setting'  => 'arc_format_on',
		    'operator' => '==',
		    'value'    => false,
	    ],
	    [
		    'setting'  => 'arc_excerpt_on',
		    'operator' => '==',
		    'value'    => true,
	    ],
    ]
] );

Crust_Customizer::add_field([
    'type'            => 'text',
    'settings'        => 'archive_more_text',
    'label'           => esc_html__('Read More Text', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'default'         => esc_html__('Read More', 'crust-core'),
    'active_callback' => [
	    [
		    'setting'  => 'arc_format_on',
		    'operator' => '==',
		    'value'    => false,
	    ],
	    [
		    'setting'  => 'arc_excerpt_on',
		    'operator' => '==',
		    'value'    => true,
	    ],
	    [
		    'setting'  => 'arc_more_on',
		    'operator' => '==',
		    'value'    => true,
	    ],
    ]
] );

Crust_Customizer::add_field([
    'settings'        => 'archive_elements',
    'label'           => esc_html__('Elements Styling', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'type'            => 'crust-label',
    'class'           => 'top-border'
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Box Style', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'margin',
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Padding', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'padding',
		],
	],
] );

// Normal
Crust_Customizer::add_field([
	'label'           => '',
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_tab_list',
	'type'            => 'crust-tab-list',
	'class'           => 'crust-pop-field crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_normal',
	'type'            => 'crust-tab',
	'class'           => 'crust-pop-field crust-tabs-head active',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_bg_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'background-color',
		],
		[
			'element' => '.crust-archive-wrapper .crust-post-item .crust-post-thumb-divider .crust-base-fill',
			'property' => 'fill',
		],
	]
] );
Crust_Customizer::add_field([
	'settings' => 'box_arch_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'border-width',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_border_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'select',
	'settings' => 'box_arch_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'crust-pop-field block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'border-style',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'border-radius',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item',
			'property' => 'box-shadow',
			'suffix' => '!important'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'normal_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_bg_dark_color',
	'type'            => 'color',
	'class'           => 'right-picker crust-pop-field block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item',
			'property' => 'background-color',
		],
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item .crust-post-thumb-divider .crust-base-fill',
			'property' => 'fill',
		],
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_border_dark_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );



// Hover
Crust_Customizer::add_field([
	'label'           => esc_html__('Hover', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_hover',
	'type'            => 'crust-tab',
	'class'           => 'crust-pop-field crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_hover_bg_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'background-color'
		],
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover .crust-post-thumb-divider .crust-base-fill',
			'property' => 'fill',
		],
	],
] );
Crust_Customizer::add_field([
	'settings' => 'box_arch_hover_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'border-width',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_hover_border_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'select',
	'settings' => 'box_arch_hover_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'crust-pop-field block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_hover_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-tabs-element crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_arch_hover_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'block-row crust-tabs-element crust-pop-field bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-archive-wrapper .crust-post-item:hover',
			'property' => 'box-shadow'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'hover_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_hover_bg_dark_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item:hover',
			'property' => 'background-color'
		],
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item:hover .crust-post-thumb-divider .crust-base-fill',
			'property' => 'fill',
		],
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'box_arch_hover_border_dark_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-archive-wrapper .crust-post-item:hover',
			'property' => 'border-color',
			'suffix' => '!important'
		]
	],
] );

// Content...
Crust_Customizer::add_field([
	'label'           => esc_html__('Content', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'cont_arch_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => '',
	'section'  => $section,
	'tab'      => 'archive',
	'settings' => 'content_archive',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-post-item, .crust-post-item a',
		],
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'content_dark_archive',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-post-item,body.crust-dark .crust-post-item a',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

// Title...
Crust_Customizer::add_field([
	'label'           => esc_html__('Title', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'title_arch_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'arc_titl_on',
			'operator' => '==',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => '',
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'title_archive',
    'class'    => 'crust-pop-field',
    'default'     => [
	    'font-family'    => '',
	    'variant'        => '',
	    'font-size'      => '',
	    'line-height'    => '',
	    'letter-spacing' => '',
	    'color'          => '',
	    'text-transform' => '',
	    'text-align'     => '',
    ],
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-post-title a',
	    ],
    ],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'title_dark_archive',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-post-title a',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );


Crust_Customizer::add_field([
    'settings' => 'title_arch_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'class'    => 'crust-pop-field',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-post-title',
		    'property' => 'margin'
	    ],
    ],
] );

// Image...
Crust_Customizer::add_field([
    'label'           => esc_html__('Featured Image', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'settings'        => 'img_arch_wrap',
    'type'            => 'crust-wrapper',
    'class'           => 'crust-pop-head',
    'active_callback' => [
	    [
		    'setting'  => 'arc_media_on',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
	'settings' => 'img_archive_classic',
	'type'     => 'switch',
	'label'    => esc_html__('Classic Style ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'block-row crust-pop-field',
	'default'  => true,
]);

Crust_Customizer::add_field([
    'type'     => 'select',
    'label'    => esc_html__('Featured Image', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'img_archive',
    'class'    => 'crust-pop-field',
    'default'  => 'large',
    'choices'  => crust_core_get_img_sizes()
] );

Crust_Customizer::add_field([
    'settings' => 'img_arch_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'class'    => 'crust-pop-field',
    'transport'       => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-post-item .crust-post-media',
		    'property' => 'margin',
	    ],
    ],
] );

Crust_Customizer::add_field([
	'settings'    => 'img_arch_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border', 'crust-core'),
	'section'     => $section,
	'tab'         => 'archive',
	'class'       => 'crust-pop-field',
	'input_attrs' => [
		'min' => 0,
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-post-item .crust-post-media > a',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'colums2 bottom-picker crust-pop-field',
	'settings' => 'img_arch_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-post-item .crust-post-media > a',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'select',
	'settings' => 'img_arch_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'colums2 crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-post-item .crust-post-media > a',
			'property' => 'border-style'
		]
	],
] );
Crust_Customizer::add_field([
	'settings' => 'img_arch_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-post-item .crust-post-media > a',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'img_arch_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-post-item .crust-post-media',
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'featured_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Border Dark Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'block-row bottom-picker crust-pop-field',
	'settings' => 'img_arch_border_dark_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-post-item .crust-post-media > a',
			'property' => 'border-color'
		]
	]
] );



// Pager...
Crust_Customizer::add_field([
    'label'    => esc_html__('Pager', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'pager_arch_wrap',
    'type'     => 'crust-wrapper',
    'class'    => 'crust-pop-head',
] );

Crust_Customizer::add_field([
    'type'     => 'select',
    'settings' => 'archive_pager',
    'label'    => esc_html__('Pager Type', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'default'  => 'numeric',
    'choices'  => [
        'numeric' => esc_html__('Numeric', 'crust-core'),
        'oldnew'  => esc_html__('Older - Newer', 'crust-core'),
        'load'    => esc_html__('Ajax Load More', 'crust-core'),
    ],
    'class'    => 'crust-pop-field colums2',
] );

Crust_Customizer::add_field([
    'type'     => 'crust-icon-radio',
    'settings' => 'archive_pager_align',
    'label'    => esc_html__('Alignment', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'default'  => 'center',
    'choices'  => [
        'left'   => 'dashicons dashicons-editor-alignleft',
        'center' => 'dashicons dashicons-editor-aligncenter',
        'right'  => 'dashicons dashicons-editor-alignright',
    ],
    'class'    => 'crust-pop-field colums2',
    'active_callback' => [
	    [
		    'setting'  => 'archive_pager',
		    'operator' => '==',
		    'value'    => 'numeric',
	    ]
    ]
] );

Crust_Customizer::add_field([
    'type'            => 'text',
    'settings'        => 'archive_load_text',
    'label'           => esc_html__('Load More Text (Ajax Pager)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'archive',
    'default'         => 'Load More',
    'class'           => 'crust-pop-field',
    'active_callback' => [
	    [
		    'setting'  => 'archive_pager',
		    'operator' => '==',
		    'value'    => 'load',
	    ]
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Links Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'pager_arch_lnk_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field  block-row colums2',
	'transport' => 'auto',
    'output'      => [
	    [
		    'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn, .loadmore .crust-loadmore-btn',
		    'property' => 'color'
	    ],
    ],
] );
Crust_Customizer::add_field([
    'label'    => esc_html__('Links BG', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'pager_arch_lnk_bg_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field  block-row colums2',
    'transport' => 'auto',
    'output'      => [
	    [
		    'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn',
		    'property' => 'background-color'
	    ],
    ],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_links_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Links Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn',
			'property' => 'margin'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_links_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Links Padding', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn',
			'property' => 'padding'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_links_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Links Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_links_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Links Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => ' block-row colums2 bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'ul.page-numbers > li > a, ul.page-numbers > li > span, .crust-pager.oldnew > li > a, .loadmore .crust-loadmore-btn',
			'property' => 'box-shadow'
		]
	],
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Pager BG Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'archive',
    'settings' => 'pager_arch_bg_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field  block-row colums2',
    'transport' => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-pager, .woocommerce-pagination',
		    'property' => 'background-color'
	    ],
    ],
] );


Crust_Customizer::add_field([
	'settings' => 'pager_arch_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Pager Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => '.crust-pager, .woocommerce-pagination',
			'property' => 'margin'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Pager Padding', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => '.crust-pager, .woocommerce-pagination',
			'property' => 'padding',
			'suffix' => '!important'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Pager Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-pager, .woocommerce-pagination',
			'property' => 'box-shadow'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'pager_arch_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Pager Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-pager, .woocommerce-pagination',
			'property' => 'border-radius'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'settings'        => 'pager_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'settings' => 'pager_arch_lnk_dark_color',
	'type'     => 'color',
	'class'    => 'crust-pop-field  block-row colums2',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark ul.page-numbers > li > a,body.crust-dark  ul.page-numbers > li > span,body.crust-dark  .crust-pager.oldnew > li > a,body.crust-dark  .loadmore .crust-loadmore-btn,body.crust-dark  .loadmore .crust-loadmore-btn',
			'property' => 'color'
		],
	],
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Links BG', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'settings' => 'pager_arch_lnk_bg_dark_color',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row colums2',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark ul.page-numbers > li > a,body.crust-dark  ul.page-numbers > li > span, body.crust-dark .crust-pager.oldnew > li > a,body.crust-dark  .loadmore .crust-loadmore-btn',
			'property' => 'background-color'
		],
	],
] );
Crust_Customizer::add_field([
	'label'    => esc_html__('Pager BG Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'settings' => 'pager_arch_bg_dark_color',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row',
	'transport' => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-pager,body.crust-dark  .woocommerce-pagination',
			'property' => 'background-color'
		],
	],
] );
