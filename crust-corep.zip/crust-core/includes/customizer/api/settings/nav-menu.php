<?php

defined('ABSPATH') || die();

$section = 'navmenu';

if( is_multisite() ){
	Crust_Customizer::add_field([
		'settings' => 'use_global_menu',
		'label'    => esc_html__('Use Multisite Root Menu', 'crust-core'),
		'section'  => $section,
		'tab'      => 'menu',
		'type'     => 'switch',
		'class'    => 'block-row'
	] );
}

Crust_Customizer::add_field([
	'settings'        => 'nav_align',
	'type'            => 'crust-icon-radio',
	'label'           => esc_html__('Alignment', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'default'         => 'center',
	'choices'         => [
		'flex-start'      => 'dashicons dashicons-editor-alignleft',
		'center' => 'dashicons dashicons-editor-aligncenter',
		'flex-end' => 'dashicons dashicons-editor-alignright',
	],
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation',
			'property' => 'justify-content',
		]
	],
] );

Crust_Customizer::add_field([
    'type'     => 'radio-buttonset',
    'settings' => 'hover_effect',
    'label'    => esc_html__('Style', 'crust-core'),
    'section'  => $section,
    'tab'      => 'menu',
    'default'  => 'underline-nav',
    'class'    => 'block-row crust-tabs-element',
    'choices'  => [
        ''             => esc_html__('Default', 'crust-core'),
        /*'creative-nav' => esc_html__('Creative', 'crust-core'),*/
        'underline-nav' => esc_html__('Underline', 'crust-core'),
        'underline-nav nav-2' => esc_html__('Underline 2', 'crust-core'),
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Underline Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'menu',
    'settings'        => 'underline_color',
    'type'            => 'color',
    'transport'       => 'auto',
    'class'           => 'block-row crust-tabs-element',
    'output'   => [
        [
            'element' => '.crust-site-header.crust-underline-nav .crust-site-navigation > ul > li > a > span:after',
            'property' => 'background-color'
        ]
    ],
    'active_callback' => [
        [
            'setting'  => 'hover_effect',
            'operator' => 'contains',
            'value'    => ['underline-nav','underline-nav nav-2'],
        ]
    ]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Underline Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'underline_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-tabs-element',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-underline-nav .crust-site-navigation > ul > li > a > span:after',
			'property' => 'background-color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'hover_effect',
			'operator' => 'contains',
			'value'    => ['underline-nav','underline-nav nav-2'],
		]
	]
] );

Crust_Customizer::add_field([
    'settings' => 'full_menu',
    'label'    => esc_html__('Full Width Items', 'crust-core'),
    'section'  => $section,
    'tab'      => 'menu',
    'type'     => 'switch',
    'class'    => 'block-row'
] );

Crust_Customizer::add_field([
    'type'     => 'crust-icon-radio',
    'settings' => 'menu_link_align',
    'label'    => esc_html__('Item Alignment', 'crust-core'),
    'section'  => $section,
    'transport' => 'auto',
    'tab'      => 'menu',
    'default'  => 'center',
    'choices'  => [
        'start'   => 'dashicons dashicons-editor-alignleft',
        'center' => 'dashicons dashicons-editor-aligncenter',
        'flex-end'  => 'dashicons dashicons-editor-alignright',
    ],
    'class'    => 'block-row',
    'output'   => [
        [
            'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
            'property' => 'justify-content'
        ]
    ],
    'active_callback' => [
        [
            'setting'  => 'full_menu',
            'operator' => '==',
            'value'    => true,
        ]
    ]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_typo_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'menu',
	'settings' => 'menu_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_typo_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'menu_typo_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'menu_typo_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'menu_typo_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'font-weight'
		],
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );
Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'menu',
	'settings' => 'menu_sticky_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_typo_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Description Typography', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_desc_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => 'Google Fonts',
	'section'  => $section,
	'tab'      => 'menu',
	'settings' => 'menu_desc_typo',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a span.description',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_desc_typo_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a span.description',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );


Crust_Customizer::add_field([
	'settings'        => 'menu_desc_typo_custom',
	'label'           => esc_html__('Custom Font', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'choices'         => crust_custom_fonts(),
] );

Crust_Customizer::add_field([
	'settings'        => 'menu_desc_typo_custom_weight',
	'label'           => esc_html__('Font Weight', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'type'            => 'select',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'menu_desc_typo_custom',
			'operator' => '!==',
			'value'    => '',
		]
	],
	'choices'  => crust_weight_choices(),
	'output'      => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a span.description',
			'property' => 'font-weight'
		],
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'menu_margin',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Margin', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'transport'       => 'auto',
	'units'           => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-navigation > ul > li',
			'property' => 'padding'
		]
	],

] );

Crust_Customizer::add_field([
	'settings'        => 'menu_padding',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Padding', 'crust-core'),
	'space'           => 'padding',
	'transport'       => 'auto',
	'section'         => $section,
	'tab'             => 'menu',
	'units'           => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'padding'
		]
	],
] );

// Normal
Crust_Customizer::add_field([
	'label'           => '',
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_tab_list',
	'type'            => 'crust-tab-list',
	'class'           => 'crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_normal',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head active',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'menu',
    'settings'        => 'menu_color',
    'type'            => 'color',
    'transport'       => 'auto',
    'class'           => 'block-row colums2 right-picker crust-tabs-element',
    'output'   => [
    	[
		    'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
		    'property' => 'color'
	    ]
    ],
] );


Crust_Customizer::add_field([
    'label'           => esc_html__('BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'menu',
    'settings'        => 'menu_bg_color',
    'type'            => 'color',
    'transport'       => 'auto',
    'class'           => 'block-row colums2 crust-tabs-element',
    'output'   => [
	    [
		    'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
		    'property' => 'background-color'
	    ]
    ]
] );

Crust_Customizer::add_field([
	'settings' => 'menu_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'transport'       => 'auto',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Border Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'menu',
    'settings'        => 'menu_border_color',
    'type'            => 'color',
    'transport'       => 'auto',
    'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
    'output'   => [
	    [
		    'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
		    'property' => 'border-color'
	    ]
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'type'     => 'select',
	'settings' => 'menu_border_type',
	'transport'       => 'auto',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'transport'       => 'auto',
	'section'  => $section,
	'tab'      => 'menu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a,.crust-site-header .crust-site-navigation > ul > li > a:before',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'transport'       => 'auto',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_normal_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_dark_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'background-color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_dark_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a',
			'property' => 'border-color'
		]
	],
] );
// Sticky
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'          => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'          => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_active_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'          => [
		[
			'element' => [
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_active_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'          => [
		[
			'element' => [
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_sticky_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'transport'       => 'auto',
	'section'  => $section,
	'tab'      => 'menu',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'type'     => 'select',
	'transport'       => 'auto',
	'settings' => 'menu_sticky_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_sticky_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'transport'       => 'auto',
	'section'  => $section,
	'tab'      => 'menu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_sticky_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'transport'       => 'auto',
	'tab'      => 'menu',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'output'   => [
		[
			'element' => [
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'box-shadow'
		]
	],

] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'          => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'          => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_active_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'          => [
		[
			'element' => [
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a.active',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-parent > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-item > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_active_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'          => [
		[
			'element' => [
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a.active',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-parent > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-item > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'background-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_sticky_dark_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a',
			'property' => 'border-color'
		]
	],
] );


// Hover
Crust_Customizer::add_field([
	'label'           => esc_html__('Hover', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a',
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_hover_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'transport'       => 'auto',
	'tab'      => 'menu',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'type'     => 'select',
	'transport'       => 'auto',
	'settings' => 'menu_hover_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_hover_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'transport'       => 'auto',
	'section'  => $section,
	'tab'      => 'menu',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'menu_hover_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'menu',
	'transport'       => 'auto',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'output'   => [
		[
			'element' => [
				'.crust-site-header .crust-site-navigation > ul > li:hover > a',
				'.crust-site-header .crust-site-navigation > ul > li > a.active',
				'.crust-site-header.crust-sticky-head .crust-site-navigation > ul > li > a:hover',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'.crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'.crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-tabs-element',
] );Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a.active',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current_page_parent > a',
			],
			'property' => 'color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_dark_bg_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a.active',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'background-color'
		]
	],
] );Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'menu',
	'settings'        => 'menu_hover_dark_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => [
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li > a.active',
				'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-navigation > ul > li:hover > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-parent > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-item > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current-menu-ancestor > a',
				'body.crust-dark .crust-site-header .crust-site-navigation > ul > li.current_page_parent > a'
			],
			'property' => 'border-color'
		]
	],
] );
