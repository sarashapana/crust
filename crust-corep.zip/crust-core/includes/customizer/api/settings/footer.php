<?php

defined('ABSPATH') || die();

$section = 'footer';

// ==================== FOOTER ========================
Crust_Customizer::add_field([
	'settings' => 'fixed_footer',
	'label'    => esc_html__('Fixed Footer ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'block-row',
	'type'     => 'switch',
] );

Crust_Customizer::add_field([
	'settings'        => 'before_widgets_template',
	'label'           => esc_html__('Content Before', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'type'            => 'select',
	'class'           => 'block-row',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
    'settings' => 'footer_widgets',
    'label'    => esc_html__('Show Widgets Area', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'class'    => 'block-row',
    'type'     => 'switch',
    'default'  => false,
] );

Crust_Customizer::add_field([
    'type'     => 'radio-buttonset',
    'settings' => 'widgets_type',
    'label'    => esc_html__('Type', 'crust-core'),
    'section'  => $section,
    'tab'      => 'widgets',
    'class'    => 'block-row',
    'default'  => 'default',
    'choices'  => [
        'default' => esc_html__('Default', 'crust-core'),
        'custom'  => esc_html__('Custom', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'widgets_template',
    'label'           => esc_html__('Template', 'crust-core'),
    'section'         => $section,
    'tab'             => 'widgets',
    'type'            => 'select',
    'class'           => 'block-row',
    'choices'         => crust_post_type_posts( 'crust_footer' ),
    'active_callback' => [
	    [
		    'setting'  => 'widgets_type',
		    'operator' => '==',
		    'value'    => 'custom',
	    ],
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
    'type'            => 'radio-buttonset',
    'settings'        => 'widgets_layout',
    'label'           => esc_html__('Layout', 'crust-core'),
    'section'         => $section,
    'tab'             => 'widgets',
    'default'         => '2',
    'choices'         => [
        '1' => esc_html__('1 Column', 'crust-core'),
        '2' => esc_html__('2 Columns', 'crust-core'),
        '3' => esc_html__('3 Columns', 'crust-core'),
        '4' => esc_html__('4 Columns', 'crust-core'),
        '5' => esc_html__('5 Columns', 'crust-core'),
        '6' => esc_html__('6 Columns', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'widgets_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
    'settings'        => 'footer_full',
    'label'           => esc_html__('Full Width', 'crust-core'),
    'section'         => $section,
    'tab'             => 'widgets',
    'type'            => 'switch',
    'default'         => false,
    'class'           => 'block-row',
    'active_callback' => [
	    [
		    'setting'  => 'widgets_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Text Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'widgets',
    'settings'        => 'footer_text_color',
    'type'            => 'color',
    'class'           => 'colums2',
    'active_callback' => [
	    [
		    'setting'  => 'widgets_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
	    [
		    'element' => '.crust-footer-widgets',
		    'property' => 'color'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_links_color',
	'type'            => 'color',
	'class'           => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => '.crust-footer-widgets a',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_headings_color',
	'type'            => 'color',
	'class'           => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => '.crust-site-footer .crust-footer-widgets .crust-widget h2.widgettitle',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Separators Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_separators_color',
	'type'            => 'color',
	'class'           => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => '.crust-site-footer .crust-footer-widgets .crust-widget ul li,.crust-site-footer .crust-footer-widgets .crust-widget .tagcloud a',
			'property' => 'border-color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'footer_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'widgets',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'default'     => 'image',
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'footer_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'footer_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-footer-widgets',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'footer_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'widgets',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-site-footer',
		],
	],
	'active_callback' => [
		[
			'setting'  => 'footer_bg_type',
			'operator' => '==',
			'value'    => 'image',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
]);

Crust_Customizer::add_field([
    'settings'        => 'footer_padding',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Padding', 'crust-core'),
    'section'         => $section,
    'tab'             => 'widgets',
    'input_attrs'     => [
        'min' => 0,
    ],
    'active_callback' => [
	    [
		    'setting'  => 'footer_widgets',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
	    [
		    'element' => '.crust-footer-widgets',
		    'property' => 'padding'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'    => 'footer_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border', 'crust-core'),
	'section'     => $section,
	'tab'         => 'widgets',
	'input_attrs' => [
		'min' => 0,
	],
	'units'    => [
		'px' => 'px',
	],
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-footer',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'colums2 bottom-picker',
	'settings' => 'footer_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'   => [
		[
			'element' => '.crust-site-footer',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'type'     => 'select',
	'settings' => 'footer_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'colums2',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-footer',
			'property' => 'border-style'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'    => 'footer_border_radius',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border Radius', 'crust-core'),
	'section'     => $section,
	'tab'         => 'widgets',
	'input_attrs' => [
		'min' => 0,
	],
	'units'    => [
		'px' => 'px',
		'%' => '%',
	],
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-footer',
			'property' => 'border-radius'
		]
	]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Text Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_dark_text_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-footer-widgets',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_dark_links_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-footer-widgets a',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_dark_headings_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-site-footer .crust-footer-widgets .crust-widget h2.widgettitle',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Separators Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'settings'        => 'footer_dark_separators_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'widgets_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-site-footer .crust-footer-widgets .crust-widget ul li,body.crust-dark .crust-site-footer .crust-footer-widgets .crust-widget .tagcloud a',
			'property' => 'border-color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'widgets',
	'class'    => 'colums2 block-row right-picker crust-pop-field',
	'settings' => 'footer_dark_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-footer',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'footer_dark_bg_type',
	'label'           => esc_html__('Background Type', 'elementor'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'widgets',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'default'     => 'image',
	'active_callback' => [
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'footer_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'widgets',
	'class'           => 'crust-pop-field',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'footer_dark_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-footer-widgets',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'footer_dark_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'widgets',
	'class'       => 'crust-pop-field',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-site-footer',
		],
	],
	'active_callback' => [
		[
			'setting'  => 'footer_dark_bg_type',
			'operator' => '==',
			'value'    => 'image',
		],
		[
			'setting'  => 'footer_widgets',
			'operator' => '==',
			'value'    => true,
		]
	],
]);
// Sub footer area
Crust_Customizer::add_field([
	'settings'        => 'before_subfooter_template',
	'label'           => esc_html__('Content Before', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'type'            => 'select',
	'class'           => 'block-row',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
    'settings' => 'subfooter_area',
    'label'    => esc_html__('Show Sub Footer', 'crust-core'),
    'section'  => $section,
    'tab'      => 'subfooter',
    'class'    => 'block-row',
    'type'     => 'switch',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'type'     => 'radio-buttonset',
    'settings' => 'subfooter_type',
    'label'    => esc_html__('Type', 'crust-core'),
    'section'  => $section,
    'tab'      => 'subfooter',
    'class'    => 'flex-row',
    'default'  => 'default',
    'choices'  => [
        'default' => esc_html__('Default', 'crust-core'),
        'custom'  => esc_html__('Custom', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
    'settings'        => 'subfooter_template',
    'label'           => esc_html__('Template', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'type'            => 'select',
    'class'           => 'block-row',
    'choices'         => crust_post_type_posts( 'crust_modules' ),
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'custom',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ]
] );

Crust_Customizer::add_field([
    'type'            => 'radio-buttonset',
    'settings'        => 'subfooter_layout',
    'label'           => esc_html__('Layout', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'default'         => '2',
    'choices'         => [
        '1' => esc_html__('1 Column', 'crust-core'),
        '2' => esc_html__('2 Columns', 'crust-core'),
        '3' => esc_html__('3 Columns', 'crust-core'),
        '4' => esc_html__('4 Columns', 'crust-core'),
        '5' => esc_html__('5 Columns', 'crust-core'),
        '6' => esc_html__('6 Columns', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'footer_copyrights',
    'label'           => esc_html__('Copyrights', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'type'            => 'textarea',
    'default'         => 'Crust © Made by winsomethemes, All rights reserved.',
    'input_attrs'     => array(
        'toolbar1'     => 'bold italic bullist numlist alignleft aligncenter alignright link',
        'mediaButtons' => true,
    ),
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'subfooter_full',
    'label'           => esc_html__('Full Width', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'type'            => 'switch',
    'default'         => false,
    'class'           => 'block-row',
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Text Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'settings'        => 'subfooter_text_color',
    'type'            => 'color',
    'class'           => 'colums2',
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
	    [
		    'element' => '.crust-sub-footer',
		    'property' => 'color'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Links Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'settings'        => 'subfooter_links_color',
    'type'            => 'color',
    'class'           => 'colums2',
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
	    [
		    'element' => '.crust-sub-footer a',
		    'property' => 'color'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_headings_color',
	'type'            => 'color',
	'class'           => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => '.crust-site-footer .crust-sub-footer .crust-widget h2.widgettitle',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Separators Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_separators_color',
	'type'            => 'color',
	'class'           => 'colums2',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => '.crust-site-footer .crust-sub-footer .crust-widget ul li,.crust-site-footer .crust-sub-footer .crust-widget .tagcloud a',
			'property' => 'border-color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'subfooter_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'subfooter',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'default'     => 'image',
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'subfooter_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'subfooter_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-sub-footer',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'subfooter_bg',
	'label'       => '',
	'section'  => $section,
	'tab'      => 'subfooter',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-sub-footer',
		],
	],
	'active_callback' => [
		[
			'setting'  => 'subfooter_bg_type',
			'operator' => '==',
			'value'    => 'image',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
]);

Crust_Customizer::add_field([
    'settings'        => 'subfooter_padding',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Padding', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'input_attrs'     => [
        'min' => 0,
    ],
    'active_callback' => [
	    [
		    'setting'  => 'subfooter_type',
		    'operator' => '==',
		    'value'    => 'default',
	    ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
	    [
		    'element' => '.crust-sub-footer',
		    'property' => 'padding'
	    ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
    'settings'        => 'subfooter_margin',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Margin', 'crust-core'),
    'section'         => $section,
    'tab'             => 'subfooter',
    'active_callback' => [
        [
            'setting'  => 'subfooter_type',
            'operator' => '==',
            'value'    => 'default',
        ],
	    [
		    'setting'  => 'subfooter_area',
		    'operator' => '==',
		    'value'    => true,
	    ]
    ],
    'output'      => [
        [
            'element' => '.crust-sub-footer',
            'property' => 'margin'
        ],
    ],
    'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings'    => 'subfooter_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border', 'crust-core'),
	'section'     => $section,
	'tab'         => 'subfooter',
	'input_attrs' => [
		'min' => 0,
	],
	'units'    => [
		'px' => 'px',
	],
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-sub-footer',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'subfooter',
	'class'    => 'colums2 bottom-picker',
	'settings' => 'subfooter_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'   => [
		[
			'element' => '.crust-sub-footer',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'subfooter',
	'type'     => 'select',
	'settings' => 'subfooter_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'colums2',
	'transport'       => 'auto',
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'   => [
		[
			'element' => '.crust-sub-footer',
			'property' => 'border-style'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Text Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_dark_text_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sub-footer',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_dark_links_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sub-footer a',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Headings Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_dark_headings_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-site-footer .crust-sub-footer .crust-widget h2.widgettitle',
			'property' => 'color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Separators Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'settings'        => 'subfooter_dark_separators_color',
	'type'            => 'color',
	'class'           => 'colums2 block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'subfooter_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-site-footer .crust-sub-footer .crust-widget ul li,body.crust-dark .crust-site-footer .crust-sub-footer .crust-widget .tagcloud a',
			'property' => 'border-color'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'subfooter',
	'class'    => 'colums2 right-picker block-row crust-pop-field',
	'settings' => 'subfooter_dark_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-sub-footer',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'subfooter_dark_bg_type',
	'label'           => esc_html__('Background Type', 'elementor'),
	'section'         => $section,
	'class'           => 'crust-pop-field block-row',
	'tab'             => 'subfooter',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
	'default'     => 'image',
	'active_callback' => [
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'subfooter_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'subfooter',
	'class'           => 'crust-pop-field',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'subfooter_dark_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sub-footer',
			'property' => 'background',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'subfooter_dark_bg',
	'class'       => 'crust-pop-field',
	'section'  => $section,
	'tab'      => 'subfooter',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-sub-footer',
		],
	],
	'active_callback' => [
		[
			'setting'  => 'subfooter_dark_bg_type',
			'operator' => '==',
			'value'    => 'image',
		],
		[
			'setting'  => 'subfooter_area',
			'operator' => '==',
			'value'    => true,
		]
	],
]);
