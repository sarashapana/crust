<?php

defined('ABSPATH') || die();

$section = 'header';

// Normal
Crust_Customizer::add_field([
	'label'           => '',
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_tab_list',
	'type'            => 'crust-tab-list',
	'class'           => 'crust-tab-list',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_normal',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head active',
] );

Crust_Customizer::add_field([
	'type'            => 'slider',
	'settings'        => 'logo_full_width',
	'label'           => esc_html__('Width', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'default'         => '',
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 700,
		'step' => 1,
	],
	'output'   => [
		[
			'element' => 'header.crust-site-header .crust-site-brand img',
			'property' => 'width',
			'units' => 'px'
		]
	],
] );

Crust_Customizer::add_field([
    'type'            => 'slider',
    'settings'        => 'logo_width',
    'label'           => esc_html__('Max Width', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'default'         => '',
    'input_attrs'     => [
        'min'  => 0,
        'max'  => 700,
        'step' => 1,
    ],
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand',
            'property' => 'max-width',
            'units' => 'px'
        ]
    ],
] );

Crust_Customizer::add_field([
    'settings'        => 'logo_margin',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Margin', 'crust-core'),
    'section'         => $section,
    'class'           => 'crust-tabs-element',
    'tab'             => 'logo',
    'units'    => [
        'px' => 'px',
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand',
            'property' => 'margin'
        ]
    ],
] );

Crust_Customizer::add_field([
    'settings'    => 'logo_padding',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'class'       => 'crust-tabs-element',
    'tab'         => 'logo',
    'input_attrs' => [
        'min' => 0,
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand',
            'property' => 'padding'
        ]
    ],
] );

Crust_Customizer::add_field([
    'type'     => 'crust-icon-radio',
    'settings' => 'logo_align',
    'label'    => esc_html__('Alignment', 'crust-core'),
    'section'  => $section,
    'tab'      => 'logo',
    'default'  => 'left',
    'choices'  => [
        'left'   => 'dashicons dashicons-editor-alignleft',
        'center' => 'dashicons dashicons-editor-aligncenter',
        'right'  => 'dashicons dashicons-editor-alignright',
    ],
    'transport'=> 'auto',
    'class'    => 'block-row crust-tabs-element',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand',
            'property' => 'text-align'
        ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'settings'        => 'logo_bg_color',
    'type'            => 'color',
    'class'           => 'block-row crust-tabs-element',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => 'header.crust-site-header .crust-site-brand',
		    'property' => 'background-color'
	    ]
    ]
] );

Crust_Customizer::add_field([
	'settings' => 'logo_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header .crust-site-brand',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Border Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'settings'        => 'logo_border_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => 'header.crust-site-header .crust-site-brand',
		    'property' => 'border-color'
	    ]
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'type'     => 'select',
	'settings' => 'logo_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header .crust-site-brand',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'logo_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header .crust-site-brand',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'logo_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header .crust-site-brand',
			'property' => 'box-shadow'
		]
	],
] );

// Sticky
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_sticky',
	'type'            => 'crust-tab',
	'class'           => 'crust-tabs-head',
] );

Crust_Customizer::add_field([
    'settings'        => 'logo_margin_sticky',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Margin', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'class'           => 'crust-tabs-element',
    'units'    => [
        'px' => 'px',
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
            'property' => 'margin'
        ]
    ],
] );

Crust_Customizer::add_field([
    'settings'    => 'logo_padding_sticky',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'class'           => 'crust-tabs-element',
    'tab'         => 'logo',
    'input_attrs' => [
        'min' => 0,
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
            'property' => 'padding'
        ]
    ],
] );

Crust_Customizer::add_field([
    'type'     => 'crust-icon-radio',
    'settings' => 'logo_align_sticky',
    'label'    => esc_html__('Alignment', 'crust-core'),
    'section'  => $section,
    'tab'      => 'logo',
    'default'  => 'left',
    'choices'  => [
        'left'   => 'dashicons dashicons-editor-alignleft',
        'center' => 'dashicons dashicons-editor-aligncenter',
        'right'  => 'dashicons dashicons-editor-alignright',
    ],
    'transport'=> 'auto',
    'class'    => 'block-row crust-tabs-element',
    'output'   => [
        [
            'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
            'property' => 'text-align'
        ]
    ],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_sticky_bg_color',
	'type'            => 'color',
	'class'           => 'block-row crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'background-color'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'logo_sticky_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_sticky_border_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'type'     => 'select',
	'settings' => 'logo_sticky_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'logo_sticky_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'crust-tabs-element',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'logo_sticky_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'logo',
	'class'    => 'block-row crust-tabs-element bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'box-shadow'
		]
	],
] );

// Tagline...
Crust_Customizer::add_field([
    'settings'        => 'tagline_head',
    'type'            => 'crust-label',
    'label'           => esc_html__('Tagline', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
] );
Crust_Customizer::add_field([
    'settings'        => 'tagline_margin',
    'type'            => 'crust-spacing',
    'label'           => esc_html__('Margin', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'units'    => [
        'px' => 'px',
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
            'property' => 'margin'
        ]
    ],
] );

Crust_Customizer::add_field([
    'settings'    => 'tagline_padding',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'tab'         => 'logo',
    'input_attrs' => [
        'min' => 0,
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
            'property' => 'padding'
        ]
    ],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'settings'        => 'tagline_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 right-picker bottom-picker',
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
            'property' => 'color'
        ]
    ]
] );
Crust_Customizer::add_field([
    'label'           => esc_html__('BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'logo',
    'settings'        => 'tagline_bg_color',
    'type'            => 'color',
    'class'           => 'block-row colums2 bottom-picker',
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
            'property' => 'background-color'
        ]
    ]
] );

Crust_Customizer::add_field([
    'settings' => 'tagline_border_radius',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Border Radius', 'crust-core'),
    'section'  => $section,
    'tab'      => 'logo',
    'direction'=> [
        'top'   => 'top-left',
        'right' => 'top-right',
        'bottom'=> 'bottom-right',
        'left'  => 'bottom-left'
    ],
    'units'    => [
        'px' => 'px',
    ],
    'transport'       => 'auto',
    'output'   => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
            'property' => 'border-radius'
        ]
    ],
] );
//dark popup
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Normal', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'normal_logo_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field'
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element crust-pop-field right-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header .crust-site-brand',
			'property' => 'background-color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_border_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element bottom-picker crust-pop-field left-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header .crust-site-brand',
			'property' => 'border-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'sticky_logo_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field'
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_sticky_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 crust-tabs-element crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'background-color'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_sticky_border_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-site-brand',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Tagline', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'logo_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field'
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'tagline_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 right-picker bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header .crust-site-brand .crust-site-slogan',
			'property' => 'color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'logo',
	'settings'        => 'tagline_bg_dark_color',
	'type'            => 'color',
	'class'           => 'block-row colums2 bottom-picker crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header .crust-site-brand .crust-site-slogan',
			'property' => 'background-color'
		]
	]
] );
///
Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => 'Typography',
    'section'  => $section,
    'tab'      => 'logo',
    'settings' => 'tagline_typo',
    'class'    => 'crust-pop-typo',
    'default'     => [
        'font-family'    => '',
        'variant'        => '',
        'font-size'      => '',
        'line-height'    => '',
        'letter-spacing' => '',
        'color'          => '',
        'text-transform' => '',
        'text-align'     => '',
    ],
    'transport'   => 'auto',
    'output'      => [
        [
            'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
        ],
    ],
] );

Crust_Customizer::add_field([
	'type'     => 'color',
	'label'    => 'Dark Typography Color',
	'section'  => $section,
	'tab'      => 'logo',
	'settings' => 'tagline_dark_typo',
	'class'    => 'crust-pop-typo right-picker',
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'header.crust-site-header .crust-site-brand .crust-site-slogan',
		],
	],
] );


