<?php

defined('ABSPATH') || die();

$section = 'general';

Crust_Customizer::add_field([
	'settings' => 'body_layout',
	'type'     => 'radio-buttonset',
	'label'    => esc_html__('Site Layout', 'crust-core'),
	'default'  => 'wide',
	'section'  => $section,
	'tab'      => 'settings',
	'class'    => 'flex-row',
	'choices'  => [
		'wide'  => esc_html__('Wide', 'crust-core'),
		'boxed' => esc_html__('Boxed', 'crust-core'),
	],
]);

Crust_Customizer::add_field([
	'settings' => 'dark_mode',
	'type'     => 'switch',
	'label'    => esc_html__('Enable Dark Mode', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'class'    => 'block-row',

]);

Crust_Customizer::add_field([
    'settings' => 'disable_emoji',
    'type'     => 'switch',
    'label'    => esc_html__('Disable Emoji', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'class'    => 'block-row',
    'default'  => '1'
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Back to top', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'back_top_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'settings' => 'show_top',
	'type'     => 'switch',
	'label'    => esc_html__('Enable / Disable', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'default'  => true,
	'class'    => 'crust-pop-field block-row',
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'back_top_color',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'show_top',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-back-to-top',
			'property' => 'color'
		],
	],
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Background color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'back_top_bg',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'show_top',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-back-to-top',
			'property' => 'background-color',
			'suffix' => '!important'
		],
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'back_top_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'back_dark_top_color',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row colums2',
	'active_callback' => [
		[
			'setting'  => 'show_top',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-back-to-top',
			'property' => 'color'
		],
	],
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Background color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'back_dark_top_bg',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row colums2',
	'active_callback' => [
		[
			'setting'  => 'show_top',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-back-to-top',
			'property' => 'background-color',
			'suffix' => '!important'
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Page Pre-loaders', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'loaders_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
    'settings' => 'page_loader',
    'type'     => 'switch',
    'label'    => esc_html__('Page Pre-loaders', 'crust-core'),
    'section'  => $section,
    'tab'      => 'settings',
    'class'    => 'crust-pop-field block-row',
    'default'  => '1'
]);

Crust_Customizer::add_field([
    'settings'        => 'preloaders',
    'type'            => 'radio-buttonset',
    'label'           => esc_html__('Style', 'crust-core'),
    'default'         => 'spin',
    'section'         => $section,
    'class'           => 'crust-pop-field block-row',
    'tab'             => 'settings',
    'choices'         => [
        '1'   => esc_html__('Style 1', 'crust-core'),
        '2'   => esc_html__('Style 2', 'crust-core'),
        '3'   => esc_html__('Style 3', 'crust-core'),
        '4'   => esc_html__('Style 4', 'crust-core'),
        'spin'   => esc_html__('Spinner', 'crust-core'),
        'img' => esc_html__('Image', 'crust-core'),
    ],
    'active_callback' => [
	    [
		    'setting'  => 'page_loader',
		    'operator' => '==',
		    'value'    => '1',
	    ]
    ]
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Body Background color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'load_body_bg',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'page_loader',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-loader',
			'property' => 'background-color'
		],
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Dark Body Background color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'load_dark_body_bg',
	'type'     => 'color',
	'class'    => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'page_loader',
			'operator' => '==',
			'value'    => '1',
		]
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-page-loader',
			'property' => 'background-color'
		],
	],
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Choose Image', 'crust-core'),
    'section'         => $section,
    'tab'             => 'settings',
    'settings'        => 'loader_img',
    'type'            => 'crust-image',
    'class'           => 'crust-pop-field',
    'active_callback' => [
	    [
		    'setting'  => 'page_loader',
		    'operator' => '==',
		    'value'    => '1',
	    ],
	    [
		    'setting'  => 'preloaders',
		    'operator' => '===',
		    'value'    => 'img',
	    ]
	]
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Max. Width ( PX )', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'loader_width',
	'type'            => 'crust-number',
	'class'           => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'page_loader',
			'operator' => '==',
			'value'    => '1',
		],
		[
			'setting'  => 'preloaders',
			'operator' => '===',
			'value'    => 'img',
		]
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-loader-img img,.crust-page-loader > div',
			'property' => 'max-width',
			'suffix' => 'px'
		]
	]
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Loading Text', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'load_text',
	'type'     => 'text',
	'class'    => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'page_loader',
			'operator' => '==',
			'value'    => '1',
		]
	]
] );

Crust_Customizer::add_field([
	'type'     => 'typography',
	'label'    => esc_html__('Text Typography', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'settings' => 'load_text_typography',
	'class'    => 'crust-pop-field',
	'default'     => [
		'font-family'    => '',
		'variant'        => '',
		'font-size'      => '',
		'line-height'    => '',
		'letter-spacing' => '',
		'color'          => '',
		'text-transform' => '',
		'text-align'     => '',
	],
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-loader-text',
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Text Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'load_text_dark_color',
	'type'            => 'color',
	'class'           => 'block-row crust-pop-field',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-loader-text',
			'property' => 'color'
		],
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Splash Screen', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'splash_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'settings'        => 'splash_screen_template',
	'label'           => esc_html__('Splash Screen', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-select',
	'class'           => 'crust-pop-field block-row',
	'mod_type'        => 'crust_modules',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Position', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'select',
	'settings' => 'splash_position',
	'choices'  => [
		''              => esc_html__('Center', 'crust-core'),
		'top-left'      => esc_html__('Top left', 'crust-core'),
		'top-center'      => esc_html__('Top Center', 'crust-core'),
		'top-right'     => esc_html__('Top Right', 'crust-core'),
		'bottom-left'   => esc_html__('Bottom left', 'crust-core'),
		'bottom-center'      => esc_html__('Bottom Center', 'crust-core'),
		'bottom-right'  => esc_html__('Bottom Right', 'crust-core'),
	],
	'class'    => 'crust-pop-field block-row',
]);

Crust_Customizer::add_field([
	'type'            => 'number',
	'settings'        => 'splash_time',
	'label'           => esc_html__('Show After (ms)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'class'           => 'crust-pop-field block-row',
	'default'         => 2000,
] );

Crust_Customizer::add_field([
	'settings' => 'splash_coockies',
	'label'    => esc_html__('Enable Coockies', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'class'    => 'crust-pop-field block-row'
] );

Crust_Customizer::add_field([
	'settings' => 'splash_close_button',
	'label'    => esc_html__('Show Close Button', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'class'    => 'crust-pop-field block-row'
] );

Crust_Customizer::add_field([
	'type'            => 'text',
	'settings'        => 'splash_name',
	'label'           => esc_html__('Cookies Name(Unique)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'class'           => 'crust-pop-field block-row',
	'active_callback' => [
		[
			'setting'  => 'splash_coockies',
			'operator' => '==',
			'value'    => true,
		],
	]
] );

Crust_Customizer::add_field([
	'type'            => 'number',
	'settings'        => 'splash_days',
	'label'           => esc_html__('Expires days', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'class'           => 'crust-pop-field block-row',
	'default'         => 10,
	'active_callback' => [
		[
			'setting'  => 'splash_coockies',
			'operator' => '==',
			'value'    => true,
		],
	]
] );

Crust_Customizer::add_field([
	'settings' => 'splash_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'class'    => 'crust-pop-field',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-splash-screen',
			'property' => 'margin'
		]
	]
] );

if ( class_exists('Woocommerce') ) {
	$woo_prim_bg = '.woocommerce .widget_price_filter .ui-slider .ui-slider-range,.woocommerce .widget_price_filter .ui-slider .ui-slider-range,.woocommerce ul.products li.product a.add_to_cart_button:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover,
			#woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce a.added_to_cart:hover,.woocommerce #respond input#submit.alt.disabled, .woocommerce #respond input#submit.alt.disabled:hover, .woocommerce #respond input#submit.alt:disabled, .woocommerce #respond input#submit.alt:disabled:hover, .woocommerce #respond input#submit.alt:disabled[disabled], .woocommerce input.button.alt,
			#woocommerce #respond input#submit.alt:disabled[disabled]:hover, .woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt:disabled, .woocommerce button.button.alt,
			.woocommerce a.button.alt:disabled:hover, .woocommerce a.button.alt:disabled[disabled], .woocommerce a.button.alt:disabled[disabled]:hover, .woocommerce button.button.alt.disabled, .woocommerce a.button.alt,
			.woocommerce button.button.alt:disabled, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt:disabled[disabled], .woocommerce button.button.alt:disabled[disabled]:hover,.wc-block-product-search .wc-block-product-search__button,
			.woocommerce input.button.alt.disabled, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt:disabled, .woocommerce input.button.alt:disabled:hover, .woocommerce form.login .woocommerce-form-login__submit,
			.woocommerce input.button.alt:disabled[disabled], .woocommerce input.button.alt:disabled[disabled]:hover, .woocommerce #respond input#submit.alt, .woocommerce nav.woocommerce-pagination ul li span.current,
			#woocommerce div.product div.summary>.product_meta>span.tagged_as a:hover,.woocommerce .upsells.products > h2:before,.woocommerce .related.products > h2:before,.woocommerce-billing-fields h3:before,.woocommerce-shipping-fields h3:before,#order_review_heading:before,.woocommerce-order-details__title:before,.woocommerce-column__title:before,.woocommerce-Address-title h3:before,.woocommerce-additional-fields h3:before,.woocommerce-EditAccountForm legend:before';

	$woo_color = ',.woocommerce-loop-product__title:hover,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.woocommerce-MyAccount-navigation ul li.is-active > a,.woocommerce div.product p.price,.woocommerce div.product span.price,
            .woocommerce div.product .woocommerce-Price-amount,.woocommerce ul.products li.product a.product_type_variable:hover,.woocommerce ul.products li.product a.product_type_grouped:hover,.woocommerce ul.products li.product a.added_to_cart.wc-forward:hover, .crust-mini-cart .total .woocommerce-Price-amount.amount,
            .crust-woo-products.crust-pro-minimal ul.products li.product .crust-products-wrap .add_to_cart_button,.woocommerce ul.products li.product .woocommerce-Price-amount, .woocommerce-page ul.products li.product .woocommerce-Price-amount';
} else {
	$woo_prim_bg = '';
	$woo_color = '';
}

if( function_exists('is_bbpress') ){
	$bb_bg = ',.bbpress input.submit, .bbpress button.submit';
	$bb_border = ',.forum-titles li, .bbp-header > div';
	$bb_alt_border = ',.forum-titles li.bbp-forum-topic-count, .forum-titles li.bbp-forum-freshness, .forum-titles li.bbp-forum-reply-count, .forum-titles li.bbp-topic-voice-count, .forum-titles li.bbp-topic-reply-count, .forum-titles li.bbp-topic-freshness, .bbp-header .bbp-reply-content';
} else {
	$bb_border = '';
	$bb_alt_border = '';
	$bb_bg = '';
}

if( class_exists('Tribe__Events__Main') ){
	$ev_bg = ',.tribe-common .tribe-common-c-btn,.tribe-common a.tribe-common-c-btn,.tribe-events .tribe-events-c-ical__link,.tribe-events .tribe-events-calendar-list__event-date-tag-datetime';
	$ev_color = ',.tribe-events .tribe-events-calendar-month__day--current .tribe-events-calendar-month__day-date, .tribe-events .tribe-events-calendar-month__day--current .tribe-events-calendar-month__day-date-link,
	.tribe-common a.tribe-events-calendar-list__event-title-link:hover,.tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-day__event-datetime-featured-text,
	.tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-list__event-datetime-featured-text,.tribe-common .tribe-common-c-svgicon';
} else {
	$ev_color = '';
	$ev_bg = '';
}

Crust_Customizer::add_field([
    'label'    => esc_html__('Primary Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'settings' => 'primary_color',
    'type'     => 'color',
    'class'    => 'block-row',
    'transport' => 'auto',
    'output'      => [
        [
            'element' => '.crust-site-navigation ul li a.crust-act-btn,.comment-form input.submit,.crust-widget .tagcloud a:hover,.crust-widget input.search-submit,.crust-badge.crust-badge-main,.swiper-scrollbar-drag,
            .primary-bg,.btn,.wp-block-search__button, .crust-widget .tagcloud a:hover, .crust-range-label:after,.crust-sidebar .crust-widget h2.widgettitle:after,.crust-infobox-tip-inner,.wp-block-search .wp-block-search__button,
            .crust-widget-cats-list > ul > li.has-cat-img > a:hover:before, .wp-block-quote:not(.has-text-color), blockquote:not(.has-text-color),.crust-meta-cat a:hover,.crust-meta-cat a:hover,
            .crust-inner-heading:before,.comment-respond .comment-reply-title:before,.crust-inner-heading:after,.comment-respond .comment-reply-title:after,.crust-portfolio-hover-box > a i,
            .crust-widget .tagcloud a:hover, .crust-meta-cat a:hover,.crust-filters > ul > li.selected > a, ul.page-numbers > li > span:not(.dots)'.$woo_prim_bg.$bb_bg.$ev_bg,
            'property' => 'background-color'
        ],
        [
	        'element' => '.crust-mini-cart .checkout',
	        'property' => 'background-color',
	        'suffix' => ' !important'
        ],
        [
            'element' => '.primary-color,.search-form .crust-search-icon,.crust-sidebar .crust-widget ul li:after,.crust-range-label,.comment-author b.fn a, .crust-single-content .has-drop-cap:first-letter,.crust-tags-list:before,.crust-tags-list:after,
            .crust-single-content .has-drop-cap:first-letter,.comment-list li.comment .comment-metadata time:before,.crust-post-title a:hover'.$woo_color.$ev_color,
            'property' => 'color',
        ],
        [
            'element' => '.crust-widget .tagcloud a:hover,input[type="text"]:focus, input[type="number"]:focus, input[type="tel"]:focus, input[type="search"]:focus, 
            input[type="password"]:focus, input[type="email"]:focus, input[type="url"]:focus, select:focus, textarea:focus, .crust-search-box-overlay .search-form .form-control,
            .woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,
			.woocommerce a.added_to_cart:hover,.woocommerce-MyAccount-navigation ul li.is-active > a,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a'.$bb_border,
            'property' => 'border-color'
        ],
	    [
	    	'element' => '.crust-post-thumb-divider .crust-div-1-bottom',
		    'property' => 'fill'
	    ],
	    [
		    'element' => '.woocommerce #content table.cart td.actions .input-text, .woocommerce table.cart td.actions .input-text, .woocommerce-page #content table.cart td.actions .input-text, 
		    .woocommerce-page table.cart td.actions .input-text',
		    'property' => 'border-color',
		    'suffix' => ' !important'
	    ],
        [
            'element' => '.crust-responsive-btn.crust-active-btn,.crust-site-navigation > ul li a.crust-act-btn:before',
            'property' => 'background-color',
            'media_query' => '@media (max-width: 992px)'
        ],
        [
            'element' => '.crust-responsive-btn,.crust-responsive-btn:focus',
            'property' => 'color',
            'media_query' => '@media (max-width: 992px)'
        ],
    ],
] );

if ( class_exists('Woocommerce') ) {
	$woo_sec_bg = ',.woocommerce ul.products li.product a.add_to_cart_button,.woocommerce #respond input#submit.alt.disabled:hover, .woocommerce #respond input#submit.alt.disabled:hover:hover,  
            .woocommerce #respond input#submit.alt:disabled:hover, .woocommerce #respond input#submit.alt:disabled[disabled]:hover, .woocommerce input.button.alt:hover,.crust-woo-products.crust-pro-card ul.products li.product .onsale,
			.woocommerce #respond input#submit.alt:disabled[disabled]:hover, .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt:disabled:hover,
			.woocommerce a.button.alt:disabled:hover, .woocommerce a.button.alt:disabled[disabled]:hover, .woocommerce a.button.alt:disabled[disabled]:hover, .woocommerce button.button.alt.disabled:hover,
			.woocommerce button.button.alt.disabled:hover, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt:disabled[disabled]:hover,
			.woocommerce button.button.alt:disabled[disabled]:hover, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt:disabled:hover,
			.woocommerce input.button.alt:disabled:hover, .woocommerce input.button.alt:disabled[disabled]:hover, .woocommerce input.button.alt:disabled[disabled]:hover, .woocommerce #respond input#submit.alt:hover,
			.woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover,.woocommerce #respond input#submit.alt:disabled:hover,.woocommerce ul.products li.product .onsale, .woocommerce div.product span.onsale';
} else {
	$woo_sec_bg = '';
}

if( class_exists('Tribe__Events__Main') ){
	$ev_alt_color = ',.tribe-events .tribe-events-calendar-month__day--current .tribe-events-calendar-month__day-date-link:active,.tribe-events .tribe-events-calendar-month__day--current .tribe-events-calendar-month__day-date-link:hover';
	$ev_alt_bg = ',.tribe-common .tribe-common-c-btn:hover,.tribe-common a.tribe-common-c-btn:hover,.tribe-events .tribe-events-c-ical__link:active,.tribe-events .tribe-events-c-ical__link:focus,.tribe-events .tribe-events-c-ical__link:hover,
	.tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-list__event-cost,.tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-day__event-cost,
	.tribe-events .tribe-events-c-view-selector__list-item--active .tribe-events-c-view-selector__list-item-link,.tribe-common--breakpoint-medium.tribe-events .tribe-events-c-view-selector--tabs .tribe-events-c-view-selector__list-item--active .tribe-events-c-view-selector__list-item-link:after,
	.tribe-events .tribe-events-calendar-list__event-row--featured .tribe-events-calendar-list__event-date-tag-datetime:after';
	$ev_imp_bg = ',.tribe-common .tribe-common-c-btn:hover, .tribe-common a.tribe-common-c-btn:hover, .tribe-events .tribe-events-c-ical__link:active, .tribe-events .tribe-events-c-ical__link:focus, .tribe-events .tribe-events-c-ical__link:hover, .tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-list__event-cost, 
	.tribe-common--breakpoint-medium.tribe-events .tribe-events-calendar-day__event-cost, .tribe-events .tribe-events-c-view-selector__list-item--active .tribe-events-c-view-selector__list-item-link, .tribe-common--breakpoint-medium.tribe-events .tribe-events-c-view-selector--tabs .tribe-events-c-view-selector__list-item--active .tribe-events-c-view-selector__list-item-link:after, 
	.tribe-events .tribe-events-calendar-list__event-row--featured .tribe-events-calendar-list__event-date-tag-datetime:after,.tribe-events .tribe-events-calendar-month__mobile-events-icon--event';
} else {
	$ev_alt_color = '';
	$ev_alt_bg = '';
	$ev_imp_bg = '';
}

Crust_Customizer::add_field([
    'label'    => esc_html__('Secondary Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'settings' => 'secondary_color',
    'type'     => 'color',
    'class'    => 'block-row',
    'transport'   => 'auto',
    'output'      => [
        [
            'element' => '.secondary-bg,.btn:hover,input[type=submit].secondary-bg,input[type=submit].secondary-bg:hover,.crust-site-footer .crust-widget ul.menu li a:after,
            .crust-site-header.crust-underline-nav .crust-site-navigation > ul > li > a > span:after,
            .crust-portfolio-hover-box > a.crust-portfolio-hover-zoom i,.crust-sidebar .crust-widget h2.widgettitle:before,b.cart-num, b.yith-num,.crust-badge.crust-badge-alt,
            .crust-site-header.crust-underline-nav .crust-site-navigation > ul > li > a > span:before,.crust-site-footer .crust-site-navigation > ul > li > a > span:before'.$woo_sec_bg.$ev_alt_bg,
            'property' => 'background-color'
        ],
        [
	        'element' => '.crust-import-bg,.crust-dots-wrap i'.$ev_imp_bg,
	        'property' => 'background-color',
	        'suffix' => ' !important'
        ],
	    [
            'element' => '.secondary-color,.crust-post-icon i,.crust-sub-pager a:hover,.crust-list-btn.active,
             .crust-grid-btn.active'.$ev_alt_color,
            'property' => 'color'
        ],
        [
            'element' => '.crust-btn.btn-trigo:after',
            'property' => 'border-left-color'
        ],
        [
            'element' => '.crust-btn.btn-trigo:after'.$bb_alt_border,
            'property' => 'border-bottom-color'
        ],
        [
            'element' => '.crust-sub-pager a:hover,.crust-sub-pager span.post-page-numbers.current',
            'property' => 'border-color'
        ],
    ],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'settings' => 'links_color',
	'type'     => 'color',
	'class'    => 'block-row',
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body a',
			'property' => 'color'
		],
	],
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'body_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'styling',
	'default'         => 'image',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'body_bg_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'body_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'output'      => [
		[
			'element' => 'body',
			'property' => 'background',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'body_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'active_callback' => [
		[
			'setting'  => 'body_bg_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
	'output'      => [
		[
			'element' => 'body',
		],
	],
]);

Crust_Customizer::add_field([
    'settings' => 'body_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'units'    => [
        'px' => 'px',
        '%'  => '%',
    ],
    'transport'   => 'auto',
    'output'      => [
	    [
		    'element' => 'body',
		    'property' => 'margin',
	    ],
    ],
]);

Crust_Customizer::add_field([
    'settings'    => 'body_padding',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'tab'         => 'styling',
    'input_attrs' => [
        'min' => 0,
    ],
    'output'      => [
	    [
		    'element' => 'body',
		    'property' => 'padding'
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Border', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'bod_border_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
    'settings' => 'body_border',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Border Width', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'class'    => 'crust-pop-field',
    'units'    => [
        'px' => 'px',
    ],
    'input_attrs' => [
	    'min' => 0,
    ],
    'output'      => [
	    [
		    'element' => 'body',
		    'property' => 'border-width'
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Border Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'class'    => 'crust-pop-field colums2',
    'settings' => 'body_bg_color',
    'type'     => 'color',
    'output'      => [
	    [
		    'element' => 'body',
		    'property' => 'border-color',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Style', 'crust-core'),
    'section'  => $section,
    'tab'      => 'styling',
    'type'     => 'select',
    'settings' => 'body_border_type',
    'choices'  => crust_border_type(),
    'class'    => 'crust-pop-field colums2',
    'output'      => [
	    [
		    'element' => 'body',
		    'property' => 'border-style',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'body_bg_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Links Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'settings' => 'body_dark_links_color',
	'type'     => 'color',
	'class'    => 'block-row colums2 right-picker crust-pop-field',
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark a',
			'property' => 'color'
		],
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'crust-pop-field block-row colums2',
	'settings' => 'body_dark_border_color',
	'type'     => 'color',
	'output'      => [
		[
			'element' => 'body.crust-dark',
			'property' => 'border-color',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'body_dark_bg',
	'class'       => 'crust-pop-field',
	'section'     => $section,
	'tab'         => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark',
		],
	],
]);

// Wrapper Styling...
$boxed_layout = [
	[
		'setting'  => 'body_layout',
		'operator' => '==',
		'value'    => 'boxed',
	]
];

Crust_Customizer::add_field([
	'settings'    => 'site_width',
	'type'        => 'slider',
	'default'     => 1140,
	'label'       => esc_html__('Width ( px )', 'crust-core'),
	'section'     => $section,
	'tab'         => 'wrapper',
	'input_attrs' => [
		'min'  => 500,
		'max'  => 2000,
		'step' => 1,
	],
	'active_callback' => $boxed_layout,
	'output'   => [
		[
			'element'  => ['.crust-boxed-wrapper .crust-site-header', '.crust-boxed-wrapper .crust-site-footer','.crust-boxed-wrapper .container','.crust-boxed-wrapper'],
			'property' => 'max-width',
			'units'    => 'px',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'wrap_bg',
	'label'       => esc_html__( 'Background', 'crust-core' ),
	'section'     => $section,
	'tab'         => 'wrapper',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.crust-main-wrap',
		],
	],
]);

Crust_Customizer::add_field([
    'settings' => 'wrap_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'directions' => [
	    'top'    => '',
	    'bottom' => '',
    ],
    'labels' => [
	    'top'    => esc_html__( 'Top', 'crust-core'),
	    'bottom' => esc_html__( 'Bottom', 'crust-core'),
    ],
    'output'   => [
	    [
		    'element' => '.crust-main-wrap',
		    'property' => 'margin',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'settings'    => 'wrap_padding',
    'type'        => 'crust-spacing',
    'label'       => esc_html__('Padding', 'crust-core'),
    'section'     => $section,
    'tab'         => 'wrapper',
    'input_attrs' => [
        'min' => 0,
    ],
    'output'   => [
		[
			'element' => '.crust-main-wrap',
			'property' => 'padding',
		],
    ],
    'transport'   => 'auto',
]);

// Boxed Styles...
Crust_Customizer::add_field([
    'settings' => 'wrap_border',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Border Width', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'units'    => [
        'px' => 'px',
    ],
    'output'   => [
	    [
		    'element' => '.crust-main-wrap',
		    'property' => 'border-width',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'class'    => 'colums2 right-picker bottom-picker block-row',
    'settings' => 'wrap_border_color',
    'type'     => 'color',
    'output'   => [
	    [
		    'element' => '.crust-boxed-wrapper',
		    'property' => 'border-color',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Style', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'type'     => 'crust-select',
    'settings' => 'wrap_border_type',
    'choices'  => crust_border_type(),
    'class'    => 'colums2 block-row',
    'output'   => [
	    [
		    'element' => '.crust-boxed-wrapper',
		    'property' => 'border-style',
	    ],
    ],
    'transport'   => 'auto',
]);

Crust_Customizer::add_field([
    'settings' => 'wrap_border_radius',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Border Radius', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'units'    => [
        'px' => 'px',
    ],
    'transport' => 'auto',
    'output'   => [
	    [
		    'element' => '.crust-boxed-wrapper',
		    'property' => 'border-radius',
	    ],
    ],
    'active_callback' => $boxed_layout
]);

Crust_Customizer::add_field([
    'settings' => 'boxed_shadow',
    'type'     => 'crust-box-shadow',
    'label'    => esc_html__('Box Shadow', 'crust-core'),
    'section'  => $section,
    'tab'      => 'wrapper',
    'class'    => 'block-row',
    'output'   => [
	    [
		    'element' => '.crust-boxed-wrapper',
		    'property' => 'box-shadow',
	    ],
    ],
    'transport'   => 'auto',
    'active_callback' => $boxed_layout
]);
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'wrapper',
	'settings'        => 'wrap_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'wrapper',
	'class'    => 'crust-pop-field block-row',
	'settings' => 'wrap_dark_border_color',
	'type'     => 'color',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-main-wrap',
			'property' => 'border-color',
		],
	],
	'transport'   => 'auto',
]);

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'wrap_dark_bg',
	'class'       => 'crust-pop-field',
	'section'     => $section,
	'tab'         => 'wrapper',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-main-wrap',
		],
	],
]);
// Error 404
Crust_Customizer::add_field([
	'label'           => esc_html__('Custom Logo', 'crust-core'),
	'section'         => $section,
	'settings'        => 'error404_logo',
	'tab'             => 'error404',
	'type'            => 'crust-image',
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Text color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'error404',
	'settings' => 'error_404_color',
	'type'     => 'color',
	'class'    => 'block-row',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-page-not-found-top h4, .crust-page-not-found-top h4 *, .crust-page-not-found-top p',
			'property' => 'color'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'error_headings_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Headings Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'error404',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-page-not-found-top',
			'property' => 'margin'
		]
	]
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'error404_bg',
	'label'       => esc_html__( 'Background', 'crust-core' ),
	'section'     => $section,
	'tab'         => 'error404',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.error404 .crust-main-wrap',
		],
	],
]);
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'error404',
	'settings'        => 'error_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Text Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'error404',
	'settings' => 'error_dark_404_color',
	'type'     => 'color',
	'class'    => 'block-row crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.error404.crust-dark .crust-page-not-found-top h4, body.error404.crust-dark .crust-page-not-found-top h4 *, body.error404.crust-dark .crust-page-not-found-top p',
			'property' => 'color'
		],
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Background Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'error404',
	'settings' => 'error_404_dark_bg_color',
	'type'     => 'color',
	'class'    => 'block-row crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => 'body.error404.crust-dark .crust-main-wrap',
			'property' => 'background-color'
		],
	],
] );


// Custom Login
Crust_Customizer::add_field([
    'settings' => 'custom_login',
    'type'     => 'switch',
    'label'    => esc_html__('Custom Login Page ?', 'crust-core'),
    'section'  => $section,
    'tab'      => 'login',
    'class'    => 'block-row',
]);

Crust_Customizer::add_field([
    'label'           => esc_html__('Logo', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_logo',
    'type'            => 'crust-image',
]);

Crust_Customizer::add_field([
    'label'           => esc_html__('Logo Width (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_logo_width',
    'class'           => 'block-row',
    'type'            => 'number',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Logo Height (px)', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_logo_height',
    'class'           => 'block-row',
    'type'            => 'number',
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Body BG Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_bg_color',
    'type'            => 'color',
    'class'           => 'bottom-picker',
] );

Crust_Customizer::add_field([
    'settings' => 'gradient_login',
    'type'     => 'switch',
    'label'    => esc_html__('Gradient ?', 'crust-core'),
    'section'  => $section,
    'tab'      => 'login',
    'class'    => 'block-row',
]);

Crust_Customizer::add_field([
    'label'           => esc_html__('First Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_bg_color_first',
    'type'            => 'color',
    'default'         => '#c850c0',
    'class'           => 'colums2',
    'active_callback' => [
        'setting'  => 'gradient_login',
        'operator' => '==',
        'value'    => true,
    ]
] );

Crust_Customizer::add_field([
    'label'           => esc_html__('Second Color', 'crust-core'),
    'section'         => $section,
    'tab'             => 'login',
    'settings'        => 'login_bg_color_second',
    'type'            => 'color',
    'default'         => '#4158d0',
    'class'           => 'colums2',
    'active_callback' => [
        'setting'  => 'gradient_login',
        'operator' => '==',
        'value'    => true,
    ]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'login',
	'settings'        => 'login_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Body BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'login',
	'settings'        => 'login_bg_dark_color',
	'type'            => 'color',
	'class'           => 'bottom-picker crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('First Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'login',
	'settings'        => 'login_bg_color_dark_first',
	'type'            => 'color',
	'default'         => '#c850c0',
	'class'           => 'colums2 crust-pop-field',
	'active_callback' => [
		'setting'  => 'gradient_login',
		'operator' => '==',
		'value'    => true,
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Second Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'login',
	'settings'        => 'login_bg_color_dark_second',
	'type'            => 'color',
	'default'         => '#4158d0',
	'class'           => 'colums2 crust-pop-field',
	'active_callback' => [
		'setting'  => 'gradient_login',
		'operator' => '==',
		'value'    => true,
	]
] );

// WooCommerce Styling...
if( class_exists( 'Woocommerce') ) {
	Crust_Customizer::add_field([
		'label'    => esc_html__( 'Sidebar Position', 'crust-core' ),
		'section'  => 'woocommerce_product_catalog',
		'type'     => 'radio-image',
		'default'  => '',
		'settings' => 'woo_bar_dir',
		'choices'  => [
			'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
			'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
			'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
		]
	]);

	Crust_Customizer::add_field([
		'label'    => esc_html__( 'Select Sidebar', 'crust-core' ),
		'section'  => 'woocommerce_product_catalog',
		'type'     => 'crust-select',
		'settings' => 'woo_sidebar',
		'default'  => 'sidebar-1',
		'choices'  => crust_get_sidebars()
	]);

	Crust_Customizer::add_field([
		'label'    => esc_html__( 'Product Sidebar', 'crust-core' ),
		'section'  => 'woocommerce_product_catalog',
		'type'     => 'radio-image',
		'settings' => 'woo_single_bar_dir',
		'default'  => '',
		'choices'  => [
			'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
			'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
			'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
		]
	]);

	Crust_Customizer::add_field([
		'label'    => esc_html__( 'Select Sidebar', 'crust-core' ),
		'section'  => 'woocommerce_product_catalog',
		'type'     => 'crust-select',
		'settings' => 'woo_single_sidebar',
		'choices'  => crust_get_sidebars()
	]);

	Crust_Customizer::add_field([
		'settings' => 'gallery_shadow',
		'type'     => 'switch',
		'label'    => esc_html__('Shadow Gallery ?', 'crust-core'),
		'section'  => 'woocommerce_product_images',
		'class'    => 'block-row',
	]);

}