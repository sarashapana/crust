<?php

defined('ABSPATH') || die();

$section = 'crust-woo';

Crust_Customizer::add_field([
	'type'            => 'radio-buttonset',
	'settings'        => 'woo_item_style',
	'label'           => esc_html__('Style', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive',
	'choices'         => [
		''  => esc_html__('Default', 'crust-core'),
		'card' => esc_html__('Card', 'crust-core'),
		'minimal' => esc_html__('Minimal', 'crust-core'),
		'over' => esc_html__('Over', 'crust-core'),
	]
] );

Crust_Customizer::add_field([
	'settings' => 'woo_sale_replace',
	'label'    => esc_html__('Sale Percentage', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row'
] );

Crust_Customizer::add_field([
	'settings' => 'woo_display_desc',
	'label'    => esc_html__('Show Description', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row'
] );

Crust_Customizer::add_field([
	'settings' => 'woo_display_quick',
	'label'    => esc_html__('Show Quick view', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row'
] );

Crust_Customizer::add_field([
	'settings' => 'woo_display_love',
	'label'    => esc_html__('Show Wishlist', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row'
] );

Crust_Customizer::add_field([
	'label'    => esc_html__( 'Sidebar Position', 'crust-core' ),
	'section'  => $section,
	'type'     => 'radio-image',
	'tab'      => 'archive',
	'settings' => 'woo_bar_dir',
	'choices'  => [
		'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
		'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
		'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
	]
]);

Crust_Customizer::add_field([
	'label'    => esc_html__( 'Select Sidebar', 'crust-core' ),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'crust-select',
	'settings' => 'woo_sidebar',
	'default'  => 'sidebar-1',
	'choices'  => crust_get_sidebars()
]);

Crust_Customizer::add_field([
	'label'    => esc_html__( 'Product Sidebar', 'crust-core' ),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'radio-image',
	'settings' => 'woo_single_bar_dir',
	'default'  => '',
	'choices'  => [
		'right' => CRUST_CORE_URI . 'assets/admin/images/right_bar.png',
		'left'  => CRUST_CORE_URI . 'assets/admin/images/left_bar.png',
		'none'  => CRUST_CORE_URI . 'assets/admin/images/no_bar.png',
	]
]);

Crust_Customizer::add_field([
	'label'    => esc_html__( 'Select Sidebar', 'crust-core' ),
	'section'  => $section,
	'tab'      => 'archive',
	'type'     => 'crust-select',
	'settings' => 'woo_single_sidebar',
	'choices'  => crust_get_sidebars()
]);

Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'catalog_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'archive-style',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'catalog_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'catalog_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'output'      => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'background',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'catalog_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'archive-style',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'active_callback' => [
		[
			'setting'  => 'catalog_bg_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
	'output'      => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
		],
	],
]);

Crust_Customizer::add_field([
	'settings'        => 'catalog_padding',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Padding', 'crust-core'),
	'space'           => 'padding',
	'transport'       => 'auto',
	'section'         => $section,
	'tab'             => 'archive-style',
	'units'           => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'padding'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'catalog_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'transport'       => 'auto',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'border-width'
		]
	],
] );
Crust_Customizer::add_field([
	'settings' => 'catalog_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'catalog_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'type'     => 'select',
	'settings' => 'catalog_border_type',
	'transport' => 'auto',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2 crust-tabs-element',
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'catalog_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'class'    => 'block-row bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-woo-products li.product .crust-products-wrap',
			'property' => 'box-shadow'
		]
	],
] );
////dark
//Crust_Customizer::add_field([
//	'label'           => esc_html__('Dark Mode', 'crust-core'),
//	'section'         => $section,
//	'tab'             => 'archive-style',
//	'settings'        => 'archive_dark_head',
//	'type'            => 'crust-label',
//] );
//
//Crust_Customizer::add_field([
//	'type'            => 'crust-icon-radio',
//	'settings'        => 'catalog_bg_dark_type',
//	'label'           => esc_html__('Background Type', 'crust-core'),
//	'section'         => $section,
//	'class'           => 'block-row',
//	'tab'             => 'archive-style',
//	'choices'         => [
//		'' => 'dashicons dashicons-hidden',
//		'image'   => 'dashicons dashicons-format-image',
//		'gradient' => 'dashicons dashicons-admin-appearance',
//	],
//] );
//
//Crust_Customizer::add_field([
//	'settings'        => 'catalog_dark_gradient',
//	'label'           => esc_html__('Gradient', 'crust-core'),
//	'section'         => $section,
//	'tab'             => 'archive-style',
//	'type'            => 'crust-gradient',
//	'active_callback' => [
//		[
//			'setting'  => 'catalog_bg_dark_type',
//			'operator' => '==',
//			'value'    => 'gradient',
//		]
//	],
//	'output'      => [
//		[
//			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
//			'property' => 'background',
//		],
//	],
//	'transport'   => 'auto',
//] );
//
//Crust_Customizer::add_field([
//	'type'        => 'background',
//	'settings'    => 'catalog_dark_bg',
//	'label'       => '',
//	'section'     => $section,
//	'tab'         => 'archive-style',
//	'default'     => [
//		'background-color'      => '',
//		'background-image'      => '',
//		'background-repeat'     => 'repeat',
//		'background-position'   => 'center center',
//		'background-size'       => 'cover',
//		'background-attachment' => 'scroll',
//	],
//	'transport'   => 'auto',
//	'active_callback' => [
//		[
//			'setting'  => 'catalog_bg_dark_type',
//			'operator' => '==',
//			'value'    => 'image',
//		]
//	],
//	'output'      => [
//		[
//			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
//		],
//	],
//]);
//
//Crust_Customizer::add_field([
//	'label'           => esc_html__('Border Color', 'crust-core'),
//	'section'         => $section,
//	'tab'             => 'archive-style',
//	'settings'        => 'catalog_border_dark_color',
//	'type'            => 'color',
//	'transport'       => 'auto',
//	'class'           => 'block-row right-picker crust-tabs-element bottom-picker',
//	'output'   => [
//		[
//			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
//			'property' => 'border-color'
//		]
//	],
//] );
//img
Crust_Customizer::add_field([
	'settings'        => 'catalog_img_margin',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Image Margin', 'crust-core'),
	'space'           => 'margin',
	'transport'       => 'auto',
	'section'         => $section,
	'tab'             => 'archive-style',
	'units'           => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'margin'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'catalog_img_padding',
	'type'            => 'crust-spacing',
	'label'           => esc_html__('Image Padding', 'crust-core'),
	'space'           => 'padding',
	'transport'       => 'auto',
	'section'         => $section,
	'tab'             => 'archive-style',
	'units'           => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'padding'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'catalog_img_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'transport'       => 'auto',
	'class'    => 'crust-tabs-element',
	'units'    => [
		'px' => 'px',
	],
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'border-width'
		]
	],
] );
Crust_Customizer::add_field([
	'settings' => 'catalog_img_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'border-radius'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'catalog_img_border_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 right-picker crust-tabs-element bottom-picker',
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'archive-style',
	'type'     => 'select',
	'settings' => 'catalog_img_border_type',
	'transport' => 'auto',
	'choices'  => crust_border_type(),
	'class'    => 'block-row crust-tabs-element',
	'output'   => [
		[
			'element' => '.crust-product-img-wrap, .crust-pro-img-wrap',
			'property' => 'border-style'
		]
	],
] );
//dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'archive_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'catalog_bg_dark_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'archive-style',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'catalog_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'type'            => 'crust-gradient',
	'class'           => 'crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'catalog_bg_dark_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
			'property' => 'background',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'catalog_dark_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'archive-style',
	'class'           => 'crust-pop-field',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'active_callback' => [
		[
			'setting'  => 'catalog_bg_dark_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
		],
	],
]);

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'catalog_border_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row right-picker crust-tabs-element bottom-picker crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-woo-products li.product .crust-products-wrap',
			'property' => 'border-color'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Image Colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'img_archive_dark_head',
	'type'            => 'crust-label',
	'class'           => 'crust-pop-field',

] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Image Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'archive-style',
	'settings'        => 'catalog_img_border_dark_color',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row right-picker crust-tabs-element bottom-picker crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-product-img-wrap,body.crust-dark .crust-pro-img-wrap',
			'property' => 'border-color'
		]
	],
] );
//////
Crust_Customizer::add_field([
	'settings'    => 'woo_title_padding',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Page Title Padding', 'crust-core'),
	'section'     => $section,
	'tab'         => 'single',
	'input_attrs' => [
		'min' => 0,
	],
	'output'      => [
		[
			'element' => 'body.single.single-product .crust-page-title > .container',
			'property' => 'padding',
			'suffix' => ' !important'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Title Min. Height (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'woo_title_height',
	'type'            => 'slider',
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 1200,
		'step' => 1,
	],
	'output'      => [
		[
			'element' => 'body.single.single-product .crust-page-title > .container',
			'property' => 'min-height',
			'units'    => 'px',
			'suffix' => ' !important'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'settings' => 'gallery_shadow',
	'type'     => 'switch',
	'label'    => esc_html__('Shadow Gallery ?', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'block-row',
]);
	