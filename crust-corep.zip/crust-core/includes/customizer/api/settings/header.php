<?php

defined('ABSPATH') || die();

$section = 'header';

// ==================== HEADER ========================
Crust_Customizer::add_field([
	'settings'        => 'before_header_template',
	'label'           => esc_html__('Content Before', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-select',
	'class'           => 'block-row',
	'mod_type'        => 'crust_modules',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
	'settings'        => 'after_header_template',
	'label'           => esc_html__('Content After', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-select',
	'class'           => 'block-row',
	'mod_type'        => 'crust_modules',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
] );

Crust_Customizer::add_field([
	'settings' => 'show_header',
	'label'    => esc_html__('Show Header', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row'
] );

Crust_Customizer::add_field([
	'type'     => 'radio-buttonset',
	'settings' => 'header_type',
	'label'    => esc_html__('Header Type', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'class'    => 'flex-row',
	'default'  => 'default',
	'choices'  => [
		'default' => esc_html__('Default', 'crust-core'),
		'custom'  => esc_html__('Custom', 'crust-core'),
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'header_template',
	'label'           => esc_html__('Choose Header', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-select',
	'mod_type'        => 'crust_header',
	'class'           => 'block-row crust-mod-temp',
	'choices'         => crust_post_type_posts( 'crust_header' ),
	'active_callback' => [
		[
			'setting'  => 'header_type',
			'operator' => '==',
			'value'    => 'custom',
		]
	]
] );

Crust_Customizer::add_field([
	'settings'        => 'header_template',
	'label'           => esc_html__('Header Template', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-select',
	'class'           => 'block-row',
	'mod_type'        => 'crust_header',
	'choices'         => crust_post_type_posts( 'crust_header' ),
	'active_callback' => [
		[
			'setting'  => 'header_type',
			'operator' => '==',
			'value'    => 'custom',
		],

	]
] );

Crust_Customizer::add_field([
	'settings' => 'header_overlab',
	'label'    => esc_html__('Overlab Content', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => true,
	'class'    => 'block-row'
] );

$default_type = [
	[
		'setting'  => 'header_type',
		'operator' => '==',
		'value'    => 'default',
	]
];

Crust_Customizer::add_field([
	'label'           => esc_html__('Offset Y (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'overlab_offset',
	'type'            => 'slider',
	'default'         => 30,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 500,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => 'header_overlab',
			'operator' => '==',
			'value'    => true,
		]
	],
	'transport' => 'auto',
	'output'   => [
		[
			'element' => '.crust-header-overlab',
			'property' => 'top',
			'units' => 'px',
			//'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'head_align',
	'type'            => 'crust-icon-radio',
	'label'           => esc_html__('Alignment', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'choices'         => [
		''      => 'dashicons dashicons-editor-alignleft',
		'right' => 'dashicons dashicons-editor-alignright',
	],
	'class'           => 'block-row',
	'active_callback' => $default_type
] );

Crust_Customizer::add_field([
	'settings'        => 'header_full',
	'label'           => esc_html__('Full Width', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'switch',
	'default'         => true,
	'class'           => 'block-row',
] );

Crust_Customizer::add_field([
	'settings' => 'head_components',
	'label'    => esc_html__('Components', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'crust-label',
	'active_callback' => $default_type
] );

Crust_Customizer::add_field([
	'settings'        => 'logo_on',
	'label'           => esc_html__('Logo', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-checkbox',
	'default'         => true,
	'active_callback' => $default_type
] );

Crust_Customizer::add_field([
	'settings'        => 'menu_on',
	'label'           => esc_html__('Menu', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-checkbox',
	'default'         => true,
	'active_callback' => $default_type
] );

Crust_Customizer::add_field([
	'settings'        => 'dark_btn_on',
	'label'           => esc_html__('Dark Mode', 'violatix-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-checkbox',
	'default'         => true,
	'active_callback' => [
		[
			'setting'  => 'header_type',
			'operator' => '==',
			'value'    => 'default',
		],
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'settings'        => 'search_on',
	'label'           => esc_html__('Search', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-checkbox',
	'default'         => true,
	'active_callback' => $default_type
] );

if( class_exists( 'Woocommerce') ){
	Crust_Customizer::add_field([
		'settings'        => 'cart_on',
		'label'           => esc_html__('Cart', 'crust-core'),
		'section'         => $section,
		'tab'             => 'settings',
		'type'            => 'crust-checkbox',
		'default'         => true,
		'active_callback' => $default_type
	] );

	Crust_Customizer::add_field([
		'settings'        => 'heart_on',
		'label'           => esc_html__('Heart', 'crust-core'),
		'section'         => $section,
		'tab'             => 'settings',
		'type'            => 'crust-checkbox',
		'default'         => true,
		'active_callback' => $default_type
	] );

}

Crust_Customizer::add_field([
	'settings'        => 'custom_on',
	'label'           => esc_html__('Custom Module', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'type'            => 'crust-checkbox',
	'active_callback' => $default_type
] );

Crust_Customizer::add_field([
	'settings'        => 'header_module',
	'label'           => esc_html__('Module Template', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'mod_type'        => 'crust_modules',
	'type'            => 'crust-select',
	'choices'         => crust_post_type_posts( 'crust_modules' ),
	'active_callback'  => function() {
		return true === get_theme_mod( 'custom_on', false );
	}
] );

Crust_Customizer::add_field([
	'type'     => 'radio-buttonset',
	'settings' => 'header_behavior',
	'label'    => esc_html__('Scroll Behavior', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'class'    => 'flex-row top-border',
	'default'  => 'normal',
	'choices'  => [
		'normal' => esc_html__('Normal', 'crust-core'),
		'fixed'  => esc_html__('Fixed', 'crust-core'),
		'sticky' => esc_html__('Sticky', 'crust-core'),
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Offset (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'fixed_offset',
	'type'            => 'slider',
	'default'         => 0,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 500,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => 'header_behavior',
			'operator' => '==',
			'value'    => 'fixed',
		]
	]
] );

// Sticky Header options..
$sticky_head = [
	[
		'setting'  => 'header_behavior',
		'operator' => '==',
		'value'    => 'sticky',
	]
];
Crust_Customizer::add_field([
	'settings' => 'show_sticky_logo',
	'label'    => esc_html__('Show Logo', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );
Crust_Customizer::add_field([
	'settings' => 'show_sticky_menu',
	'label'    => esc_html__('Show Menu', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );
Crust_Customizer::add_field([
	'settings' => 'show_sticky_darkmod',
	'label'    => esc_html__('Show Dark Mode', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );
Crust_Customizer::add_field([
	'settings' => 'show_sticky_search',
	'label'    => esc_html__('Show Search', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );
Crust_Customizer::add_field([
	'settings' => 'show_sticky_woo_icon',
	'label'    => esc_html__('Show Cart Icon', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '1',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );
Crust_Customizer::add_field([
	'settings' => 'show_sticky_module',
	'label'    => esc_html__('Show Custom Module', 'crust-core'),
	'section'  => $section,
	'tab'      => 'settings',
	'type'     => 'switch',
	'default'  => '0',
	'class'    => 'block-row',
	'active_callback' => $sticky_head,
] );


Crust_Customizer::add_field([
	'label'           => esc_html__('Top Offset (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'top_sticky_offset',
	'type'            => 'slider',
	'default'         => 0,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 500,
		'step' => 1,
	],
	'active_callback' => $sticky_head,
	'transport' => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head',
			'property' => 'top',
			'units' => 'px'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Scroll Offset (px)', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'top_sticky',
	'type'            => 'slider',
	'default'         => 400,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 1500,
		'step' => 1,
	],
	'active_callback' => $sticky_head
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'sticky_head_bg_color',
	'type'            => 'color',
	'class'           => 'block-row bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head > .crust-header-wrap, .crust-site-header.crust-sticky-scrolled > .crust-header-wrap',
			'property' => 'background-color',
			'suffix' => ' !important'
		]
	],
	'active_callback' => $sticky_head
] );
////dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Sticky BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'settings',
	'settings'        => 'sticky_head_dark_bg_color',
	'type'            => 'color',
	'class'           => 'block-row bottom-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head > .crust-header-wrap,body.crust-dark .crust-site-header.crust-sticky-scrolled > .crust-header-wrap',
			'property' => 'background-color',
			'suffix' => ' !important'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'header_behavior',
			'operator' => '==',
			'value'    => 'sticky',
		],
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'header_bg_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row',
	'tab'             => 'styling',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'header_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-gradient',
	'active_callback' => [
		[
			'setting'  => 'header_bg_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'output'      => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap',
			'property' => 'background',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'head_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'active_callback' => [
		[
			'setting'  => 'header_bg_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
	'output'      => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap',
		],
	],
]);


Crust_Customizer::add_field([
	'settings' => 'header_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'units'    => [
		'px' => 'px',
		'%'  => '%',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header',
			'property' => 'margin'
		]
	]
] );

Crust_Customizer::add_field([
	'settings'    => 'header_padding',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Padding', 'crust-core'),
	'section'     => $section,
	'tab'         => 'styling',
	'input_attrs' => [
		'min' => 0,
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) > .crust-header-wrap',
			'property' => 'padding'
		]
	]
] );



Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'colums2 bottom-picker',
	'settings' => 'header_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap',
			'property' => 'border-color'
		]
	]
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Border Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'type'     => 'select',
	'settings' => 'header_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'colums2',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'    => 'header_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border Width', 'crust-core'),
	'section'     => $section,
	'tab'         => 'styling',
	'input_attrs' => [
		'min' => 0,
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'header_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) > .crust-header-wrap',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'header_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'block-row bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) > .crust-header-wrap',
			'property' => 'box-shadow'
		]
	],
] );
//dark popup
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'settings'        => 'styling_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );
Crust_Customizer::add_field([
	'type'            => 'crust-icon-radio',
	'settings'        => 'header_bg_dark_type',
	'label'           => esc_html__('Background Type', 'crust-core'),
	'section'         => $section,
	'class'           => 'block-row crust-pop-field',
	'tab'             => 'styling',
	'choices'         => [
		'' => 'dashicons dashicons-hidden',
		'image'   => 'dashicons dashicons-format-image',
		'gradient' => 'dashicons dashicons-admin-appearance',
	],
] );

Crust_Customizer::add_field([
	'settings'        => 'header_dark_gradient',
	'label'           => esc_html__('Gradient', 'crust-core'),
	'section'         => $section,
	'tab'             => 'styling',
	'type'            => 'crust-gradient',
	'class'           => 'block-row crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'header_bg_dark_type',
			'operator' => '==',
			'value'    => 'gradient',
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark header.crust-site-header > .crust-header-wrap',
			'property' => 'background',
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'head_dark_bg',
	'label'       => '',
	'class'           => 'block-row crust-pop-field',
	'section'     => $section,
	'tab'         => 'styling',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'active_callback' => [
		[
			'setting'  => 'header_bg_dark_type',
			'operator' => '==',
			'value'    => 'image',
		]
	],
	'output'      => [
		[
			'element' => 'body.crust-dark header.crust-site-header > .crust-header-wrap',
		],
	],
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'styling',
	'class'    => 'bottom-picker crust-pop-field',
	'settings' => 'header_border_dark_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header > .crust-header-wrap',
			'property' => 'border-color'
		]
	]
] );
//////
// Container
Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'head_container_bg',
	'label'       => '',
	'section'     => $section,
	'tab'         => 'container',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row'
		]
	],
]);

Crust_Customizer::add_field([
	'settings'    => 'header_container_margin',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Margin', 'crust-core'),
	'section'     => $section,
	'tab'         => 'container',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header > .crust-header-wrap .crust-header-row',
			'property' => 'margin'
		]
	]
] );

Crust_Customizer::add_field([
	'settings'    => 'header_container_padding',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Padding', 'crust-core'),
	'section'     => $section,
	'tab'         => 'container',
	'input_attrs' => [
		'min' => 0,
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'padding'
		]
	]
] );



Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'container',
	'class'    => 'colums2 bottom-picker',
	'settings' => 'header_container_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'border-color'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'container',
	'type'     => 'select',
	'settings' => 'header_container_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'block-row colums2',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings'    => 'header_container_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border Width', 'crust-core'),
	'section'     => $section,
	'tab'         => 'container',
	'input_attrs' => [
		'min' => 0,
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'header_container_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'container',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'header_container_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'container',
	'class'    => 'block-row bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'box-shadow'
		]
	],
] );
///dark
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode colors', 'crust-core'),
	'section'         => $section,
	'tab'             => 'container',
	'settings'        => 'container_dark_colors_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	]
] );

Crust_Customizer::add_field([
	'type'        => 'background',
	'settings'    => 'head_container_dark_bg',
	'label'       => '',
	'class'    => 'crust-pop-field',
	'section'     => $section,
	'tab'         => 'container',
	'default'     => [
		'background-color'      => '',
		'background-image'      => '',
		'background-repeat'     => '',
		'background-position'   => '',
		'background-size'       => '',
		'background-attachment' => '',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.crust-dark header.crust-site-header:not(.crust-sticky-head) .crust-header-row'
		]
	],
]);

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'container',
	'class'    => 'colums2 bottom-picker crust-pop-field',
	'settings' => 'header_container_border_dark_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark header.crust-site-header:not(.crust-sticky-head) .crust-header-row',
			'property' => 'border-color'
		]
	]
] );