<?php

defined('ABSPATH') || die();

$section = 'navmenu';

// ==================== HEADER MOBILE ========================
Crust_Customizer::add_field([
	'label'           => esc_html__('Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_colors',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-responsive-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_colors_sticky',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-site-header.crust-sticky-head .crust-responsive-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Background Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-responsive-btn,.crust-site-header.crust-sticky-head .crust-responsive-btn',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_active_menu_icon',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-responsive-btn.crust-active-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Icon BG', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_active_menu_icon_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-responsive-btn.crust-active-btn',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_menu_links',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker',
	'output'   => [
		[
			'element' => '.crust-site-header .crust-site-navigation ul li a,.crust-collapse-nav',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Active Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_menu_active_links',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker',
	'output'   => [
		[
			'element' => '.crust-site-navigation ul li a.crust-act-btn span,.crust-act-btn + .crust-submenu-wrap + .crust-collapse-nav i',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Active BG', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_menu_links_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker',
	'output'   => [
		[
			'element' => '.crust-site-navigation ul li a.crust-act-btn,
							.crust-site-navigation > ul > li > a.active, 
							.crust-site-navigation > ul > li.current-menu-ancestor > a, 
							.crust-site-navigation > ul > li.current-menu-item > a, 
							.crust-site-navigation > ul > li.current-menu-parent > a, 
							.crust-site-navigation > ul > li.current_page_parent > a',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dropdown BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_menu_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker',
	'output'   => [
		[
			'element' => '.crust-site-navigation .crust-submenu-box, .crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu',
			'property' => 'background-color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Mode', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_head',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_colors',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-responsive-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Sticky Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_colors_sticky',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header.crust-sticky-head .crust-responsive-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Background Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-responsive-btn,body.crust-dark .crust-site-header.crust-sticky-head .crust-responsive-btn',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Icon Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_active_dark_menu_icon',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-responsive-btn.crust-active-btn',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Active Icon BG', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_active_dark_menu_icon_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-responsive-btn.crust-active-btn',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_menu_links',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-header .crust-site-navigation ul li a,body.crust-dark .crust-collapse-nav',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Active Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_menu_active_links',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-navigation ul li a.crust-act-btn span,body.crust-dark .crust-act-btn + .crust-submenu-wrap + .crust-collapse-nav i',
			'property' => 'color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Links Active BG', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_menu_links_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-navigation ul li a.crust-act-btn,
							body.crust-dark .crust-site-navigation > ul > li > a.active, 
							body.crust-dark .crust-site-navigation > ul > li.current-menu-ancestor > a, 
							body.crust-dark .crust-site-navigation > ul > li.current-menu-item > a, 
							body.crust-dark .crust-site-navigation > ul > li.current-menu-parent > a, 
							body.crust-dark .crust-site-navigation > ul > li.current_page_parent > a',
			'property' => 'background-color',
			'suffix' => ' !important',
			'media_query'   => '@media screen and (max-width:768px)',
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Dropdown BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'mobile',
	'settings'        => 'mobile_head_dark_menu_bg',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row bottom-picker colums2 crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-site-navigation .crust-submenu-box,body.crust-dark .crust-site-navigation li:not(.mega-menu) ul.sub-menu ul.sub-menu',
			'property' => 'background-color',
			'media_query'   => '@media screen and (max-width:768px)',
			'suffix' => ' !important'
		]
	],
] );


