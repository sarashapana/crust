<?php

defined('ABSPATH') || die();

$section = 'title_tagline';

// ==================== LOGO ========================
Crust_Customizer::add_field([
    'settings' => 'show_tagline',
    'label'    => esc_html__('Show Tagline', 'crust-core'),
    'section'  => $section,
    'type'     => 'switch',
    'priority' => 11,
    'default'  => true
]);

Crust_Customizer::add_field([
    'label'           => esc_html__('Logo', 'crust-core'),
    'section'         => $section,
    'settings'        => 'crust_logo',
    'priority'        => 12,
    'type'            => 'crust-image',
    //'class'           => 'colums2',
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Retina Logo', 'crust-core'),
    'section'  => $section,
    'settings' => 'retina_logo',
    'priority' => 13,
    'type'     => 'crust-image',
    //'class'    => 'colums2'
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Sticky Logo', 'crust-core'),
    'section'  => $section,
    'settings' => 'sticky_logo',
    'priority' => 14,
    'type'     => 'crust-image',
    //'class'    => 'colums2'
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Retina Sticky', 'crust-core'),
    'section'  => $section,
    'settings' => 'retina_sticky_logo',
    'priority' => 15,
    'type'     => 'crust-image',
    //'class'    => 'colums2'
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Mobile Logo', 'crust-core'),
    'section'  => $section,
    'settings' => 'mobile_logo',
    'priority' => 16,
    'type'     => 'crust-image',
    //'class'    => 'colums2'
]);

Crust_Customizer::add_field([
    'label'    => esc_html__('Retina Mobile', 'crust-core'),
    'section'  => $section,
    'settings' => 'retina_mobile_logo',
    'priority' => 17,
    'type'     => 'crust-image',
    //'class'    => 'colums2'
]);
