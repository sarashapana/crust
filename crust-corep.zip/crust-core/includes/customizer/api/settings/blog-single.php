<?php

defined('ABSPATH') || die();

$section = 'blog';

Crust_Customizer::add_field([
    'settings' => 'single_opts',
    'label'    => esc_html__('Post Settings', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-label',
] );

Crust_Customizer::add_field([
    'settings' => 'singl_media_on',
    'label'    => esc_html__('Media', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_icon_on',
    'label'    => esc_html__('Icon', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => false,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_cat_on',
    'label'    => esc_html__('Category', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_date_on',
    'label'    => esc_html__('Date', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_author_on',
    'label'    => esc_html__('Author', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
	'settings' => 'singl_comments_on',
	'label'    => esc_html__('Comments', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'type'     => 'crust-checkbox',
	'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_content_on',
    'label'    => esc_html__('Content', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_tags_on',
    'label'    => esc_html__('Tags', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_nav_on',
    'label'    => esc_html__('Nav', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_authbox_on',
    'label'    => esc_html__('Author Box', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_related_on',
    'label'    => esc_html__('Related', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

Crust_Customizer::add_field([
    'settings' => 'singl_share_on',
    'label'    => esc_html__('Socials', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'type'     => 'crust-checkbox',
    'default'  => true,
] );

//////featured image
Crust_Customizer::add_field([
	'label'           => esc_html__('Page Title Settings', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'page_title_sngl_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'     => 'radio-buttonset',
	'settings' => 'page_title_single_type',
	'label'    => esc_html__('Title Type', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field block-row',
	'choices'  => [
		'default' => esc_html__('Normal', 'crust-core'),
		'custom'  => esc_html__('Featured Image', 'crust-core'),
	],
] );

Crust_Customizer::add_field([
	'type'     => 'radio-buttonset',
	'settings' => 'page_title_single_type_height',
	'label'    => esc_html__('Height', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field block-row',
	'default'         => 'default',
	'choices'  => [
		'default' => esc_html__('Auto', 'crust-core'),
		'custom'  => esc_html__('custom', 'crust-core'),
		'full'    => esc_html__('Full', 'crust-core'),
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	]
] );

Crust_Customizer::add_field([
	'type'            => 'slider',
	'settings'        => 'image_title_custom_height',
	'label'           => esc_html__('Custom Height (px)', 'crust-core'),
	'section'         => $section,
	'class'           => 'crust-pop-field',
	'tab'             => 'single',
	'default'         => 0,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 1200,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type_height',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title > .container',
			'property' => 'min-height',
			'units'    => 'px',
			'suffix' => ' !important'
		],
	],
	'transport'   => 'auto',
] );

Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'page_title_single_repeat',
	'label'           => esc_html__('Background Repeat', 'crust-core'),
	'section'         => $section,
	'class'           => 'colums2 crust-pop-field',
	'tab'             => 'single',
	'choices'         => [
		'' => esc_html__('Auto', 'crust-core'),
		'no-repeat'    => 'No Repeat',
		'repeat'    => 'Repeat All',
		'repeat-x'    => 'Repeat Horizontally',
		'repeat-y'    => 'Repeat Vertically',
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title',
			'property' => 'background-repeat',
			'suffix'   => ' !important'
		],
	],
] );
Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'page_title_single_position',
	'label'           => esc_html__('Background Position', 'crust-core'),
	'section'         => $section,
	'class'           => 'colums2 crust-pop-field',
	'tab'             => 'single',
	'default'         => 'auto',
	'choices'         => [
		'' => esc_html__('Auto', 'crust-core'),
		'left top'    => 'Left Top',
		'left centre'    => 'Left Centre',
		'left bottom'    => 'Left Bottom',
		'right top'    => 'Right Top',
		'right centre'    => 'Right Centre',
		'right bottom'    => 'Right Bottom',
		'centre top'    => 'Centre Top',
		'centre centre'    => 'Centre Centre',
		'centre bottom'    => 'Centre Bottom',
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title',
			'property' => 'background-position',
			'suffix'   => ' !important'
		],
	],
] );
Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'page_title_single_attachment',
	'label'           => esc_html__('Background Attachment', 'crust-core'),
	'section'         => $section,
	'class'           => 'colums2 crust-pop-field',
	'tab'             => 'single',
	'default'         => 'auto',
	'choices'         => [
		'' => esc_html__('Auto', 'crust-core'),
		'fixed'    => 'Fixed',
		'scroll'    => 'Scroll',
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title',
			'property' => 'background-attachment',
			'suffix'   => ' !important'
		],
	],
] );
Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'page_title_single_Size',
	'label'           => esc_html__('Background Size', 'crust-core'),
	'section'         => $section,
	'class'           => 'colums2 crust-pop-field',
	'tab'             => 'single',
	'default'         => 'auto',
	'choices'         => [
		'' => esc_html__('Auto', 'crust-core'),
		'cover'    => 'Cover',
		'contain'    => 'Contain',
		'auto'    => 'Auto',
	],
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title',
			'property' => 'background-size',
			'suffix'   => ' !important'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'title_image_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'           => 'crust-pop-field',
	'active_callback' => [
		[
			'setting'  => 'page_title_single_type',
			'operator' => '==',
			'value'    => 'custom',
		],
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'body.single-post .crust-page-title',
			'property' => 'margin'
		],
	],
] );
////////
// Box styling...
Crust_Customizer::add_field([
	'label'           => esc_html__('Boxes Styles', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'settings' => 'box_sngl_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => ['.crust-post-wrapper .crust-single-container','.crust-post-block:not(.crust-nav-single)', '#comments.comments', '.comment-respond'],
			'property' => 'margin'
		],
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_sngl_padding',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Padding', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => ['.crust-post-wrapper .crust-single-container','.crust-post-block:not(.crust-nav-single)', '#comments.comments', '.comment-respond'],
			'property' => 'padding'
		],
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_bg_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'background-color'
		]
	]
] );

Crust_Customizer::add_field([
	'settings' => 'box_sngl_border',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Width', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'border-width'
		]
	],
] );

Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_border_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'border-color'
		]
	],
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'type'     => 'select',
	'settings' => 'box_sngl_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'crust-pop-field block-row colums2',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'border-style'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_sngl_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'box_sngl_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field block-row bottom-shadow',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['.crust-post-block:not(.crust-nav-single), .crust-single-content, .comment-respond, .crust-share-block'],
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field',
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('BG Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_bg_dark_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-post-block:not(.crust-nav-single),body.crust-dark .crust-single-content,body.crust-dark .comment-respond,body.crust-dark .crust-share-block'],
			'property' => 'background-color'
		]
	]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Border Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'box_sngl_border_dark_color',
	'type'            => 'color',
	'class'           => 'crust-pop-field block-row colums2 right-picker',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => ['body.crust-dark .crust-post-block:not(.crust-nav-single),body.crust-dark .crust-single-content,body.crust-dark .comment-respond,body.crust-dark .crust-share-block'],
			'property' => 'border-color'
		]
	],
] );

// Meta...
Crust_Customizer::add_field([
    'label'           => esc_html__('Meta', 'crust-core'),
    'section'         => $section,
    'tab'             => 'single',
    'settings'        => 'meta_sngl_wrap',
    'type'            => 'crust-wrapper',
    'class'           => 'crust-pop-head',
    'active_callback' => function () {
        if (false == crust_mod('singl_cat_on') && false == crust_mod('singl_date_on') && false == crust_mod('singl_author_on')) {
            return false;
        }

        return true;
    },
] );

Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => '',
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'meta_sngl',
    'class'    => 'crust-pop-field',
    'default'     => [
	    'font-family'    => '',
	    'variant'        => '',
	    'font-size'      => '',
	    'line-height'    => '',
	    'letter-spacing' => '',
	    'color'          => '',
	    'text-transform' => '',
	    'text-align'     => '',
    ],
    'transport' => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-post-wrapper .crust-single-container ul.crust-post-meta,.crust-post-wrapper .crust-single-container ul.crust-post-meta a',
	    ],
    ],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'meta_dark_archive',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-post-wrapper .crust-single-container ul.crust-post-meta,.crust-post-wrapper .crust-single-container ul.crust-post-meta a',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );


Crust_Customizer::add_field([
    'settings' => 'meta_sngl_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'space'    => 'margin',
    'section'  => $section,
    'tab'      => 'single',
    'class'    => 'crust-pop-field',
    'transport' => 'auto',
    'output'      => [
	    [
		    'element' => '.crust-post-wrapper .crust-single-container ul.crust-post-meta',
		    'property' => 'margin'
	    ],
    ],
] );

// Image...
Crust_Customizer::add_field([
    'label'           => esc_html__('Featured Image', 'crust-core'),
    'section'         => $section,
    'tab'             => 'single',
    'settings'        => 'img_sngl_wrap',
    'type'            => 'crust-wrapper',
    'class'           => 'crust-pop-head',
    'active_callback' => function () {
        if (true == crust_mod('singl_media_on')) {
            return true;
        }

        return false;
    },
] );

Crust_Customizer::add_field([
	'settings' => 'img_sngl_margin',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Margin', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'transport'       => 'auto',
	'output'      => [
		[
			'element' => '.crust-single-media',
			'property' => 'margin',
			'suffix'   => ' !important'
		],
	],
] );
Crust_Customizer::add_field([
	'settings'    => 'img_sngl_border',
	'type'        => 'crust-spacing',
	'label'       => esc_html__('Border', 'crust-core'),
	'section'     => $section,
	'tab'         => 'single',
	'class'       => 'crust-pop-field',
	'input_attrs' => [
		'min' => 0,
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-single-media',
			'property' => 'border-width'
		]
	]
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'colums2 bottom-picker crust-pop-field',
	'settings' => 'img_sngl_border_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-single-media',
			'property' => 'border-color'
		]
	]
] );


Crust_Customizer::add_field([
	'label'    => esc_html__('Style', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'type'     => 'select',
	'settings' => 'img_sngl_border_type',
	'choices'  => crust_border_type(),
	'class'    => 'colums2 crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-single-media',
			'property' => 'border-style'
		]
	],
] );


Crust_Customizer::add_field([
	'settings' => 'img_sngl_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-single-media',
			'property' => 'border-radius'
		]
	],
] );

Crust_Customizer::add_field([
	'settings' => 'img_sngl_shadow',
	'type'     => 'crust-box-shadow',
	'label'    => esc_html__('Box Shadow', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'block-row bottom-shadow crust-pop-field',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust-single-media',
			'property' => 'box-shadow'
		]
	],
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'img_dark_colors',
	'type'            => 'crust-label',
	'class'            => 'crust-pop-field',
] );

Crust_Customizer::add_field([
	'label'    => esc_html__('Border Color', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'block-row bottom-picker crust-pop-field',
	'settings' => 'img_sngl_border_dark_color',
	'type'     => 'color',
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-single-media',
			'property' => 'border-color'
		]
	]
] );


// Content...
Crust_Customizer::add_field([
    'label'           => esc_html__('Post Content', 'crust-core'),
    'section'         => $section,
    'tab'             => 'single',
    'settings'        => 'cont_sngl_wrap',
    'type'            => 'crust-wrapper',
    'class'           => 'crust-pop-head',
    'active_callback' => function () {
        if (true == crust_mod('singl_content_on')) {
            return true;
        }

        return false;
    },
] );

Crust_Customizer::add_field([
    'type'     => 'typography',
    'label'    => '',
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'cont_sngl',
    'class'    => 'crust-pop-field',
    'default'     => [
	    'font-family'    => '',
	    'variant'        => '',
	    'font-size'      => '',
	    'line-height'    => '',
	    'letter-spacing' => '',
	    'color'          => '',
	    'text-transform' => '',
	    'text-align'     => '',
    ],
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust-single-content',
	    ]
    ]
] );
Crust_Customizer::add_field([
	'label'           => esc_html__('Dark Color', 'elementor'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'cont_dark_archive',
	'type'            => 'color',
	'transport'       => 'auto',
	'class'           => 'block-row crust-pop-field',
	'output'   => [
		[
			'element' => 'body.crust-dark .crust-single-content',
			'property' => 'color'
		]
	],
	'active_callback' => [
		[
			'setting'  => 'dark_mode',
			'operator' => '===',
			'value'    => true,
		]
	],
] );

Crust_Customizer::add_field([
    'settings' => 'cont_sngl_margin',
    'type'     => 'crust-spacing',
    'label'    => esc_html__('Margin', 'crust-core'),
    'space'    => 'margin',
    'section'  => $section,
    'tab'      => 'single',
    'class'    => 'crust-pop-field',
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust-single-content',
		    'property' => 'margin'
	    ]
    ]
] );

// Social Share...
Crust_Customizer::add_field([
    'label'           => esc_html__('Social Share', 'crust-core'),
    'section'         => $section,
    'tab'             => 'single',
    'settings'        => 'share_wrap',
    'type'            => 'crust-wrapper',
    'class'           => 'crust-pop-head',
    'active_callback' => function () {
        if (true == crust_mod('singl_share_on')) {
            return true;
        }

        return false;
    },
] );

Crust_Customizer::add_field([
    'type'     => 'crust-icon-checkbox',
    'settings' => 'share_icons',
    'label'    => '',
    'section'  => $section,
    'tab'      => 'single',
    'choices'  => [
        'twitter'     => 'Twitter',
        'facebook'    => 'Facebook',
        'linkedin'    => 'LinkedIn',
        'pinterest'   => 'Pinterest',
        'whatsapp'    => 'WhatsApp',
        'email'       => 'Email',
        'stumbleupon' => 'Stumbleupon',
        'telegram'    => 'Telegram',
        'vkontakte'   => 'Vkontakte',
        'messenger'   => 'Messenger',
        'pocket'      => 'Pocket',
        'viber'       => 'Viber',
        'line'        => 'Line',
    ],
    'default'  => 'twitter,facebook,linkedin,pinterest',
    'class'    => 'crust-pop-field',
] );

Crust_Customizer::add_field([
	'settings' => 'share_border_radius',
	'type'     => 'crust-spacing',
	'label'    => esc_html__('Border Radius', 'crust-core'),
	'space'    => 'border',
	'section'  => $section,
	'tab'      => 'single',
	'class'    => 'crust-pop-field',
	'direction'=> [
		'top'   => 'top-left',
		'right' => 'top-right',
		'bottom'=> 'bottom-right',
		'left'  => 'bottom-left'
	],
	'units'    => [
		'px' => 'px',
	],
	'transport'       => 'auto',
	'output'   => [
		[
			'element' => '.crust_single_share .jssocials-share .jssocials-share-link',
			'property' => 'border-radius',
		]
	],
] );
//////related posts settings
Crust_Customizer::add_field([
	'label'           => esc_html__('Related Posts Settings', 'crust-core'),
	'section'         => $section,
	'tab'             => 'single',
	'settings'        => 'related_settings_sngl_wrap',
	'type'            => 'crust-wrapper',
	'class'           => 'crust-pop-head',
] );

Crust_Customizer::add_field([
	'type'            => 'slider',
	'settings'        => 'related_number',
	'label'           => esc_html__('Related Posts Number', 'crust-core'),
	'section'         => $section,
	'class'           => 'crust-pop-field',
	'tab'             => 'single',
	'default'         => 3,
	'input_attrs'     => [
		'min'  => 0,
		'max'  => 10,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => 'singl_related_on',
			'operator' => '==',
			'value'    => true,
		],
	]
] );

Crust_Customizer::add_field([
	'type'            => 'select',
	'settings'        => 'related_colums',
	'label'           => esc_html__('Related Posts Columns', 'crust-core'),
	'section'         => $section,
	'class'           => 'crust-pop-field',
	'tab'             => 'single',
	'default'         => 'auto',
	'choices'         => [
		'auto' => esc_html__('Auto', 'crust-core'),
		'1'    => '1',
		'2'    => '2',
		'3'    => '3',
		'4'    => '4',
		'5'    => '5',
		'6'    => '6',
	],
	'active_callback' => [
		[
			'setting'  => 'singl_related_on',
			'operator' => '==',
			'value'    => true,
		],
	]
] );

Crust_Customizer::add_field([
	'type'     => 'select',
	'label'    => esc_html__('Related Featured Image', 'crust-core'),
	'section'  => $section,
	'tab'      => 'single',
	'settings' => 'related_img',
	'class'    => 'crust-pop-field',
	'default'  => 'large',
	'choices'  => crust_core_get_img_sizes(),
	'active_callback' => [
		[
			'setting'  => 'singl_related_on',
			'operator' => '==',
			'value'    => true,
		],
	]
] );
///////////

$default_share = function (){
    if ('default' == crust_mod('share_theme')) {
        return true;
    }

    return false;
};

Crust_Customizer::add_field([
    'label'    => esc_html__('Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust_single_share[data-theme="default"] .jssocials-share-link',
		    'property' => 'color'
	    ]
    ]
] );
//*dark*//
Crust_Customizer::add_field([
    'label'    => esc_html__('Dark Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_dark_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => 'body.crust-dark .crust_single_share[data-theme="default"] .jssocials-share-link',
		    'property' => 'color'
	    ]
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('BG Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_bg_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust_single_share[data-theme="default"] .jssocials-share-link',
		    'property' => 'background-color'
	    ]
    ]
] );
//*dark*//
Crust_Customizer::add_field([
    'label'    => esc_html__('BG Dark Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_bg_dark_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => 'body.crust-dark .crust_single_share[data-theme="default"] .jssocials-share-link',
		    'property' => 'background-color'
	    ]
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Hover Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_hover_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust_single_share[data-theme="default"] .jssocials-share-link:hover',
		    'property' => 'color'
	    ]
    ]
] );
//*dark*//
Crust_Customizer::add_field([
    'label'    => esc_html__('Hover Dark Color', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_hover_dark_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust_single_share[data-theme="default"] .jssocials-share-link:hover',
		    'property' => 'color'
	    ]
    ]
] );

Crust_Customizer::add_field([
    'label'    => esc_html__('Hover BG', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_hover_bg_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => '.crust_single_share[data-theme="default"] .jssocials-share-link:hover',
		    'property' => 'background-color'
	    ]
    ]
] );
//*dark*//
Crust_Customizer::add_field([
    'label'    => esc_html__('Hover Dark BG', 'crust-core'),
    'section'  => $section,
    'tab'      => 'single',
    'settings' => 'share_hover_bg_dark_color',
    'type'     => 'color',
    'class'    => 'crust-pop-field colums2',
    'active_callback' => $default_share,
    'transport'       => 'auto',
    'output'   => [
	    [
		    'element' => 'body.crust-dark .crust_single_share[data-theme="default"] .jssocials-share-link:hover',
		    'property' => 'background-color'
	    ]
    ]
] );
