var crustPreview = crustPreview || {};

(function (wp, $) {
    "use strict";

    // Bail if the customizer isn't initialized
    if (!wp || !wp.customize) {
        return;
    }

    var api = wp.customize, OldPreview;

    // Custom Customizer Preview class (attached to the Customize API)
    api.customizerPreview = {
        // Init
        init: function () {
        }

    };

    OldPreview = api.Preview;
    api.Preview = OldPreview.extend({
        initialize: function (params, options) {
            // Store a reference to the Preview
            api.customizerPreview.preview = this;

            // Call the old Preview's initialize function
            OldPreview.prototype.initialize.call(this, params, options);
        }
    });

    /* ================ Window.Load Functions. ================ */

    wp.customize.bind('preview-ready', function () {
        api.customizerPreview.init();
    });

})(window.wp, jQuery);