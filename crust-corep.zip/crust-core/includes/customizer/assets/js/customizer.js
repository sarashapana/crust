"use strict";

(function ($, wp) {

    let api = wp.customize,
        crustCustomize = api.crustCustomize || {};

    // Custom Tabbed Section...
    api.sectionConstructor['kirki-tab-section'] = api.Section.extend({

        isContextuallyActive: function () {

            var section = this,
                controls = section.controls(),
                activeCount = 0,
                tabs = {};

            _(controls).each(function (control) {
                if (control.active()) {
                    tabs[control.container.data('tab')] = '';
                    activeCount += 1;
                }
            });

            for (var tab in tabs) {
                var element = section.container.find('.customize-control[data-tab=' + tab + ']'),
                    pane = section.container.find('.crust-tab-panel[data-parent-tab="' + tab + '"]');
                element.detach().appendTo(pane);
            }

            _( controls ).each( function ( control ) {
                if ( control.container.hasClass( 'crust-pop-head' ) ) {
                    var el = control.container,
                        titl = el.find( '.customize-control-title' ),
                        txt = titl.text(),
                        pane = el.find( 'ul.crust-fields-wrap' );
                    el.nextUntil( ':not(.crust-pop-field)' ).each( function () {
                        $( this ).detach().appendTo( pane );
                    });

                    el.find( '.crust-pop-title span' ).text( txt );
                    titl.on( 'click', function (e) {
                        e.preventDefault();
                        $( '.crust-fields-wrap' ).removeClass( 'active' );
                        el.find( '.crust-fields-wrap' ).addClass( 'active' );
                    });
                    el.find( '.close-box' ).on( 'click', function (e) {
                        e.preventDefault();
                        el.find( '.crust-fields-wrap' ).removeClass( 'active' );
                    });
                } else if ( control.container.hasClass( 'crust-tabs-head' ) ){
                    var el = control.container,
                        titl = el.find( '.customize-control-title' ),
                        txt = titl.text(),
                        panel = el.parents( '.crust-tab-panel' ),
                        pane = el.find( 'ul.crust-fields-tab' );
                    el.nextUntil( ':not(.crust-tabs-element)' ).each( function () {
                        $( this ).detach().appendTo( pane );
                    });

                    el.find( '.crust-field-tab' ).each( function () {
                        var th = $( this ),
                            id = th.data( 'id' );
                        th.detach().appendTo( panel.find( '.crust-tab-list .crust-list-wrp' ) );
                        if( th.is( ':first-child' ) ) {
                            th.addClass( 'active' );
                        }
                        th.text( txt );
                        th.on( 'click', function (e) {
                            e.preventDefault();
                            panel.find( '.crust-field-tab' ).removeClass( 'active' );
                            th.addClass( 'active' );
                            panel.find( '.crust-tabs-head' ).removeClass( 'active' );
                            panel.find( '.customize-control[id="'+id+'"]' ).addClass( 'active' );
                        });
                    });

                }
            });

            return ( activeCount !== 0 );

        },

        attachEvents: function () {
            var meta, content, section = this;
            var container = this.container;

            if (container.hasClass('cannot-expand')) {
                return;
            }

            // Expand/Collapse accordion sections on click.
            container.find('.accordion-section-title, .crust-section-back').on('click keydown', function (event) {
                if (api.utils.isKeydownButNotEnterEvent(event)) {
                    return;
                }
                event.preventDefault(); // Keep this AFTER the key filter above

                if (section.expanded()) {
                    section.collapse();
                } else {
                    section.expand();
                }

                $('.crust-fields-wrap').removeClass('active');

            });

            // This is very similar to what is found for api.Panel.attachEvents().
            container.find('.customize-section-title .customize-help-toggle').on('click', function () {

                meta = container.find('.section-meta');
                if (meta.hasClass('cannot-expand')) {
                    return;
                }
                content = meta.find('.customize-section-description:first');
                content.toggleClass('open');
                content.slideToggle(section.defaultExpandedArguments.duration, function () {
                    content.trigger('toggled');
                });
                $(this).attr('aria-expanded', function (i, attr) {
                    return 'true' === attr ? 'false' : 'true';
                });
            });

            var tablink = container.find('.crust-tabs-list li a'),
                poplink = container.find('.crust-pop-head .customize-control-title');

            tablink.each(function (i, button) {
                var previewLink = $( this ).data('preview' );
                $( button ).on('click', function (event) {
                    event.preventDefault();
                    var tab = $(button).data('tab-link');
                    container.find('.crust-tabs-list li a').removeClass('active');
                    container.find('.crust-tab-panel').removeClass('active-pane');
                    $(button).addClass('active');
                    container.find('.crust-tab-panel[data-parent-tab="' + tab + '"]').addClass('active-pane');

                    if ( previewLink  ) {
                        api.previewer.previewUrl.set(previewLink.toString());
                        api.previewer.refresh();
                    }

                });

            });

            poplink.each(function (j, popup) {
                /*$(popup).on('click', function (event) {
                    event.preventDefault();
                    $(this).parent().find('.crust-fields-wrap').addClass('active');
                });*/
            });

        },

        onChangeExpanded: function (expanded, args) {
            var section = this,
                container = section.headContainer.closest('.wp-full-overlay-sidebar-content'),
                content = section.contentContainer,
                overlay = section.headContainer.closest('.wp-full-overlay'),
                backBtn = content.find('.customize-section-back'),
                sectionTitle = section.headContainer.find('.accordion-section-title').first(), expand, panel,
                params = this.params;

            if (expanded && !content.hasClass('open')) {

                if (args.unchanged) {
                    expand = args.completeCallback;
                } else {
                    expand = $.proxy(function () {
                        section._animateChangeExpanded(function () {
                            sectionTitle.attr('tabindex', '-1');
                            backBtn.attr('tabindex', '0');

                            backBtn.focus();
                            content.css('top', '');
                            container.scrollTop(0);

                            if (args.completeCallback) {
                                args.completeCallback();
                            }
                        });

                        content.addClass('open');
                        overlay.addClass('section-open');
                        api.state('expandedSection').set(section);
                    }, this);
                }

                if (!args.allowMultiple) {
                    api.section.each(function (otherSection) {
                        if (otherSection !== section) {
                            otherSection.collapse({duration: args.duration});
                        }
                    });
                }

                if (section.panel()) {
                    api.panel(section.panel()).expand({
                        duration: args.duration,
                        completeCallback: expand
                    });
                } else {
                    if (!args.allowMultiple) {
                        api.panel.each(function (panel) {
                            panel.collapse();
                        });
                    }
                    expand();
                }

            } else if (!expanded && content.hasClass('open')) {
                if (section.panel()) {
                    panel = api.panel(section.panel());
                    if (panel.contentContainer.hasClass('skip-transition')) {
                        panel.collapse();
                    }
                }
                section._animateChangeExpanded(function () {
                    backBtn.attr('tabindex', '-1');
                    sectionTitle.attr('tabindex', '0');

                    sectionTitle.focus();
                    content.css('top', '');

                    if (args.completeCallback) {
                        args.completeCallback();
                    }
                });

                content.removeClass('open');
                overlay.removeClass('section-open');
                if (section === api.state('expandedSection').get()) {
                    api.state('expandedSection').set(false);
                }

            } else {
                if (args.completeCallback) {
                    args.completeCallback();
                }
            }

            var previewLink = this.params.preview_link;
            if ( expanded && previewLink  ) {
                api.previewer.previewUrl.set(previewLink.toString());
            }

        },

    });

    // Extend Control...
    api.Control = api.Control.extend({
        ready: function () {
            var control = this,
                container = control.container;
            crustCustomize.load.crustControl(container);
        }
    });

    // Margin Control ...
    crustCustomize.crustSpacing = api.Control.extend({
        ready: function () {

            var control    = this,
                container  = control.container,
                wrap       = container.find('.crust-spacing-wrapper');

            crustCustomize.load.crustControl(container);

            wrap.each(function () {
                var el          = $(this),
                    units       = control.params.units,
                    unit        = el.find('input[type="radio"]'),
                    inputs      = el.find('.crust-spacing-input'),
                    field       = el.find('.crust-spacing-control'),
                    field_val   = field.val(),
                    unit_val    = 'px',
                    valArray    = [];

                unit.removeAttr('checked');
                _.each( units, function( v, i ) {
                    if( field_val.indexOf(v) >= 0 ){
                        unit_val = i;
                    }
                });

                if( field_val !== '' ){
                    var newvl = field_val.replace( /[^\d -]/g , '' );
                    $.each(newvl.split(" ").slice(0,-1), function(index, item) {
                        valArray.push(item);
                    });
                }

                inputs.each(function (index) {
                    $(this).val(valArray[index]);
                    $(this).on('change keyup paste input', function (e) {
                        control.updateSpacingValue(field, inputs, unit_val);
                    });
                });

                unit.each(function () {
                    if( unit_val == $(this).val()  ){
                        $(this).attr('checked','checked');
                    }
                    unit.on('change', function () {
                        unit_val = $(this).val();
                        control.updateSpacingValue(field, inputs, unit_val);
                    });
                });

            });

        },

        updateSpacingValue: function (field, inputs, unit_val) {

            var field_val = '';
            inputs.each(function () {
                var inp_val = $(this).val(),
                    min_val = $(this).attr('min');
                if ( typeof min_val !== typeof undefined && min_val !== false && inp_val < 0  ) {
                    $(this).val(0);
                }
                field_val += (inp_val !== '') ? inp_val + unit_val + ' ' : '0 ';
            });

            if( field_val !== '0 0 0 0 ' ){
                field.val(field_val).trigger('change');
            } else {
                field.val('').trigger('change');
            }

        }

    });

    // Box Shadow Control ...
    crustCustomize.crustBoxShadow = api.Control.extend({
        ready: function () {

            var control    = this,
                container  = control.container,
                wrap       = container.find('.crust-shadow-wrapper');

            crustCustomize.load.crustControl(container);

            wrap.each(function () {
                var el        = $(this),
                    btn       = el.find('.crust-shadow-btn'),
                    reset     = el.find('.crust-shadow-reset'),
                    box       = el.find('.crust-shadow-control-wrap'),
                    input     = el.find('.crust-shadow-input'),
                    field     = el.find('.crust-shadow-control'),
                    field_val = field.val(),
                    valArray  = [];

                if( field_val !== '' ){
                    if( !field_val.indexOf('inset') >= 0 ){
                        valArray.push('outset');
                    }
                    $.each(field_val.split(" ").slice(0,-1), function(index, item) {
                        valArray.push(item);
                    });
                }

                input.each(function (index) {
                    $(this).val(valArray[index]);
                    var th = $(this);
                    var shadow = $(this).attr('data-shadow');

                    $(this).on('input change', function () {
                        control.updateShadowValue(field, input);
                    });

                });

                btn.on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if( !box.hasClass('visible-shadow-wrap') ){
                        box.addClass('visible-shadow-wrap');
                        $(document).mouseup(function (e) {
                            if ($(e.target).closest(".visible-shadow-wrap").length === 0) {
                                box.removeClass('visible-shadow-wrap');
                            }
                        });
                    } else {
                        box.removeClass('visible-shadow-wrap');
                    }
                });

                reset.on('click', function (e) {
                    e.preventDefault();
                    el.find('.crust-shadow-input.crust-slider-value').val(0).trigger('change');
                    el.find('.crust-shadow-input:not(.crust-slider-value)').val('').trigger('change');
                    field.val('').trigger('change');
                });

            });

        },

        updateShadowValue: function (field, input) {

            var field_val = '';

            input.each(function () {

                var inp_val = $(this).val();

                if( inp_val !== '' ){
                    if( $(this).val() === 'outset' ){
                        inp_val = '';
                    }

                    field_val += (inp_val != '') ? inp_val + ' ' : '';
                }

            });
            field.val(field_val).trigger('change');
        }

    });

    // Gradient Control
    crustCustomize.crustGradient = api.Control.extend({
        ready: function () {

            let control    = this,
                container  = control.container,
                wrap       = container.find('.crust-gradient-control'),
                input 		= wrap.find('.crust-grad-field'),
                $field      = wrap.find('.crust-grad-control'),
                value 		= $field.val(),
                grd 		= [];

            crustCustomize.load.crustControl(container);

            $( '.crust-grad-color', wrap ).wpColorPicker();

            if( value ){
                let array = value
                    .substring( value.lastIndexOf("(") + 1, value.lastIndexOf(")") )
                    .replace('deg', '')
                    .replaceAll('%', '')
                    .replace(/,/g , '').split(' ');

                grd = array;
                for ( let k in array ){
                    let inp = array[k],
                        item = $('.crust-grad-field[data-index="'+k+'"]');
                    item.parents('.wp-picker-container').find('.color-alpha').css( 'background', inp );
                    item.val( inp );
                }
            }

            // the inputs...
            input.each(function (){

                let index = $(this).data('index');

                if( $(this).hasClass('crust-grad-color') ){
                    $(this).wpColorPicker({
                        change: function (event, ui){
                            let col = ui.color.toString();
                            if (col.indexOf("rgba") >= 0) {
                                col = control.crust_rgb2hex(col);
                            }
                            grd[index] = col;
                            control.updateGradientValue(grd, $field);
                        }
                    });
                }
                $(this).on('change input type', function () {
                    grd[index] = $(this).val();
                    control.updateGradientValue(grd, $field);
                });

            });

        },

        updateGradientValue: function (grd, $field) {

            if( grd[0] === undefined ){
                grd[0] = 90;
            }
            if( grd[2] === undefined ){
                grd[2] = 0;
            }
            if( grd[4] === undefined ){
                grd[4] = 100;
            }

            let value = 'linear-gradient(' + grd[0] + 'deg, ' + grd[1] + ' ' + grd[2] + '%, ' + grd[3] + ' ' + grd[4] + '%)';
            $field.val(value).attr('value', value).trigger('change');

        },

        crust_rgb2hex: function (rgba) {

            let inParts = rgba.substring(rgba.indexOf("(")).split(","),
                r = parseInt(trim(inParts[0].substring(1)), 10),
                g = parseInt(trim(inParts[1]), 10),
                b = parseInt(trim(inParts[2]), 10),
                a = (inParts[3]) ? parseFloat(trim(inParts[3].substring(0, inParts[3].length - 1))).toFixed(2) : '';
            if( inParts[3] ){
                let outParts = [
                    r.toString(16),
                    g.toString(16),
                    b.toString(16),
                    Math.round(a * 255).toString(16).substring(0, 2)
                ];

                // Pad single-digit output values
                outParts.forEach(function (part, i) {
                    if (part.length === 1) {
                        outParts[i] = '0' + part;
                    }
                })

                return ('#' + outParts.join(''));
            }

        }

    });

    /*crustCustomize.crustEditMod = api.Control.extend({
        ready: function () {
            let control    = this,
                container  = control.container;

            if ( container.find('.crust-btn-model') ){

                let modal = container.find(".crust-custom-modal"),
                    btn = container.find(".crust-btn-model"),
                    edt = btn.data("edit"),
                    ad = btn.data("add"),
                    mod = btn.data("mod"),
                    span = container.find(".crust-custom-modal-close"),
                    ifrm = container.find('iframe'),
                    type = crust_localize.type,
                    admn = crust_localize.admin_url,
                    chid = crust_localize.chid,
                    post = crust_localize.post,
                    slct = container.find('select'),

                    tmp = '';
                  var  val_tmp = '';


                    if (chid) {
                        if (type === 'wpb') {
                            tmp = 'post.php?post_id=' + chid + '&post_type=' + mod + '&vc_action=vc_inline';
                        } else {
                            tmp = 'post.php?post=' + chid + '&action=elementor';
                        }
                    } else {
                        tmp = 'edit.php?post_type=' + mod;
                    }

                if( slct.val() !== '' ) {
                    btn.text(edt);
                } else {
                    btn.text(ad);
                }

                slct.on('change', function (){

                    let vl = $(this).val();

                    if( vl ){
                        if( type === 'wpb' ){
                            val_tmp = 'post.php?post_id='+ vl +'&post_type='+ mod +'&vc_action=vc_inline';
                        } else {
                            val_tmp = 'post.php?post='+ vl +'&action=elementor';
                        }
                    } else {
                        val_tmp = 'edit.php?post_type='+mod;
                    }

                    if( vl !== '' ) {
                        btn.text(edt);
                    } else {
                        btn.text(ad);
                    }

                });




                btn.addClass('actv');

                btn.on('click', function (e){
                    modal.fadeIn();
                    e.preventDefault();

                    //ajax edit module
                    if( slct.val() === '' ) {
                        ifrm.attr('src',admn+tmp);
                    }else {
                        ifrm.attr('src',admn+val_tmp);
                    };

                    var data = {
                        'action': 'crust_edit_module',
                        'xyz':$(this).data('temp'),
                    }
                    $.post(admn+'admin-ajax.php', data, function(response) {
                        console.log(response);
                    });

                    var xyz = $(this).attr('id');
                    $.ajax({
                        type : "post",
                        dataType : "json",
                        url : admn+'admin-ajax.php',
                        data : {
                            action: "crust_edit_module",xyz : xyz
                        },
                        success: function(response) {
                            //ifrm.attr("src",admn+response);
                            console.log(response);
                        },
                        error: function () {
                            console.log('error');

                        },
                    });
                });

                span.on('click',function(e) {
                    e.preventDefault();
                    modal.fadeOut();
                });

            }

        }
    });*/

    $.extend(api.controlConstructor, {
        'crust-spacing': crustCustomize.crustSpacing,
        'crust-box-shadow': crustCustomize.crustBoxShadow,
        'crust-gradient': crustCustomize.crustGradient,
        //'crust-edit-module': crustCustomize.crustEditMod,
    });

    crustCustomize.load = {
        crustControl: function (container) {

            $( '.crust-checkbox.multi-checkbox' ).on(
                'change',
                function() {

                    var checkbox_values = $( this ).parents( '.customize-control' ).find( 'input[type="checkbox"]:checked' ).map(
                        function() {
                            return this.value;
                        }
                    ).get().join( ',' );

                    $( this ).parents( '.customize-control' ).find( 'input[type="hidden"]' ).val( checkbox_values ).trigger( 'change' );
                }
            );

            var params = {
                change: function(e, ui) {
                    $( e.target ).val( ui.color.toString() );
                    $( e.target ).trigger('change'); // enable widget "Save" button
                },
            }

            $('.crust-shadow-color').wpColorPicker( params );

            if (container.hasClass('crust-pop-typo')) {
                var el = container,
                    head = el.find('.customizer-text'),
                    titl = el.find('.customize-control-title'),
                    txt = titl.text(),
                    pane = el.find('.wrapper');

                pane.prepend('<div class="crust-pop-title"><span>'+txt+'</span><a href="#" class="close-box">Close</a></div>');

                head.on('click', function (e) {
                    e.preventDefault();
                    $('.crust-pop-typo .wrapper').removeClass('active');
                    pane.addClass('active');
                });
                el.find('.close-box').on('click', function (e) {
                    e.preventDefault();
                    pane.removeClass('active');
                });
            }

        }

    }

})(jQuery, wp);