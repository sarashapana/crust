<?php

defined('ABSPATH') || die();

class Crust_Customizer_Init
{

	protected $modules = [
		'kirki-extend' => 'Crust_Kirki_Extend'
	];

	public function __construct() {

		$this->init();
		add_action( 'customize_register',                   [ $this, 'load_customizer' ], 6 );
		add_action( 'init',                                 [ $this, 'load_settings' ] );
		add_action( 'customize_controls_enqueue_scripts',   [ $this, 'enqueue_scripts' ] );
		add_action( 'customize_preview_init',               [ $this, 'crust_preview_init' ] );
		//add_action( 'wp_ajax_crust_edit_module',            [ $this, 'crust_edit_module' ] );
		//add_action( 'wp_ajax_nopriv_crust_edit_module',     [ $this, 'crust_edit_module' ] );

	}

//	public function crust_edit_module(){
//		$xyz = $_POST['xyz'];
//		$temp = crust_dyn_mod($xyz);
//		$post_id = get_option('$xyz');
//		$elementor_page = get_post_meta( $post_id, '_elementor_edit_mode', true );
//		if ($elementor_page || defined( 'WPB_VC_VERSION' ) )
//		{
//			if (  $elementor_page ) {
//				$temp = 'edit.php?post='.$post_id.'&action=elementor';
//			} else if( defined( 'WPB_VC_VERSION' ) ) {
//				$temp = 'edit.php?vc_action=vc_inline&post_id='.$post_id.'&post_type=crust_header';
//			}
//		}else{
//			$temp = 'edit.php?post_type=';
//		}

//		wp_send_json($temp);
//		return $temp;
//		wp_die();
//	}

	public function init()
	{

		if ( ! crust_edit_page() ) {
			Crust_Core::load_files([
				'customizer/api/kirki/kirki',
				'customizer/api/customizer',
				'customizer/api/modules/multilingual'
			]);
		}

	}

	public function load_customizer()
	{

		Crust_Core::load_files([
			'customizer/api/modules/control',
			'customizer/api/modules/section'
		]);

		// Load custom controls..
		foreach ( glob( CRUST_CORE_DIR . 'includes/customizer/api/controls/*.php' ) as $control_file ) { require_once $control_file; }

		add_filter( 'kirki_section_types', [ $this, 'register_section_types' ] );
		add_filter( 'kirki_control_types', [ $this, 'register_control_types' ] );

	}

	public function load_settings()
	{

		if ( ! crust_edit_page() ) {
			Kirki::add_config( Crust_Customizer::$config_id, [
				'capability'  => 'edit_theme_options',
				'option_type' => 'theme_mod',
			] );

			$this->add_sections();

			// Load Settings fields..
			foreach ( glob( CRUST_CORE_DIR . 'includes/customizer/api/settings/*.php' ) as $setting_file ) {
				require_once $setting_file;
			}
		}

	}

	public function get_random_post( $post_type = '' ) {

		if ( empty( $post_type ) ) {
			return false;
		}
		$args = [
			'ignore_sticky_posts' => true,
			'post_type'           => $post_type,
			'posts_per_page'      => 1,
			'orderby'             => 'rand',
			'post_status'         => 'any'
		];
		$item = get_posts( $args );
		$id = ! empty( $item[0] ) ? $item[0]->ID : 0;
		if ( $id ) {
			if ( function_exists( 'pll_get_post' ) ) {
				return pll_get_post( $id );
			}
			return $id;
		}
		return false;

	}

	public function add_sections()
	{

		$general_tabs = [
			'settings' => esc_html__('Settings', 'crust-core'),
			'styling'  => esc_html__('Body', 'crust-core'),
			'wrapper'  => esc_html__('Wrapper', 'crust-core'),
			'error404' => esc_html__('404 Error', 'crust-core'),
			'login'    => esc_html__('Login', 'crust-core'),
		];

		$header_tabs = [
			'settings' => esc_html__('Settings', 'crust-core'),
			'styling'  => esc_html__('Styling', 'crust-core'),
			'container'=> esc_html__('Container', 'crust-core'),
			'logo'     => esc_html__('Logo', 'crust-core'),
			'search'   => esc_html__('Search', 'crust-core'),
		];

		if(class_exists( 'Woocommerce')) {
			$header_tabs['cart'] = esc_html__('Cart', 'crust-core');
		}

		$nav_tabs = [
			'menu'      => esc_html__('Menu', 'crust-core'),
			'submenu'   => esc_html__('Sub Menu', 'crust-core'),
			'mobile'    => esc_html__('Mobile', 'crust-core'),
		];

		$title_tabs = [
			'settings'    => esc_html__('Settings', 'crust-core'),
			'styling'     => esc_html__('Styling', 'crust-core'),
			'breadcrumbs' => esc_html__('Breadcrumbs', 'crust-core'),
		];

		$footer_tabs = [
			'widgets'   => esc_html__('widgets Area', 'crust-core'),
			'subfooter' => esc_html__('Sub Footer', 'crust-core'),
		];

		$typo_tabs = [
			'body' => esc_html__('Body', 'crust-core'),
			'head' => esc_html__('Headings', 'crust-core'),
			'titl' => esc_html__('Page Title', 'crust-core'),
		];

		if( class_exists('Tribe__Events__Main') ){
			$typo_tabs['eventstypo'] = esc_html__('Events', 'crust-core');
		};

		$blog_tabs = [
			'archive' => esc_html__('Archive', 'crust-core'),
			'single'  => [
				'name' => esc_html__('Single', 'crust-core'),
				'slug' => get_permalink( $this->get_random_post( 'post' ) )
			],
		];

		$portfolio_tabs = [
			'archive' => esc_html__('Archive', 'crust-core'),
			'single'  => esc_html__('Single', 'crust-core'),
		];

		$layout_tabs = [
			'styling'  => esc_html__('Styling', 'crust-core'),
			'sidebars' => esc_html__('Sidebar', 'crust-core'),
			'widgets'  => esc_html__('Widget Styling', 'crust-core'),
		];

		$woo_tabs = [
			'archive' => esc_html__('Archive', 'crust-core'),
			'archive-style' => esc_html__('Archive Styling', 'crust-core'),
			'single'  => esc_html__('Single', 'crust-core')
		];

		$bbpress_tabs = [
			'general' => esc_html__('General', 'crust-core'),
		];

		$blog_preview = get_permalink( get_option( 'page_for_posts' ) );
		$portfolio_preview = get_post_type_archive_link( CRUST_PORTFOLIO );
		$page_preview = get_permalink( $this->get_random_post( 'page' ) );

		// Sections..
		$sections = [
			'general'    => [ esc_html__('General Settings', 'crust-core'),  30, 'kirki-tab-section', '#',                $general_tabs ],
			'header'     => [ esc_html__('Header', 'crust-core'),            31, 'kirki-tab-section', '#',                $header_tabs ],
			'navmenu'    => [ esc_html__('Navigation Menu', 'crust-core'),   32, 'kirki-tab-section', '#',                $nav_tabs ],
			'title'      => [ esc_html__('Page Title', 'crust-core'),        33, 'kirki-tab-section', '#',                $title_tabs ],
			'footer'     => [ esc_html__('Footer', 'crust-core'),            34, 'kirki-tab-section', '#',                $footer_tabs ],
			'typography' => [ esc_html__('Typography', 'crust-core'),        35, 'kirki-tab-section', '#',                $typo_tabs ],
			'blog'       => [ esc_html__('Blog Options', 'crust-core'),      36, 'kirki-tab-section', $blog_preview,      $blog_tabs   ],
			'portfolio'  => [ esc_html__('Portfolio', 'crust-core'),         37, 'kirki-tab-section', $portfolio_preview, $portfolio_tabs ],
			'layout'     => [ esc_html__('Layout', 'crust-core'),            38, 'kirki-tab-section', '#',                $layout_tabs ],
		];

		if( class_exists( 'Woocommerce' ) ) {
			$sections['crust-woo'] = [
				esc_html__('Crust WooCommerce', 'crust-core'), 39, 'kirki-tab-section', '#', $woo_tabs
			];
		}

		if( function_exists('is_bbpress') ) {
			$sections['crust-bbpress'] = [
				esc_html__('Crust BBPress', 'crust-core'), 40, 'kirki-tab-section', '#', $bbpress_tabs
			];
		}

		foreach ( $sections as $id => $section ) {

			$args = [
				'title'         => $section[0],
				'priority'      => $section[1],
				'type'          => $section[2],
				'preview_link'  => $section[3],
				'tabs'          => $section[4]
			];
			Crust_Customizer::add_section( $id, $args );
		}

	}

	public function register_section_types( $section_types = [] ) {
		return array_merge( $section_types, Crust_Customizer::$section_types );
	}

	public function register_control_types( $control_types = [] )
	{
		return array_merge( $control_types, Crust_Customizer::$control_types);
	}

	public function enqueue_scripts()
	{

		wp_deregister_style( 'kirki-styles');

		wp_enqueue_style( 'crust-control-style', CRUST_CORE_URI . 'includes/customizer/assets/css/control-style.css', ['customize-controls']);
		wp_enqueue_style('crust-customizer', CRUST_CORE_URI . 'includes/customizer/assets/css/customizer.css', ['customize-controls']);
		wp_enqueue_script('crust-customizer', CRUST_CORE_URI . 'includes/customizer/assets/js/customizer.js', ['customize-controls'], null, true);

		crust_customizer_modules();

	}

	public function crust_preview_init() {
		add_action( 'wp_enqueue_scripts', [ $this, 'crust_preview_scripts' ] );
	}

	public function crust_preview_scripts()
	{
		wp_enqueue_style('crust-preview', CRUST_CORE_URI . 'includes/customizer/assets/css/preview.css');
		wp_enqueue_script('crust-preview', CRUST_CORE_URI . 'includes/customizer/assets/js/preview.js', ['customize-preview-widgets'], null, true);
	}

}

new Crust_Customizer_Init();