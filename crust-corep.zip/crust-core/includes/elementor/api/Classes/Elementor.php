<?php

namespace Crust_Core\Classes;

use Elementor\Base_Control;
use Elementor\Controls_Manager;

if ( ! defined('ABSPATH')) { exit('Access Denied.'); }

class Elementor
{

    use \Crust_Core\Traits\Helper;
    use \Crust_Core\Traits\Elements;

    const MINIMUM_ELEMENTOR_VERSION = '2.8.0';

    const MINIMUM_PHP_VERSION = '7.0';

    private static $_instance = null;

    public $registered_elements;

    public function __construct()
    {

		// elements classmap
		$this->registered_elements = apply_filters('crust_core/registered_elements', $GLOBALS['crust_core_config']['elements']);

		// Register our custom source.
		add_action( 'elementor/init', [ $this, 'crust_custom_source' ] );
		add_action( 'elementor/controls/controls_registered', [ $this, 'register_controls' ] );

		add_action( 'wp_enqueue_scripts', [ $this, 'crust_elementor_front_assets' ] );
		add_action( 'elementor/preview/enqueue_styles', [ $this, 'crust_elementor_editor_scripts' ] );

		// Check for required Elementor version
		if ( ! version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
			add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
			return;
		}

		// Check for required PHP version
		if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
			add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/elements/categories_registered',                  [ $this, 'register_widget_categories'] );
		add_action( 'elementor/widgets/widgets_registered',                      [ $this, 'register_elements'] );
		add_filter( 'elementor/icons_manager/additional_tabs',                   [ $this, 'add_custom_icons_tab'] );
		add_action( 'elementor/element/section/section_background_overlay/before_section_end', [ $this, 'crust_elementor_section_overlay' ], 11, 2 );
		add_action( 'elementor/element/section/section_background/after_section_end', [ $this, 'crust_elementor_section_extras' ], 11, 2 );
		add_action( 'elementor/element/column/section_background_overlay/after_section_end', [ $this, 'crust_elementor_dark_column' ], 11, 2 );

		add_action( 'elementor/frontend/section/before_render',                  [ $this, 'crust_elementor_before_render' ] );
		add_action( 'elementor/element/column/layout/after_section_start',       [ $this, 'crust_elementor_column_extras' ] );
		add_action( 'elementor/frontend/column/before_render',                   [ $this, 'crust_elementor_column_render' ] );
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'crust_elementor_widget_extras'] , 10, 2);
		add_filter( 'elementor/frontend/widget/before_render',                   [ $this, 'crust_elementor_widget_content'] );

	}

    public function register_controls(){
	    $controls_manager = \Elementor\Plugin::$instance->controls_manager;
	    $controls_manager->register_control( 'crust_hotspot_control', new Crust_Image_Hotspot_Control() );
	    $controls_manager->register_control( 'crust_select_control', new Crust_Image_Select_Control() );
    }

    public function crust_custom_source() {

	    crust_core()->load_files( [ 'elementor/api/templates/source' ] );

	    $unregister_source = function($id) {
		    unset( $this->_registered_sources[ $id ] );
	    };

	    $unregister_source->call( \Elementor\Plugin::instance()->templates_manager, 'remote');
	    \Elementor\Plugin::instance()->templates_manager->register_source( 'Elementor\TemplateLibrary\Source_Custom' );

    }

    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }




    public function get_settings( $element = null )
    {

	    $elements = array_fill_keys(array_keys($this->registered_elements), true);
        return (isset($element) ? (isset($elements[$element]) ? $elements[$element] : 0) : array_keys(array_filter($elements)));

    }

    public function admin_notice_minimum_elementor_version()
    {
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }

        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'crust-core'),
            '<strong>' . esc_html__('Crust Core', 'crust-core') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'crust-core') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_php_version()
    {
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }

        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'crust-core'),
            '<strong>' . esc_html__('Crust Core', 'crust-core') . '</strong>',
            '<strong>' . esc_html__('PHP', 'crust-core') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function add_custom_icons_tab( $tabs = [] ) {

        // Append new icons
        $icons = [
	        [
		        'name'  => 'duotone',
		        'title' => esc_html__( 'Duotone', 'crust-core' ),
		        'slug'  => '',
		        'url'   => 'https://pro.fontawesome.com/releases/v5.15.2/css/all.css',
		        'icon'  => 'fa fa-bell'
	        ],
	        [
		        'name'  => 'uicons',
		        'title' => esc_html__( 'Uicons', 'crust-core' ),
		        'slug'  => '',
		        'url'   => CRUST_URI . '/lib/assets/icons/uicons-regular-rounded.css',
		        'icon'  => 'fa fa-bell'
	        ],
        ];

        foreach( $icons as $icon ){
            $icons_array = include CRUST_CORE_DIR  .'assets/icons/elementor/'.$icon['name'].'.php';

            $tabs[$icon['name']] = [
                'name'          => $icon['name'],
                'label'         => $icon['title'],
                'labelIcon'     => $icon['icon'],
                'prefix'        => '',
                'displayPrefix' => $icon['slug'],
                'url'           => $icon['url'],
                'icons'         => $icons_array,
                'ver'           => '',
            ];
        }

        return $tabs;

    }

    public function crust_elementor_front_assets()
    {
	    //wp_deregister_style( 'yith-wcwl-font-awesome' );
	    wp_deregister_style( 'elementor-icons-duotone' );
	    wp_deregister_style( 'elementor-icons-shared-0' );
	    wp_deregister_style( 'elementor-icons-fa-solid' );
	    wp_deregister_style( 'elementor-icons-uicons' );
	    wp_enqueue_style( 'crust-elementor', CRUST_CORE_URI . 'includes/elementor/assets/front/css/style.css', ['crust-frontend'] );
	    wp_enqueue_script( 'crust-elementor', CRUST_CORE_URI . 'includes/elementor/assets/js/script.js', ['jquery'], null, true );
    }

    public function crust_elementor_editor_scripts()
    {
        wp_enqueue_script( 'crust-elementor', CRUST_CORE_URI . 'includes/elementor/assets/js/script.js', ['jquery'], null, true );
    }

}
