<?php

namespace Crust_Core\Classes;

if ( ! defined('ABSPATH')) { exit('Access Denied.'); }

class Crust_Image_Hotspot_Control extends \Elementor\Base_Data_Control {

	public function get_type() {
		return 'crust_hotspot_control';
	}

	public function enqueue() {
		// Styles
		wp_register_style( 'crust-hotspot', CRUST_CORE_URI . 'assets/admin/css/hotspot.css', ['elementor-editor'], '' );
		wp_enqueue_style( 'crust-hotspot' );

		// Scripts
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker');
		wp_enqueue_script( 'crust-jquery-hotspot', CRUST_CORE_URI . 'assets/admin/js/jquery.hotspot.js', [], '' );
		wp_enqueue_script( 'crust-hotspot', CRUST_CORE_URI . 'includes/elementor/assets/admin/hotspot.js', [], '' );
	}

	protected function get_default_settings() {
		return [
			'label_block' => true,
		];
	}

	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo esc_attr( $control_uid ); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">

                <div class="cp-marker-holder">
                    <div class="cp-image-map-holder">
                        <img alt="" class="mark_img" src="<?php echo CRUST_CORE_URI ?>/includes/elementor/assets/images/placeholder.jpg" />
                    </div>
                    <input type="hidden" class="cp_map_marker" id="<?php echo esc_attr( $control_uid ); ?>" data-setting="{{ data.name }}" />
                </div>
			</div>
		</div>
		<# if ( data.description ) { #>
		<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}

}