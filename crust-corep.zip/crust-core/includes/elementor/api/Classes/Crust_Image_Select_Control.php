<?php

namespace Crust_Core\Classes;

if ( ! defined('ABSPATH')) { exit('Access Denied.'); }

class Crust_Image_Select_Control extends \Elementor\Base_Data_Control {

	public function get_type() {
		return 'crust_select_control';
	}

	public function enqueue() {
		wp_enqueue_style( 'crust-image-select', CRUST_CORE_URI . 'includes/elementor/assets/admin/image-select.css', ['elementor-editor'], '' );
		wp_enqueue_script( 'crust-image-select', CRUST_CORE_URI . 'includes/elementor/assets/admin/image-select.js', [], '' );
    }

	protected function get_default_settings() {
		return [
			'label_block' => true,
		];
	}

	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo esc_attr( $control_uid ); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
                <a href="#" class="crust-select-shape"><?php echo esc_html__('SELECT SHAPE', 'crust-core'); ?></a>
                <div class="crust-select-holder">
                    <# _.each( data.options, function( options, value ) { #>
                    <div class="crust-select-img">
                        <input id="crst-{{ value }}" type="radio" name="crst-choose-{{ data.name }}-{{ data._cid }}" value="{{ value }}">
                        <label class="crust-select-img-lbl" for="crst-{{ value }}">
                            <img src="{{ options.image }}" >
                            <span class="elementor-screen-only">{{{ options.title }}}</span>
                        </label>
                    </div>
                    <# } ); #>
                </div>
                <input id="<?php echo $control_uid; ?>" class="crust-img-selector" type="hidden" data-setting="{{ data.name }}" name="elementor-choose-{{ data.name }}" />
			</div>
		</div>
		<# if ( data.description ) { #>
		<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}

}