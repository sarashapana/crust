<?php

function crust_elementor_pages_templates(){

    $templates = [];
	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/pages/';
	$link = 'https://crust.it-rays.net/elementor/';

	$data = [
		'id'                => 'about-us',
		"title"             => "About Us",
		"thumbnail"         => $thumb . "about.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/about-us.json',
		"url"               => $link . 'about-us',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["about", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'about-extended',
		"title"             => "About Extended",
		"thumbnail"         => $thumb . "about-extended.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/about-extended.json',
		"url"               => $link . 'about-extended',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["about", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'about-me',
		"title"             => "About Me",
		"thumbnail"         => $thumb . "about-me.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/about-me.json',
		"url"               => $link . 'about-me',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["about", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'coming-soon',
		"title"             => "Coming Soon",
		"thumbnail"         => $thumb . "soon.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/coming-soon.json',
		"url"               => $link . 'coming-soon',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["soon", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'features',
		"title"             => "Features",
		"thumbnail"         => $thumb . "features.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/features.json',
		"url"               => $link . 'features',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["features", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'services',
		"title"             => "Services",
		"thumbnail"         => $thumb . "services.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/services.json',
		"url"               => $link . 'services',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["services", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'jobs',
		"title"             => "Jobs",
		"thumbnail"         => $thumb . "jobs.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/jobs.json',
		"url"               => $link . 'jobs',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["jobs", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'job-apply',
		"title"             => "Job Apply",
		"thumbnail"         => $thumb . "job-apply.jpg",
		"tmpl_created"      => "1475067229",
		"author"            => "winsomethemes",
		"file"              => 'pages/job-apply.json',
		"url"               => $link . 'job-apply',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["jobs", "intros"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'contact',
		"title"             => 'Contact',
		"thumbnail"         => $thumb . 'contact.jpg',
		"tmpl_created"      => '1475067229',
		"author"            => 'winsomethemes',
		"file"              => 'pages/contact.json',
		"url"               => $link . 'contact',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["contact"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'contact-extended',
		"title"             => 'Contact Extended',
		"thumbnail"         => $thumb . 'contact-extended.jpg',
		"tmpl_created"      => '1475067229',
		"author"            => 'winsomethemes',
		"file"              => 'pages/contact-extended.json',
		"url"               => $link . 'contact-extended',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["contact"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'pricing',
		"title"             => 'Pricing Tables',
		"thumbnail"         => $thumb . 'pricing.jpg',
		"tmpl_created"      => '1475067229',
		"author"            => 'winsomethemes',
		"file"              => 'pages/pricing.json',
		"url"               => $link . 'pricing-tables',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["pricing"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

	$data = [
		'id'                => 'pricing-extended',
		"title"             => 'Pricing Extended',
		"thumbnail"         => $thumb . 'pricing-extended.jpg',
		"tmpl_created"      => '1475067229',
		"author"            => 'winsomethemes',
		"file"              => 'pages/pricing-extended.json',
		"url"               => $link . 'pricing-extended',
		"type"              => 'page',
		"subtype"           => 'page',
		"tags"              => '["pricing"]',
		"menu_order"        => '0',
		"popularity_index"  => '0',
		"trend_index"       => '0',
		"has_page_settings" => '0'
	];

	array_push($templates, $data);

    return $templates;

}
