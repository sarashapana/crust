<?php

function crust_elementor_templates_divider(){

	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/sections/';
	$link = 'https://crust.it-rays.net/elementor';

	return [
		[
			'id'                => 'divider-1',
			"title"             => 'Divider 1',
			"thumbnail"         => $thumb . 'divider-1.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-1.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-2',
			"title"             => 'Divider 2',
			"thumbnail"         => $thumb . 'divider-2.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-2.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-3',
			"title"             => 'Divider 3',
			"thumbnail"         => $thumb . 'divider-3.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-3.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-4',
			"title"             => 'Divider 4',
			"thumbnail"         => $thumb . 'divider-4.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-4.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-5',
			"title"             => 'Divider 5',
			"thumbnail"         => $thumb . 'divider-9.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-5.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-6',
			"title"             => 'Divider 6',
			"thumbnail"         => $thumb . 'divider-6.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-6.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-7',
			"title"             => 'Divider 7',
			"thumbnail"         => $thumb . 'divider-7.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-7.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'divider-8',
			"title"             => 'Divider 8',
			"thumbnail"         => $thumb . 'divider-8.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/divider-8.json',
			"url"               => $link . 'divider',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["divider"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],
	];

}
