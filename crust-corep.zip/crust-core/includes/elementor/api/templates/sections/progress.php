<?php

function crust_elementor_templates_progress(){

	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/sections/';
	$link = 'https://crust.it-rays.net/elementor';

	return [
		[
			'id'                => 'progress-1',
			"title"             => 'Progress Bar 1',
			"thumbnail"         => $thumb . 'carousel-2.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-2.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-2',
			"title"             => 'Progress Bar 2',
			"thumbnail"         => $thumb . 'progress-2.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-2.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress", "counters"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-3',
			"title"             => 'Progress Bar 3',
			"thumbnail"         => $thumb . 'progress-3.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-3.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-4',
			"title"             => 'Progress Bar 4',
			"thumbnail"         => $thumb . 'progress-4.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-4.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-5',
			"title"             => 'Progress Bar 5',
			"thumbnail"         => $thumb . 'splitter-3.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-5.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-6',
			"title"             => 'Progress Bar 6',
			"thumbnail"         => $thumb . 'progress-5.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-6.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-8',
			"title"             => 'Progress Bar 8',
			"thumbnail"         => $thumb . 'progress-7.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-8.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-9',
			"title"             => 'Progress Bar 9',
			"thumbnail"         => $thumb . 'progress-8.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-9.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'progress-10',
			"title"             => 'Progress Bar 10',
			"thumbnail"         => $thumb . 'progress-9.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/progress-10.json',
			"url"               => $link . 'progress',
			"type"              => 'block',
			"subtype"           => 'stats',
			"tags"              => '["progress"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],
	];

}
