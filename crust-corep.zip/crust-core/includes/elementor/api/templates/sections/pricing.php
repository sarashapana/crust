<?php

function crust_elementor_templates_pricing(){

	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/sections/';
	$link = 'https://crust.it-rays.net/elementor/';

	return [
		[
			'id'                => 'pricing-1',
			"title"             => 'pricing 1',
			"thumbnail"         => $thumb . 'pricing-1.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-1.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-2',
			"title"             => 'pricing 2',
			"thumbnail"         => $thumb . 'pricing-2.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-2.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-3',
			"title"             => 'pricing 3',
			"thumbnail"         => $thumb . 'pricing-3.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-3.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-4',
			"title"             => 'pricing 4',
			"thumbnail"         => $thumb . 'pricing-4.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-4.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-5',
			"title"             => 'pricing 5',
			"thumbnail"         => $thumb . 'pricing-5.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-5.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-6',
			"title"             => 'pricing 6',
			"thumbnail"         => $thumb . 'pricing-6.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-6.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-7',
			"title"             => 'pricing 7',
			"thumbnail"         => $thumb . 'pricing-7.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-7.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'pricing-8',
			"title"             => 'pricing 8',
			"thumbnail"         => $thumb . 'pricing-8.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/pricing-8.json',
			"url"               => $link . 'pricing',
			"type"              => 'block',
			"subtype"           => 'pricing',
			"tags"              => '["pricing"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],
	];

}
