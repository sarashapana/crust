<?php

function crust_elementor_templates_carousel(){

	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/sections/';
	$link = 'https://crust.it-rays.net/elementor';

	return [
		[
			'id'                => 'carousel-1',
			"title"             => 'Carousel 1',
			"thumbnail"         => $thumb . 'carousel-1.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-1.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-2',
			"title"             => 'Carousel 2',
			"thumbnail"         => $thumb . 'carousel-2.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-2.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-3',
			"title"             => 'Carousel 3',
			"thumbnail"         => $thumb . 'carousel-3.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-3.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-4',
			"title"             => 'Carousel 4',
			"thumbnail"         => $thumb . 'carousel-10.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-4.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-5',
			"title"             => 'Carousel 5',
			"thumbnail"         => $thumb . 'carousel-5.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-5.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-6',
			"title"             => 'Carousel 6',
			"thumbnail"         => $thumb . 'carousel-6.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-6.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-7',
			"title"             => 'Carousel 7',
			"thumbnail"         => $thumb . 'carousel-7.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-7.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-8',
			"title"             => 'Carousel 8',
			"thumbnail"         => $thumb . 'carousel-8.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-8.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],[
			'id'                => 'carousel-9',
			"title"             => 'Carousel 9',
			"thumbnail"         => $thumb . 'carousel-9.jpg',
			"tmpl_created"      => '1475067229',
			"author"            => 'winsomethemes',
			"file"              => 'sections/carousel-9.json',
			"url"               => $link . 'carousel',
			"type"              => 'block',
			"subtype"           => 'hero',
			"tags"              => '["carousel"]',
			"menu_order"        => '0',
			"popularity_index"  => '0',
			"trend_index"       => '0',
			"has_page_settings" => '0'
		],
	];

}
