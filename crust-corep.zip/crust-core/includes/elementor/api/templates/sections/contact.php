<?php

function crust_elementor_templates_contact(){

	$thumb = 'https://dev.winsomethemes.com/crust/templates/images/sections/';
	$link = 'https://crust.it-rays.net/elementor/';

    return [
	    [
		    'id'                => 'contact-1',
		    "title"             => 'Contact 1',
		    "thumbnail"         => $thumb . 'contact-1.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-1.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-2',
		    "title"             => 'Contact 2',
		    "thumbnail"         => $thumb . 'contact-2.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-2.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-3',
		    "title"             => 'Contact 3',
		    "thumbnail"         => $thumb . 'contact-3.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-3.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-4',
		    "title"             => 'Contact 4',
		    "thumbnail"         => $thumb . 'contact-4.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-4.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-5',
		    "title"             => 'Contact 5',
		    "thumbnail"         => $thumb . 'contact-5.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-5.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-6',
		    "title"             => 'Contact 6',
		    "thumbnail"         => $thumb . 'contact-6.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-6.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],[
		    'id'                => 'contact-7',
		    "title"             => 'Contact 7',
		    "thumbnail"         => $thumb . 'contact-7.jpg',
		    "tmpl_created"      => '1475067229',
		    "author"            => 'winsomethemes',
		    "file"              => 'sections/contact-7.json',
		    "url"               => $link . 'contact',
		    "type"              => 'block',
		    "subtype"           => 'contact',
		    "tags"              => '["contact"]',
		    "menu_order"        => '0',
		    "popularity_index"  => '0',
		    "trend_index"       => '0',
		    "has_page_settings" => '0'
	    ],
    ];

}
