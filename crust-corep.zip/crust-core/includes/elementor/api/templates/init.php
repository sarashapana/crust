<?php

foreach ( glob( CRUST_CORE_DIR  .'includes/elementor/api/templates/sections/*.php' ) as $section ) { include_once $section; }

include_once CRUST_CORE_DIR  .'includes/elementor/api/templates/pages/pages.php';

$sections  = [];
$pages     = [];

$sections  = array_merge( $sections, crust_elementor_templates_intros() );
$sections  = array_merge( $sections, crust_elementor_templates_accordion() );
$sections  = array_merge( $sections, crust_elementor_templates_cards() );
$sections  = array_merge( $sections, crust_elementor_templates_carousel() );
$sections  = array_merge( $sections, crust_elementor_templates_counters() );
$sections  = array_merge( $sections, crust_elementor_templates_cta() );
$sections  = array_merge( $sections, crust_elementor_templates_contact() );
$sections  = array_merge( $sections, crust_elementor_templates_divider() );
$sections  = array_merge( $sections, crust_elementor_templates_infobox() );
$sections  = array_merge( $sections, crust_elementor_templates_posts() );
$sections  = array_merge( $sections, crust_elementor_templates_progress() );
$sections  = array_merge( $sections, crust_elementor_templates_reviews() );
$sections  = array_merge( $sections, crust_elementor_templates_splitter() );
$sections  = array_merge( $sections, crust_elementor_templates_tabs() );
$sections  = array_merge( $sections, crust_elementor_templates_pricing() );
$sections  = array_merge( $sections, crust_elementor_templates_team() );
$sections  = array_merge( $sections, crust_elementor_templates_misc() );
$pages     = array_merge( $pages, crust_elementor_pages_templates() );

$templates = array_merge( $sections, $pages );

$library = [
	'timestamp' => 1561218722,
	'upgrade_notice' => [
		'version' => '2.0.0',
		'message' => '',
		'update_link' => '',
	],
	'library' => [
		'types_data' => [
			'block' => [
				'categories' => [
					'404 page',
					'about',
					'archive',
					'call to action',
					'clients',
					'contact',
					'faq',
					'features',
					'footer',
					'header',
					'intro',
					'portfolio',
					'pricing',
					'product archive',
					'services',
					'single page',
					'single post',
					'single product',
					'stats',
					'subscribe',
					'team',
					'testimonials',
				],
			],
			'popup' => [
				'categories' => [
					0 => 'bottom bar',
					1 => 'classic',
					2 => 'fly-in',
					3 => 'full screen',
					4 => 'hello bar',
					5 => 'slide-in',
				],
			],
		],
		'categories' => '["404 page","about","archive","call to action","clients","contact","faq","features","footer","header","intro","portfolio","pricing","product archive","services","single page","single post","single product","stats","subscribe","team","testimonials"]',
		'templates' => $templates
	],
];
