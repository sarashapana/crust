<?php

namespace Crust_Core\Elements;

use \Elementor\Group_Control_Background;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Content_Ticker extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

	public function get_script_depends()
	{
		return ['crust-clients'];
	}

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-content-ticker', false, true);
		return ['crust-content-ticker'];
	}

    public function get_name()
    {
        return 'crust-content-ticker';
    }

    public function get_title()
    {
        return esc_html__('Content Ticker', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-call-to-action';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_core_section_content_ticker_settings',
            [
                'label' => esc_html__('Ticker Settings', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_content_ticker_content',
		    [
			    'label'     => esc_html__('Content', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'default'   => 'posts',
			    'options'   => [
				    'posts'  => esc_html__('Posts', 'crust-core'),
				    'list' => esc_html__('Custom Content', 'crust-core'),
			    ],
		    ]
	    );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_ticker_item', [
			    'label'       => esc_html__('Content', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'crust-core')
		    ]
	    );

	    $repeater->add_control(
		    'crust_ticker_item_link', [
			    'label'         => esc_html__('Link', 'elementor'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'default'       => [
				    'url'         => '#',
				    'is_external' => '',
			    ],
			    'show_external' => true,
		    ]
	    );

	    $this->add_control(
		    'crust_content_ticker_content_items',
		    [
			    'type'        => Controls_Manager::REPEATER,
			    'seperator'   => 'before',
			    'default'     => [
				    ['crust_ticker_item' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'],
				    ['crust_ticker_item' => 'Galley of type and scrambled it to make a type specimen book.'],
				    ['crust_ticker_item' => 'Publishing software like Aldus PageMaker including versions of ipsum.'],
			    ],
			    'fields'      => $repeater->get_controls(),
			    'title_field' => '{{crust_ticker_item}}',
			    'condition' => [
				    'crust_content_ticker_content' => 'list',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_core_section_content_ticker_tag',
		    [
			    'label' => esc_html__('Tag', 'crust-core'),
		    ]
	    );

        $this->add_control(
            'crust_ticker_tag_text',
            [
                'label'       => esc_html__('Tag Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('Trending Today', 'crust-core'),
            ]
        );

        $this->end_controls_section();

        $this->crust_core_slider_settings();

        /**
         * -------------------------------------------
         * Tab Style (Ticker Content Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_ticker_typography_settings',
            [
                'label' => esc_html__('Ticker Content', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'crust_ticker_content_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'default'      => 'flex-start',
			    'selectors' => [
				    '{{WRAPPER}} .crust-content-ticker .swiper-slide' => 'justify-content: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_ticker_content_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-ticker-wrap',
		    ]
	    );

        $this->add_control(
            'crust_ticker_content_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#222222',
                'selectors' => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-content,{{WRAPPER}} .crust-ticker-wrap .ticker-content a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'crust_ticker_hover_content_color',
            [
                'label'     => esc_html__('Links Hover Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f44336',
                'selectors' => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-content a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_ticker_content_typography',
                'selector' => '{{WRAPPER}} .crust-ticker-wrap .ticker-content,{{WRAPPER}} .crust-ticker-wrap .ticker-content a',

            ]
        );

        $this->add_responsive_control(
            'crust_ticker_content_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_ticker_content_border',
			    'selector' => '{{WRAPPER}} .crust-ticker-wrap',
		    ]
	    );

        $this->add_responsive_control(
            'crust_ticker_content_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-ticker-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'client_ticker_content_shadow',
			    'selector' => '{{WRAPPER}} .crust-ticker-wrap',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_ticker_typography_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_ticker_content_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-ticker-wrap',
		    ]
	    );

	    $this->add_control(
		    'crust_ticker_content_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-content,body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-content a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_ticker_hover_content_dark_color',
		    [
			    'label'     => esc_html__('Links Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-content a:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_ticker_content_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-ticker-wrap',
		    ]
	    );
        $this->end_controls_section();

        $this->start_controls_section(
            'crust_core_section_ticker_tag_style_settings',
            [
                'label' => esc_html__('Tag Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_ticker_tag_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-ticker-wrap .ticker-badge',
		    ]
	    );

        $this->add_control(
            'crust_ticker_tag_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-badge span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_ticker_tag_typography',
                'selector' => '{{WRAPPER}} .crust-ticker-wrap .ticker-badge span',
            ]
        );
        $this->add_responsive_control(
            'crust_ticker_tag_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_ticker_tag_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_ticker_tag_border',
			    'selector' => '{{WRAPPER}} .crust-ticker-wrap .ticker-badge',
		    ]
	    );

        $this->add_responsive_control(
            'crust_ticker_tag_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default'   => [
                    'top' => '5',
                    'right' => '5',
                    'bottom' => '5',
                    'left' => '5',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-ticker-wrap .ticker-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_ticker_tag_shadow',
			    'selector' => '{{WRAPPER}} .crust-ticker-wrap .ticker-badge',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_section_ticker_tag_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_ticker_tag_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-badge',
		    ]
	    );

	    $this->add_control(
		    'crust_ticker_tag_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-badge span' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_ticker_tag_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-ticker-wrap .ticker-badge',
		    ]
	    );

        $this->end_controls_section();

        $this->crust_core_slider_styling();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $settings = $this->fix_wp_query($settings);
        $args     = $this->crust_core_get_query_args($settings);
        $content_type = $settings['crust_content_ticker_content'];

	    $this->add_render_attribute('crust_carousel', 'class', [
	    	'crust-content-ticker',
		    'swiper-container',
		    'crust-carousel',
	    ]);

        $html = '<div class="crust-ticker-wrap">';
            if ( ! empty($settings['crust_ticker_tag_text'])) {
                $html .= '<div class="ticker-badge">';
                    $html .= '<span>' . $settings['crust_ticker_tag_text'] . '</span>';
                $html .= '</div>';
            }
	    $this->crust_core_slider_attributes();
            $html .= '<div ' . $this->get_render_attribute_string('crust_carousel') . '>';

	            $html .= '<div class="swiper-wrapper">';
	                if( $content_type == 'posts' ){
						$html .= $this-> render_ticker_content( $args, null );
					} else {
						$html .= $this-> render_content_list( $settings, $this );
					}
	            $html .= '</div>';
			    $html .= '<div class="crust-ticker-nav">';
			     // $html .= $this->crust_carousel_nav();
	            $html .= apply_filters('crust_carousel_nav_site',$settings);
			    $html .= '</div>';

            $html .= '</div>';

        $html .= '</div>';

        echo $html;

    }

    protected function render_ticker_content($args, $settings)
    {
        $html  = '';
        $query = new \WP_Query($args);

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $html .= '<div class="swiper-slide">';
                    $html .= '<div class="ticker-content">';
                        $html .= '<a href="' . get_the_permalink() . '" class="ticker-content-link">' . get_the_title() . '</a>';
                    $html .= '</div>';
                $html .= '</div>';
            }
        } else {
            $html .= '<div class="swiper-slide"><a href="#" class="ticker-content">' . esc_html__('No content found!', 'crust-core') . '</a></div>';
        }

        wp_reset_postdata();

        return $html;
    }

	protected function render_content_list( $settings, $obj )
	{
		if (empty($settings['crust_content_ticker_content_items'])) {
			return;
		}

		$counter = 0;
		$html = '';
		foreach ($settings['crust_content_ticker_content_items'] as $item) {
			$link = $item['crust_ticker_item_link'];
			$html .= '<div class="swiper-slide">';
				$html .= '<div class="ticker-content">';
					if ( $link !== '' ) {
						$a_string = 'href="' . esc_url( $link['url'] ) . '"';
						$a_string .= ( $link['nofollow'] ) ? 'rel="nofollow"' : '';;
						$a_string .= ( $link['is_external'] ) ? 'target="_blank"' : '';
					}
					if ( ! empty($link['url'])) {
						$html .= '<a ' . $a_string . '>';
					}
					$html .= $item['crust_ticker_item'];
					if ( ! empty($link['url'])) {
						$html .= '</a>';
					}
				$html .= '</div>';
			$html .= '</div>';
			$counter++;
		}

		return $html;

	}

}
