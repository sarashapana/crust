<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Widget_Base;
use \Elementor\Repeater;

class Crust_Steps extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-steps', false, true);
        return ['crust-steps'];
    }

    public function get_name()
    {
        return 'crust-steps';
    }

    public function get_title()
    {
        return esc_html__('Steps', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-navigation-horizontal';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Feature Steps Settings
         */
        $this->start_controls_section(
            'crust_section_steps_content_settings',
            [
                'label' => esc_html__('Content', 'crust-core')
            ]
        );

        $repeater = new Repeater();

	    $repeater->add_control(
		    'crust_step_status',
		    [
			    'label'       => esc_html__('Status', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'crust-steps-normal',
			    'label_block' => false,
			    'options'     => [
				    'crust-steps-normal'  => esc_html__('Normal', 'crust-core'),
				    'crust-steps-done'   => esc_html__('Done', 'crust-core'),
				    'crust-steps-active'   => esc_html__('Active', 'crust-core'),
			    ],
		    ]
	    );

        $repeater->add_control(
            'crust_steps_icon_type',
            [
                'label'       => esc_html__('Icon Type', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                ''  => [
		                'title' => esc_html__('None', 'elementor'),
		                'icon'  => 'fa fa-ban',
	                ],
	                'icon'  => [
                        'title' => esc_html__('Icon', 'elementor'),
                        'icon'  => 'fa fa-star',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'crust-core'),
                        'icon'  => 'fa fa-picture-o',
                    ],
                    'number' => [
	                    'title' => esc_html__('Number', 'crust-core'),
	                    'icon'  => 'fa fa-sort-numeric-up',
                    ],
                ],
                'default'     => 'icon',
                'label_block' => false,
            ]
        );

        $repeater->add_control(
            'crust_steps_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'condition'        => [
                    'crust_steps_icon_type' => 'icon'
                ]
            ]
        );

	    $repeater->add_control(
		    'crust_steps_img',
		    [
			    'label'     => esc_html__('Image', 'crust-core'),
			    'type'      => Controls_Manager::MEDIA,
			    'default'   => [
				    'url' => Utils::get_placeholder_image_src(),
			    ],
			    'condition' => [
				    'crust_steps_icon_type' => 'image'
			    ]
		    ]
	    );

	    $repeater->add_control(
		    'crust_steps_number',
		    [
			    'label'     => esc_html__('Number', 'crust-core'),
			    'type'      => Controls_Manager::TEXT,
			    'default'   => '1',
			    'condition' => [
				    'crust_steps_icon_type' => 'number'
			    ]
		    ]
	    );

        $repeater->add_control(
            'crust_steps_title',
            [
                'label'   => esc_html__('Title', 'crust-core'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Title', 'crust-core'),
                'dynamic' => ['active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'crust_steps_content',
            [
                'label'   => esc_html__('Content', 'crust-core'),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.', 'crust-core'),
                'dynamic' => ['active' => true]
            ]
        );

        $repeater->add_control(
            'crust_steps_link',
            [
                'label'       => esc_html__('Link', 'elementor'),
                'type'        => Controls_Manager::URL,
                'dynamic'     => ['active' => true],
                'placeholder' => esc_html__('https://your-link.com', 'crust-core'),
                'separator'   => 'before',
            ]
        );

        $this->add_control(
            'crust_steps',
            [
                'label'       => esc_html__('Item', 'crust-core'),
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    [
                    	'crust_step_status'    => 'crust-steps-done',
	                    'crust_steps_icon' => [
		                    'value'   => 'fas fa-circle',
	                    ],
                        'crust_steps_title'    => esc_html__('Campaign', 'crust-core'),
                        'crust_steps_content'  => esc_html__('We are planning to increase sales', 'crust-core')
                    ],
                    [
	                    'crust_step_status'    => 'crust-steps-done',
	                    'crust_steps_icon' => [
		                    'value'   => 'fas fa-circle',
	                    ],
                        'crust_steps_title'    => esc_html__('Content', 'crust-core'),
                        'crust_steps_content'  => esc_html__('We are planning to increase sales', 'crust-core')
                    ],
	                [
		                'crust_step_status'    => 'crust-steps-active',
		                'crust_steps_icon' => [
			                'value'   => 'fas fa-circle',
		                ],
		                'crust_steps_title'    => esc_html__('Recipients', 'crust-core'),
		                'crust_steps_content'  => esc_html__('We are planning to increase sales', 'crust-core')
	                ],
	                [
		                'crust_step_status'    => 'crust-steps-normal',
		                'crust_steps_icon' => [
			                'value'   => 'fas fa-circle',
		                ],
		                'crust_steps_title'    => esc_html__('Delivery', 'crust-core'),
		                'crust_steps_content'  => esc_html__('We are planning to increase sales', 'crust-core')
	                ]
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '<i class="{{ crust_steps_icon.value }}" aria-hidden="true"></i> {{{ crust_steps_title }}}',
            ]
        );

	    $this->add_control(
		    'crust_steps_inline_columns',
		    [
			    'label'       => esc_html__('Columns', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => '4',
			    'label_block' => false,
			    'options'     => [
				    '1' => esc_html__('1', 'crust-core'),
				    '2' => esc_html__('2', 'crust-core'),
				    '3' => esc_html__('3', 'crust-core'),
				    '4' => esc_html__('4', 'crust-core'),
				    '5' => esc_html__('5', 'crust-core'),
				    '6' => esc_html__('6', 'crust-core'),
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_steps_order',
		    [
			    'label'       => esc_html__('Order', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'default'     => 'icon-title-content',
			    'options'     => [
				    'icon-title-content' => esc_html__('Icon/Title/Content', 'crust-core'),
				    'title-icon-content' => esc_html__('Title/Icon/Content', 'crust-core'),
				    'title-content-icon' => esc_html__('Title/Content/Icon', 'crust-core'),
			    ]
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Steps Icon Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_steps_style_icon',
            [
                'label' => esc_html__('Icon', 'elementor'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'icon_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => '',
			    'label_block' => false,
			    'options'     => [
				    ''  => esc_html__('Default', 'crust-core'),
				    'crust-steps-triangle'   => esc_html__('Triangle', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'step_icon_hover_effect',
		    [
			    'label'       => esc_html__('Hover Effect', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'default'     => 'scale',
			    'options'     => [
				    ''              => esc_html__('None', 'crust-core'),
				    'scale'         => esc_html__('Scale', 'crust-core'),
				    'rotate'        => esc_html__('Rotate', 'crust-core'),
				    'spin'          => esc_html__('Spin', 'crust-core'),
				    'pulse'         => esc_html__('Pulse', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'steps_icon_rotate',
		    [
			    'label' => __( 'Rotate', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -360,
					    'max' => 360,
					    'step' => 1,
				    ],
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps .crust-icon-triangle' => 'transform: rotate({{SIZE}}deg)',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Background:: get_type(),
            [
                'name'     => 'crust_steps_icon_background',
                'types'    => ['classic', 'gradient'],
                'exclude'  => [
                    'image',
                ],
                'selector' => '{{WRAPPER}} .crust-steps .crust-steps-icon',
                'condition' => [
	                'icon_style!' => 'crust-steps-triangle'
                ]
            ]
        );

	    $this->add_control(
		    'crust_steps_icon_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_steps_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_steps_icon_width',
            [
                'label'     => esc_html__('Width', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 6,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_steps_icon_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 6,
					    'max' => 300,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_steps_icon_size',
            [
                'label'     => esc_html__('Icon Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 6,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-steps-icon-box .crust-steps-icon img' => 'width: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_steps_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-steps .crust-steps-icon'
            ]
        );

        $this->add_control(
            'crust_steps_icon_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_steps_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps .crust-steps-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'icon_box_shadow',
                'selector' => '{{WRAPPER}} .crust-steps .crust-steps-icon',
            ]
        );

	    $this->add_responsive_control(
		    'crust_section_steps_style_dark_icon',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_steps_icon_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_steps_icon_triangle_dark_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_steps_icon_dark_color',
		    [
			    'label'     => esc_html__('Icon Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_steps_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps .crust-steps-icon'
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Feature Steps Content Style
         * -------------------------------------------
         */
	    $this->start_controls_section(
		    'crust_section_steps_style_title',
		    [
			    'label' => esc_html__('Title', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );
	    $this->add_control(
		    'crust_steps_title_tag',
		    [
			    'label'     => esc_html__('HTML Tag', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => [
				    'h1'   => 'H1',
				    'h2'   => 'H2',
				    'h3'   => 'H3',
				    'h4'   => 'H4',
				    'h5'   => 'H5',
				    'h6'   => 'H6',
				    'div'  => 'div',
				    'span' => 'span',
				    'p'    => 'p',
			    ],
			    'default'   => 'h6',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_steps_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_steps_title_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_steps_title_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps-title,{{WRAPPER}} .crust-steps-title a' => 'color: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_steps_title_typography',
			    'selector' => '{{WRAPPER}} .crust-steps-title',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_steps_style_dark_title',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_steps_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps-title,{{WRAPPER}} .crust-steps-title a' => 'color: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_steps_style_content',
            [
                'label' => esc_html__('Content', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
	    $this->add_control(
		    'crust_steps_content_tag',
		    [
			    'label'     => esc_html__('HTML Tag', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => [
				    'h1'   => 'H1',
				    'h2'   => 'H2',
				    'h3'   => 'H3',
				    'h4'   => 'H4',
				    'h5'   => 'H5',
				    'h6'   => 'H6',
				    'div'  => 'div',
				    'span' => 'span',
				    'p'    => 'p',
			    ],
			    'default'   => 'p',
		    ]
	    );

        $this->add_control(
            'crust_steps_description_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-steps-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'           => 'crust_steps_description_typography',
                'selector'       => '{{WRAPPER}} .crust-steps-content',
            ]
        );

	    $this->add_control(
		    'description_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_steps_style_dark_content',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_steps_description_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps-content' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();

        // Steps Custom Design...
	    $this->start_controls_section(
		    'wrap_line',
		    [
			    'label' => esc_html__('Wrap Line', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'wrap_line_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => ['max' => 1000],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li .crust-steps-icon-box:before' => 'height: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'line_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li .crust-steps-icon-box:before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'line_border',
			    'selector' => '{{WRAPPER}} .crust-steps li .crust-steps-icon-box:before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'line_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li .crust-steps-icon-box:before',
		    ]
	    );

	    $this->add_control(
		    'line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li .crust-steps-icon-box:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'wrap_dark_line',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'line_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li .crust-steps-icon-box:before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'line_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li .crust-steps-icon-box:before',
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'normal_status',
		    [
			    'label' => esc_html__('Normal Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'normal_inner_line',
		    [
			    'label'     => esc_html__('Inner Line', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_responsive_control(
		    'normal_inner_line_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => ['max' => 1000],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon-box:after' => 'height: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_inner_line_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon-box:after',
		    ]
	    );

	    $this->add_control(
		    'normal_inner_line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li .crust-steps-icon-box .crust-steps-icon-box:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'normal_title',
		    [
			    'label'     => esc_html__('Title', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'normal_title_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title, {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_title_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'normal_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'normal_title_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'normal_icon',
		    [
			    'label'     => esc_html__('Icon', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'normal_icon_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_icon_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'normal_icon_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'normal_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon'
		    ]
	    );

	    $this->add_control(
		    'normal_icon_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'normal_icon_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );



	    $this->add_responsive_control(
		    'normal_dark_status',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_responsive_control(
		    'normal_inner_line_dark_height',
		    [
			    'label'      => esc_html__(' Inner line', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_inner_line_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon-box:after',
		    ]
	    );
	    $this->add_responsive_control(
		    'normal_dark_title',
		    [
			    'label'      => esc_html__(' Title', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'normal_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title, body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_title_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-title',
		    ]
	    );
	    $this->add_responsive_control(
		    'normal_dark_icon',
		    [
			    'label'      => esc_html__(' Icon', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'normal_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'normal_icon_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'normal_icon_triangle_dark_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'normal_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-normal .crust-steps-icon'
		    ]
	    );
	    $this->end_controls_section();

	    // Done Status
	    $this->start_controls_section(
		    'done_status',
		    [
			    'label' => esc_html__('Done Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'done_inner_line',
		    [
			    'label'     => esc_html__('Inner Line', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_inner_line_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon-box:after',
		    ]
	    );

	    $this->add_responsive_control(
		    'done_inner_line_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => ['max' => 1000],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon-box:after' => 'height: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'done_inner_line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li .crust-steps-icon-box .crust-steps-icon-box:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'done_title',
		    [
			    'label'     => esc_html__('Title', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'done_title_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title, {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_title_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'done_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'done_title_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'done_icon',
		    [
			    'label'     => esc_html__('Icon', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'done_icon_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_icon_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'done_icon_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'done_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon'
		    ]
	    );

	    $this->add_control(
		    'done_icon_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'done_icon_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'done_dark_status',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_responsive_control(
		    'done_inner_dark_line',
		    [
			    'label'      => esc_html__(' Inner Line', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_inner_line_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon-box:after',
		    ]
	    );

	    $this->add_responsive_control(
		    'done_dark_title',
		    [
			    'label'      => esc_html__('Title ', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'done_title_dark_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title, {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_title_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-title',
		    ]
	    );
	    $this->add_responsive_control(
		    'done_dark_icon',
		    [
			    'label'      => esc_html__(' Icon', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'done_icon_dark_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'done_icon_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'done_icon_triangle_dark_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'done_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-done .crust-steps-icon'
		    ]
	    );
	    $this->end_controls_section();

	    // Active Status
	    $this->start_controls_section(
		    'active_status',
		    [
			    'label' => esc_html__('Active Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'active_inner_line',
		    [
			    'label'     => esc_html__('Inner Line', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_inner_line_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon-box:after',
		    ]
	    );

	    $this->add_responsive_control(
		    'active_inner_line_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => ['max' => 1000],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon-box:after' => 'height: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'active_inner_line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li .crust-steps-icon-box .crust-steps-icon-box:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'active_title',
		    [
			    'label'     => esc_html__('Title', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'active_title_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title, {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_title_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'active_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );



	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'active_title_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title',
		    ]
	    );

	    $this->add_control(
		    'active_icon',
		    [
			    'label'     => esc_html__('Icon', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'active_icon_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_icon_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'active_icon_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'active_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon'
		    ]
	    );

	    $this->add_control(
		    'active_icon_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'active_icon_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );
	    $this->add_responsive_control(
		    'active_dark_status',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_responsive_control(
		    'active_inner_dark_line',
		    [
			    'label'      => esc_html__(' Inner Line', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_inner_dark_line_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon-box:after',
		    ]
	    );
	    $this->add_responsive_control(
		    'active_dark_title',
		    [
			    'label'      => esc_html__(' Title', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'active_title_dark_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title, {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_title_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-title',
		    ]
	    );

	    $this->add_responsive_control(
		    'active_dark_icon',
		    [
			    'label'      => esc_html__(' Icon', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'active_icon_dark_color',
		    [
			    'label'     => esc_html__(' Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'active_icon_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon',
			    'condition' => [
				    'icon_style!' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_control(
		    'active_icon_triangle_dark_color',
		    [
			    'label'     => esc_html__('Triangle Fill Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-icon-triangle' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'icon_style' => 'crust-steps-triangle'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'active_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-steps li.crust-steps-active .crust-steps-icon'
		    ]
	    );

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
		$order = $settings['crust_steps_order'];
        $this->add_render_attribute(
            'crust_steps',
            [
                'class' => [
                    'crust-steps',
	                $settings['crust_steps_order'],
	                'crust-grid-rows-'.$settings['crust_steps_inline_columns']
                ]
            ]
        );

        $this->add_render_attribute('crust_steps_item', 'class', 'crust-steps-item');

	    $list_class = 'crust-steps-item';
	    $list_class .= ( $settings['step_icon_hover_effect'] ) ? ' crust-animate-icon-' . $settings['step_icon_hover_effect'] : '';
	    $list_class .= ($settings['icon_style']) ? ' ' . $settings['icon_style'] : '';

        $html = '<ul '. $this->get_render_attribute_string('crust_steps') .'>';
            $i = 0;
            foreach ($settings['crust_steps'] as $index => $item) {

	            $zindx = 50 - $i;

                $this->add_render_attribute('crust_steps_icon' . $i, 'class', 'crust-steps-icon');
                $this->add_render_attribute('crust_steps_title' . $i, 'class', 'crust-steps-title');
                $this->add_render_attribute('crust_steps_content' . $i, 'class', 'crust-steps-content');

                if ($item['crust_steps_link']['url']) {
                    $this->add_render_attribute('crust_steps_title_anchor' . $i, 'href', esc_url($item['crust_steps_link']['url']));

                    if ($item['crust_steps_link']['is_external']) {
                        $this->add_render_attribute('crust_steps_title_anchor' . $i, 'target', '_blank');
                    }

                    if ($item['crust_steps_link']['nofollow']) {
                        $this->add_render_attribute('crust_steps_title_anchor' . $i, 'rel', 'nofollow');
                    }
                }

	            $status = $item['crust_step_status'];

                $html .= '<li class="'. $list_class .' '. $status .'" style="z-index: '.$zindx.'">';

                    if( $order === 'icon-title-content' ){
	                    $html .= $this->_get_icon($item, $settings, $i);
	                    $html .= $this->_get_title($item, $settings, $i);
	                    $html .= $this->_get_content($item, $settings, $i);
                    } else if( $order === 'title-icon-content' ){
	                    $html .= $this->_get_title($item, $settings, $i);
	                    $html .= $this->_get_icon($item, $settings, $i);
	                    $html .= $this->_get_content($item, $settings, $i);
                    } else {
	                    $html .= $this->_get_title($item, $settings, $i);
	                    $html .= $this->_get_content($item, $settings, $i);
	                    $html .= $this->_get_icon($item, $settings, $i);
                    }

                $html .= '</li>';
            $i++;
        }

        $html .= '</ul>';

        echo $html;

    }

	protected function _get_icon($item, $settings, $i){

    	$feature_icon_tag = 'span';

		if ($item['crust_steps_link']['url']) {
			$this->add_render_attribute('crust_steps_link' . $i, 'href', $item['crust_steps_link']['url']);

			if ($item['crust_steps_link']['is_external']) {
				$this->add_render_attribute('crust_steps_link' . $i, 'target', '_blank');
			}

			if ($item['crust_steps_link']['nofollow']) {
				$this->add_render_attribute('crust_steps_link' . $i, 'rel', 'nofollow');
			}
			$feature_icon_tag = 'a';
		}

		$triangle = '<svg class="crust-icon-triangle" viewBox="0 0 56 49"><path d="M22.791,9.117a6,6,0,0,1,10.419,0L50.87,40.023A6,6,0,0,1,45.661,49H10.339A6,6,0,0,1,5.13,40.023Z"/></svg>';

		$html = '<div class="crust-steps-icon-box">';
			$html .= '<div class="crust-steps-icon-inner">';

				$html .= '<' . $feature_icon_tag . ' ' . $this->get_render_attribute_string('crust_steps_icon' . $i) . ' ' .$this->get_render_attribute_string('crust_steps_link' . $i).'>';

					if ( $item['crust_steps_icon_type'] == 'icon' && isset($item['crust_steps_icon']) ) {

						if ( isset($item['crust_steps_icon']['value']['url'])) {
							$html .= '<img src="' . esc_url($item['crust_steps_icon']['value']['url']) . '" alt="' . esc_attr(get_post_meta($item['crust_steps_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
						} else {
							$html .= '<i class="' . esc_attr($item['crust_steps_icon']['value']) . '" aria-hidden="true"></i>';
						}

					} else if ($item['crust_steps_icon_type'] == 'image') {

						$this->add_render_attribute(
							'feature_steps_image' . $i,
							[
								'src'   => esc_url($item['crust_steps_img']['url']),
								'class' => 'crust-steps-img',
								'alt'   => esc_attr(get_post_meta($item['crust_steps_img']['id'], '_wp_attachment_image_alt', true))
							]
						);

						$html .= '<img ' . $this->get_render_attribute_string('feature_steps_image' . $i) . '>';

					} else if ($item['crust_steps_icon_type'] == 'number') {

						$html .= $item['crust_steps_number'];
					}

					$html .= ( $settings['icon_style'] === 'crust-steps-triangle' ) ? $triangle : '';

				$html .= '</'.$feature_icon_tag.'>';

			$html .= '</div>';

		$html .= '</div>';

		return $html;

	}

    protected function _get_title($item, $settings, $i){

	    $title_tag = $settings['crust_steps_title_tag'];

	    if( $item['crust_steps_title'] ){

		    $html = '<' . $title_tag . ' ' . $this->get_render_attribute_string('crust_steps_title' . $i) .'>';
			    $html .= (! empty($item['crust_steps_link']['url'])) ? "<a {$this->get_render_attribute_string('crust_steps_title_anchor'.$i)}>" : '';
			        $html .= $item['crust_steps_title'];
			    $html .= (! empty($item['crust_steps_link']['url'])) ? "</a>" : '';
		    $html .= '</'.$title_tag.'>';
		    return $html;

	    }
    }

	protected function _get_content($item, $settings, $i){

		$content_tag = $settings['crust_steps_content_tag'];

		if( $item['crust_steps_content'] ) {
			return '<'.$content_tag.' ' . $this->get_render_attribute_string( 'crust_steps_content' . $i ) . '>' . $item['crust_steps_content'] . '</'.$content_tag.'>';
		}
	}

    protected function _content_template() { }
}
