<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Split_Text extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-split-text';
    }

    public function get_title()
    {
        return esc_html__('Split Text', 'crust-core');
    }

	public function get_icon()
	{
		return 'eicon-animated-headline';
	}

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Heading Content Settings
         */
        $this->start_controls_section(
            'crust_section_split_content_settings',
            [
                'label' => esc_html__('Content Settings', 'crust-core')
            ]
        );

	    $this->add_control(
		    'style',
		    [
			    'label'       => esc_html__('Animation Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'default'     => 'style-1',
			    'options'     => [
				    'style-1'       => esc_html__('Style 1', 'crust-core'),
				    'style-2'       => esc_html__('Style 2', 'crust-core'),
				    'style-3'       => esc_html__('Style 3', 'crust-core'),
				    'style-4'       => esc_html__('Style 4', 'crust-core'),
				    'style-5'       => esc_html__('Style 5', 'crust-core'),
				    'style-6'       => esc_html__('Style 6', 'crust-core'),
				    'style-7'       => esc_html__('Style 7', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'duration',
		    [
			    'label'     => esc_html__('Duration ( seconds )', 'crust-core'),
			    'type'      => Controls_Manager::NUMBER,
		    ]
	    );

	    $this->add_control(
		    'delay',
		    [
			    'label'     => esc_html__('Delay ( seconds )', 'crust-core'),
			    'type'      => Controls_Manager::NUMBER,
		    ]
	    );

        $this->add_control(
            'crust_split_text',
            [
                'label'       => esc_html__('Text', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => esc_html__('Crust Split Text Element', 'crust-core'),
                'dynamic'     => ['action' => true]
            ]
        );

	    $this->add_control(
		    'crust_head_link',
		    [
			    'label'     => esc_html__('Link', 'elementor'),
			    'type'      => Controls_Manager::URL,
			    'placeholder' => __( 'Paste URL or type', 'crust-core' ),
			    'show_external' => true,
			    'default' => [
				    'url' => '',
			    ],
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style ( Heading Style )
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_head_style_settings',
            [
                'label' => esc_html__('Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_head_content_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'default'      => 'center',
			    'selectors' => [
				    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h2',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_head_base_title_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-split-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_head_first_title_typography',
                'selector' => '{{WRAPPER}} .crust-split-text, {{WRAPPER}} .crust-split-text span',
            ]
        );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_head_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-split-text',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-split-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-split-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'split_bg_type',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-split-text',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_head_border',
			    'selector' => '{{WRAPPER}} .crust-split-text',
		    ]
	    );

	    $this->add_control(
		    'crust_head_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-split-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_head_shadow',
			    'selector' => '{{WRAPPER}} .crust-split-text',
		    ]
	    );
	    $this->add_control(
		    'crust_head_base_title_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_head_base_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-split-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'split_bg_type_dark',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-split-text',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_head_border_dark',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-split-text',
		    ]
	    );


	    $this->end_controls_section();

    }

    protected function render()
    {
    	$settings = $this->get_settings_for_display();

	    $wrap  = 'crust-split-text';
	    $target   = $settings['crust_head_link']['is_external'] ? ' target="_blank"' : '';
	    $nofollow = $settings['crust_head_link']['nofollow'] ? ' rel="nofollow"' : '';
	    $link     = ( $settings['crust_head_link']['url'] ) ? $settings['crust_head_link']['url'] : '';
	    $content = wp_kses( $settings['crust_split_text'],crust_allowed_tags(),null );

	    $attributes = ' data-split-style="'.$settings['style'].'"';
	    $attributes .= ( $settings['duration'] !== '' ) ? ' data-split-duration="'.$settings['duration'].'"' : '';
	    $attributes .= ( $settings['delay'] !== '' ) ? ' data-split-delay="'.$settings['delay'].'"' : '';

	    $output = '';

	    if( $content){
		    $output .= '<'.$settings['tag'].' class="'. esc_attr($wrap) .'"'.$attributes.'>';
			    $output .= ( $link ) ? '<a href="'.esc_url($link).'"' . $target . $nofollow . '>' : '';
			        $output .= wp_kses( $content, crust_allowed_tags() );
			    $output .= ( $link ) ? '</a>' : '';
		    $output .= '</'.$settings['tag'].'>';

	    }
	    
	    echo $output;
    }

}
