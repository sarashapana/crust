<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Button extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-button';
    }

    public function get_title()
    {
        return esc_html__('Button', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-button';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        // Content Controls
        $this->start_controls_section(
            'section_button_content',
            [
                'label' => esc_html__('Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'       => esc_html__('Text', 'elementor'),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Request Access',
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'button_link_url',
            [
                'label'         => esc_html__('Link', 'elementor'),
                'type'          => Controls_Manager::URL,
                'label_block'   => true,
                'default'       => [
                    'url'         => '#',
                    'is_external' => '',
                ],
                'show_external' => true,
            ]
        );

        $this->add_control(
            'button_style',
            [
                'label'   => esc_html__('Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'crust-btn'            => esc_html__('Button', 'crust-core'),
                    'crust-btn-underline'  => esc_html__('Underline', 'crust-core'),
                ],
                'default' => 'crust-btn'
            ]
        );

        $this->add_control(
            'size',
            [
                'label' => __( 'Size', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'xs' => esc_html__('Extra Small', 'crust-core'),
                    'sm' => esc_html__('Small', 'crust-core'),
                    'md' => esc_html__('Medium', 'crust-core'),
                    'lg' => esc_html__('Large', 'crust-core'),
                    'xl' => esc_html__('Extra Large', 'crust-core'),
                ],
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

        $this->add_control(
            'button_block',
            [
                'label'         => esc_html__('Full Width', 'crust-core'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'YES', 'crust-core' ),
                'label_off'     => esc_html__( 'NO', 'crust-core' ),
                'return_value'  => 'yes',
                'condition'     => [
                    'button_style' => 'crust-btn',
                ]
            ]
        );

        $this->add_control(
            'button_hover_style',
            [
                'label'   => esc_html__('Hover Style', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    ''              => esc_html__('Default', 'crust-core'),
                    'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
                    'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
                    'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
                    'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
                    'btn-greip'     => esc_html__('Greip', 'crust-core'),
                    'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
                ],
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

        $this->add_control(
            'button_use_icon',
            [
                'label'         => esc_html__('Use Icon', 'crust-core'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'YES', 'crust-core' ),
                'label_off'     => esc_html__( 'NO', 'crust-core' ),
            ]
        );

        $this->add_control(
            'button_icon',
            [
                'label'     => esc_html__('Icon', 'elementor'),
                'type'      => Controls_Manager::ICONS,
                'condition' => [
                    'button_use_icon' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'button_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                    'button_use_icon' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'button_icon_block',
            [
                'label'         => esc_html__('Block Icon', 'crust-core'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'YES', 'crust-core' ),
                'label_off'     => esc_html__( 'NO', 'crust-core' ),
                'return_value'  => 'yes',
                'default'       => 'no',
                'condition'     => [
                    'button_icon[value]!' => '',
                    'button_use_icon' => 'yes'
                ],
            ]
        );

        $this->add_responsive_control(
            'button_icon_size',
            [
                'label'      => esc_html__('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'rem', 'em'],
                'default'    => [
                    'size' => '',
                    'unit' => 'rem',
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'button_icon[value]!' => '',
                    'button_use_icon' => 'yes'
                ],
                'selectors'  => [
                    '{{WRAPPER}} i.crust-btn-icon'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} img.crust-btn-icon' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );



        $this->end_controls_section();

        // Style Controls
        $this->start_controls_section(
            'section_button_settings',
            [
                'label' => esc_html__('Styles', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .crust-btn,{{WRAPPER}} .crust-btn-underline'
            ]
        );
	    $this->add_responsive_control(
		    'section_button_alignment',
		    [
			    'label'       => esc_html__('Alignment', 'elementor'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left' => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'     => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'   => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

        $this->start_controls_tabs('crust_button_tabs');

        $this->start_controls_tab('normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_responsive_control(
		    'button_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-btn,{{WRAPPER}} .crust-btn.btn-bestia > span,{{WRAPPER}} .crust-btn-underline' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );


	    $this->add_responsive_control(
		    'button_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-btn,{{WRAPPER}} .crust-btn.btn-bestia > span,{{WRAPPER}} .crust-btn-underline' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'button_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:not(i),{{WRAPPER}} .crust-btn-underline:not(i)' => 'color: {{VALUE}};',
                ],
                'default'   => '#fff'
            ]
        );


        $this->add_control(
            'button_line_background',
            [
                'label'     => esc_html__('Line Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#eee',
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:before' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ],
            ]
        );


        $this->add_control(
            'button_line_height',
            [
                'label'     => esc_html__('Line Height', 'elementor'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => '2',
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:before' => 'height: {{VALUE}}px;',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ],
            ]
        );

        $this->add_responsive_control(
            'button_line_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ]
            ]
        );




	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [
					    'default' => 'classic'
				    ],
				    'color' => [
					    'default' => '#FF5B4A'
				    ],
			    ],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia), {{WRAPPER}} .crust-btn.btn-hyperion:before, {{WRAPPER}} .crust-btn.btn-anthe::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );




        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'button_border',
                'selector' => '{{WRAPPER}} .crust-btn',
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'button_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .crust-btn',
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'section_button_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'button_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn,body.crust-dark {{WRAPPER}} .crust-btn-underline' => 'color: {{VALUE}};',
			    ],

		    ]
	    );
	    $this->add_control(
		    'button_line_dark_background',
		    [
			    'label'     => esc_html__('Line Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn-underline:before' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_style' => 'crust-btn-underline'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [

				    ],
				    'color' => [

				    ],
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia),body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion:before,body.crust-dark {{WRAPPER}} .crust-btn.btn-anthe::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn',
			    'condition' => [
				    'button_style' => 'crust-btn'
			    ]
		    ]
	    );
        $this->end_controls_tab();

        $this->start_controls_tab('button_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_responsive_control(
		    'button_hover_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-btn:hover,{{WRAPPER}} .crust-btn.btn-bestia:hover > span,{{WRAPPER}} .crust-btn-underline:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_hover_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-btn:hover,{{WRAPPER}} .crust-btn.btn-bestia:hover > span,{{WRAPPER}} .crust-btn-underline:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'btn_hover_top',
            [
                'label'      => esc_html__('Margin Top', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'max' => 100,
                        'min' => -100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-btn:hover, {{WRAPPER}} .crust-btn-underline:hover' => 'transform: translateY({{SIZE}}{{UNIT}});-webkit-transform: translateY({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:hover,{{WRAPPER}} .crust-btn-underline:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_line_hover_background',
            [
                'label'     => esc_html__('Line Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FF5B4A',
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:after' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ],
            ]
        );

        $this->add_control(
            'button_line_hover_height',
            [
                'label'     => esc_html__('Line Height', 'elementor'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => '2',
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:after' => 'height: {{VALUE}}px;',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ],
            ]
        );

        $this->add_responsive_control(
            'button_line_border_hover_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-underline:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_style' => 'crust-btn-underline'
                ]
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.styled-btn):hover, 
					{{WRAPPER}} .crust-btn.btn-hyperion,{{WRAPPER}} .crust-btn::before,{{WRAPPER}} .crust-btn::after,{{WRAPPER}} .crust-btn.btn-anthe:hover::before,
					{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_border_hover',
			    'selector' => '{{WRAPPER}} .crust-btn:hover',
			    'condition' => [
				    'button_style' => 'crust-btn'
			    ]
		    ]
	    );



        $this->add_responsive_control(
            'button_border_hover_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_box_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-btn:hover',
                'condition' => [
                    'button_style' => 'crust-btn'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'button_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'button_hover_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn:hover,body.crust-dark {{WRAPPER}} .crust-btn-underline:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_line_hover_dark_background',
		    [
			    'label'     => esc_html__('Line Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn-underline:after' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_style' => 'crust-btn-underline'
			    ],
		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.styled-btn):hover, 
					body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion,body.crust-dark {{WRAPPER}} .crust-btn::before,body.crust-dark {{WRAPPER}} .crust-btn::after,body.crust-dark {{WRAPPER}} .crust-btn.btn-anthe:hover::before,
					body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_border_dark_hover',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:hover',
			    'condition' => [
				    'button_style' => 'crust-btn'
			    ]
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();



	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_icon_settings',
		    [
			    'label'     => esc_html__('Icon', 'elementor'),
			    'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'button_icon[value]!' => '',
                    'button_use_icon' => 'yes'
                ],
		    ]
	    );

        $this->add_control(
            'button_icon_width',
            [
                'label'     => esc_html__('Width (px)', 'elementor'),
                'type'      => Controls_Manager::NUMBER,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-icon' => 'width: {{VALUE}}px;',
                ]
            ]
        );

        $this->add_control(
            'button_icon_height',
            [
                'label'     => esc_html__('Height (px)', 'elementor'),
                'type'      => Controls_Manager::NUMBER,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-icon' => 'height: {{VALUE}}px;line-height: {{VALUE}}px;',
                ]
            ]
        );

        $this->start_controls_tabs('crust_button_icon_tabs');

        $this->start_controls_tab('icon_normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_responsive_control(
            'button_icon_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_button_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors'  => [
                    '{{WRAPPER}} .crust-btn-icon'   => 'color: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'button_icon_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'button_icon_border',
                'selector' => '{{WRAPPER}} .crust-btn-icon',
            ]
        );

        $this->add_responsive_control(
            'button_icon_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_icon_box_shadow',
                'selector' => '{{WRAPPER}} .crust-btn-icon',
            ]
        );

	    $this->add_responsive_control(
		    'crust_section_icon_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_button_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    'body.crust-dark {{WRAPPER}} .crust-btn-icon'   => 'color: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_icon_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn-icon' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn-icon',
		    ]
	    );

        $this->end_controls_tab();

        $this->start_controls_tab('button_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_responsive_control(
            'button_icon_hover_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_button_icon_hover_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors'  => [
                    '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon'   => 'color: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'button_icon_hover_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'button_icon_hover_border',
                'selector' => '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon',
            ]
        );

        $this->add_responsive_control(
            'button_icon_border_hover_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_icon_hover_box_shadow',
                'selector' => '{{WRAPPER}} .crust-btn:hover .crust-btn-icon,{{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon',
            ]
        );
	    $this->add_responsive_control(
		    'crust_section_icon_dark_hover',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_button_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    'body.crust-dark {{WRAPPER}} .crust-btn:hover .crust-btn-icon,body.crust-dark {{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon'   => 'color: {{SIZE}};',
				    'separator'   => 'before',
			    ],

		    ]

	    );

	    $this->add_control(
		    'button_icon_hover_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn:hover .crust-btn-icon,body.crust-dark {{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:hover .crust-btn-icon,body.crust-dark {{WRAPPER}} .crust-btn-underline:hover .crust-btn-icon',
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();

	    $this->end_controls_section();

    }

    protected function render()
    {

        $settings      = $this->get_settings_for_display();
	    $btn           = $settings['button_style'];
	    $styled        = ( $settings['button_hover_style'] ) ? 'styled-btn' : '';
        $btnblock      = ( 'yes' == $settings['button_block'] ) ? ' crust-btn-block' : '';
        $iconblock     = ( 'yes' == $settings['button_icon_block'] ) ? ' crust-btn-block-icon' : '';
        $btn_size      = ( $settings['size'] !== 'md' && 'crust-btn' == $btn ) ? 'crust-btn-size-' . $settings['size'] : '';

        $this->add_render_attribute(
            'crust_button',
            [
                'class' => [
                    esc_attr( $btn ),
                    esc_attr( $settings['button_hover_style'] ),
                    esc_attr( $btn_size ),
	                esc_attr( $styled ),
                    esc_attr( $iconblock ),
                    esc_attr( $btnblock ),
                ],
                'href'  => esc_attr( $settings['button_link_url']['url'] ),
                //'data-scroll-speed' => '2',
	            //'data-scroll-position' => 'top'
            ]

        );

        if ($settings['button_link_url']['is_external']) {
            $this->add_render_attribute('crust_button', 'target', '_blank');
        }

        if ($settings['button_link_url']['nofollow']) {
            $this->add_render_attribute('crust_button', 'rel', 'nofollow');
        }

        $output = '<a '. $this->get_render_attribute_string("crust_button") .'>';
	        $output .= ( $settings['button_hover_style'] == 'btn-bestia' ) ? '<b class="bestia-bg"></b>' : '';
            $output .= '<span><span>';
                $output .= ( $settings['button_use_icon'] === 'yes' && $settings['button_icon_alignment'] == 'left') ? $this->render_icon() : '';
                $output .= $settings['button_text'];
                $output .= ( $settings['button_use_icon'] === 'yes' && $settings['button_icon_alignment'] == 'right') ? $this->render_icon() : '';
            $output .= '</span></span>';
        $output .= '</a>';

        echo $output;

    }

    protected function render_icon()
    {

        $settings   = $this->get_settings_for_display();
	    $iconoutput = $iconclass = '';
        $icondir    = $settings['button_icon_alignment'];
        $iconclass  .= ( 'yes' == $settings['button_icon_block'] ) ? ' crust-block-icon' : '';
        $iconclass  .= ( $settings['button_icon']['value'] && ! isset($settings['button_icon']['value']['url']) ) ? ' ' . $settings['button_icon']['value'] : '';

        $this->add_render_attribute('crust_button_icon',
            [
                'class' => ['crust-btn-icon',esc_attr($iconclass), 'crust-btn-icon-'.esc_attr($icondir)],
            ]
        );

        if (isset($settings['button_icon']['value']['url'])) {
            $iconoutput .= '<span '. $this->get_render_attribute_string("crust_button_icon") .'><img src="'. esc_attr($settings['button_icon']['value']['url']) .'" alt="'.esc_attr(get_post_meta($settings['button_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'"></span>';
        } else {
            $iconoutput .= ( ! empty($settings['button_icon']['value'])) ? '<i '. $this->get_render_attribute_string("crust_button_icon") .'></i>' : '';
        }

	    return $iconoutput;

    }

}
