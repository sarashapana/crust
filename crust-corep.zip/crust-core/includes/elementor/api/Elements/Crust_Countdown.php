<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Countdown extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-countdown'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-countdown', true, true);
        return ['crust-countdown'];
    }

    public function get_name()
    {
        return 'crust-countdown';
    }

    public function get_title()
    {
        return esc_html__('Countdown', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-countdown';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'crust_countdown_settings_general',
            [
                'label' => esc_html__('Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_countdown_due_date',
            [
                'label'       => esc_html__('Due Date', 'crust-core'),
                'type'        => Controls_Manager::DATE_TIME,
                'default'     => date("Y-m-d", strtotime("+ 1 day")),
            ]
        );

        $this->add_control(
            'crust_countdown_label_view',
            [
                'label'   => esc_html__('Number Position', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'crust-countdown-label-block',
                'options' => [
                    'crust-countdown-label-inline' => esc_html__('Inline', 'crust-core'),
                    'crust-countdown-label-block'  => esc_html__('Block', 'crust-core'),
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_countdown_label_padding_left',
            [
                'label'       => esc_html__('Left Margin', 'crust-core'),
                'type'        => Controls_Manager::SLIDER,
                'description' => esc_html__('For Inline Number Style.', 'crust-core'),
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'   => [
                    '{{WRAPPER}} .crust-countdown-label' => 'padding-left:{{SIZE}}px;',
                ],
                'condition'   => [
                    'crust_countdown_label_view' => 'crust-countdown-label-inline',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_countdown_settings_content',
            [
                'label' => esc_html__('Content Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_countdown_days',
            [
                'label'        => esc_html__('Display Days', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'crust_countdown_days_label',
            [
                'label'       => esc_html__('Label', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__('Days', 'crust-core'),
                'condition'   => [
                    'crust_countdown_days' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_hours',
            [
                'label'        => esc_html__('Display Hours', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'crust_countdown_hours_label',
            [
                'label'       => esc_html__('Label', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__('Hours', 'crust-core'),
                'condition'   => [
                    'crust_countdown_hours' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_minutes',
            [
                'label'        => esc_html__('Display Minutes', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'crust_countdown_minutes_label',
            [
                'label'       => esc_html__('Label', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__('Minutes', 'crust-core'),
                'condition'   => [
                    'crust_countdown_minutes' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_seconds',
            [
                'label'        => esc_html__('Display Seconds', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'crust_countdown_seconds_label',
            [
                'label'       => esc_html__('Label', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__('Seconds', 'crust-core'),
                'condition'   => [
                    'crust_countdown_seconds' => 'yes',
                ],
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'crust_countdown_separator_heading',
            [
                'label' => __('Separator', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
            ]
        );

	    $this->add_control(
		    'crust_countdown_separator',
		    [
			    'label'        => esc_html__('Display Separator', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'return_value' => 'crust-countdown-show-separator',
			    'default'      => '',
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_separator_label',
		    [
			    'label'       => esc_html__('Text', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,

			    'condition'   => [
				    'crust_countdown_separator' => 'crust-countdown-show-separator',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_separator_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'condition' => [
				    'crust_countdown_separator' => 'crust-countdown-show-separator',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-countdown-item::after' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'      => 'crust_countdown_separator_typography',
			    'selector'  => '{{WRAPPER}} .crust-countdown-item::after',
			    'condition' => [
				    'crust_countdown_separator' => 'crust-countdown-show-separator',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_countdown_separator_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-countdown-item::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'crust_countdown_separator' => 'crust-countdown-show-separator',
			    ],
		    ]
	    );

        $this->end_controls_section();

        $this->start_controls_section(
            'countdown_on_expire_settings',
            [
                'label' => esc_html__('Expiry Action', 'crust-core')
            ]
        );

        $this->add_control(
            'countdown_expire_type',
            [
                'label'       => esc_html__('Expiry Type', 'crust-core'),
                'label_block' => false,
                'type'        => Controls_Manager::SELECT,
                'options'     => [
                    'text'     => esc_html__('Message', 'crust-core'),
                    'url'      => esc_html__('Redirection Link', 'crust-core'),
                    'template' => esc_html__('Saved Templates', 'crust-core'),
                    'none'     => esc_html__('None', 'crust-core'),
                ],
                'default'     => 'text'
            ]
        );

        $this->add_control(
            'countdown_expiry_image',
            [
                'label'   => __('Image', 'elementor'),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'countdown_expire_type' => 'text'
                ]
            ]
        );

        $this->add_control(
            'countdown_expiry_text_title',
            [
                'label'     => esc_html__('Expiry Title', 'crust-core'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => esc_html__('Ooops... Time Up!!', 'crust-core'),
                'condition' => [
                    'countdown_expire_type' => 'text'
                ]
            ]
        );

        $this->add_control(
            'countdown_expiry_text',
            [
                'label'     => esc_html__('Expiry Content', 'crust-core'),
                'type'      => Controls_Manager::WYSIWYG,
                'default'   => esc_html__('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', 'crust-core'),
                'condition' => [
                    'countdown_expire_type' => 'text'
                ]
            ]
        );

        $this->add_control(
            'countdown_expiry_redirection',
            [
                'label'     => esc_html__('Redirect To URL', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'countdown_expire_type' => 'url'
                ],
                'default'   => '#'
            ]
        );

        $this->add_control(
            'countdown_expiry_templates',
            [
                'label'     => __('Custom Template', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->crust_core_get_page_templates(),
                'condition' => [
                    'countdown_expire_type' => 'template',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_countdown_styles_general',
            [
                'label' => esc_html__('Styles', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_countdown_background',
                'types'     => ['classic', 'gradient'],
                'selector'  => '{{WRAPPER}} .crust-countdown-item > div',
            ]
        );

	    $this->add_responsive_control(
		    'crust_countdown_width',
		    [
			    'label'     => esc_html__('Width', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-countdown-item > div' => 'width:{{SIZE}}px;',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_countdown_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-countdown-item > div' => 'height:{{SIZE}}px;',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_countdown_spacing',
            [
                'label'     => esc_html__('Space Between Boxes', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 15,
                ],
                'range'     => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div' => 'margin-right:{{SIZE}}px; margin-left:{{SIZE}}px;',
                    '{{WRAPPER}} .crust-countdown-container'  => 'margin-right: -{{SIZE}}px; margin-left: -{{SIZE}}px;',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_countdown_box_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-countdown-item > div' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_countdown_box_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-countdown-item > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_countdown_box_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-countdown-item > div',
            ]
        );

        $this->add_control(
            'crust_countdown_box_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_countdown_box_shadow',
                'selector' => '{{WRAPPER}} .crust-countdown-item > div',
            ]
        );
		////////////
	    $this->add_responsive_control(
		    'crust_countdown_styles_dark_general',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_countdown_dark_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-countdown-item > div',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_countdown_box_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-countdown-item > div',
		    ]
	    );
	    ///////////

        $this->end_controls_section();


        $this->start_controls_section(
            'crust_countdown_styles_content',
            [
                'label' => esc_html__('Typography', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_control(
		    'digits_tag',
		    [
			    'label'       => esc_html__('Digits Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h3',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_countdown_digits_color',
            [
                'label'     => esc_html__('Digits Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ff5b4a',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-digits' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'crust_countdown_digit_typography',
                'selector'  => '{{WRAPPER}} .crust-countdown-digits',
            ]
        );

	    $this->add_responsive_control(
		    'crust_countdown_digits_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-countdown-digits' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
			    ],
		    ]
	    );


        $this->add_control(
            'crust_countdown_label_color',
            [
                'label'     => esc_html__('Labels Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-label' => 'color: {{VALUE}};',
                ],
                'separator' => 'before'
            ]
        );

	    $this->add_control(
		    'labels_tag',
		    [
			    'label'       => esc_html__('Labels Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'span',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_countdown_label_typography',
                'selector' => '{{WRAPPER}} .crust-countdown-label',
            ]
        );
		///////////

	    $this->add_responsive_control(
		    'crust_countdown_styles_dark_content',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_countdown_digits_dark_color',
		    [
			    'label'     => esc_html__('Digits Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-digits' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_label_dark_color',
		    [
			    'label'     => esc_html__('Labels Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-label' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
		/////////////
	    $this->end_controls_section();

///// section custom box
        $this->start_controls_section(
            'crust_countdown_styles_individual',
            [
                'label' => esc_html__('Custom Box Styles', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );
////////days
        $this->add_control(
            'crust_countdown_days_label_heading',
            [
                'label' => __('Days', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'crust_countdown_days_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-days' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_days_digit_color',
            [
                'label'     => esc_html__('Digit Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-days .crust-countdown-digits' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_days_label_color',
            [
                'label'     => esc_html__('Label Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-days .crust-countdown-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_days_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-days' => 'border-color: {{VALUE}};',
                ],
            ]
        );
/////hours
        $this->add_control(
            'crust_countdown_hours_label_heading',
            [
                'label' => __('Hours', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_countdown_hours_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-hours' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_hours_digit_color',
            [
                'label'     => esc_html__('Digit Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-hours .crust-countdown-digits' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_hours_label_color',
            [
                'label'     => esc_html__('Label Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-hours .crust-countdown-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_hours_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-hours' => 'border-color: {{VALUE}};',
                ],
            ]
        );
/////minutes
        $this->add_control(
            'crust_countdown_minutes_label_heading',
            [
                'label' => __('Minutes', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_countdown_minutes_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-minutes' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_minutes_digit_color',
            [
                'label'     => esc_html__('Digit Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-minutes .crust-countdown-digits' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_minutes_label_color',
            [
                'label'     => esc_html__('Label Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-minutes .crust-countdown-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_minutes_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-minutes' => 'border-color: {{VALUE}};',
                ],
            ]
        );
////////seconds
        $this->add_control(
            'crust_countdown_seconds_label_heading',
            [
                'label' => __('Seconds', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_countdown_seconds_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-seconds' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_seconds_digit_color',
            [
                'label'     => esc_html__('Digit Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-seconds .crust-countdown-digits' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_seconds_label_color',
            [
                'label'     => esc_html__('Label Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-seconds .crust-countdown-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_countdown_seconds_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-item > div.crust-countdown-seconds' => 'border-color: {{VALUE}};',
                ],
            ]
        );

///////////start custom editing/////////
///////days/////
	    $this->add_responsive_control(
		    'crust_countdown_styles_dark_individual',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_countdown_days_dark_label_heading',
		    [
			    'label' => __('Days', 'crust-core'),
			    'type'  => Controls_Manager::HEADING,
		    ]
	    );


	    $this->add_control(
		    'crust_countdown_days_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-days' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_days_dark_digit_color',
		    [
			    'label'     => esc_html__('Digit Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-days .crust-countdown-digits' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->add_control(
		    'crust_countdown_days_dark_label_color',
		    [
			    'label'     => esc_html__('Label Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-days .crust-countdown-label' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_days_dark_border_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-days' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
		/////HOURS////
	    $this->add_control(
		    'crust_countdown_hours_label_dark_heading',
		    [
			    'label' => __('Hours', 'crust-core'),
			    'type'  => Controls_Manager::HEADING,
			    'separator' => 'before'
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_hours_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-hours' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_hours_digit_dark_color',
		    [
			    'label'     => esc_html__('Digit Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-color {{WRAPPER}} .crust-countdown-hours .crust-countdown-digits' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->add_control(
		    'crust_countdown_hours_label_dark_color',
		    [
			    'label'     => esc_html__('Label Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-hours .crust-countdown-label' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_hours_border_dark_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-hours' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
		/////minutes///
	    $this->add_control(
		    'crust_countdown_minutes_label_dark_heading',
		    [
			    'label' => __('Minutes', 'crust-core'),
			    'type'  => Controls_Manager::HEADING,
			    'separator' => 'before'
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_minutes_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-minutes' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_minutes_digit_dark_color',
		    [
			    'label'     => esc_html__('Digit Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-minutes .crust-countdown-digits' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_minutes_label_dark_color',
		    [
			    'label'     => esc_html__('Label Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-minutes .crust-countdown-label' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_minutes_border_dark_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-minutes' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
		////seconds////
	    $this->add_control(
		    'crust_countdown_seconds_label_dark_heading',
		    [
			    'label' => __('Seconds', 'crust-core'),
			    'type'  => Controls_Manager::HEADING,
			    'separator' => 'before'
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_seconds_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-seconds' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_seconds_digit_dark_color',
		    [
			    'label'     => esc_html__('Digit Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-seconds .crust-countdown-digits' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_seconds_label_dark_color',
		    [
			    'label'     => esc_html__('Label Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-seconds .crust-countdown-label' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_seconds_border_dark_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-item > div.crust-countdown-seconds' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

///////////
        $this->end_controls_section();


        $this->start_controls_section(
            'crust_countdown_expire_style',
            [
                'label'     => esc_html__('Expire Message', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'countdown_expire_type' => 'text'
                ]
            ]
        );

	    $this->add_control(
		    'countdown_expire_display',
		    [
			    'label'       => esc_html__('Display', 'crust-core'),
			    'label_block' => false,
			    'type'        => Controls_Manager::SELECT,
			    'options'     => [
				    ''     => esc_html__('Blocks', 'crust-core'),
				    'inline' => esc_html__('Inline', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_countdown_expire_message_alignment',
            [
                'label'       => esc_html__('Text Alignment', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'     => 'left',
                'selectors'   => [
                    '{{WRAPPER}} .crust-countdown-finish-message' => 'text-align: {{VALUE}};',
                ],
                'condition'  => [
	                'countdown_expire_display!' => 'inline',
                ],
            ]
        );

        $this->add_control(
            'heading_crust_countdown_expire_title',
            [
                'label'     => __('Title Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_countdown_expire_title_color',
            [
                'label'     => esc_html__('Title Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-finish-message .expiry-title' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'countdown_expire_type' => 'text',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'crust_countdown_expire_title_typography',
                'selector'  => '{{WRAPPER}} .crust-countdown-finish-message .expiry-title',
                'condition' => [
                    'countdown_expire_type' => 'text',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_core_expire_title_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-countdown-finish-message .expiry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );
		///////////
	    $this->add_responsive_control(
		    'crust_countdown_expire_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
		    ]
	    );

	    $this->add_control(
		    'crust_countdown_expire_title_dark_color',
		    [
			    'label'     => esc_html__('Title Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-finish-message .expiry-title' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'countdown_expire_type' => 'text',
			    ],
		    ]
	    );
	    ///////////

        $this->add_control(
            'heading_crust_countdown_expire_message',
            [
                'label'     => __('Content Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_countdown_expire_message_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-countdown-finish-text' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'countdown_expire_type' => 'text',
                ],
            ]
        );


	    $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'crust_countdown_expire_message_typography',
                'selector'  => '.crust-countdown-finish-text',
                'condition' => [
                    'countdown_expire_type' => 'text',
                ],
            ]
        );

	    //////////

	    $this->add_responsive_control(
		    'crust_countdown_expire_dark_content_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,

		    ]
	    );
	    $this->add_control(
		    'crust_countdown_expire_message_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-countdown-finish-text' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'countdown_expire_type' => 'text',
			    ],
		    ]
	    );
//////////

        $this->add_responsive_control(
            'crust_countdown_expire_message_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'separator'  => 'before',
                'selectors'  => [
                    '{{WRAPPER}} .crust-countdown-finish-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'  => [
                    'countdown_expire_type' => 'text',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'expire_icon_margin',
		    [
			    'label'      => esc_html__('Icon Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'separator'  => 'before',
			    'selectors'  => [
				    '{{WRAPPER}} .crust-countdown-finish-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition'  => [
				    'countdown_expire_type' => 'text',
			    ],
		    ]
	    );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $get_due_date = esc_attr($settings['crust_countdown_due_date']);
        $due_date = date("M d Y G:i:s", strtotime($get_due_date));
        $template = '';

        if ( 'template' == $settings['countdown_expire_type'] && ! empty($settings['countdown_expiry_templates']) ) {

            $crust_template_id = $settings['countdown_expiry_templates'];
            $crust_frontend = new Frontend;
            $template = $crust_frontend->get_builder_content($crust_template_id, true);

        } elseif( $settings['countdown_expire_type'] == 'text' ) {

            $countdown_expire_image = $settings['countdown_expiry_image'];
	        $expire_display = $settings['countdown_expire_display'];
            $countdown_expire_image_url = ($countdown_expire_image) ? $countdown_expire_image['url'] : '';

            $ex_class = 'crust-countdown-finish-message';
            $ex_class .= ( $expire_display ) ? ' ' . $expire_display : '';
            $template = '
            <div class="'.esc_attr($ex_class).'">
                <div class="crust-countdown-finish-img">
                    <img src="'.esc_url($countdown_expire_image_url).'" />
                </div>
                <div class="crust-countdown-finish-content">
	                <h3 class="expiry-title secondary-color">'.wp_kses_post($settings['countdown_expiry_text_title']).'</h3>
	                <div class="crust-countdown-finish-text">
	                    '.wp_kses_post($settings['countdown_expiry_text']).'
	                </div>
				</div>
            </div>';

        }

        $this->add_render_attribute('crust-countdown', [
            'class' => 'crust-countdown-wrapper',
            'data-countdown-id' => esc_attr($this->get_id()),
            'data-expire-type' => $settings['countdown_expire_type']
        ]);

        if ($settings['countdown_expire_type'] == 'url') {
            $this->add_render_attribute('crust-countdown', 'data-redirect-url', $settings['countdown_expiry_redirection']);
        } else {
            $this->add_render_attribute('crust-countdown', 'data-template', esc_attr($template));
        }

        $tag = $settings['digits_tag'];
        $lbl_tag = $settings['labels_tag'];

	    $sep_atts = ($settings['crust_countdown_separator'] == 'crust-countdown-show-separator' && $settings['crust_countdown_separator_label'] ) ? $settings['crust_countdown_separator_label'] : ':';

        $html = '<div '.$this->get_render_attribute_string('crust-countdown').'>';
            $html .= '<div class="crust-countdown-container '.esc_attr($settings['crust_countdown_label_view']).' '.esc_attr($settings['crust_countdown_separator']).'">';
                $html .= '<ul id="crust-countdown-'.esc_attr($this->get_id()).'" class="crust-countdown-items" data-date="'.esc_attr($due_date).'">';
                    if ( ! empty($settings['crust_countdown_days'])) {
                        $html .= '<li class="crust-countdown-item" data-separator="'.$sep_atts.'">';
                            $html .= '<div class="crust-countdown-days"><'.$tag.' data-days class="crust-countdown-digits">00</'.$tag.'>';
                                if ( ! empty($settings['crust_countdown_days_label'])) {
                                    $html .= '<'.$lbl_tag.' class="crust-countdown-label">'.$settings['crust_countdown_days_label'].'</'.$lbl_tag.'>';
                                }
                            $html .= '</div>';
                        $html .= '</li>';
                    }
                    if ( ! empty($settings['crust_countdown_hours'])) {
                        $html .= '<li class="crust-countdown-item" data-separator="'.$sep_atts.'">';
                            $html .= '<div class="crust-countdown-hours"><'.$tag.' data-hours class="crust-countdown-digits">00</'.$tag.'>';
                                if (!empty($settings['crust_countdown_hours_label'])) {
                                    $html .= '<'.$lbl_tag.' class="crust-countdown-label">'.esc_attr($settings['crust_countdown_hours_label']).'</'.$lbl_tag.'>';
                                }
                            $html .= '</div>';
                        $html .= '</li>';
                    }
                    if ( ! empty($settings['crust_countdown_minutes'])) {
                        $html .= '<li class="crust-countdown-item" data-separator="'.$sep_atts.'">';
                            $html .= '<div class="crust-countdown-minutes"><'.$tag.' data-minutes class="crust-countdown-digits">00</'.$tag.'>';
                                if (!empty($settings['crust_countdown_minutes_label'])) {
                                    $html .= '<'.$lbl_tag.' class="crust-countdown-label">';
                                        $html .= $settings['crust_countdown_minutes_label'];
                                    $html .= '</'.$lbl_tag.'>';
                                }
                            $html .= '</div>';
                        $html .= '</li>';
                    }
                    if ( ! empty($settings['crust_countdown_seconds'])) {
                        $html .= '<li class="crust-countdown-item">';
                            $html .= '<div class="crust-countdown-seconds"><'.$tag.' data-seconds class="crust-countdown-digits">00</'.$tag.'>';
                                if (!empty($settings['crust_countdown_seconds_label'])) {
                                    $html .= '<'.$lbl_tag.' class="crust-countdown-label">'.$settings['crust_countdown_seconds_label'].'</'.$lbl_tag.'>';
                                }
                            $html .= '</div>';
                        $html .= '</li>';
                    }
                $html .= '</ul>';
                $html .= '<div class="clearfix"></div>';
            $html .= '</div>';
        $html .= '</div>';

        echo $html;

    }

    protected function content_template() { }
}
