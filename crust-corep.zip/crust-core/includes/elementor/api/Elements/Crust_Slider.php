<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Slider extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-slider'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-slider', false, true);
        return ['crust-slider'];
    }

    public function get_name()
    {
        return 'crust-slider';
    }

    public function get_title()
    {
        return esc_html__('Crust Slider', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-slider-push';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Slider Content Settings
         */
        $this->start_controls_section(
            'crust_clients_settings',
            [
                'label' => esc_html__('Content', 'crust-core'),
            ]
        );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_slider_content', [
			    'label'   => __('Content Type', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    'content'  => __('Content', 'crust-core'),
				    'template' => __('Saved Templates', 'crust-core'),
			    ],
			    'default' => 'content',
		    ]
	    );

	    $repeater->add_control(
		    'crust_core_primary_templates', [
			    'label'     => __('Choose Template', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => $this->crust_core_get_page_templates(),
			    'condition' => [
				    'crust_slider_content' => 'template',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_slider_img', [
			    'label'       => esc_html__('Image', 'crust-core'),
			    'type'        => Controls_Manager::MEDIA,
			    'label_block' => true,
			    'default'     => [
				    'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
			    ],
			    'condition' => [
				    'crust_slider_content' => 'content',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_slider_title', [
			    'label'       => esc_html__('Title', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Slider Title', 'crust-core'),
			    'dynamic'     => ['active' => true],
			    'condition' => [
				    'crust_slider_content' => 'content',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_slider_text', [
			    'label'       => esc_html__('Text', 'crust-core'),
			    'type'        => Controls_Manager::TEXTAREA,
			    'label_block' => true,
			    'dynamic'     => ['action' => true],
			    'condition' => [
				    'crust_slider_content' => 'content',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_slider_link', [
			    'label'         => esc_html__('Link', 'crust-core'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'default'       => [
				    'url'         => '#',
				    'is_external' => '',
			    ],
			    'show_external' => true,
			    'condition' => [
				    'crust_slider_content' => 'content',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_slider_imgs',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_slider_title}}',
            ]
        );

        $this->end_controls_section();

        $this->crust_core_slider_settings('');

        /**
         * -------------------------------------------
         * Tab Style (Slider Item)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_slider_wrapper_settings',
            [
                'label' => esc_html__('Wrapper', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_wrapper_border',
                'selector' => '{{WRAPPER}} .crust-carousel',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_wrapper_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-carousel' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_wrapper_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-carousel .swiper-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; width: auto !important',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_wrapper_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-carousel' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_slider_wrapper_box_shadow',
                'selector' => '{{WRAPPER}} .crust-carousel',
            ]
        );
	    /**
	     *-------------------------------
	     *start wrapper dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_wrapper_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_wrapper_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-carousel',
		    ]
	    );

	    /**
	     *-------------------------------
	     *end wrapper dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_slider_style_settings',
            [
                'label' => esc_html__('Item Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background:: get_type(),
            [
                'name'     => 'crust_slider_item_bg',
                'types'    => ['classic', 'gradient'],
                'exclude'  => [
                    'image',
                ],
                'selector' => '{{WRAPPER}} .crust-carousel .crust-slider-item',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_item_border',
                'selector' => '{{WRAPPER}} .crust-slider-item-wrapper',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_item_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-item-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_item_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-item-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_slider_item_box_shadow',
                'selector' => '{{WRAPPER}} .crust-slider-item-wrapper',
            ]
        );
	    /**
	     *-------------------------------
	     *start item style dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_slider_item_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-carousel .crust-slider-item',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_item_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-slider-item-wrapper',
		    ]
	    );
	    /**
	     *-------------------------------
	     *end item style dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        /* Content */
        $this->start_controls_section(
            'crust_slider_content_settings',
            [
                'label' => esc_html__('Content', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_style',
            [
                'label' => __( 'Style', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('Overlay', 'crust-core'),
                    'crust-content-below' => esc_html__('Below Image', 'crust-core'),
                ],
            ]
        );

	    $this->add_control(
		    'content_visibility',
		    [
			    'label' => __( 'Visibility', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'options' => [
				    '' => esc_html__('All Slides', 'crust-core'),
				    'crust-visible-active' => esc_html__('Active Slide', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_slider_content_alignment',
            [
                'label'        => esc_html__('Alignment', 'elementor'),
                'type'         => Controls_Manager::CHOOSE,
                'options'      => [ 
                    '' => [
                    'title' => __('Default', 'crust-core'),
                    'icon'  => 'fa fa-ban',
                    ],
                    'left'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'      => 'center',
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-content' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_content_border',
                'selector' => '{{WRAPPER}} .crust-slider-content',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_content_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_slider_content_box_shadow',
                'selector' => '{{WRAPPER}} .crust-slider-content',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_content_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_content_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    /**
	     *-------------------------------
	     *start content dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_content_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_content_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-slider-content',
		    ]
	    );
	    /**
	     *-------------------------------
	     *end content dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        /* Title */
        $this->start_controls_section(
            'crust_slider_title_settings',
            [
                'label' => esc_html__('Title', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'crust_slider_title_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h5',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_slider_title_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-title,{{WRAPPER}} .crust-slider-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_slider_title_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-title' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_slider_title_use_gradient_bg!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'crust_slider_title_use_gradient_bg',
            [
                'label' => esc_html__( 'Gradient Background', 'crust-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_slider_title_gradient_bg',
                'types'     => ['gradient'],
                'selector'  => '{{WRAPPER}} .crust-slider-title',
                'condition' => [
                    'crust_slider_title_use_gradient_bg' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_slider_title_typography',
                'selector' => '{{WRAPPER}} .crust-slider-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'crust_slider_title_shadow',
                'label'      => esc_html__('Text Shadow', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-slider-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_title_border',
                'selector' => '{{WRAPPER}} .crust-slider-title',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_title_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_slider_title_box_shadow',
                'selector' => '{{WRAPPER}} .crust-slider-title',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_title_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_title_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->crust_animations( 'slider_title' );
	    /**
	     *-------------------------------
	     *start title dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_title_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_slider_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-slider-title,{{WRAPPER}} .crust-slider-title a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_slider_title_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-slider-title' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_slider_title_use_gradient_bg!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_slider_title_use_gradient_dark_bg',
		    [
			    'label' => esc_html__( 'Gradient Background', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_slider_title_gradient_dark_bg',
			    'types'     => ['gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-slider-title',
			    'condition' => [
				    'crust_slider_title_use_gradient_dark_bg' => 'yes',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_title_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-slider-title',
		    ]
	    );

	    /**
	     *-------------------------------
	     *end title dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        /* Content */
        $this->start_controls_section(
            'crust_slider_text_settings',
            [
                'label' => esc_html__('Text', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'crust_slider_text_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_slider_text_typography',
                'selector' => '{{WRAPPER}} .crust-slider-text',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'crust_slider_text_shadow',
                'label'      => esc_html__('Text Shadow', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-slider-text',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_text_border',
                'selector' => '{{WRAPPER}} .crust-slider-text',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_text_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_slider_text_box_shadow',
                'selector' => '{{WRAPPER}} .crust-slider-text',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_text_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->crust_animations( 'slider_text' );
	    /**
	     *-------------------------------
	     *start text dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_text_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_slider_text_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-slider-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_text_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-slider-text',
		    ]
	    );


	    /**
	     *-------------------------------
	     *end text dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        /* OverLay */
        $this->start_controls_section(
            'crust_slider_style_overlay',
            [
                'label' => esc_html__('Overlay', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'crust_slider_overlay',
            [
                'label'         => esc_html__('Overlay', 'crust-core'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'YES', 'crust-core' ),
                'label_off'     => esc_html__( 'NO', 'crust-core' ),
                'return_value'  => 'yes',
            ]
        );

        $this->add_control(
            'crust_slider_overlay_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-overlay' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_slider_overlay_gradient_bg!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'crust_slider_overlay_gradient_bg',
            [
                'label' => esc_html__( 'Gradient Background', 'crust-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_slider_overlay_gradient_background',
                'types'     => ['gradient'],
                'selector'  => '{{WRAPPER}} .crust-slider-overlay',
                'condition' => [
                    'crust_slider_overlay_gradient_bg' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_slider_overlay_border',
                'selector' => '{{WRAPPER}} .crust-slider-overlay',
            ]
        );

        $this->add_responsive_control(
            'crust_slider_overlay_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-slider-overlay' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_slider_overlay_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-slider-overlay' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .crust-slider-overlay' => 'width: calc( 100% - {{RIGHT}}{{UNIT}} - {{LEFT}}{{UNIT}} );height: calc( 100% - {{TOP}}{{UNIT}} - {{BOTTOM}}{{UNIT}} );',
                ],
            ]
        );
	    /**
	     *-------------------------------
	     *start overlay dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_slider_overlay_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_slider_overlay_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-slider-overlay' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_slider_overlay_gradient_dark_bg!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_slider_overlay_gradient_dark_bg',
		    [
			    'label' => esc_html__( 'Gradient Background', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_slider_overlay_gradient_dark_background',
			    'types'     => ['gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-slider-overlay',
			    'condition' => [
				    'crust_slider_overlay_gradient_dark_bg' => 'yes',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_slider_overlay_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-slider-overlay',
		    ]
	    );
	    /**
	     *-------------------------------
	     *end overlay dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        $this->crust_core_slider_styling();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();
        $over = $settings['crust_slider_overlay'];
        $tag = $settings['crust_slider_title_tag'];
        $slides = $settings['crust_slider_imgs'];
        $content_style = ( '' !== $settings['content_style'] ) ? ' ' . $settings['content_style'] : '';
        $this->add_render_attribute('crust_carousel', 'class', [
            'swiper-container',
            'crust-carousel',
        ]);

        $this->add_render_attribute('slider_title', 'class', 'crust-slider-title' );
        $this->crust_animation_attributes( 'slider_title' );

        $this->add_render_attribute('slider_text', 'class', 'crust-slider-text' );
        $this->crust_animation_attributes( 'slider_text' );

        $this->crust_core_slider_attributes();

		$wrap_class = 'swiper-wrapper';
		$wrap_class .= ( $settings['content_visibility'] !== '' ) ? ' ' . $settings['content_visibility'] : '';

	    $html = '<div class="crust-slider-wrapper">';
	        $html .= '<div ' . $this->get_render_attribute_string('crust_carousel') . '>';
	            $html .= '<div class="'. $wrap_class .'">';
	                foreach ( $slides as $slide) {
	                    $html .= '<div class="swiper-slide">';
	                        $html .= '<div class="crust-slider-item">';

	                            if ('content' == $slide['crust_slider_content']) {
	                                $src      = $slide['crust_slider_img']['url'];
	                                $title    = $slide['crust_slider_title'];
	                                $content  = $slide['crust_slider_text'];
	                                $link     = $slide['crust_slider_link']['url'];
	                                $target   = $slide['crust_slider_link']['is_external'] ? 'target="_blank"' : '';
	                                $nofollow = $slide['crust_slider_link']['nofollow'] ? 'rel="nofollow"' : '';

	                                $link_before = ( $link !== '' ) ? '<a href="' . esc_url($link) . '" ' . $target . ' ' . $nofollow . '>' : '';
	                                $link_after = ( $link !== '' ) ? '</a>' : '';

	                                $html .= '<div class="crust-slider-item-wrapper">';
	                                    $html .= ( 'yes' === $over ) ? '<div class="crust-slider-overlay"></div>' : '';
	                                    $html .= '<div class="crust-slider-img-wrap">';
											$html .= ( $link !== '' ) ? $link_before : '';
				                                $html .= '<img alt="" src="'.esc_url($src).'" class="crust-slider-img" />';
			                                $html .= ( $link !== '' ) ? $link_after : '';
			                            $html .= '</div>';
	                                $html .= '</div>';
	                                if(  $title != '' || $content != '' ){
	                                    $html .= '<div class="crust-slider-content'.$content_style.'">';
	                                        $html .= ( $title != '' ) ? '<'.$tag.' ' .$this->get_render_attribute_string('slider_title').'>' . $link_before . esc_attr($title) . $link_after . '</'.$tag.'>' : '';
	                                        $html .= ( $content != '' ) ? '<p ' .$this->get_render_attribute_string('slider_text').'>'. esc_attr($content) .'</p>' : '';
	                                    $html .= '</div>';
	                                }
	                            } elseif ('template' == $slide['crust_slider_content']){
	                                if ( ! empty($slide['crust_core_primary_templates'])) {
	                                    $crust_core_template_id = $slide['crust_core_primary_templates'];
	                                    $html .= \Elementor\Plugin::$instance->frontend->get_builder_content_for_display($crust_core_template_id, true);
	                                }
	                            }

	                        $html .= '</div>';
	                    $html .= '</div>';
	                }
	            $html .= '</div>';

	        $html .= '</div>';

	    //$html .= $this->crust_carousel_nav();

	    $html .= apply_filters('crust_carousel_nav_site',$settings);

		$idd = uniqid('crust-thumbs-');
	    $show_thumbs = $settings['show_thumbs'];
	    if( $show_thumbs ){
		    $html .= '<div class="swiper-container crust-gallery-thumbs" data-idm="'.$idd.'">';
			    $html .= '<div class="swiper-wrapper">';
				    $items = $settings['thumbs'];
				    foreach ( $items as $item ) {
					    $src = $item['thumb']['url'];
					    $html .= '<div class="swiper-slide" style="background-image: url('.esc_url($src).')"></div>';
				    }
			    $html .= '</div>';
		    $html .= '</div>';
	    }

	    $html .= '</div>';

        echo $html;

    }

}
