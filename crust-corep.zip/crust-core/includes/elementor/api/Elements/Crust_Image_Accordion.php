<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Frontend;
use Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Image_Accordion extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-image-accordion'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-image-accordion', true, true);
        return ['crust-image-accordion'];
    }

    public function get_name()
    {
        return 'crust-image-accordion';
    }

    public function get_title()
    {
        return esc_html__('Image Accordion', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Image accordion Content Settings
         */
        $this->start_controls_section(
            'crust_img_accordion_settings',
            [
                'label' => esc_html__('Image Accordion Settings', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_img_accordion_dir',
		    [
			    'label'       => esc_html__('Direction', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'horizontal',
			    'label_block' => false,
			    'options'     => [
				    'horizontal' => esc_html__('Horizontal', 'crust-core'),
				    'vertical' => esc_html__('Vertical', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'scale_type',
		    [
			    'label'       => esc_html__('Hover Scale', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__( 'Default', 'crust-core' ),
				    '1.5' => esc_html__( 'Small', 'crust-core' ) ,
				    '2' => esc_html__( 'Medium', 'crust-core' ),
				    '3' => esc_html__( 'Large', 'crust-core' ),
				    '4' => esc_html__( 'X Large', 'crust-core' ),
			    ],
			    'selectors' => [
			    	'{{WRAPPER}} .crust-img-accordion.hover-accordion .crust-img-accordion-overlay:hover, .crust-img-accordion .crust-img-accordion-overlay-active' => 'flex: {{VALUE}}'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_img_accordions',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    ['crust_accordion_bg' => CRUST_URI . '/assets/front/images/accordion.png'],
                    ['crust_accordion_bg' => CRUST_URI . '/assets/front/images/accordion.png'],
                    ['crust_accordion_bg' => CRUST_URI . '/assets/front/images/accordion.png'],
                    ['crust_accordion_bg' => CRUST_URI . '/assets/front/images/accordion.png'],
                ],
                'fields'      => [
                    [
                        'name'        => 'crust_accordion_bg',
                        'label'       => esc_html__('Background Image', 'crust-core'),
                        'type'        => Controls_Manager::MEDIA,
                        'label_block' => true,
                        'default'     => [
                            'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
                        ],
                    ],
                    [
                        'name'        => 'crust_accordion_tittle',
                        'label'       => esc_html__('Title', 'crust-core'),
                        'type'        => Controls_Manager::TEXT,
                        'label_block' => true,
                        'default'     => esc_html__('Accordion item title', 'crust-core'),
                        'dynamic'     => ['active' => true],
                    ],

	                 [
		                'name'        => 'crust_accordion_text_type',
		                'label'   => esc_html__('Content Type', 'crust-core'),
		                'type'    => Controls_Manager::SELECT,
		                'options' => [
			                'content'  => esc_html__('Content', 'crust-core'),
			                'template' => esc_html__('Saved Templates', 'crust-core'),
		                ],
		                'default' => 'content',
	                ],
	                [
					    'name'        => 'crust_core_primary_templates',
					    'label'     => esc_html__('Choose Template', 'crust-core'),
					    'type'      => Controls_Manager::SELECT,
					    'options'   => $this->crust_core_get_page_templates(),
					    'condition' => [
						    'crust_accordion_text_type' => 'template',
					    ],
				    ],
                    [
                        'name'        => 'crust_accordion_content',
                        'label'       => esc_html__('Content', 'crust-core'),
                        'type'        => Controls_Manager::WYSIWYG,
                        'label_block' => true,
                        'default'     => esc_html__('Accordion content goes here!', 'crust-core'),
                        'condition' => [
	                        'crust_accordion_text_type' => 'content',
                        ],
                    ],
                    [
                        'name'          => 'crust_accordion_title_link',
                        'label'         => esc_html__('Title Link', 'crust-core'),
                        'type'          => Controls_Manager::URL,
                        'label_block'   => true,
                        'default'       => [
                            'url'         => '#',
                            'is_external' => '',
                        ],
                        'show_external' => true,
                    ],
                ],
                'title_field' => '{{crust_accordion_tittle}}',
            ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Image accordion)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_img_accordion_style_settings',
            [
                'label' => esc_html__('Image Accordion Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'crust_accordion_height',
            [
                'label'       => esc_html__('Height', 'crust-core'),
                'type'        => Controls_Manager::NUMBER,
                'default'     => 400,
                'description' => 'Unit in px',
                'selectors'   => [
                    '{{WRAPPER}} .crust-img-accordion ' => 'height: {{VALUE}}px;',
                ],
            ]
        );

	    $this->add_control(
		    'crust_accordion_overflow',
		    [
			    'label'   => esc_html__('Overflow', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'hidden'         => esc_html__('Hidden', 'crust-core'),
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion' => 'overflow: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_accordion_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-img-accordion',
		    ]
	    );

        $this->add_responsive_control(
            'crust_accordion_container_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-img-accordion' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_accordion_container_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-img-accordion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_accordion_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-img-accordion',
            ]
        );

	    $this->add_responsive_control(
		    'crust_accordion_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_accordion_shadow',
                'selector' => '{{WRAPPER}} .crust-img-accordion',
            ]
        );

        $this->add_control(
            'crust_accordion_img_overlay_color',
            [
                'label'     => esc_html__('Overlay Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_accordion_img_hover_color',
		    [
			    'label'     => esc_html__('Hover Overlay Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => 'rgba(0, 0, 0, .5)',
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:hover:after,{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay.crust-img-accordion-overlay-active:after'         => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_accordion_img_non_hover_color',
            [
                'label'     => esc_html__('Non Hovered Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:hover:after'         => 'background-color: {{VALUE}};',
                ],
            ]
        );
	    /**
	     * -------------------------------------------
	     * Tab Style (Image accordion) Dark
	     * -------------------------------------------
	     */

	    $this->add_responsive_control(
		    'crust_accordion_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_accordion_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-img-accordion',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_accordion_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-img-accordion',
		    ]
	    );
	    $this->add_control(
		    'crust_accordion_dark_img_overlay_color',
		    [
			    'label'     => esc_html__('Overlay Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:after' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_dark_img_hover_color',
		    [
			    'label'     => esc_html__('Hover Overlay Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => 'rgba(0, 0, 0, .5)',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:hover:after,body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay.crust-img-accordion-overlay-active:after'         => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_dark_img_non_hover_color',
		    [
			    'label'     => esc_html__('Non Hovered Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay:hover:after'         => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Image accordion Item)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_img_accordion_item_style_settings',
		    [
			    'label' => esc_html__('Item Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_img_accordion_item_alignment',
		    [
			    'label'        => esc_html__('Horizontal Align', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => false,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'fa fa-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'fa fa-align-center',
				    ],
				    'flex-end'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'fa fa-align-right',
				    ],
			    ],
			    'selectors'            => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'justify-content: {{VALUE}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_img_accordion_item_vertical_align',
		    [
			    'label'       => __('Vertical Align', 'crust-core'),
			    'type'        => Controls_Manager::CHOOSE,
			    'label_block' => false,
			    'default'     => 'top',
			    'options'      => [
				    'flex-start'    => [
					    'title' => __('Top', 'crust-core'),
					    'icon'  => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => __('Middle', 'crust-core'),
					    'icon'  => 'eicon-v-align-middle',
				    ],
				    'flex-end' => [
					    'title' => __('Bottom', 'crust-core'),
					    'icon'  => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors'            => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'align-items: {{VALUE}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_accordion_item_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_accordion_item_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_item_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_item_bg',
		    [
			    'label'     => esc_html__('Background Size ( % )', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    '%' => [
					    'max' => 100,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'background-size: {{SIZE}}%;',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_accordion_item_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay',
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_item_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_accordion_item_shadow',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay',
		    ]
	    );

	    /**
	     * -------------------------------------------
	     * Tab Style (Image accordion Item) Dark
	     * -------------------------------------------
	     */
	    $this->add_responsive_control(
		    'crust_accordion_item_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_accordion_item_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_accordion_item_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay',
		    ]
	    );

	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Title)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_img_accordion_title',
            [
                'label' => esc_html__('Title', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'visible_title',
		    [
			    'label'     => __('Visible by Default', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

        $this->add_control(
            'crust_img_accordion_title_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h4',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_accordion_title_max_width',
		    [
			    'label' => esc_html__( 'Max. Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 2000,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title' => 'max-width: {{SIZE}}{{UNIT}};'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_accordion_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-title, {{WRAPPER}} .crust-img-accordion .crust-img-accordion-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_accordion_title_typography',
                'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title',
            ]
        );

	    $this->add_responsive_control(
		    'crust_accordion_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_accordion_title_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_accordion_title_border',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title',
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_accordion_title_shadow',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_accordion_title_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_accordion_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#fff',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-title, body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-title a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_accordion_title_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-title',
		    ]
	    );

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Content)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_img_accordion_content',
		    [
			    'label' => esc_html__('Content', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'visible_content',
		    [
			    'label'     => __('Visible by Default', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

        $this->add_control(
            'crust_accordion_content_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-img-accordion .overlay .crust-img-accordtion-content' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_accordion_content_typography',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_accordion_content_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_accordion_content_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_accordion_content_border',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content',
		    ]
	    );

	    $this->add_control(
		    'crust_accordion_content_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_accordion_content_shadow',
			    'selector' => '{{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_accordion_content_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_accordion_content_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#fff',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-img-accordion .overlay .crust-img-accordtion-content' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_accordion_content_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-img-accordion .crust-img-accordion-overlay .crust-img-accordion-content',
		    ]
	    );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $tag = $settings['crust_img_accordion_title_tag'];
	    $dir = ( $settings['crust_img_accordion_dir'] === 'vertical') ? 'crust-vertical-acc' : '';
	    $vis_title = ( $settings['visible_title'] ) ? ' crust-acc-visible-title' : '';
	    $vis_content = ( $settings['visible_content'] ) ? ' crust-acc-visible-content' : '';
        $this->add_render_attribute('crust-image-accordion', 'class', [
            'crust-img-accordion hover-accordion',
	        $vis_title,
	        $vis_content,
	        $dir
        ]);
        $this->add_render_attribute('crust-image-accordion', 'data-img-accordion-id', esc_attr($this->get_id()));

        if ( ! empty($settings['crust_img_accordions'])) {
            $html = '<div ' . $this->get_render_attribute_string('crust-image-accordion') . ' id="crust-img-accordion-' . $this->get_id() . '">';
                foreach ($settings['crust_img_accordions'] as $img_accordion) {
                    $link     = $img_accordion['crust_accordion_title_link']['url'];
                    $target   = $img_accordion['crust_accordion_title_link']['is_external'] ? 'target="_blank"' : '';
                    $nofollow = $img_accordion['crust_accordion_title_link']['nofollow'] ? 'rel="nofollow"' : '';

                        $html .= '<div class="crust-img-accordion-overlay" style="background-image: url(' . esc_url($img_accordion['crust_accordion_bg']['url']) . ');">';
                            $html .= '<div class="crust-img-accordion-overlay-inner">';
                                $html .= '<'.$tag.' class="crust-img-accordion-title">';
                                    $html .= '<a href="' . esc_url($link) . '" ' . $target . ' ' . $nofollow . '>';
                                        $html .= $img_accordion['crust_accordion_tittle'];
                                    $html .= '</a>';
                                $html .= '</'.$tag.'>';
				                if ('content' == $img_accordion['crust_accordion_text_type']) {
					                $html .= '<div class="crust-img-accordion-content">' . $img_accordion['crust_accordion_content'] . '</div>';
				                } elseif ('template' == $img_accordion['crust_accordion_text_type']) {
					                if ( ! empty($img_accordion['crust_core_primary_templates'])) {
						                $crust_core_template_id = $img_accordion['crust_core_primary_templates'];
						                $crust_core_frontend    = new Frontend;
						                $html .= '<div class="crust-img-accordion-content">' . $crust_core_frontend->get_builder_content($crust_core_template_id, true) . '</div>';
					                }
				                }
                            $html .= '</div>';
                        $html .= '</div>';
                }
            $html .= '</div>';

            echo $html;

        }
    }

}
