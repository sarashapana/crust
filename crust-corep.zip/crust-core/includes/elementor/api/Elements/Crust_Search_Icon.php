<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;

class Crust_Search_Icon extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-search-icon';
    }

    public function get_title()
    {
        return esc_html__('Header Search Icon', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-search';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_section_search_content_settings',
			[
				'label' => esc_html__('General', 'crust-core')
			]
		);

		$this->add_control(
			'search_style',
			[
				'label'   => esc_html__('Style', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'icon'  => esc_html__('Icon', 'crust-core'),
					'form'  => esc_html__('Form', 'crust-core'),
				],
				'default' => 'icon'
			]
		);

		$this->add_control(
			'crust_search_content',
			[
				'label'        => esc_html__('You need to customize the header search style from Theme Options.', 'crust-core'),
				'type'         => Controls_Manager::HEADING,
			]
		);

		$this->end_controls_section();

	}

    protected function render()
    {

		$settings = $this->get_settings_for_display();

	    if( $settings['search_style'] === 'form' ){

		    $args = [
			    'show_option_all'  => __( 'Any Category' ),
			    'name'             => 'crust-cat-limiter',
			    'echo'             => 0,
			    'taxonomy'         => 'product_cat'
		    ];

		    echo '<form role="search" method="get" class="crust-search-form" action="'. home_url( '/' ) .'">';
			    echo '<div class="crust-srch-box"><input type="search" class="crust-search-field" placeholder="'. esc_attr__('search product ...', 'crust-core') .'" value="'. esc_attr( get_search_query() ) .'" name="s" /></div>';
			    echo '<div class="crust-search-dropdown">' . wp_dropdown_categories( $args ) . '</div>';
			    echo '<div class="crust-search-btn"><button type="submit" class="primary-bg crust-search-submit"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.75 24.75"><path d="M24.54,23.49l-6-6a10.55,10.55,0,1,0-1,1l6,6a.78.78,0,0,0,.52.21.74.74,0,0,0,.53-.21A.76.76,0,0,0,24.54,23.49Zm-23-12.92a9.07,9.07,0,1,1,9.07,9.07A9.08,9.08,0,0,1,1.49,10.57Z"/></svg></button></div>';
		    echo '</form>';

		    wp_enqueue_script( 'select2',  CRUST_CORE_URI . '/assets/js/vendor/select2.min.js', ['jquery'], null, true);
		    wp_enqueue_style('select2',   CRUST_CORE_URI . '/assets/css/vendor/select2.min.css', ['crust-frontend'], null);


	    } else {
		    do_action('crust_site_header_search');
	    }


    }

}
