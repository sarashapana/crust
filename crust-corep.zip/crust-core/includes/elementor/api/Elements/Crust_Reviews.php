<?php
namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Reviews extends Widget_Base {

	use \Crust_Core\Traits\Helper;

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-reviews', false, true);
		return ['crust-reviews'];
	}

	public function get_name() {
		return 'crust-review-slider';
	}

	public function get_title() {
		return esc_html__( 'Reviews', 'crust-core' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	public function get_categories() {
		return [ 'crust' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_review_content',
			[
				'label' => esc_html__( 'Content', 'crust-core' )
			]
		);

		$this->add_control(
			'is_slider',
			[
				'label'         => esc_html__('Enable Slider', 'crust-core'),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => esc_html__( 'YES', 'crust-core' ),
				'label_off'     => esc_html__( 'NO', 'crust-core' ),
				'return_value'  => 'carousel',
				'default'       => 'carousel'
			]
		);

		$this->add_control(
			'display',
			[
				'label'       => esc_html__('Layout', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'grid',
				'label_block' => false,
				'options'     => [
					'grid' => esc_html__('Grid', 'crust-core'),
					'masonry' => esc_html__('Masonry', 'crust-core'),
				],
				'condition' => [
					'is_slider' => ''
				]
			]
		);

		$this->add_control(
			'columns',
			[
				'label'       => esc_html__('Columns', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => '3',
				'label_block' => false,
				'options'     => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'condition' => [
					'is_slider' => ''
				]
			]
		);

		$this->add_control(
			'review_style',
			[
				'label'		=> __( 'Style', 'crust-core' ),
				'type'		=> Controls_Manager::SELECT,
				'default'	=> 'default-style',
				'options'	=> [
					'default-style'						=> __( 'Default', 'crust-core' ),
					'classic-style'						=> __( 'Classic', 'crust-core' ),
					'icon-img-top-content'				=> __( 'Top Image | Content', 'crust-core' ),
					'icon-img-left-content'				=> __( 'Left Image | Content', 'crust-core' ),
					'content-top-icon-title-inline'		=> __( 'Content Top | Image Title Inline', 'crust-core' ),
					'content-bottom-icon-title-inline'	=> __( 'Content Bottom | Image Title Inline', 'crust-core' )
				]
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'enable_avatar', [
				'label' => esc_html__( 'Display Avatar?', 'crust-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Avatar', 'crust-core' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'enable_avatar' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'crust-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'John Doe', 'crust-core' ),
				'dynamic' => [ 'active' => true ]
			]
		);

		$repeater->add_control(
			'company_title', [
				'label' => esc_html__( 'Company', 'crust-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'envato.com', 'crust-core' ),
				'dynamic' => [ 'active' => true ]
			]
		);

		$repeater->add_control(
			'review_desc', [
				'label' => esc_html__( 'Description', 'crust-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ipsum suspendisse ultrices.', 'crust-core' ),
			]
		);

		$repeater->add_control(
			'review_enable_rating', [
				'label' => esc_html__( 'Display Rating?', 'crust-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'review_rating_number', [
				'label'       => __( 'Rating Number', 'crust-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'rating-five',
				'options' => [
					'rating-one'    => __( '1', 'crust-core' ),
					'rating-two'    => __( '2', 'crust-core' ),
					'rating-three'  => __( '3', 'crust-core' ),
					'rating-four'   => __( '4', 'crust-core' ),
					'rating-five'   => __( '5', 'crust-core' ),
				],
				'condition' => [
					'review_enable_rating' => 'yes',
				],
			]
		);

		$this->add_control(
			'review_block',
			[
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'name' => 'Ralph Fox',
					],
					[
						'name' => 'Gary Hunt',
					],
					[
						'name' => 'Maverick Sosa',
					],

				],
				'fields' => $repeater->get_controls(),
				'title_field' => 'Review Item',
			]
		);

		$this->end_controls_section();

		$this->crust_core_slider_settings('is_slider');

		$this->start_controls_section(
			'crust_section_wrapper_style',
			[
				'label' => __('Wrapper', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'crust_review_wraper_margin',
			[
				'label'      => esc_html__('Margin', 'crust-core'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-carousel-wrapper .crust-carousel' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_review_wraper_padding',
			[
				'label'      => esc_html__('Padding', 'crust-core'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-carousel-wrapper .crust-carousel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_block_style',
			[
				'label' => esc_html__( 'Block Styles', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'review_align',
			[
				'label' => esc_html__( 'Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'' => [
						'title' => esc_html__( 'Left', 'crust-core' ),
						'icon' => 'eicon-h-align-left',
					],
					'crust-review-center' => [
						'title' => esc_html__( 'Center', 'crust-core' ),
						'icon' => 'eicon-h-align-center',
					],
					'crust-review-right' => [
						'title' => esc_html__( 'Right', 'crust-core' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => 'crust-review-center'
			]
		);

		$this->add_control(
			'user_display_block',
			[
				'label' => esc_html__( 'Block User & Company?', 'crust-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'background',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-review-item .crust-inner-review',
			]
		);

		$this->add_responsive_control(
			'margin',
			[
				'label' => esc_html__( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-item .crust-inner-review' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-item .crust-inner-review' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => '{{WRAPPER}} .crust-review-item .crust-inner-review',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item .crust-inner-review' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow:: get_type(),
			[
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .crust-review-item .crust-inner-review',
			]
		);
		/**
		 * -------------------------------------------
		 * Reviews block Style dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'background_dark',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-review-item .crust-inner-review',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_dark',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-review-item .crust-inner-review',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_active_style',
			[
				'label' => esc_html__( 'Active Item Style', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'active_background',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review',
			]
		);

		$this->add_responsive_control(
			'active_margin',
			[
				'label' => esc_html__( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'active_padding',
			[
				'label' => esc_html__( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'active_border',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => '{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review',
			]
		);

		$this->add_control(
			'active_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow:: get_type(),
			[
				'name'     => 'active_box_shadow',
				'selector' => '{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review',
			]
		);
		/**
		 * -------------------------------------------
		 * Active Item Style dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_active_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'active_background_dark',
				'types'     => ['classic', 'gradient'],

				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'active_border_dark',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-inner-review',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_image_styles',
			[
				'label' => esc_html__( 'Avatar Style', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'image_max_width',
			[
				'label' => esc_html__( 'Max Width', 'crust-core' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 55,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-image' => 'max-width:{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .icon-img-left-content .crust-review-image' => 'flex-basis: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .icon-img-left-content .crust-review-right-content' => 'flex-basis: calc( 100% - {{SIZE}}{{UNIT}});'
				],
			]
		);

		$this->add_responsive_control(
			'image_margin',
			[
				'label' => esc_html__( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_padding',
			[
				'label' => esc_html__( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-image img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => '{{WRAPPER}} .crust-review-image img',
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor' ),
				'size_units' => [ 'px', '%' ],
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .crust-review-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow:: get_type(),
			[
				'name'     => 'image_shadow',
				'selector' => '{{WRAPPER}} .crust-review-image img',
			]
		);
		/**
		 * -------------------------------------------
		 * Avatar Style dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_image_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_border_dark',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-review-image img',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_name',
			[
				'label' => esc_html__( 'Name', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'section_review_name_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'h6',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-content .crust-review-user' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_name_color',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-content .crust-review-user' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-content .crust-review-user' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'selector' => '{{WRAPPER}} .crust-review-content .crust-review-user',
			]
		);

		$this->add_responsive_control(
			'name_margin',
			[
				'label'      => esc_html__('Margin', 'crust-core'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-review-content .crust-review-user' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		/**
		 * -------------------------------------------
		 * Name Tag Style Dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_name_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'name_color_dark',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-content .crust-review-user' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_name_color_dark',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-content .crust-review-user' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_bg_color_dark',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-content .crust-review-user' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_company_style',
			[
				'label' => esc_html__( 'Company', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'section_review_company_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'p',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'company_color',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-position' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_company_color',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-position' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'company_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-position' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'company_typography',
				'selector' => '{{WRAPPER}} .crust-review-position',
			]
		);
		/**
		 * -------------------------------------------
		 * Company Tag Style Dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_company_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'company_color_dark',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-position' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_company_color_dark',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-position' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'company_bg_color_dark',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-position' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_content_style',
			[
				'label' => esc_html__( 'Content Style', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-content .crust-review-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_text_color',
			[
				'label' => esc_html__( 'Active Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-content .crust-review-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .crust-review-content .crust-review-text',
			]
		);

		$this->add_responsive_control(
			'content_margin',
			[
				'label' => esc_html__( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label' => esc_html__( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-text' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'content_border',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => '{{WRAPPER}} .crust-review-text',
			]
		);

		$this->add_control(
			'content_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .crust-review-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow:: get_type(),
			[
				'name'     => 'content_box_shadow',
				'selector' => '{{WRAPPER}} .crust-review-text',
			]
		);
		/**
		 * -------------------------------------------
		 * Content Tag Style Dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_content_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'text_color_dark',
			[
				'label' => esc_html__( 'Text Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-content .crust-review-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_text_color_dark',
			[
				'label' => esc_html__( 'Active Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-content .crust-review-text' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'content_bg_color_dark',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-text' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'content_border_dark',
				'label' => esc_html__( 'Border', 'crust-core' ),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-review-text',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_review_style',
			[
				'label' => esc_html__( 'Rating Style', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'review_color',
			[
				'label' => esc_html__( 'Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-stars.rating-five i,
					{{WRAPPER}} .crust-stars.rating-four i:not(:nth-child(5)),
					{{WRAPPER}} .crust-stars.rating-three i:nth-child(1),
					{{WRAPPER}} .crust-stars.rating-three i:nth-child(2),
					{{WRAPPER}} .crust-stars.rating-three i:nth-child(3),
					{{WRAPPER}} .crust-stars.rating-two i:nth-child(1),
					{{WRAPPER}} .crust-stars.rating-two i:nth-child(2),
					{{WRAPPER}} .crust-stars.rating-one i:nth-child(1)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'review_active_color',
			[
				'label' => esc_html__( 'Active Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-five i,
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-four i:not(:nth-child(5)),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(1),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(2),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(3),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-two i:nth-child(1),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-two i:nth-child(2),
					{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-one i:nth-child(1)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'review_size',
			[
				'label'     => esc_html__('Size (PX)', 'crust-core'),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .crust-stars i' => 'font-size: {{VALUE}}px;',
				],
			]
		);

		$this->add_control(
			'review_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-stars' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'review_active_bg_color',
			[
				'label' => esc_html__( 'Active Background Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'review_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-stars' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'review_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-stars' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		/**
		 * -------------------------------------------
		 * Review Tag Style Dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_review_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'review_color_dark',
			[
				'label' => esc_html__( 'Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-stars.rating-five i,
					body.crust-dark {{WRAPPER}} .crust-stars.rating-four i:not(:nth-child(5)),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-three i:nth-child(1),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-three i:nth-child(2),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-three i:nth-child(3),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-two i:nth-child(1),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-two i:nth-child(2),
					body.crust-dark {{WRAPPER}} .crust-stars.rating-one i:nth-child(1)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'review_active_color_dark',
			[
				'label' => esc_html__( 'Active Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-five i,
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-four i:not(:nth-child(5)),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(1),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(2),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-three i:nth-child(3),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-two i:nth-child(1),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-two i:nth-child(2),
					body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars.rating-one i:nth-child(1)' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'review_bg_color_dark',
			[
				'label' => esc_html__( 'Background Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-stars' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'review_active_bg_color_dark',
			[
				'label' => esc_html__( 'Active Background Color', 'crust-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-stars' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_review_quotation_style',
			[
				'label' => esc_html__( 'Quotation', 'crust-core' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'quote_width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-review-quote'   => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'quote_height',
			[
				'label'      => esc_html__('Height', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-review-quote'   => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'quote_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'review_quote_icon',
			[
				'label'     => esc_html__('Icon', 'elementor'),
				'type'      => Controls_Manager::ICONS,
				'default'          => [
					'value'   => 'fad fa-quote-right',
					'library' => 'fontawesome',
				],
			]
		);

		$this->add_control(
			'quotation_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'quotation_color',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.15)',
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_quotation_color',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-quote' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'quotation_opacity',
			[
				'label'     => esc_html__('Opacity', 'crust-core'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => .01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_responsive_control(
			'quotation_svg_size',
			[
				'label' => esc_html__( 'SVG Size', 'crust-core' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 50,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote img' => 'width: {{SIZE}}{{UNIT}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'quotation_typography',
				'selector' => '{{WRAPPER}} .crust-review-quote',
			]
		);

		$this->add_responsive_control(
			'quotation_rotate',
			[
				'label' => __( 'Rotate', 'crust-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -360,
						'max' => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'transform: rotate({{SIZE}}deg)',
				],
			]
		);

		$start = is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );
		$end = ! is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );

		$this->add_control(
			'quotation_offset_orientation_h',
			[
				'label' => __( 'Horizontal Orientation', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'options' => [
					'start' => [
						'title' => $start,
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => $end,
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'elementor-control-start-end',
				'render_type' => 'ui',
			]
		);

		$this->add_responsive_control(
			'quotation_offset_x',
			[
				'label' => __( 'Offset', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .crust-review-quote' => 'right:auto;left: {{SIZE}}{{UNIT}}',
					'body.rtl {{WRAPPER}} .crust-review-quote' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'quotation_offset_orientation_h!' => 'end',
				],
			]
		);

		$this->add_responsive_control(
			'quotation_offset_x_end',
			[
				'label' => __( 'Offset', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .crust-review-quote' => 'left:auto;right: {{SIZE}}{{UNIT}}',
					'body.rtl {{WRAPPER}} .crust-review-quote' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'quotation_offset_orientation_h' => 'end',
				],
			]
		);

		$this->add_control(
			'quotation_offset_orientation_v',
			[
				'label' => __( 'Vertical Orientation', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'options' => [
					'start' => [
						'title' => __( 'Top', 'elementor' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => __( 'Bottom', 'elementor' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
			]
		);

		$this->add_responsive_control(
			'quotation_offset_y',
			[
				'label' => __( 'Offset', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'quotation_offset_orientation_v!' => 'end',
				],
			]
		);

		$this->add_responsive_control(
			'quotation_offset_y_end',
			[
				'label' => __( 'Offset', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .crust-review-quote' => 'top:auto;bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'quotation_offset_orientation_v' => 'end',
				],
			]
		);
		/**
		 * -------------------------------------------
		 * Quotation Tag Style Dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'crust_review_quotation_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'quotation_bg_color_dark',
			[
				'label' => esc_html__( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-quote' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'quotation_color_dark',
			[
				'label' => esc_html__( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.15)',
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-quote' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_quotation_color_dark',
			[
				'label' => esc_html__( 'Active Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-review-item.swiper-slide-active .crust-review-quote' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		$this->crust_core_slider_styling('is_slider');

	}

	protected function _render_user_meta( $item ) {
		$settings = $this->get_settings_for_display();
		$name_tag = $settings['section_review_name_tag'];
		$copm_tag = $settings['section_review_company_tag'];
		$blk = ( $settings['user_display_block'] === 'yes' ) ? ' crust-block-user' : '';
		$html  = '<div class="crust-testimonial-meta">';
		$html .= '<'.$name_tag.' class="crust-review-user'.$blk.'"">'.esc_html( $item['name'] ).'</'.$name_tag.'>';
		$html .= '<'.$copm_tag.' class="crust-review-position">'.esc_html( $item['company_title'] ).'</'.$copm_tag.'>';
		$html .= '</div>';
		return $html;
	}

	protected function _render_avatar( $item ) {
		if ( $item['enable_avatar'] != 'yes' ) return;
		$settings = $this->get_settings();
		$html = '<div class="crust-review-image">';
		$html .= '<img src="'.esc_url($item['image']['url']).'" alt="'.esc_attr(get_post_meta($item['image']['id'], '_wp_attachment_image_alt', true)).'">';
		$html .= '</div>';
		return $html;
	}

	protected function _render_user_review( $item ) {
		if ( empty($item['review_enable_rating'] ) ) return;
		$html = '<span class="crust-stars '.$item['review_rating_number'].'">';
		$html .= '<i class="fad fa-star"></i>';
		$html .= '<i class="fad fa-star"></i>';
		$html .= '<i class="fad fa-star"></i>';
		$html .= '<i class="fad fa-star"></i>';
		$html .= '<i class="fad fa-star"></i>';
		$html .= '</span>';
		return $html;
	}

	protected function _render_review_content( $item ) {
		return '<div class="crust-review-text">'.wpautop($item["review_desc"]).'</div>';
	}

	protected function _render_quote() {
		$settings = $this->get_settings_for_display();
		$html = '<span class="crust-review-quote">';
		if (isset($settings['review_quote_icon']['value']['url'])) {
			$html .= '<img src="'. esc_attr($settings['review_quote_icon']['value']['url']) .'" alt="'.esc_attr(get_post_meta($settings['review_quote_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
		} else {
			$html .= '<i class="'. esc_attr( $settings['review_quote_icon']['value'] ) .'"></i>';
		}
		$html .= '</span>';
		return $html;
	}

	protected function render()
	{
		$settings       = $this->get_settings_for_display();
		$is_slider      = ( $settings['is_slider'] === 'carousel' );
		$style          = $settings['review_style'];
		$display        = $settings['display'];
		$columns        = $settings['columns'];
		$block_class    = 'crust-review-item';
		$block_class   .= ( $is_slider ) ? ' swiper-slide' : '';
		$block_class   .= " " . $settings['review_align'];

		$wrap_class    = ( !$is_slider ) ? 'crust-review-' . $display : '';
		$wrap_class   .= ( !$is_slider && $columns ) ? ' crust-review-columns-' . $columns : '';
		$wrap_class   .= ( $is_slider ) ? ' swiper-container crust-carousel' : '';

		if( !$is_slider && 'masonry' === $display ){
			wp_enqueue_script('masonry');
		}

		$this->add_render_attribute('crust_reviews', [
			'class' => [
				$wrap_class,
				$style,
			]
		]);

		$this->add_render_attribute('review_content_wrap', [
			'class' => ['crust-review-content'],
		]);

		if( $is_slider ){
			$this->crust_core_slider_attributes('crust_reviews');
		}

		$this->add_render_attribute('review_slide', [
			'class' => [$block_class]
		]);

		$html = '';

		$html .=  ( $is_slider ) ? '<div class="crust-carousel-wrapper">': '';
		$html .= '<div '.$this->get_render_attribute_string( 'crust_reviews' ).'>';

		$html .= ( $is_slider ) ? '<div class="swiper-wrapper">' : '';

		foreach ( $settings['review_block'] as $item ) {

			$html .= '<div '. $this->get_render_attribute_string('review_slide') .'>';
			$html .= '<div '. $this->get_render_attribute_string('review_content_wrap').'>';
			$html .= '<div class="crust-inner-review">';

			if('classic-style' == $style) {
				$html .= $this->_render_quote();
				$html .= '<div class="review-classic-content">';
				$html .= $this->_render_review_content( $item );
				$html .= $this->_render_user_review( $item );
				$html .= $this->_render_user_meta( $item );
				$html .= '</div>';
				$html .= $this->_render_avatar($item);
			}

			if('icon-img-left-content' == $style) {
				$html .= $this->_render_avatar($item);
				$html .= '<div class="crust-review-right-content">';
				$html .= $this->_render_quote();
				$html .= $this->_render_review_content( $item );
				$html .= $this->_render_user_review( $item );
				$html .= $this->_render_user_meta( $item );
				$html .= '</div>';
			}

			if('icon-img-top-content' == $style) {
				$html .= $this->_render_avatar($item);
				$html .= '<div class="crust-testimonial-bottom-content">';
				$html .= $this->_render_quote();
				$html .= $this->_render_review_content( $item );
				$html .= $this->_render_user_review( $item );
				$html .= $this->_render_user_meta( $item );
				$html .= '</div>';
			}

			if('content-top-icon-title-inline' == $style) {
				$html .= $this->_render_quote();
				$html .= $this->_render_review_content( $item );
				$html .= '<div class="review-inline-style">';
				$html .= $this->_render_avatar($item);
				$html .= $this->_render_user_meta( $item );
				$html .= $this->_render_user_review( $item );
				$html .= '</div>';
			}

			if('content-bottom-icon-title-inline' == $style) {
				$html .= '<div class="review-inline-wrapper">';
				$html .= '<div class="review-inline-style">';
				$html .= $this->_render_avatar($item);
				$html .= $this->_render_user_meta( $item );
				$html .= '</div>';
				$html .= $this->_render_user_review( $item );
				$html .= '</div>';
				$html .= $this->_render_quote();
				$html .= $this->_render_review_content( $item );
			}

			// Default Style
			if('default-style' == $style) {

				$html .= '<div class="review-classic-content">';
				$html .= $this->_render_review_content( $item );
				$html .= '</div>';
				$html .= $this->_render_avatar($item);
				$html .= $this->_render_quote();
				$html .= $this->_render_user_review( $item );
				$html .= $this->_render_user_meta( $item );
			}

			$html .= '</div>';
			$html .= '</div>';
			$html .= '</div>';

		}

		$html .= ( $is_slider ) ? '</div>' : '';

		$html .= '</div>';

		//$html .= ( $is_slider ) ? $this->crust_carousel_nav() : '';
		$html .= ( $is_slider ) ? apply_filters('crust_carousel_nav_site',$settings) : '';

		$show_thumbs = $settings['show_thumbs'];
		if( $show_thumbs ){
			$html .= '<div class="swiper-container crust-gallery-thumbs" data-idm="'.$idd.'">';
			$html .= '<div class="swiper-wrapper">';
			$items = $settings['thumbs'];
			foreach ( $items as $item ) {
				$src = $item['thumb']['url'];
				$html .= '<div class="swiper-slide" style="background-image: url('.esc_url($src).')"></div>';
			}
			$html .= '</div>';
			$html .= '</div>';
		}

		$html .=  ( $is_slider ) ? '</div>' : '';

		echo $html;

	}

}
