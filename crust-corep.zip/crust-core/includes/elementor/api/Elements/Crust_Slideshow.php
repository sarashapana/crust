<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Slideshow extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-slideshow';
    }

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-slideshow', false, true);
		return ['crust-slideshow'];
	}

    public function get_title()
    {
        return esc_html__('Crust Slideshow', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

	    /**
	     * Content Settings
	     */
	    $this->start_controls_section(
		    'crust_slideshow_content_settings',
		    [
			    'label' => esc_html__('Content Settings', 'crust-core')
		    ]
	    );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'image',
		    [
			    'label'     => esc_html__('Image', 'crust-core'),
			    'type'      => Controls_Manager::MEDIA,
		    ]
	    );

	    $repeater->add_group_control(
		    Group_Control_Image_Size::get_type(),
		    [
			    'name'      => 'thumbnail',
			    'default'   => 'full',
			    'condition' => [
				    'image[url]!' => '',
			    ]
		    ]
	    );

	    $repeater->add_control(
		    'badge', [
			    'label'   => esc_html__('Badge', 'crust-core'),
			    'type'    => Controls_Manager::TEXT,
			    'label_block' => true,
		    ]
	    );

	    $repeater->add_control(
		    'title_1', [
			    'label'   => esc_html__('Title', 'crust-core'),
			    'type'    => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default' => esc_html__('Tab Title', 'crust-core'),
		    ]
	    );

	    $repeater->add_control(
		    'slideshow_content_type', [
			    'label'   => esc_html__('Description Type', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    'content'  => esc_html__('Content', 'crust-core'),
				    'template' => esc_html__('Saved Templates', 'crust-core'),
			    ],
			    'default' => 'content',
		    ]
	    );

	    $repeater->add_control(
		    'slideshow_templates', [
			    'label'     => esc_html__('Choose Template', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => $this->crust_core_get_page_templates(),
			    'condition' => [
				    'slideshow_content_type' => 'template',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'description', [
			    'label'     => esc_html__('Content', 'crust-core'),
			    'type'      => Controls_Manager::WYSIWYG,
			    'default'   => esc_html__(
				    'Create the difference and let your clients love your work.',
				    'crust-core'
			    ),
			    'dynamic'   => ['active' => true],
			    'condition' => [
				    'slideshow_content_type' => 'content',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'button', [
			    'label'   => esc_html__('Button', 'crust-core'),
			    'type'    => Controls_Manager::TEXT,
			    'label_block' => true,
			    'dynamic' => ['active' => true],
		    ]
	    );

	    $repeater->add_control(
		    'link_url',
		    [
			    'label'         => esc_html__('Link', 'elementor'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'default'       => [
				    'url'         => '#',
				    'is_external' => '',
			    ],
			    'show_external' => true,
		    ]
	    );

	    $this->add_control(
		    'items',
		    [
			    'type'        => Controls_Manager::REPEATER,
			    'seperator'   => 'before',
			    'default'     => [
				    [
				    	'badge' => 'Unlimited layouts',
					    'title_1' => 'Passion and people are what move the world',
					    'description' => 'Create the difference and let your clients love your work.',
				    ],
				    [
					    'badge' => 'Unlimited layouts',
					    'title_1' => 'The Ultimate theme for Digital Inspiration',
					    'description' => 'Create the difference and let your clients love your work.',
				    ],
				    [
					    'badge' => 'Unlimited layouts',
					    'title_1'=> 'Exceptional products crafted for you.',
					    'description'=> 'Create the difference and let your clients love your work.',
				    ]
			    ],
			    'fields'      => $repeater->get_controls(),
			    'title_field' => '{{title_1}}',
		    ]
	    );

	    $this->add_control(
		    'slideshow_type',
		    [
			    'label'       => esc_html__('Effect', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    'arrows' => esc_html__('Style 1', 'crust-core'),
				    'curve' => esc_html__('Style 2', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'height',
		    [
			    'label'       => esc_html__('Height', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    'full_height' => esc_html__('Fit to screen', 'crust-core'),
				    'min_height' => esc_html__('Min Height', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'min_height',
		    [
			    'label'      => esc_html__('Min. Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min' => 1,
				    	'max' => 2000
				    ],
				    '%' => [
					    'min' => 1,
					    'max' => 100
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-slideshow' => 'min-height: {{SIZE}}{{UNIT}};',
			    ],
			    'condition' => [
				    'height' => 'min_height'
			    ]
		    ]
	    );

	    $this->add_control(
		    'fraction',
		    [
			    'label'     => __('Show Fraction', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
			    'default'   => 'yes'
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_slideshow_wrapper_style',
		    [
			    'label' => __('Wrapper', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_wraper_padding',
		    [
			    'label'      => esc_html__('Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-slideshow .crust-sls-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_badge_style',
		    [
			    'label' => esc_html__('Badge', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'badge_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    ''       => esc_html__('Default', 'crust-core'),
				    'main' => esc_html__('Primary Badge', 'crust-core'),
				    'alt' => esc_html__('Secondary Badge', 'crust-core'),
				    'gradient' => esc_html__('Gradient Badge', 'crust-core'),
				    'light' => esc_html__('Light Badge', 'crust-core'),
				    'minimal' => esc_html__('Minimal Badge', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'badge_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'span',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_badge_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-badge, {{WRAPPER}} .crust-badge a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_head_first_title_typography',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_badge_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

        $this->add_responsive_control(
            'crust_badge_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_badge_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_badge_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_badge_border',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_control(
		    'crust_badge_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_badge_shadow',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_badge_dark_style',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_badge_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-badge, {{WRAPPER}} .crust-badge a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_badge_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_badge_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-badge',
		    ]
	    );
        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Heading Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_head_style_settings',
		    [
			    'label' => esc_html__('Title', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_control(
		    'head_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h2',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_slideshow_title_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-heading' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_slideshow_title_typography',
			    'selector' => '{{WRAPPER}} .crust-heading, {{WRAPPER}} .crust-heading span',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_head_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_head_max_width',
		    [
			    'label' => esc_html__( 'Max. Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 2000,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-sls-title .crust-heading' => 'max-width: {{SIZE}}{{UNIT}};'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_head_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_head_style_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_slideshow_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-heading' => 'color: {{VALUE}};',
			    ],
		    ]
	    );




	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Description Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_description',
		    [
			    'label' => esc_html__('Description', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_control(
		    'description_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'div',
			    'label_block' => false,
			    'options'     => [
				    'p' => esc_html__('p', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'address' => esc_html__('address', 'crust-core'),
			    ],
		    ]
	    );


	    $this->add_control(
		    'crust_slideshow_description_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_slideshow_description_typography',
			    'selector' => '{{WRAPPER}} .crust-text',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_description_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-text',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_description_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_slideshow_dark_description',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_slideshow_description_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );



	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Button Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_btn_settings',
		    [
			    'label' => esc_html__('Button', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_control(
		    'btn_size',
		    [
			    'label' => __( 'Size', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => 'md',
			    'options' => [
				    'xs' => esc_html__('Extra Small', 'crust-core'),
				    'sm' => esc_html__('Small', 'crust-core'),
				    'md' => esc_html__('Medium', 'crust-core'),
				    'lg' => esc_html__('Large', 'crust-core'),
				    'xl' => esc_html__('Extra Large', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'hover_style',
		    [
			    'label'   => esc_html__('Hover Style', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
				    'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
				    'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
				    'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
				    'btn-greip'     => esc_html__('Greip', 'crust-core'),
				    'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_slideshow_btn_typography',
			    'selector' => '{{WRAPPER}} .crust-btn'
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_btn_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_btn_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_slideshow_button_tabs');

	    $this->start_controls_tab('slideshow_btn_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_control(
		    'slideshow_btn_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn' => 'color: {{VALUE}};',
			    ],
			    'default'   => '#fff'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'slideshow_btn_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [
					    'default' => 'classic'
				    ],
				    'color' => [
					    'default' => '#19D0D6'
				    ],
			    ],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia), {{WRAPPER}} .crust-btn.btn-hyperion:before, {{WRAPPER}} .crust-btn.btn-anthe::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'slideshow_btn_border',
			    'selector' => '{{WRAPPER}} .crust-btn',
		    ]
	    );

	    $this->add_responsive_control(
		    'slideshow_btn_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'slideshow_btn_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-btn',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('slideshow_btn_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'slideshow_btn_hover_top',
		    [
			    'label'      => esc_html__('Margin Top', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'max' => 100,
					    'min' => -100,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-btn:hover' => 'transform: translateY({{SIZE}}{{UNIT}});-webkit-transform: translateY({{SIZE}}{{UNIT}});',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_btn_hover_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn:hover,{{WRAPPER}} .btn-winona::after,{{WRAPPER}} .crust-btn:hover > span,{{WRAPPER}} .crust-btn.btn-nina:hover u:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'slideshow_btn_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.styled-btn):hover, 
					{{WRAPPER}} .crust-btn.btn-hyperion,{{WRAPPER}} .crust-btn::before,{{WRAPPER}} .crust-btn::after,{{WRAPPER}} .crust-btn.btn-anthe:hover::before,
					{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'slideshow_btn_border_hover',
			    'selector' => '{{WRAPPER}} .crust-btn:hover',
		    ]
	    );

	    $this->add_responsive_control(
		    'slideshow_btn_border_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'slideshow_btn_box_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-btn:hover',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->add_control(
		    'slideshow_btn_hover_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn:hover,{{WRAPPER}} .btn-winona::after,body.crust-dark {{WRAPPER}} .crust-btn:hover > span,body.crust-dark {{WRAPPER}} .crust-btn.btn-nina:hover u:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'slideshow_btn_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.styled-btn):hover, 
					body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion,body.crust-dark {{WRAPPER}} .crust-btn::before,body.crust-dark {{WRAPPER}} .crust-btn::after,body.crust-dark {{WRAPPER}} .crust-btn.btn-anthe:hover::before,
					body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'slideshow_btn_border_dark_hover',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:hover',
		    ]
	    );
	    $this->end_controls_tabs();



	    $this->add_responsive_control(
		    'crust_slideshow_btn_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'slideshow_btn_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-btn' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'slideshow_btn_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [

				    ],
				    'color' => [

				    ],
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia), body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion:before,body.crust-dark  {{WRAPPER}} .crust-btn.btn-anthe::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Arrows Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_arrows_settings',
		    [
			    'label' => esc_html__('Arrows', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_responsive_control(
		    'arrow_bot_position',
		    [
			    'label'                 => __( 'Bottom Offset', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
				    '%' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'         => [
				    '{{WRAPPER}} .crust-sls-nav' => 'bottom: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'arrow_rit_position',
		    [
			    'label'                 => __( 'Right Offset', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
				    '%' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'         => [
				    '{{WRAPPER}} .crust-sls-nav' => 'right: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'next_icon',
		    [
			    'label'            => esc_html__('Next Arrow Icon', 'crust-core'),
			    'type'             => Controls_Manager::ICONS,
			    'default'          => [
				    'value'   => 'fa fa-angle-right',
				    'library' => 'fa-solid',
			    ],
		    ]
	    );

	    $this->add_control(
		    'prev_icon',
		    [
			    'label'            => esc_html__('Prev. Arrow Icon', 'crust-core'),
			    'type'             => Controls_Manager::ICONS,
			    'default'          => [
				    'value'   => 'fa fa-angle-left',
				    'library' => 'fa-solid',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'arrows_size',
		    [
			    'label'                 => __( 'Size', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'default'               => [ 'size' => '22' ],
			    'range'                 => [
				    'px' => [
					    'min'   => 15,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'font-size: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'arrows_width',
		    [
			    'label'                 => __( 'Width', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => 15,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'arrows_height',
		    [
			    'label'                 => __( 'Height', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => 15,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'arrow_margin',
		    [
			    'label'      => esc_html__('Margin', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs( 'slideshow_arrows_style' );

	    $this->start_controls_tab(
		    'slideshow_arrows_normal',
		    [
			    'label'                 => __( 'Normal', 'elementor' ),
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_bg_color',
		    [
			    'label'                 => __( 'Background Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_color',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'                  => 'slideshow_arrows_border',
			    'label'                 => __( 'Border', 'crust-core' ),
			    'selector'              => '{{WRAPPER}} .crust-sls-nav-button'
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_border_radius',
		    [
			    'label'                 => __( 'Border Radius', 'elementor' ),
			    'type'                  => Controls_Manager::DIMENSIONS,
			    'size_units'            => [ 'px', '%' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'slideshow_arrow_shadow',
			    'selector' => '{{WRAPPER}} .crust-sls-nav-button',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab(
		    'slideshow_arrows_hover',
		    [
			    'label' => __( 'Hover', 'elementor' ),
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_bg_color_hover',
		    [
			    'label'                 => __( 'Background Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button:hover' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_color_hover',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button:hover i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_border_color_hover',
		    [
			    'label'                 => __( 'Border Color', 'crust-core' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-button:hover' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'slideshow_arrow_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-sls-nav-button:hover',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->add_responsive_control(
		    'crust_slideshow_arrows_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'slideshow_arrows_bg_color_dark_hover',
		    [
			    'label'                 => __( 'Background Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-button:hover' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_color_dark_hover',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-button:hover i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_border_color_dark_hover',
		    [
			    'label'                 => __( 'Border Color', 'crust-core' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-button:hover' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tabs();

	    $this->add_responsive_control(
		    'crust_slideshow_arrows_dark_settings_head',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_bg_dark_color',
		    [
			    'label'                 => __( 'Background Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-button' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'slideshow_arrows_dark_color',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'default'               => '',
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-button i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'                  => 'slideshow_arrows_dark_border',
			    'label'                 => __( 'Border', 'crust-core' ),
			    'selector'              => 'body.crust-dark {{WRAPPER}} .crust-sls-nav-button'
		    ]
	    );

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Fraction Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_fraction',
		    [
			    'label' => esc_html__('Fraction', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_control(
		    'slideshow_fraction_color',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-nav-index' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_fraction_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-sls-nav-index' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_fraction_typography',
			    'selector' => '{{WRAPPER}} .crust-sls-nav-index',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_slideshow_dark_fraction',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'slideshow_fraction_dark_color',
		    [
			    'label'                 => __( 'Color', 'elementor' ),
			    'type'                  => Controls_Manager::COLOR,
			    'selectors'             => [
				    'body.crust-dark {{WRAPPER}} .crust-sls-nav-index' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style ( Overlay Style )
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_slideshow_overlay',
		    [
			    'label' => esc_html__('Overlay', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_slideshow_overlay_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-sls-img-wrap:before',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_overlay_opacity',
		    [
			    'label'                 => __( 'Opacity', 'crust-core' ),
			    'label'                 => __( 'Opacity', 'crust-core' ),
			    'type'                  => Controls_Manager::NUMBER,
			    'range'                 => [
				    'px' => [
					    'min'   => 0,
					    'max'   => 1,
					    'step'  => .01,
				    ],
			    ],
			    'size_units'            => [ 'px' ],
			    'selectors'         => [
				    '{{WRAPPER}} .crust-sls-img-wrap:before' => 'opacity: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_overlay_width',
		    [
			    'label'                 => __( 'Width', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => 15,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-img-wrap:before' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_overlay_height',
		    [
			    'label'                 => __( 'Height', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => 15,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'             => [
				    '{{WRAPPER}} .crust-sls-img-wrap:before' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_overlay_top_position',
		    [
			    'label'                 => __( 'Top Offset', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
				    '%' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'         => [
				    '{{WRAPPER}} .crust-sls-img-wrap:before' => 'top: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_overlay_left_position',
		    [
			    'label'                 => __( 'Left Offset', 'crust-core' ),
			    'type'                  => Controls_Manager::SLIDER,
			    'range'                 => [
				    'px' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
				    '%' => [
					    'min'   => -100,
					    'max'   => 100,
					    'step'  => 1,
				    ],
			    ],
			    'size_units'            => [ 'px', '%' ],
			    'selectors'         => [
				    '{{WRAPPER}} .crust-sls-img-wrap:before' => 'left: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_slideshow_dark_overlay',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_slideshow_overlay_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-sls-img-wrap:before',
		    ]
	    );

	    $this->end_controls_section();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();
	    $prev_icon = ( $settings['prev_icon']['value'] !== '' ) ? $settings['prev_icon']['value'] : 'fi-rr-arrow-left';
	    $next_icon = ( $settings['next_icon']['value'] !== '' ) ? $settings['next_icon']['value'] : 'fi-rr-arrow-right';

	    $desc_class  = 'crust-text crust-sls-txt';
	    $wrp_class = 'crust-slideshow-wrap crust-slideshow-' . $settings['slideshow_type'];

	    $output = '<div class="'.$wrp_class.'">';
		    $output .= '<nav class="crust-sls-nav">';
			    $output .= '<button class="crust-sls-nav-button crust-sls-nav-button-prev"><i class="'.$prev_icon.'"></i></button>';
			    $output .= '<button class="crust-sls-nav-button crust-sls-nav-button-next"><i class="'.$next_icon.'"></i></button>';
			    if( $settings['fraction'] ){
				    $output .= '<div class="crust-sls-nav-index">';
					    $output .= '<span class="crust-sls-nav-index-current">';
					        $output .= '<span>1</span>';
					    $output .= '</span>';
					    $output .= '-';
					    $output .= '<span class="crust-sls-nav-index-total">5</span>';
				    $output .= '</div>';
			    }
		    $output .= '</nav>';

		    $btn_class   = 'crust-btn crust-sls-lnk';
		    $btn_class  .= ( $settings['hover_style'] ) ? ' styled-btn ' . $settings['hover_style'] : '';
		    $btn_class  .= ( $settings['btn_size'] !== 'md' ) ? ' crust-btn-size-' . $settings['btn_size'] : '';

		    $class = 'crust-slideshow';
		    $class .= ( $settings['height'] === 'full_height' ) ? ' crust-slide-full-height' : '';

		    $badge_class  = 'crust-badge';
		    $badge_class .= ( $settings['badge_style'] ) ? ' crust-badge-' . $settings['badge_style'] : '';

		    $output .= '<div class="'.$class.'">';
		    $items = $settings['items'];
		    if ( is_array( $items ) ) {
			    $i = 0;
			    foreach ( $items as $item ) {
				    $slide_class = ( $i == 0 ) ? ' crust-current' : '';
				    $css_bg = ( $item['image']['url'] ) ? ' background-image: url(' . $item['image']['url'] . ')' : '';
				    $output .= '<figure class="crust-sls-slide'.$slide_class.'">';
					    $output .= '<div class="crust-sls-img-wrap"><div class="crust-sls-img" style="'.$css_bg.'"></div></div>';

					    $output .= '<figcaption class="container">';
						    if( ( isset( $item['title_1'] ) && $item['title_1'] ) || ( isset( $item['description'] ) && $item['description'] )  ){
							    $output .= '<div class="crust-sls-title">';
								    if( isset( $item['badge'] ) && $item['badge'] ){
									    $output .= '<span class="crust-sls-txt"><span>';
									    $output .= '<'.$settings['badge_tag'].' class="'.$badge_class.'">' . $item['badge'] .'</'.$settings['badge_tag'].'>';
									    $output .= '</span></span>';
								    }
								    $output .= '<'.$settings['head_tag'].' class="crust-heading">';
								        $output .= ( isset( $item['title_1'] ) && $item['title_1'] ) ? '<span class="crust-sls-txt"><span>'. $item['title_1'] .'</span></span>' : '';
								    $output .= '</'.$settings['head_tag'].'>';
								    $output .= ( isset( $item['description'] ) && $item['description'] ) ? '<'.$settings['description_tag'].' class="'.$desc_class.'"><span>'. $item['description'] .'</span></'.$settings['description_tag'].'>' : '';
							    $output .= '</div>';

						    }
						    if( isset( $item['button'] ) && $item['button'] ){
							    $lnk        = ( $item['link_url']['url'] ) ? '<a class="'.$btn_class.'" href="' . esc_attr( $item['link_url']['url'] ) . '">' : '';
							    $output .= $lnk . '<span><span>' . $item['button'] .'</span></span></a>';
						    }
					    $output .= '</figcaption>';

				    $output .= '</figure>';
				    $i++;
			    }
		    }

		    $output .= "</div>";
	    $output .= "</div>";

	    if( $settings['slideshow_type'] == 'arrows' ){
		    wp_enqueue_script( 'crust-slideshow',   CRUST_CORE_URI . 'assets/front/js/vendor/crust-slideshow.js', ['jquery'], null, true );
	    } else if( $settings['slideshow_type'] == 'curve' ) {
		    wp_enqueue_script( 'crust-slideshow-1',   CRUST_CORE_URI . 'assets/front/js/vendor/crust-slideshow-1.js', ['jquery'], null, true );
	    }
	    
	    echo $output;

    }

}
