<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Login_Popup extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-login-popup';
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-login-popup', true, false);
        return ['crust-login-popup'];
    }

    public function get_title()
    {
        return esc_html__('Login Popup', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-lock-user';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_section_login_btn_style',
            [
                'label' => esc_html__('Button', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_control(
		    'login_popup_text',
		    [
			    'label'       => esc_html__('Text', 'elementor'),
			    'type'        => Controls_Manager::TEXT,
			    'default'     => 'Login',
			    'dynamic' => [
				    'active' => true,
			    ],
		    ]
	    );

	    $this->add_control(
		    'use_icon',
		    [
			    'label'         => esc_html__('Use Icon', 'crust-core'),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
		    ]
	    );

	    $this->add_control(
		    'icon',
		    [
			    'label'     => esc_html__('Icon', 'elementor'),
			    'type'      => Controls_Manager::ICONS,
			    'condition' => [
				    'use_icon' => 'yes'
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'login_btn_typography',
                'selector' => '{{WRAPPER}} .crust-login-btn'
            ]
        );

        $this->add_responsive_control(
            'login_btn_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-login-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'login_btn_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-login-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_login_btn_tabs');

        $this->start_controls_tab('normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_control(
            'login_btn_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'login_btn_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'login_btn_use_gradient_bg!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'login_btn_use_gradient_bg',
            [
                'label' => esc_html__( 'Gradient Background', 'crust-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'login_btn_gradient_background',
                'types'     => ['gradient'],
                'selector'  => '{{WRAPPER}} .crust-login-btn',
                'condition' => [
                    'login_btn_use_gradient_bg' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'login_btn_border',
                'selector' => '{{WRAPPER}} .crust-login-btn',
            ]
        );

        $this->add_responsive_control(
            'login_btn_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'login_btn_box_shadow',
                'selector' => '{{WRAPPER}} .crust-login-btn',
            ]
        );
	    /**
	     * -------------------------------------------
	     * pup login Style dark normal
	     * -------------------------------------------
	     */



	    $this->add_control(
		    'crust_pup_login_btn_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'login_btn_normal_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-btn' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_btn_normal_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-btn' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'login_btn_normal_dark_use_gradient_bg!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_btn_normal_dark_use_gradient_bg',
		    [
			    'label' => esc_html__( 'Gradient Background', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'login_btn_normal_dark_gradient_background',
			    'types'     => ['gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-login-btn',
			    'condition' => [
				    'login_btn_normal_dark_use_gradient_bg' => 'yes',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'login_normal_dark_btn_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-login-btn',
		    ]
	    );

        $this->end_controls_tab();

        $this->start_controls_tab('login_btn_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_control(
            'login_btn_hover_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'login_btn_hover_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'login_btn_use_gradient_hover_bg!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'login_btn_use_gradient_hover_bg',
            [
                'label' => esc_html__( 'Gradient Background', 'crust-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'login_btn_gradient_hover_background',
                'types'     => ['gradient'],
                'selector'  => '{{WRAPPER}} .crust-login-btn:hover',
                'condition' => [
                    'login_btn_use_gradient_hover_bg' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'login_btn_hover_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-login-btn:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'login_btn_box_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-login-btn:hover',
            ]
        );
	    /**
	     * -------------------------------------------
	     * pup login Style dark hover
	     * -------------------------------------------
	     */



	    $this->add_control(
		    'crust_pup_login_btn_hover_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'login_btn_hover_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-btn:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_btn_hover_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-btn:hover' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'login_btn_use_gradient_hover_dark_bg!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_btn_use_gradient_hover_dark_bg',
		    [
			    'label' => esc_html__( 'Gradient Background', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'login_btn_gradient_hover_dark_background',
			    'types'     => ['gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-login-btn:hover',
			    'condition' => [
				    'login_btn_use_gradient_hover_dark_bg' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_btn_hover_dark_border_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-btn:hover' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_login_pop_style',
            [
                'label' => esc_html__('Popup Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_responsive_control(
            'login_pop_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-login-popup' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'login_pop_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-login-popup' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'login_pop_typography',
                'selector' => '{{WRAPPER}} .crust-login-popup'
            ]
        );

        $this->add_control(
            'login_pop_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-popup' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'login_pop_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-login-popup' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'login_pop_use_gradient_bg!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'login_pop_use_gradient_bg',
            [
                'label' => esc_html__( 'Gradient Background', 'crust-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'login_pop_gradient_background',
                'types'     => ['gradient'],
                'selector'  => '{{WRAPPER}} .crust-login-popup',
                'condition' => [
                    'login_pop_use_gradient_bg' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'login_pop_border',
                'selector' => '{{WRAPPER}} .crust-login-popup',
            ]
        );

        $this->add_responsive_control(
            'login_pop_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-login-popup' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'login_pop_box_shadow',
                'selector' => '{{WRAPPER}} .crust-login-popup',
            ]
        );
	    /**
	     * -------------------------------------------
	     * pup login Style dark
	     * -------------------------------------------
	     */



	    $this->add_control(
		    'crust_login_pop_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'login_pop_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-popup' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_pop_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-popup' => 'background-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'login_pop_dark_use_gradient_bg!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'login_pop_dark_use_gradient_bg',
		    [
			    'label' => esc_html__( 'Gradient Background', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'login_pop_dark_gradient_background',
			    'types'     => ['gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-login-popup',
			    'condition' => [
				    'login_pop_dark_use_gradient_bg' => 'yes',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'login_pop_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-login-popup',
		    ]
	    );

        $this->end_controls_section();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();

	    $output = '';
	    $iconclass   = 'crust-btn-icon';
	    $iconclass  .= ( isset($settings['icon']['value']) && ! isset($settings['icon']['value']['url']) ) ? ' ' . $settings['icon']['value'] : '';
	    $icon_output = "<i class='{$iconclass}'></i>";

        if( $settings['login_popup_text'] || ( $settings['icon']['value'] && ! isset($settings['icon']['value']['url']) ) ){
            $output .= '<div class="crust-login-popup-wrap">';
                $output .= '<a class="crust-login-btn" href="#">';
                    $output .= ( isset($settings['icon']['value']) && ! isset($settings['icon']['value']['url']) ) ? $icon_output : '';
                        $output .= '<span>' . $settings['login_popup_text'] . '</span>';
                    $output .= '</span>';
                $output .= '</a>';

                if ( function_exists( 'crust_login_form') ){
                    $output .= '<div class="crust-login-popup">';
	                    $output .= '<a href="#" class="crust-close-login"><i class="fad fa-times"></i></a>';
	                    $output .= '<h5><i class="fad fa-user-cog primary-color"></i>'.esc_html__('Login to your account!', 'crust-core').'</h5>';
                        $output .= crust_login_form();
                    $output .= '</div>';
                }
            $output .= '</div>';

        }
        echo $output;

    }

}
