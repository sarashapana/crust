<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Posts extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-posts', true, true);
        return [
            'crust-posts',
        ];
    }

    public function get_script_depends()
    {
        return [
            'isotope',
            'imagesloaded',
            'crust-posts'
        ];

    }

    public function get_name()
    {
        return 'crust-posts';
    }

    public function get_title()
    {
        return __('Posts', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->crust_core_query_controls();
        $this->crust_core_layout_controls();
        $this->crust_core_slider_settings('crust_core_posts_type');

        $this->start_controls_section(
            'crust_section_wrapper_style',
            [
                'label' => __('Wrapper', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'crust_post_wraper_margin',
            [
                'label'      => esc_html__('Margin', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-carousel-wrapper,{{WRAPPER}} .crust-posts' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_post_wraper_padding',
            [
                'label'      => esc_html__('Padding', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-carousel,{{WRAPPER}} .crust-posts' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_item_style',
            [
                'label' => __('Item Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector' => '{{WRAPPER}} .crust-post-column .crust-post-holder',

		    ]
	    );

        $this->add_control(
            'crust_post_tilt',
            [
                'label'        => __('Tilt Effect', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_responsive_control(
            'crust_post_item_margin',
            [
                'label'      => esc_html__('Margin', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-post-column .crust-post-holder' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_post_item_padding',
		    [
			    'label'      => esc_html__('Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-holder' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'item_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'default'   => [
				    'size' => 300,
			    ],
			    'range'      => [
				    'px' => ['max' => 1000],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-column .crust-post-holder' => 'height: {{SIZE}}{{UNIT}};',
			    ],
			    'condition' => [
			    	'crust_core_posts_style' => ['paleo', 'kara']
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_core_posts_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-post-holder',
            ]
        );

        $this->add_control(
            'crust_core_posts_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .crust-post-holder' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_core_posts_box_shadow',
                'selector' => '{{WRAPPER}} .crust-post-holder',
            ]
        );

	    $this->add_control(
		    'crust_section_hover_shad',
		    [
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
			    'label'     => __('Hover', 'crust-core'),
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_core_posts_hover_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-post-column:hover .crust-post-holder',
		    ]
	    );


	    $this->add_responsive_control(
		    'crust_section_item_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-column .crust-post-holder',

		    ]
	    );



	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-holder',
		    ]
	    );






        $this->end_controls_section();

        /*
		 *  Image Style
		 */
        $this->start_controls_section(
            'crust_section_image_styles',
            [
                'label' => __('Media', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'crust_post_item_image_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-entry-media' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'crust_core_posts_style!' => ['kara','paleo']
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_post_item_image_border',
                'selector' => '{{WRAPPER}} .crust-entry-media',
            ]
        );

        $this->add_responsive_control(
            'crust_post_item_image_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-entry-media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .crust-entry-media .crust-entry-thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .crust-entry-media:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_post_item_image_shadow',
                'selector' => '{{WRAPPER}} .crust-entry-media',
            ]
        );

        $this->crust_animations( 'post_image' );

        $this->add_control(
            'crust_post_image_overlay_heading',
            [
                'label'     => esc_html__('Overlay', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_post_image_overlay',
                'types'     => ['classic', 'gradient'],
                'selector'  => '{{WRAPPER}} .crust-entry-media:before',
            ]
        );

        $this->add_control(
            'crust_post_image_overlay_hover_heading',
            [
                'label'     => esc_html__('Hover Overlay', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_post_image_hover_overlay',
                'types'     => ['classic', 'gradient'],
                'selector'  => '{{WRAPPER}} .crust-post-column:hover .crust-entry-media:before',
            ]
        );

	    $this->add_responsive_control(
		    'crust_section_image_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_image_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-entry-media',
		    ]
	    );
	    $this->add_control(
		    'crust_post_image_overlay_dark_heading',
		    [
			    'label'     => esc_html__('Overlay', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_image_dark_overlay',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-entry-media:before',
		    ]
	    );

	    $this->add_control(
		    'crust_post_image_overlay_hover_dark_heading',
		    [
			    'label'     => esc_html__('Hover Overlay', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_image_hover_dark_overlay',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-entry-media:before',
		    ]
	    );



	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_div_styles',
		    [
			    'label' => __('Divider Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_core_posts_style' => 'porta'
			    ]
		    ]
	    );

	    $this->add_control(
		    'div_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'options'     => [
				    '' => esc_html__( 'None' ,'crust'),
				    '1' => esc_html__( 'Style 1' ,'crust'),
				    '2' => esc_html__( 'Style 2' ,'crust'),
				    '3' => esc_html__( 'Style 3' ,'crust'),
				    '4' => esc_html__( 'Style 4' ,'crust'),
				    '5' => esc_html__( 'Style 5' ,'crust'),
				    '6' => esc_html__( 'Style 6' ,'crust'),
				    '7' => esc_html__( 'Style 7' ,'crust'),
				    '8' => esc_html__( 'Style 8' ,'crust'),
				    '9' => esc_html__( 'Style 9' ,'crust'),
				    '10' => esc_html__( 'Style 10' ,'crust'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'flip_horizontal',
		    [
			    'label'     => __('Horizontal Flip', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'flip_vertical',
		    [
			    'label'     => __('Vertical Flip', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'layers_no',
		    [
			    'label'       => esc_html__('Number of layers', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => '3',
			    'options'     => [
				    ''  => esc_html__('0', 'crust-core'),
				    '1' => esc_html__('1', 'crust-core'),
				    '2' => esc_html__('2', 'crust-core'),
				    '3' => esc_html__('3', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'sm_div_height',
		    [
			    'label' => __( 'Height', 'elementor' ),
			    'type' => Controls_Manager::NUMBER,
			    'dynamic' => [
				    'active' => true,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-sm-divider svg' => 'max-height: {{VALUE}}px;height: {{VALUE}}px;'
			    ]
		    ]
	    );

	    $this->add_control(
		    'base_color',
		    [
			    'label'     => esc_html__('Base Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-sm-divider .crust-sm-div-base' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'div_style!' => ['style4','style5'],
			    ],
		    ]
	    );

	    $this->add_control(
		    'layer_1_color',
		    [
			    'label'     => esc_html__('Layer 1 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-sm-divider .crust-sm-div-3' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'layer_2_color',
		    [
			    'label'     => esc_html__('Layer 2 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-sm-divider .crust-sm-div-2' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'layer_3_color',
		    [
			    'label'     => esc_html__('Layer 3 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-sm-divider .crust-sm-div-1' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->end_controls_section();

        /*
         * Filter Styles
         */
	    $this->start_controls_section(
		    'crust_section_filter_styles',
		    [
			    'label' => __('Filter Styles', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
			    	'crust_core_filter_post' => 'yes'
			    ]
		    ]
	    );

        $this->add_control(
            'post_filter_wrap_head',
            [
                'label'     => esc_html__('Wrapper', 'elementor'),
                'type'      => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'post_filter_wrap_inline',
            [
                'label'        => __('Inline ?', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

	    $this->add_control(
		    'post_filter_show_all',
		    [
			    'label'        => __('Show All Label', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'yes',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_control(
		    'post_filter_all_text',
		    [
			    'label'        => __('All Text', 'crust-core'),
			    'type'         => Controls_Manager::TEXT,
			    'default'      => esc_html__('All', 'crust-core'),
			    'condition'  => [
				    'post_filter_show_all' => 'yes',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_posts_filter_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'flex-start' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
				'default' => 'center',
                'selectors'  => [
                    '{{WRAPPER}} .crust-filters > ul' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_core_posts_filter_wrap_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-filters > ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_core_posts_filter_wrap_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-filters' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'post_filter_wrap_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-filters > ul' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_core_posts_filter_wrap_border',
                'selector' => '{{WRAPPER}} .crust-filters > ul',
            ]
        );

        $this->add_responsive_control(
            'crust_core_posts_wrap_filter_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-filters > ul' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'post_filter_wrap_box_shadow',
                'selector' => '{{WRAPPER}} .crust-filters > ul',
            ]
        );

        $this->add_control(
            'post_filter_wrap_links',
            [
                'label'     => esc_html__('Items', 'elementor'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_typography',
			    'label'    => __('Typography', 'crust-core'),

			    'selector' => '{{WRAPPER}} .crust-filters li a',
                'separator' => 'before'
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_filter_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-filters li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_filter_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-filters li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_filter_tabs');

	    $this->start_controls_tab('post_filter_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_control(
		    'post_filter_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_border',
			    'selector' => '{{WRAPPER}} .crust-filters li a',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_filter_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-filters li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'post_filter_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-filters li a',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_filter_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );




	    $this->add_control(
		    'post_filter_wrap_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-filters > ul' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_wrap_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-filters > ul',
		    ]
	    );
	    $this->add_control(
		    'post_filter_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-filters li a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-filters li a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-filters li a',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('post_filter_active', ['label' => esc_html__('Active', 'crust-core')]);

	    $this->add_control(
		    'post_filter_active_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li.selected a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_active_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li.selected a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_active_border',
			    'selector' => '{{WRAPPER}} .crust-filters li.selected a',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_filter_active_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-filters li.selected a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'post_filter_active_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-filters li.selected a',
		    ]
	    );



	    $this->add_responsive_control(
		    'post_filter_dark_active',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'post_filter_active_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-filters li.selected a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_active_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-filters li.selected a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_active_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-filters li.selected a',
		    ]
	    );
	    $this->end_controls_tab();

	    $this->start_controls_tab('post_filter_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'post_filter_hover_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li a:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_hover_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li.selected a:hover' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_hover_border',
			    'selector' => '{{WRAPPER}} .crust-filters li.selected a:hover',
		    ]
	    );



	    $this->add_responsive_control(
		    'post_filter_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'post_filter_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li a:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'post_filter_hover_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-filters li.selected a:hover' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_posts_filter_hover_dark_border',
			    'selector' => '{{WRAPPER}} .crust-filters li.selected a:hover',
		    ]
	    );





	    $this->end_controls_tab();

	    $this->end_controls_tabs();


	    $this->end_controls_section();

	    /*
		 *  Meta Style
		 */
	    $this->start_controls_section(
		    'crust_section_meta_styles',
		    [
			    'label' => __('Meta', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_meta_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start'   => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'  => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-item-meta,{{WRAPPER}} .crust-top-meta' => 'justify-content: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_meta_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-item-meta',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_meta_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-item-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_meta_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-item-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_meta_border',
			    'selector' => '{{WRAPPER}} .crust-post-item-meta',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_meta_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-item-meta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_meta_shadow',
			    'selector' => '{{WRAPPER}} .crust-post-item-meta',
		    ]
	    );

        $this->crust_animations( 'post_meta' );

	    $this->add_responsive_control(
		    'crust_section_meta_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_meta_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-item-meta',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_meta_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-item-meta',
		    ]
	    );

	    $this->end_controls_section();

	    /*
		 *  Title Style
		 */
	    $this->start_controls_section(
		    'crust_section_title_styles',
		    [
			    'label' => __('Title', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_core_posts_title_typography',
			    'label'    => __('Typography', 'crust-core'),

			    'selector' => '{{WRAPPER}} .crust-entry-title',
		    ]
	    );

	    $this->add_control(
		    'crust_posts_title_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h5',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_title_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-entry-title' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_title_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->crust_animations( 'post_title' );

	    $this->start_controls_tabs('crust_post_title_tabs');

	    $this->start_controls_tab('post_title_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_control(
		    'crust_core_posts_title_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-entry-title a' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_title_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-entry-title a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_title_border',
			    'selector' => '{{WRAPPER}} .crust-entry-title a',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_title_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'selectors' => [
				    '{{WRAPPER}} .crust-entry-title a' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_title_shadow',
			    'selector' => '{{WRAPPER}} .crust-entry-title a'
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_title_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_core_posts_title_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-entry-title a' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_title_bg_dark_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-entry-title a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_title_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-entry-title a',
		    ]
	    );


	    $this->end_controls_tab();

	    $this->start_controls_tab('post_title_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'crust_core_posts_title_hover_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-entry-title a, {{WRAPPER}} .crust-entry-title a:hover' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_title_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-column:hover .crust-entry-title a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_hover_title_border',
			    'selector' => '{{WRAPPER}} .crust-post-column:hover .crust-entry-title a',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_title_hover_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-entry-title a' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_title_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-post-column:hover .crust-entry-title a'
		    ]
	    );
	    $this->add_responsive_control(
		    'post_title_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_core_posts_title_hover_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-entry-title a, {{WRAPPER}} .crust-entry-title a:hover' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_title_hover_bg_dark_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-entry-title a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_hover_title_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-entry-title a',
		    ]
	    );


	    $this->end_controls_tab();

	    $this->end_controls_tabs();



	    $this->end_controls_section();

	    /*
	     * Content Styling
	     */
	    $this->start_controls_section(
		    'crust_section_content_styles',
		    [
			    'label' => __('Content', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'crust_post_vertical_align',
		    [
			    'label' => __( 'Vertical Align', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'options' => [
				    'flex-start' => [
					    'title' => __( 'Top', 'elementor' ),
					    'icon' => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => __( 'Center', 'elementor' ),
					    'icon' => 'eicon-v-align-middle',
				    ],
				    'flex-end' => [
					    'title' => __( 'Bottom', 'elementor' ),
					    'icon' => 'eicon-v-align-bottom',
				    ],
			    ],
			    'condition' => [
				    'crust_core_posts_style' => 'kara'
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-entry-wrapper' => 'justify-content: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_conent_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-entry-wrapper',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_conent_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_conent_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_content_border',
			    'selector' => '{{WRAPPER}} .crust-entry-wrapper',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_conent_shadow',
			    'selector' => '{{WRAPPER}} .crust-entry-wrapper',
		    ]
	    );

        $this->crust_animations( 'post_content' );

	    $this->add_responsive_control(
		    'crust_section_content_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_conent_dark_bg',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-entry-wrapper',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_content_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-entry-wrapper',
		    ]
	    );


	    $this->end_controls_section();

	    /*
         *  Excerpt Style
         */
	    $this->start_controls_section(
		    'crust_section_excerpt_styles',
		    [
			    'label' => __('Excerpt', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'crust_excerpt_visible_hover',
		    [
			    'label'        => __('Visible On Hover', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'condition' => [
				    'crust_core_posts_style' => 'kara'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_core_posts_excerpt_typography',
			    'label'    => __('Typography', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-post-excerpt p'
		    ]
	    );

	    $this->add_control(
		    'crust_core_posts_excerpt_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-excerpt' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_core_posts_excerpt_hover_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-post-excerpt' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_posts_excerpt_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'    => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'fa fa-align-left',
				    ],
				    'center'  => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'fa fa-align-center',
				    ],
				    'right'   => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'fa fa-align-right',
				    ],
				    'justify' => [
					    'title' => __('Justified', 'crust-core'),
					    'icon'  => 'fa fa-align-justify',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-excerpt p' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_inner_conent_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-entry-content',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_inner_conent_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_inner_conent_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-entry-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_inner_conent_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-entry-content',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_excerpt_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_core_posts_excerpt_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-excerpt' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_core_posts_excerpt_hover_dark_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-excerpt' => 'color: {{VALUE}};',
			    ],

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_inner_conent_dark_bg',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-entry-content',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_inner_conent_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-entry-content',
		    ]
	    );


	    $this->end_controls_section();

	    /*
         *  Date Style
         */
	    $this->start_controls_section(
		    'crust_section_date_styles',
		    [
			    'label' => __('Date', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_post_item_date_typography',
			    'label'    => __('Typography', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-post-date',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_date_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
			    	'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_date_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_date_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-date' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-post-date i' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-entry-media .crust-def-date .crust-post-date' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_date_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-date,{{WRAPPER}} .crust-entry-media .crust-def-date .crust-post-date',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_date_hover_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-post-date' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-post-column:hover .crust-post-date i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_date_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-column:hover .crust-post-date, {{WRAPPER}} .crust-post-column:hover .crust-entry-media .crust-def-date.crust-post-date',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_date_border',
			    'selector' => '{{WRAPPER}} .crust-post-date',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_date_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-date' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px !important;',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_date_shadow',
			    'selector' => '{{WRAPPER}} .crust-post-date',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_date_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start' => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'fa fa-align-left',
				    ],
				    'center'     => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'fa fa-align-center',
				    ],
				    'flex-end'   => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'fa fa-align-right',
				    ],
				    'stretch'    => [
					    'title' => __('Justified', 'crust-core'),
					    'icon'  => 'fa fa-align-justify',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-date'   => 'justify-content: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_date_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
	    'crust_post_item_date_dark_color',
	    [
		    'label'     => __('Color', 'elementor'),
		    'type'      => Controls_Manager::COLOR,

		    'selectors' => [
			    'body.crust-dark {{WRAPPER}} .crust-post-date' => 'color: {{VALUE}};',
			    'body.crust-dark {{WRAPPER}} .crust-post-date i' => 'color: {{VALUE}};',
			    'body.crust-dark {{WRAPPER}} .crust-entry-media .crust-def-date .crust-post-date' => 'color: {{VALUE}};',
		    ],
	    ]
    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_date_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-date,{{WRAPPER}} .crust-entry-media .crust-def-date .crust-post-date',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_date_hover_color_dark',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-date' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-date i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_date_hover_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-date, body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-entry-media .crust-def-date.crust-post-date',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_date_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-date',
		    ]
	    );


	    $this->end_controls_section();

	    /*
         *  Author Style
         */
	    $this->start_controls_section(
		    'crust_section_author_styles',
		    [
			    'label' => __('Author', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_post_item_author_typography',
			    'label'    => __('Typography', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-author-avatar',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_author_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-author-avatar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_author_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-author-avatar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_author_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-author-avatar .crust-posted-by a' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-author-avatar .crust-posted-by a i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_author_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-author-avatar',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_author_hover_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-author-avatar .crust-posted-by a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_author_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-column:hover .crust-author-avatar',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_author_border',
			    'selector' => '{{WRAPPER}} .crust-author-avatar',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_author_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'selectors' => [
				    '{{WRAPPER}} .crust-author-avatar' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_author_shadow',
			    'selector' => '{{WRAPPER}} .crust-author-avatar',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_author_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start' => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'fa fa-align-left',
				    ],
				    'center'     => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'fa fa-align-center',
				    ],
				    'flex-end'   => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'fa fa-align-right',
				    ],
				    'stretch'    => [
					    'title' => __('Justified', 'crust-core'),
					    'icon'  => 'fa fa-align-justify',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-author-avatar'   => 'justify-content: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_author_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_post_item_author_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-author-avatar .crust-posted-by a' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-author-avatar .crust-posted-by a i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_author_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-author-avatar',
		    ]
	    );

	    $this->add_control(
	    'crust_post_item_author_hover_dark_color',
	    [
		    'label'     => __('Hover Color', 'crust-core'),
		    'type'      => Controls_Manager::COLOR,

		    'selectors' => [
			    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-author-avatar .crust-posted-by a' => 'color: {{VALUE}};',
		    ],
	    ]
    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_author_hover_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-author-avatar',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_author_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-author-avatar',
		    ]
	    );



	    $this->end_controls_section();

	    /*
         *  Category Style
         */
	    $this->start_controls_section(
		    'crust_section_cat_styles',
		    [
			    'label' => __('Category', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_post_item_cat_typography',
			    'label'    => __('Typography', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-post-category a',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_cat_wrap_margin',
		    [
			    'label'      => esc_html__('Wrapper Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-category' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_cat_margin',
		    [
			    'label'      => esc_html__('Links Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-category a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_cat_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-post-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_cat_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-category a' => 'color: {{VALUE}};'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_cat_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-category a',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_cat_hover_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-column:hover .crust-post-category a' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-post-column:hover .crust-post-category a i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_cat_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-post-column:hover .crust-post-category a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_cat_border',
			    'selector' => '{{WRAPPER}} .crust-post-category a',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_cat_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-category a' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_post_item_cat_shadow',
			    'selector' => '{{WRAPPER}} .crust-post-category a',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_post_item_cat_alignment',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start' => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'fa fa-align-left',
				    ],
				    'center'     => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'fa fa-align-center',
				    ],
				    'flex-end'   => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'fa fa-align-right',
				    ],
				    'stretch'    => [
					    'title' => __('Justified', 'crust-core'),
					    'icon'  => 'fa fa-align-justify',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-post-category a'   => 'justify-content: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_core_posts_style!' => 'classic'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_cat_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_post_item_cat_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-category a' => 'color: {{VALUE}};'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_cat_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-category a',
		    ]
	    );

	    $this->add_control(
		    'crust_post_item_cat_hover_dark_color',
		    [
			    'label'     => __('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-category a' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-category a i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_post_item_cat_hover_bg_dark_color',
			    'types'     => ['classic', 'gradient'],

			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-post-column:hover .crust-post-category a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_post_item_cat_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-post-category a',
		    ]
	    );


	    $this->end_controls_section();

	    /*
	     * Read More
	     */
        $this->crust_core_read_more_button_style();

        /*
         * Carousel styles
         */
        $this->crust_core_slider_styling('crust_core_posts_type');

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $args     = $this->crust_core_get_query_args($settings);
        $style    = $settings['crust_core_posts_style'];

        $this->add_render_attribute(
            'posts_wrapper',
            [
                'id'    => 'crust-posts-' . esc_attr($this->get_id()),
                'class' => [
                    'crust-posts',
                    $settings['crust_core_posts_columns'],
                    'crust-post-'.esc_attr($style),
	                'crust-post-layout-'.esc_attr($settings['crust_core_posts_type'])
                ]
            ]
        );

        $this->add_render_attribute('crust_carousel', [
            'class' => [
	            'crust-posts',
                'crust-carousel',
                'swiper-container',
                'crust-post-'.esc_attr($style)
            ]
        ]);

	    $html = '';
        $this->crust_core_slider_attributes();
	   do_action('crust_core_filter_posts_site',$settings);

        if( 'carousel' === $settings['crust_core_posts_type'] ) {
            $html .= '<div class="crust-carousel-wrapper">';
                $html .= '<div ' . $this->get_render_attribute_string('crust_carousel') . '>';

                    $html .= '<div class="swiper-wrapper">';
                        $html .= $this->_render_post($args, $settings);
                    $html .= '</div>';

                $html .= '</div>';

	            $html .=  apply_filters('crust_carousel_nav_site',$settings);

        } else {

            $html .= '<div ' . $this->get_render_attribute_string('posts_wrapper') . ' data-layout="'.esc_attr($settings['crust_core_posts_type']).'">';
                $html .= $this->_render_post($args, $settings);

        }

	    $html .= '</div>';

	    echo $html;

    }

    protected function _render_post($args, $settings)
    {

	    $style = $settings['crust_core_posts_style'];
	    $date_on = $settings['crust_core_show_date'];
	    $cat_on = $settings['crust_core_show_category'];
	    $media_on = $settings['crust_core_show_image'];
	    $author_on = $settings['crust_core_show_author'];
	    $title_on = $settings['crust_core_show_title'];
	    $excrpt_on = $settings['crust_core_show_excerpt'];
	    $more_on = $settings['crust_core_show_read_more'];
	    $type = $settings['crust_core_posts_type'];
	    $filter = $settings['crust_core_filter_post'];

	    // Divider
	    $div_class = 'crust-sm-divider';
	    $div_class .= ( 'yes' === $settings['flip_horizontal'] ) ? ' crust-horizontal-flip'  : '';
	    $div_class .= ( 'yes' === $settings['flip_vertical'] )   ? ' crust-vertical-flip'    : '';
	    $f_col = ( $settings['layer_1_color'] === '' ) ? '#12d0de' : $settings['layer_1_color'];
	    $s_col = ( $settings['layer_2_color'] === '' ) ? '#b9d114' : $settings['layer_2_color'];
	    $layers = $settings['layers_no'];

	    $entry_wrap = 'crust-entry-wrapper';
	    $entry_wrap .= ($settings['crust_excerpt_visible_hover'] === 'yes' ) ? ' crust-hover-desc' : '';

        $this->add_render_attribute( 'post_title', 'class', [
            'crust-entry-title',
        ]);
        $this->crust_animation_attributes( 'post_title' );

        $this->add_render_attribute( 'post_image', 'class', [
            'crust-entry-media',
        ]);
        $this->crust_animation_attributes( 'post_image' );

        $this->add_render_attribute( 'post_content', 'class', [
            'crust-entry-content',
        ]);
        $this->crust_animation_attributes( 'post_content' );

	    $class = 'crust-post-column';
	    $class .= ( 'carousel' === $type ) ? ' swiper-slide' : '';

        $query = new \WP_Query($args);

	    $html = $tax = '';
        if ($query->have_posts()) {

            while ($query->have_posts()) {
                $query->the_post();

                $porto = get_the_terms( get_the_ID(), CRUST_PORTFOLIO . '_categories' );

                $post_categories = ( $settings['post_type'] === CRUST_PORTFOLIO ) ? $porto : get_the_category( get_the_ID() );

                if( $post_categories && ! is_wp_error( $post_categories ) ){
	                $cats = [];
                    foreach( $post_categories as $category ){
                        $cats[] = $category->slug;
                    }
	                $tax = join( " ", $cats );
                }

	            $tag  = $settings['crust_posts_title_tag'];

                $this->add_render_attribute( 'crust_post_item_holder',[
                    'class' => 'crust-post-holder',
                ] );

                if( $settings['crust_post_tilt'] == 'yes' ){
                    $this->add_render_attribute('crust_post_item_holder', [
                        'class' => 'js-tilt',
	                    'data-tilt-scale' => '1.05'
                    ]);
                }

                $dataid = ( 'carousel' !== $type && 'yes' === $filter ) ? ' data-id="'.get_the_ID().'"' : '';
                $class_fil = ( 'carousel' !== $type && 'yes' === $filter ) ? ' ' . strtolower($tax) : '';

                $html .= '<article class="'.$class.$class_fil.'"'.$dataid.'>';

                    $html .= '<div '. $this->get_render_attribute_string( 'crust_post_item_holder' ) .'>';

                    if ( $media_on == 'yes') {
                        $html .= '<div '. $this->get_render_attribute_string( 'post_image' ) .'>';
	                    $thumb_bg = get_the_post_thumbnail_url(get_the_ID(), $settings['image_size']);
		                    $html .= ( 'paleo' === $style || 'kara' === $style ) ? '<div class="crust-post-over-bg" style="background-image: url('. $thumb_bg .')"></div>' : '';
		                    $html .= ('kara' !== $style ) ? apply_filters('crust_post_thumb',$settings['image_size']) : '';
		                    $html .= ( 'porta' == $style ) ? '<div class="'.$div_class.'">' . apply_filters('crust_ele_site_sm_dividers', $settings['div_style'], $f_col, $s_col, $layers ) . '</div>' : '';
	                    $html .= '</div>';

                    }

                    if ($title_on || $author_on || $date_on || $excrpt_on || $more_on || $cat_on ) {
                        $html .= '<div class="'.$entry_wrap.'">';

		                    if( 'porta' === $style ){
			                    $html .= '<div class="crust-top-meta">';
				                    $html .= ( $author_on ) ? $this->_get_author() : '';
				                    $html .= ( $date_on ) ? $this->_get_date() : '';
			                    $html .= '</div>';
		                    } else {
			                    if ( ( ( $date_on && 'kara' === $style) || $cat_on ) && 'widget' !== $style ){
				                    $html .= '<div class="crust-top-meta">';
					                    $html .= ( $date_on && 'kara' === $style ) ? $this->_get_date() : '';
					                    $html .= ( $cat_on ) ? $this->_get_category() : '';
				                    $html .= '</div>';
			                    }
		                    }

	                        $html .= ( $title_on ) ? '<'.$tag.' '. $this->get_render_attribute_string( 'post_title' ) .'><a class="crust-post-link" href="' . get_the_permalink() . '" title="' . get_the_title() . '">' . get_the_title() . '</a></'.$tag.'>' : '';

                            if ( $excrpt_on ) {
                                $html .= '<div '. $this->get_render_attribute_string( 'post_content' ) .'>';
                                    $html .= '<div class="crust-post-excerpt">';
                                        $html .= '<p>' . wp_trim_words(strip_shortcodes(get_the_excerpt() ? get_the_excerpt() : get_the_content()), $settings['crust_core_excerpt_length'], $settings['excerpt_expanison_indicator']) . '</p>';
                                    $html .= '</div>';
                                $html .= '</div>';
                            }

		                    $html .= ( 'classic' === $style || 'paleo' === $style ) ? $this->_get_meta() : '';
	
		                    if( 'porta' == $style ){
			                    $html .= '<div class="crust-post-bottom">';
				                    $html .= ( $cat_on ) ? $this->_get_category() : '';
				                    $html .= ( $more_on ) ? $this->_get_more() : '';
			                    $html .= '</div>';
		                    } else {
			                    if( $more_on && 'kara' == $style ){
				                    $html .= '<div class="crust-post-bottom">';
				                        $html .= $this->_get_more();
				                    $html .= '</div>';
			                    }
		                    }

                        $html .= '</div>';
                    }

                    $html .= '</div>';

                $html .= '</article>';

            }

	        wp_reset_postdata();

        } else {
            $html .= '<p class="no-posts-found">';
                $html .= esc_html__('No posts found!', 'crust-core');
            $html .= '</p>';
        }

        return $html;

    }

    protected function _get_meta()
    {
	    $settings = $this->get_settings_for_display();
	    $style = $settings['crust_core_posts_style'];
	    $date_on = $settings['crust_core_show_date'];
	    $author_on = $settings['crust_core_show_author'];
	    $more_on = $settings['crust_core_show_read_more'];

	    $this->add_render_attribute( 'post_meta', 'class', [
		    'crust-post-item-meta',
	    ]);

	    $this->crust_animation_attributes( 'post_meta' );

	    $html = '<div '. $this->get_render_attribute_string( 'post_meta' ) .'>';
		    $html .= ( $author_on ) ? $this->_get_author() : '';
		    $html .= ( $date_on ) ? $this->_get_date() : '';
		    $html .= ( $more_on ) ? $this->_get_more() : '';
	    $html .= '</div>';

	    return $html;

    }

    protected function _get_author()
    {

	    $settings = $this->get_settings_for_display();
	    $style = $settings['crust_core_posts_style'];
	    $html = '<div class="crust-author-avatar">';
	        $html .= '<a href="' . get_author_posts_url(get_the_author_meta('ID')) . '">' . get_avatar(get_the_author_meta('ID'), 40) . '</a>';
	        $html .= ( 'classic' === $style ) ? '<div class="crust-posted-by">' . get_the_author_posts_link() . '</div>' : '';
	    $html .= '</div>';

	    return $html;
    }

    protected function _get_date()
    {
	    $date = get_the_date('d M Y');
	    $date_ico = '<i class="crust-meta-icon fi-rr-clock"></i>';
	    return '<div class="crust-post-date">' . $date_ico . $date . '</div>';

    }

	protected function _get_category()
	{
		$settings = $this->get_settings_for_display();
		$porto = get_the_terms( get_the_ID(), CRUST_PORTFOLIO . '_categories' );
		$post_categories = ( $settings['post_type'] === CRUST_PORTFOLIO ) ? $porto : get_the_category( get_the_ID() );

		if ( ! empty($post_categories)) {

			$get_cat = '<div class="crust-post-category">';
				$icon = ( 'porta' === $settings['crust_core_posts_style'] || 'classic' === $settings['crust_core_posts_style'] ) ? '<i class="fi-rr-folder"></i>' : '' ;
				$get_cat .= '<a href="' . esc_url(get_category_link($post_categories[0]->term_id)) . '">' . $icon . esc_html($post_categories[0]->name) . '</a>';
			$get_cat .= '</div>';
			return $get_cat;

		}

	}

	protected function _get_more()
	{
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute( 'more_button', 'class', [
			'crust-post-more',
		]);
		$this->crust_animation_attributes( 'more_button' );

		$wrap_class = 'crust-btn-icon-wrap';
		$more_txt = $settings['crust_core_read_more_text'];
		$more_icon = $settings['crust_core_read_more_icon'];

		$more = '<div '. $this->get_render_attribute_string( 'more_button' ) .'><a href="' . get_the_permalink() . '" class="crust-post-readmore-btn">';

			if( $more_txt || $more_icon ){
				$more .= ( $more_txt ) ? $more_txt : '';
				if( $more_icon ){
					$more .= '<span class="'. esc_attr( $wrap_class ) .'">';
					if (isset($settings['crust_core_read_more_icon']['value']['url'])) {
						$more .= '<img class="read-more-button-icon" src="'. esc_attr($settings['crust_core_read_more_icon']['value']['url']) .'" alt="'. esc_attr(get_post_meta
							($settings['crust_core_read_more_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'"/>';
					} else {
						$more .= ( esc_attr($settings['crust_core_read_more_icon']['value']) ) ? '<i class="'.esc_attr($settings['crust_core_read_more_icon']['value']).'"></i><span class="crust-dots-wrap"><i></i><i></i><i></i></span>' : '';
					}
					$more .= '</span>';
				}
			}

		$more .= '</a></div>';

		return $more;

	}

}
