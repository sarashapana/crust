<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use \Elementor\Widget_Base;

class Crust_Woo_Products extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-woo-products';
    }

    public function get_title()
    {
        return esc_html__('Woo Products', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-products';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_section_products_style',
            [
                'label' => esc_html__('Settings', 'crust-core'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

	    $this->add_control(
		    'crust_products_columns',
		    [
			    'label'       => esc_html__('Columns Per Row', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => '4',
			    'label_block' => false,
			    'options'     => [
				    '1' => esc_html__('1', 'crust-core'),
				    '2' => esc_html__('2', 'crust-core'),
				    '3' => esc_html__('3', 'crust-core'),
				    '4' => esc_html__('4', 'crust-core'),
				    '5' => esc_html__('5', 'crust-core'),
				    '6' => esc_html__('6', 'crust-core'),
			    ]
		    ]
	    );

	    $this->add_control(
		    'limit',
		    [
			    'label'     => esc_html__('Products Limit', 'elementor'),
			    'type'      => Controls_Manager::NUMBER,
			    'default'   => '-1',
		    ]
	    );

        $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_products_style',
		    [
			    'label' => esc_html__('Wrapper Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_woo_wrap_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-products-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_product_img_style',
		    [
			    'label' => esc_html__('Image Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_woo_img_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-product-img-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_woo_img_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-product-img-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_woo_img_border',
			    'selector' => '{{WRAPPER}} .crust-product-img-wrap',
		    ]
	    );
		//dark
	    $this->add_control(
		    'crust_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
//	    $this->add_group_control(
//		    Group_Control_Border::get_type(),
//		    [
//			    'name'     => 'crust_woo_img_dark_border',
//			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-product-img-wrap',
//		    ]
//	    );


	    $this->add_responsive_control(
		    'crust_woo_img_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-product-img-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_woo_img_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-product-img-wrap'
		    ]
	    );

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $columns = $settings['crust_products_columns'];
	    $limit = $settings['limit'];
	    $style = 'crust-pro-'. crust_woo_settings()['style'];

	    $this->add_render_attribute(
		    'crust_products',
		    [
			    'class' => [
				    'crust-woo-products',
				    esc_attr( $style ),
			    ],
		    ]
	    );

		$html = '<div '. $this->get_render_attribute_string("crust_products") .'>';
            $html .= do_shortcode('[products limit="'.$limit.'" columns="'.$columns.'"]');
		$html .= '</div>';

		echo $html;

    }

}
