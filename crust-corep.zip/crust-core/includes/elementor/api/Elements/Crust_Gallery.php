<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;
use \Elementor\Repeater;
use \Elementor\Group_Control_Background;

class Crust_Gallery extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-gallery'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-gallery', true, true);
        return ['crust-gallery'];
    }

    public function get_name()
    {
        return 'crust-gallery';
    }

    public function get_title()
    {
        return esc_html__('Gallery', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-gallery-justified';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Filter Gallery Settings
         */
        $this->start_controls_section(
            'crust_section_gallery_settings',
            [
                'label' => esc_html__('Settings', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_gallery_grid_style',
            [
                'label'   => esc_html__('Layout', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => [
                    'grid'    => esc_html__('Grid', 'crust-core'),
                    'masonry' => esc_html__('Masonry', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'columns',
            [
                'label'              => __('Columns', 'crust-core'),
                'type'               => Controls_Manager::SELECT,
                'default'            => '3',
                'options'            => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
	                '7' => '7'
                ],
            ]
        );

        $this->add_control(
            'crust_gallery_grid_item_height',
            [
                'label'     => esc_html__('Image Height', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'crust_gallery_grid_style' => 'grid',
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item .gallery-item-thumbnail-wrap' => 'height: {{VALUE}}px;',
                ],
            ]
        );

	    $this->add_control(
		    'crust_gallery_tilt',
		    [
			    'label'        => __('Tilt Effect', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

        $this->add_control(
            'crust_gallery_show_popup',
            [
                'label'     => esc_html__('Link to', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'buttons',
                'options'   => [
                    'none'    => esc_html__('None', 'crust-core'),
                    'title'   => esc_html__('Title', 'crust-core'),
                    'buttons' => esc_html__('Buttons', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_section_gallery_zoom_icon',
            [
                'label'            => esc_html__('Lightbox Icon', 'crust-core'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-search-plus',
                    'library' => 'icomoon',
                ],
                'condition'        => [
                    'crust_gallery_show_popup' => 'buttons',
                ],
            ]
        );

        $this->add_control(
            'crust_section_gallery_link_icon',
            [
                'label'            => esc_html__('Link Icon', 'crust-core'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-link',
                    'library' => 'icomoon',
                ],
                'condition'        => [
                    'crust_gallery_show_popup' => 'buttons',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Filter Gallery Control Settings
         */
        $this->start_controls_section(
            'crust_section_gallery_control_settings',
            [
                'label' => esc_html__('Filter', 'crust-core'),
            ]
        );

        $this->add_control(
            'filter_enable',
            [
                'label'   => __('Enable Filter', 'crust-core'),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'crust_gallery_all_label_text',
            [
                'label'     => esc_html__('Gallery All Label', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'default'   => 'All',
                'condition' => [
                    'filter_enable' => 'yes',
                ],
            ]
        );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_gallery_control', [
			    'label'       => esc_html__('List Item', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Gallery Item', 'crust-core'),
		    ]
	    );

        $this->add_control(
            'crust_gallery_controls',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    ['crust_gallery_control' => 'Gallery Item'],
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_gallery_control}}',
            ]
        );

        $this->end_controls_section();

        /**
         * Filter Gallery Grid Settings
         */
        $this->start_controls_section(
            'crust_section_gallery_grid_settings',
            [
                'label' => esc_html__('Gallery Items', 'crust-core'),
            ]
        );

        $repeater = new Repeater();

	    $repeater->add_control(
		    'crust_gallery_img',
		    [
			    'label'   => esc_html__('Image', 'crust-core'),
			    'type'    => Controls_Manager::MEDIA,
			    'default' => [
				    'url' => CRUST_CORE_URI . 'includes/elementor/assets/images/gallery-placeholder.jpg',
			    ],
		    ]
	    );

        $repeater->add_control(
            'crust_gallery_item_name',
            [
                'label'       => esc_html__('Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Gallery item name', 'crust-core'),
            ]
        );

        $repeater->add_control(
            'crust_gallery_item_content',
            [
                'label'       => esc_html__('Content', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing.', 'crust-core'),
            ]
        );

        $repeater->add_control(
            'crust_gallery_category',
            [
                'label'       => esc_html__('Catrgory', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'description' => __('Assign Category names separated by comma (Ex. <strong>Item, Item 2</strong>)', 'crust-core'),
            ]
        );

        $repeater->add_control(
            'crust_gallery_lightbox',
            [
                'label'        => __('Popup Button?', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'true',
                'label_on'     => esc_html__('Yes', 'crust-core'),
                'label_off'    => esc_html__('No', 'crust-core'),
                'return_value' => 'true',
            ]
        );

        $repeater->add_control(
            'crust_gallery_link',
            [
                'label'        => __('Link Button?', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'true',
                'label_on'     => esc_html__('Yes', 'crust-core'),
                'label_off'    => esc_html__('No', 'crust-core'),
                'return_value' => 'true',
            ]
        );

        $repeater->add_control(
            'crust_gallery_img_link',
            [
                'type'          => Controls_Manager::URL,
                'label_block'   => true,
                'default'       => [
                    'url'         => '#',
                    'is_external' => '',
                ],
                'show_external' => true,
                'condition'     => [
                    'crust_gallery_link'      => 'true',
                ],
            ]
        );

        $this->add_control(
            'crust_gallery_items',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                    ['crust_gallery_item_name' => 'Gallery Item Title'],
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_gallery_item_name}}',
            ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Filterable Gallery Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_gallery_style_settings',
            [
                'label' => esc_html__('General', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-gallery-wrapper',
		    ]
	    );

        $this->add_responsive_control(
            'crust_gallery_container_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_container_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-gallery-wrapper',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-gallery-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_gallery_shadow',
                'selector' => '{{WRAPPER}} .crust-gallery-wrapper',
            ]
        );

		/////////////
	    $this->add_responsive_control(
		    'crust_section_gallery_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-gallery-wrapper',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-gallery-wrapper',
		    ]
	    );

	    /////////////

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Filterable Gallery Control Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_gallery_filter_style_settings',
            [
                'label'     => esc_html__('Filter Items Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'crust_gallery_filter_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-filter ul li.filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_filter_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-filter ul li.filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_gallery_filter_typography',
                'selector' => '{{WRAPPER}} .crust-gallery-filter ul li.filter',
            ]
        );
        // Tabs
        $this->start_controls_tabs('crust_gallery_filter_tabs');

        // Normal State Tab
        $this->start_controls_tab('crust_gallery_filter', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_control(
            'crust_gallery_filter_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-gallery-filter ul li.filter' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_filter_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-gallery-filter ul > li.filter',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_control_filter_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-gallery-filter ul > li.filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_gallery_filter_shadow',
                'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter',
                'separator' => 'before',
            ]
        );
		///////normal///////
	    $this->add_responsive_control(
		    'crust_section_gallery_filter_style_normal_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_gallery_filter_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_filter_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul > li.filter',
		    ]
	    );
	    ///////////////

        $this->end_controls_tab();

        // Hover State Tab
        $this->start_controls_tab('crust_gallery_filter_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_control(
            'crust_gallery_filter_hover_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-gallery-filter ul li:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_hover_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter:hover',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_filter_hover_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-gallery-filter ul li.filter:hover',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_filter_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-gallery-filter ul li.filter:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_gallery_control_hover_shadow',
                'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter:hover',
                'separator' => 'before',
            ]
        );

		//////hover/////
	    $this->add_responsive_control(
		    'crust_section_gallery_filter_style_hover_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_gallery_filter_hover_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_hover_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_filter_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter:hover',
		    ]
	    );
	    ////////////////

        $this->end_controls_tab();

        // Active State Tab
        $this->start_controls_tab('crust_gallery_filter_active', ['label' => esc_html__('Active', 'crust-core')]);

        $this->add_control(
            'crust_gallery_filter_active_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-gallery-filter ul li.active' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_active_bg',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter.active',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_filter_active_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-gallery-filter ul li.filter.active',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_filter_active_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-gallery-filter ul li.filter.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_gallery_control_active_shadow',
                'selector'  => '{{WRAPPER}} .crust-gallery-filter ul li.filter.active',
                'separator' => 'before',
            ]
        );
		////////active////
	    $this->add_responsive_control(
		    'crust_section_gallery_filter_style_active_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_gallery_filter_active_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.active' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_filter_active_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter.active',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_filter_active_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-gallery-filter ul li.filter.active',
		    ]
	    );
	    //////////////////

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Filterable Gallery Item Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_gallery_item_style_settings',
            [
                'label' => esc_html__('Item Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_item_container_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_item_container_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_item_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_item_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				    '{{WRAPPER}} .crust-gallery-item-wrap .gallery-item-thumbnail-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_gallery_item_shadow',
                'selector' => '{{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item',
            ]
        );
/////////////
	    $this->add_responsive_control(
		    'crust_section_gallery_item_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_item_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-gallery-item-wrap .crust-gallery-item',
		    ]
	    );
/////////////
        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Filterable Gallery Hoverer Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_gallery_item_cap_style_settings',
            [
                'label'     => esc_html__('Item Hover Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'crust_gallery_item_cap_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(0,0,0,0.7)',
                'selectors' => [
                    '{{WRAPPER}} .gallery-item-hoverer-bg' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_item_cap_container_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		///////////////
	    $this->add_responsive_control(
		    'crust_section_gallery_item_cap_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_gallery_item_cap_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .gallery-item-hoverer-bg' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );


	    //////////////

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_gallery_item_title_typography',
		    [
			    'label'     => esc_html__('Title Style', 'crust-core'),
			    'tab'       => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_title_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h5',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_gallery_item_hover_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title,{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_gallery_item_hover_title_hover_color',
            [
                'label'     => esc_html__('Hover Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title:hover,{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title:hover a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_gallery_item_content_title_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title' => 'background-color: {{VALUE}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_item_content_title_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_item_content_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_gallery_item_content_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_gallery_item_hover_title_typography',
                'selector' => '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title',
            ]
        );
		//////////////////
	    $this->add_responsive_control(
		    'crust_gallery_item_title_dark_typography',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_gallery_item_hover_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title,{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_hover_title_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title:hover,{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title:hover a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_content_title_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-title' => 'background-color: {{VALUE}};',
			    ]
		    ]
	    );
	    //////////////////

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_gallery_item_content_typography',
		    [
			    'label'     => esc_html__('Content Style', 'crust-core'),
			    'tab'       => Controls_Manager::TAB_STYLE,
		    ]
	    );

        $this->add_control(
            'crust_gallery_item_hover_content_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_gallery_item_hover_content_typography',
                'selector' => '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-content',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_item_hover_content_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_item_cap_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap',
            ]
        );



        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_gallery_item_cap_shadow',
                'selector' => '{{WRAPPER}} .crust-gallery-item:hover',
            ]
        );

        $this->add_responsive_control(
            'crust_gallery_item_hoverer_content_alignment',
            [
                'label'        => esc_html__('Content Alignment', 'crust-core'),
                'type'         => Controls_Manager::CHOOSE,
                'label_block'  => false,
                'separator'    => 'before',
                'options'      => [
                    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
                    'left'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'      => 'center',
                'selectors'  => [
		            '{{WRAPPER}} .gallery-item-caption-wrap' => 'text-align: {{VALUE}};',
	            ],
            ]
        );
///////////////////
	    $this->add_responsive_control(
		    'crust_gallery_item_content_dark_typography',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_hover_content_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap .fg-item-content' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_item_cap_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .caption-style-hoverer .gallery-item-caption-wrap',
		    ]
	    );
//////////////////
        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Hoverer Icon Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_gallery_item_hover_icons_style',
            [
                'label' => esc_html__('Icons Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_item_icon_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_gallery_item_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_icon_size',
		    [
			    'label'      => esc_html__('Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', 'em'],
			    'range'      => [
				    'px' => [
					    'min' => 0,
					    'max' => 120,
				    ],
				    'em' => [
					    'min' => 0,
					    'max' => 50,
				    ],
			    ],
			    'default'    => [
				    'unit' => 'px',
				    'size' => 30,
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_icon_font_size',
		    [
			    'label'      => esc_html__('Font Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', 'em'],
			    'range'      => [
				    'px' => [
					    'max' => 50,
				    ]
			    ],
			    'default'    => [
				    'unit' => 'px',
				    'size' => 14,
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span'     => 'font-size: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->start_controls_tabs('fg_icons_style');

        $this->start_controls_tab(
            'fg_icons_style_normal',
            [
                'label' => __('Normal', 'elementor')
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_item_icon_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span',
		    ]
	    );

        $this->add_control(
            'crust_gallery_item_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_gallery_item_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span',
            ]
        );

	    $this->add_responsive_control(
		    'crust_gallery_item_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
		/////////normal////////
	    $this->add_responsive_control(
		    'crust_section_gallery_item_hover_icons_normal_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_item_icon_bg_dark_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span',
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_item_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span',
		    ]
	    );

	    //////////////////

        $this->end_controls_tab();

        $this->start_controls_tab(
            'fg_icons_style_hover',
            [
                'label' => __('Hover', 'elementor')
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_item_icon_bg_color_hover',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span',
		    ]
	    );

        $this->add_control(
            'crust_gallery_item_icon_color_hover',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_item_icon_border_hover',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_gallery_item_icon_border_radius_hover',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_gallery_item_icon_transition',
            [
                'label'     => esc_html__('Transition', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 300,
                ],
                'range'     => [
                    'px' => [
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a span' => 'transition: {{SIZE}}ms;',
                ],
            ]
        );
///////hover////////
	    $this->add_responsive_control(
		    'crust_section_gallery_item_hover_icons_hover_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );



	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_gallery_item_icon_dark_bg_color_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span',
		    ]
	    );

	    $this->add_control(
		    'crust_gallery_item_icon_dark_color_hover',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_gallery_item_icon_dark_border_hover',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .gallery-item-caption-wrap .gallery-item-buttons > a:hover span',
		    ]
	    );
///////////////////

        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $gallery_items = $settings['crust_gallery_items'];
		$cols = 'crust-columns-' . $settings['columns'];
        $this->add_render_attribute(
            'gallery-items-wrap',
            [
                'class' => [
                    'crust-gallery-container',
	                $cols
                ],
                'data-layout' => $settings['crust_gallery_grid_style']
            ]
        );

        $html = '<div class="crust-gallery-wrapper">';

            $html .= ( 'yes' === $settings['filter_enable'] ) ? $this->render_filters() : '';

            $html .= '<div '. $this->get_render_attribute_string('gallery-items-wrap') .'>';

                foreach ($gallery_items as $gallery) {
                    $html .= $this->render_item( $settings, $gallery );
                }

	            $html .= '<div class="clearfix"></div>';

            $html .= '</div>';

        $html .= '</div>';

        echo $html;

    }

    public function render_item( $settings, $gallery )
    {
        $title         = $gallery['crust_gallery_item_name'];
        $content       = $gallery['crust_gallery_item_content'];
        $image         = $gallery['crust_gallery_img']['url'];
        $image_id      = $gallery['crust_gallery_img']['id'];
        $categories    = ( 'yes' === $settings['filter_enable'] ) ? $this->filter_class($gallery['crust_gallery_category']) : '';
	    $is_link       = $gallery['crust_gallery_link'];
	    $link          = $gallery['crust_gallery_img_link'];
        $caption_style = ' caption-style-hoverer';
	    $tilt          = ( $settings['crust_gallery_tilt'] === 'yes' ) ? ' js-tilt' : '';
	    $tag           = $settings['crust_gallery_item_title_tag'];

        $html = '<div class="crust-gallery-item-wrap ' . $categories . $caption_style . ' gallery-item">';

            $html .= '<div class="crust-gallery-item '. $tilt .'">';

                $html .= '<div class="gallery-item-thumbnail-wrap">';

                    $html .= '<div class="gallery-item-hoverer-bg"></div>';
                    $html .= '<img src="' . $image . '" alt="' . esc_attr(get_post_meta($image_id, '_wp_attachment_image_alt', true)) . '" class="gallery-item-thumbnail">';

                $html .= '</div>';

                $html .= '<div class="gallery-item-caption-wrap">';

                    if (isset($title) && ! empty($title) || isset($content) && ! empty($content)) {
                        if ( ! empty($title) ) {
                            if ( $is_link == 'true' ) {
                                $a_string = 'href="' . esc_url( $link['url'] ) . '"';
                                $a_string .= ( $link['nofollow'] ) ? 'rel="nofollow"' : '';;
                                $a_string .= ( $link['is_external'] ) ? 'target="_blank"' : '';
                            }

                            $html .= '<'.$tag.' class="fg-item-title">';
                                $html .= ( ! empty($link['url']) && $settings['crust_gallery_show_popup'] === 'title' ) ? '<a ' . $a_string . '>' : '';
	                                $html .= $title;
	                            $html .= ( ! empty($link['url']) && $settings['crust_gallery_show_popup'] === 'title' ) ? '</a>' : '';
                            $html .= '</'.$tag.'>';

                        }
                        if ( ! empty($content)) {
                            $html .= '<div class="fg-item-content">' . wpautop($content) . '</div>';
                        }
                    }

                    if ($settings['crust_gallery_show_popup'] == 'buttons') {
                        $html .= $this->render_buttons($settings, $gallery);
                    }

                $html .= '</div>';

            $html .= '</div>';

        $html .= '</div>';

        return $html;

    }

    public function filter_class( $string )
    {
        $class = strtolower($string);
        $class = str_replace(' ', '-', $class);
        $class = str_replace('&', 'and', $class);
        $class = str_replace('amp;', '', $class);
        $class = str_replace('/', 'slash', $class);
        $class = str_replace(',-', ' ', $class);
        $class = str_replace('.', '-', $class);
        $class = str_replace(',', ' ', $class);

        return $class;
    }

    protected function render_buttons( $settings, $item )
    {
        $zoom_icon     = $settings['crust_section_gallery_zoom_icon'];
        $link_icon     = $settings['crust_section_gallery_link_icon'];
        $image         = $item['crust_gallery_img']['url'];
        $show_lightbox = $item['crust_gallery_lightbox'];
        $is_link       = $item['crust_gallery_link'];
        $link          = $item['crust_gallery_img_link'];

	    $html = '<div class="gallery-item-buttons">';

	        if ($show_lightbox == true) {
		        $html .= '<a href="' . esc_url($image) . '" class="crust-magnific-link">';

	                $html .= '<span class="fg-item-icon-inner">';
	                    if ($zoom_icon) {
	                        if (isset($settings['crust_section_gallery_zoom']['value']['url'])) {
	                            $html .= '<img src="' . $settings['crust_section_gallery_zoom_icon']['value']['url'] . '" alt="' . esc_attr(get_post_meta($settings['crust_section_gallery_zoom_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '" />';
	                        } else {
	                            $html .= '<i class="' . $settings['crust_section_gallery_zoom_icon']['value'] . '"></i>';
	                        }
	                    }
	                $html .= '</span>';

	            $html .= '</a>';
	        }

	        if ( $is_link == 'true' ) {
	            $a_string = 'href="' . esc_url($link['url']) . '"';

	            if ($link['nofollow']) {
	                $a_string .= 'rel="nofollow"';
	            }

	            if ($link['is_external']) {
	                $a_string .= 'target="_blank"';
	            }

	            if ( ! empty($link['url'])) {
	                $html .= '<a ' . $a_string . '>';
	                    $html .= '<span class="fg-item-icon-inner">';

	                        if ($link_icon) {
	                            if (isset($settings['crust_section_gallery_link_icon']['value']['url'])) {
	                                $html .= '<img src="' . $settings['crust_section_gallery_link_icon']['value']['url'] . '" alt="' . esc_attr(get_post_meta($settings['crust_section_gallery_link_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '" />';
	                            } else {
	                                $html .= '<i class="' . $settings['crust_section_gallery_link_icon']['value'] . '"></i>';
	                            }
	                        }

	                    $html .= '</span>';
	                $html .= '</a>';
	            }
	        }

        $html .= '</div>';

	    return $html;

    }

    protected function render_filters()
    {
        $settings = $this->get_settings_for_display();
        $all_text = ($settings['crust_gallery_all_label_text'] != '') ? $settings['crust_gallery_all_label_text'] : esc_html__('All', 'crust-core');

        if ($settings['filter_enable'] == 'yes') {

            $html = '<div class="crust-gallery-filter">';
                $html .= '<ul>';
                    if ($settings['crust_gallery_all_label_text']) {
                        $html .= '<li class="filter active" data-filter="*">'.$all_text.'</li>';
                    }

                    foreach ($settings['crust_gallery_controls'] as $key => $category){
                        $sorter_filter = $this->filter_class($category['crust_gallery_control']);
                            $active = ($key == 0 && empty($settings['crust_gallery_all_label_text'])) ? ' active' : '';
                            $html .= '<li class="filter'.$active.'" data-filter=".'.esc_attr($sorter_filter).'">'. esc_html__($category['crust_gallery_control']).'</li>';
                    }
                $html .= '</ul>';
            $html .= '</div>';

            return $html;

        }

    }

}
