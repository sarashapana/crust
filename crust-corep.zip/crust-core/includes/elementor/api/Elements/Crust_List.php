<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;
use \Elementor\Repeater;

class Crust_List extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-list', false, true);
        return ['crust-list'];
    }

    public function get_name()
    {
        return 'crust-list';
    }

    public function get_title()
    {
        return esc_html__('Custom List', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-bullet-list';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Feature List Settings
         */
        $this->start_controls_section(
            'crust_section_list_content_settings',
            [
                'label' => esc_html__('Content', 'crust-core')
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'crust_list_icon_type',
            [
                'label'       => esc_html__('Icon Type', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
                    'icon'  => [
                        'title' => esc_html__('Icon', 'elementor'),
                        'icon'  => 'fa fa-star',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'crust-core'),
                        'icon'  => 'fa fa-picture-o',
                    ],
                    'number' => [
	                    'title' => esc_html__('Number', 'crust-core'),
	                    'icon'  => 'fa fa-sort-numeric-up',
                    ],
                ],
                'default'     => 'icon',
                'label_block' => false,
            ]
        );

        $repeater->add_control(
            'crust_list_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'condition'        => [
                    'crust_list_icon_type' => 'icon'
                ]
            ]
        );

	    $repeater->add_control(
		    'crust_list_img',
		    [
			    'label'     => esc_html__('Image', 'crust-core'),
			    'type'      => Controls_Manager::MEDIA,
			    'condition' => [
				    'crust_list_icon_type' => 'image'
			    ]
		    ]
	    );

	    $repeater->add_control(
		    'crust_list_number',
		    [
			    'label'     => esc_html__('Number', 'crust-core'),
			    'type'      => Controls_Manager::TEXT,
			    'default'   => '1',
			    'condition' => [
				    'crust_list_icon_type' => 'number'
			    ]
		    ]
	    );

        $repeater->add_control(
            'crust_list_title',
            [
                'label'   => esc_html__('Title', 'crust-core'),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__('Title', 'crust-core'),
                'dynamic' => ['active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'crust_list_content',
            [
                'label'   => esc_html__('Content', 'crust-core'),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.', 'crust-core'),
                'dynamic' => ['active' => true]
            ]
        );

        $repeater->add_control(
            'crust_list_link',
            [
                'label'       => esc_html__('Link', 'elementor'),
                'type'        => Controls_Manager::URL,
                'dynamic'     => ['active' => true],
                'placeholder' => esc_html__('https://your-link.com', 'crust-core'),
                'separator'   => 'before',
            ]
        );

        $this->add_control(
            'crust_list',
            [
                'label'       => esc_html__('Item', 'crust-core'),
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    [
                        'crust_list_icon' => [
                            'value'   => 'fad fa-alarm-exclamation',
                            'library' => 'mobirise'
                        ],
                        'crust_list_title'    => esc_html__('Do You Need More Assistance ?', 'crust-core'),
                        'crust_list_content'  => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.', 'crust-core')
                    ],
                    [
                        'crust_list_icon' => [
                            'value'   => 'fad fa-heartbeat',
                            'library' => 'mobirise'
                        ],
                        'crust_list_title'    => esc_html__('We Created It With Love.', 'crust-core'),
                        'crust_list_content'  => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.', 'crust-core')
                    ],
                    [
                        'crust_list_icon' => [
                            'value'   => 'fad fa-envelope-open-text',
                            'library' => 'mobirise'
                        ],
                        'crust_list_title'    => esc_html__('Easily Contact Us Anytime.', 'crust-core'),
                        'crust_list_content'  => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.', 'crust-core')
                    ]
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '<i class="{{ crust_list_icon.value }}" aria-hidden="true"></i> {{{ crust_list_title }}}',
            ]
        );

	    $this->add_control(
		    'crust_list_connector',
		    [
			    'label'        => esc_html__('Show Connector', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => esc_html__('Show', 'crust-core'),
			    'label_off'    => esc_html__('No', 'crust-core'),
			    'return_value' => 'yes',
			    'separator'    => 'before',
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Feature List Style
         * -------------------------------------------
         */
	    $this->start_controls_section(
		    'crust_section_list_wrap_style',
		    [
			    'label' => esc_html__('Wrapper', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_wrap_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_wrap_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_wrap_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-list',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_list_wrap_border',
			    'selector' => '{{WRAPPER}} .crust-list',
		    ]
	    );

	    $this->add_control(
		    'crust_list_border_wrap_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_list_wrap_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-list',
		    ]
	    );
		/**
		 * ------------------------------
		 *start wrapper dark mode
		 * ------------------------------
		 */
	    $this->add_responsive_control(
		    'crust_section_list_wrap_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_wrap_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_list_wrap_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list',
		    ]
	    );
	    /**
	     * ------------------------------
	     *end wrapper dark mode
	     * ------------------------------
	     */

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_list_style',
            [
                'label' => esc_html__('List', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'list_vertical_align',
		    [
			    'label'       => __('Vertical Align', 'crust-core'),
			    'type'        => Controls_Manager::CHOOSE,
			    'label_block' => false,
			    'default'     => 'baseline',
			    'options'      => [
				    'baseline'    => [
					    'title' => __('Top', 'crust-core'),
					    'icon'  => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => __('Middle', 'crust-core'),
					    'icon'  => 'eicon-v-align-middle',
				    ],
				    'flex-end' => [
					    'title' => __('Bottom', 'crust-core'),
					    'icon'  => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors'            => [
				    '{{WRAPPER}} .crust-list .crust-list-item' => 'align-items: {{VALUE}};'
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_list_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-list .crust-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_list_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-list .crust-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_list_tabs');

        $this->start_controls_tab('normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-item',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border:: get_type(),
            [
                'name'     => 'crust_list_border',
                'selector' => '{{WRAPPER}} .crust-list .crust-list-item',
            ]
        );

	    $this->add_control(
		    'remove_border',
		    [
			    'label'         => esc_html__('Remove Last Item Border', 'crust-core'),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );

        $this->add_control(
            'crust_list_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-list .crust-list-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'crust_list_box_shadow',
                'selector' => '{{WRAPPER}} .crust-list .crust-list-item',
            ]
        );
	    /**
	     * ------------------------------
	     *start list dark mode
	     * ------------------------------
	     */

	    $this->add_responsive_control(
		    'crust_list_dark_tabs',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_list_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item',
		    ]
	    );


	    /**
	     * ------------------------------
	     *end list dark mode
	     * ------------------------------
	     */

        $this->end_controls_tab();

        $this->start_controls_tab('crust_list_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_hover_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-item:hover',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border:: get_type(),
            [
                'name'     => 'crust_list_hover_border',
                'selector' => '{{WRAPPER}} .crust-list .crust-list-item:hover',
            ]
        );

        $this->add_control(
            'crust_list_hover_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-list .crust-list-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'crust_list_hover_box_shadow',
                'selector' => '{{WRAPPER}} .crust-list .crust-list-item:hover',
            ]
        );
	    /**
	     * ------------------------------
	     *start list dark mode hover
	     * ------------------------------
	     */

	    $this->add_responsive_control(
		    'crust_list_hover_dark_tabs',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_hover_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_list_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item:hover',
		    ]
	    );


	    /**
	     * ------------------------------
	     *end list dark mode
	     * ------------------------------
	     */


	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * List Title Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_list_style_title',
            [
                'label' => esc_html__('Title', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'crust_list_title_tag',
            [
                'label'     => esc_html__('HTML Tag', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'h1'   => 'H1',
                    'h2'   => 'H2',
                    'h3'   => 'H3',
                    'h4'   => 'H4',
                    'h5'   => 'H5',
                    'h6'   => 'H6',
                    'div'  => 'div',
                    'span' => 'span',
                    'p'    => 'p',
                ],
                'default'   => 'h5',
            ]
        );

	    $this->add_responsive_control(
		    'crust_list_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_list_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-list-content-box .crust-list-title, {{WRAPPER}} .crust-list-content-box .crust-list-title > a' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_list_title_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-list-content-box .crust-list-title:hover, {{WRAPPER}} .crust-list-content-box .crust-list-title:hover > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_list_title_typography',
                'selector' => '{{WRAPPER}} .crust-list-content-box .crust-list-title',
            ]
        );
	    /**
	     * ------------------------------
	     *start totle dark mode
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'crust_section_list_style_dark_title',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_list_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-list-content-box .crust-list-title, body.crust-dark {{WRAPPER}} .crust-list-content-box .crust-list-title > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_list_title_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-list-content-box .crust-list-title:hover, body.crust-dark {{WRAPPER}} .crust-list-content-box .crust-list-title:hover > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    /**
	     * ------------------------------
	     *end title dark mode
	     * ------------------------------
	     */


	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Feature List Icon Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_list_style_icon',
            [
                'label' => esc_html__('Icon', 'elementor'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'crust_list_icon_position',
            [
                'label'           => esc_html__('Position', 'elementor'),
                'type'            => Controls_Manager::CHOOSE,
                'options'         => [
                    'left'  => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'fa fa-align-right',
                    ],
                ],
                'default'         => 'left',
            ]
        );

	    $this->add_control(
		    'media_hover_animation',
		    [
			    'label'   => esc_html__('Hover Animation', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('None', 'crust-core'),
				    'scale'         => esc_html__('Grow', 'crust-core'),
				    'shrink'         => esc_html__('Shrink', 'crust-core'),
				    'rotate'        => esc_html__('Rotate', 'crust-core'),
				    'spin'          => esc_html__('Spin', 'crust-core'),
				    'pulse'         => esc_html__('Pulse', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_icon_width',
		    [
			    'label'     => esc_html__('Width', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 60,
			    ],
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list-icon-box .crust-list-icon' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_icon_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list-icon-box .crust-list-icon' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_icon_size',
		    [
			    'label'     => esc_html__('Font Size', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 40,
			    ],
			    'range'     => [
				    'px' => [
					    'min' => 6,
					    'max' => 150,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list-icon-box .crust-list-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-list-icon-box .crust-list-icon img' => 'width: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'label'          => esc_html__('Number Typography', 'crust-core'),
			    'name'           => 'crust_list_number_typography',
			    'selector'       => '{{WRAPPER}} .crust-list-icon-box .crust-list-icon',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_icon_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_list_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_list_icon_tabs');

	    $this->start_controls_tab('normal_icon', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_control(
		    'crust_list_icon_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#B9D114',
			    'selectors' => [
				    '{{WRAPPER}} .crust-list .crust-list-icon' => 'color: {{VALUE}};',
			    ],
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_list_icon_background',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner'
		    ]
	    );

	    $this->add_control(
		    'crust_list_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'button_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start title dark mode
	     * ------------------------------
	     */
	    $this->add_responsive_control(
		    'crust_section_list_style_dark_normal_icon',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_list_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-list .crust-list-icon' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_list_icon_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-icon-box .crust-list-icon-inner'
		    ]
	    );

	    /**
	     * ------------------------------
	     *end title dark mode
	     * ------------------------------
	     */

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_list_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'crust_list_icon_hover_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon' => 'color: {{VALUE}};',
			    ],
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_list_icon_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_icon_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon-box .crust-list-icon-inner'
		    ]
	    );

	    $this->add_control(
		    'crust_list_icon_border_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon-box .crust-list-icon-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'button_box_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start title dark mode hover
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'crust_section_list_style_dark_hover_icon',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_list_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_list_icon_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'exclude'  => [
				    'image',
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon-box .crust-list-icon-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_icon_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .crust-list-item:hover .crust-list-icon-box .crust-list-icon-inner'
		    ]
	    );

	    /**
	     * ------------------------------
	     *end title dark mode hover
	     * ------------------------------
	     */

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Feature List Content Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_list_style_content',
            [
                'label' => esc_html__('Content', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
	    $this->add_control(
		    'crust_list_content_tag',
		    [
			    'label'     => esc_html__('HTML Tag', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => [
				    'h1'   => 'H1',
				    'h2'   => 'H2',
				    'h3'   => 'H3',
				    'h4'   => 'H4',
				    'h5'   => 'H5',
				    'h6'   => 'H6',
				    'div'  => 'div',
				    'span' => 'span',
				    'p'    => 'p',
			    ],
			    'default'   => 'p',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_list_text_align',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'    => [
					    'title' => __('Left', 'elementor'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'  => [
					    'title' => __('Center', 'elementor'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'   => [
					    'title' => __('Right', 'elementor'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list-content-box' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_list_description_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-list-content-box .crust-list-content' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'           => 'crust_list_description_typography',
                'selector'       => '{{WRAPPER}} .crust-list-content-box .crust-list-content',
            ]
        );

	    /**
	     * ------------------------------
	     *start content dark mode
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'crust_section_list_style_dark_content',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_list_description_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-list-content-box .crust-list-content' => 'color: {{VALUE}};',
			    ]
		    ]
	    );

	    /**
	     * ------------------------------
	     *end content dark mode
	     * ------------------------------
	     */

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Feature List Connector Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_list_style_connector',
            [
                'label' => esc_html__('Connector', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition'   => [
                    'crust_list_connector' => 'yes',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_connector_color',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .connector',
		    ]
	    );

        $this->add_control(
            'crust_list_connector_width',
            [
                'label'     => esc_html__('Width', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'px' => [
	                'min' => 1,
	                'max' => 1000,
                ],
                '%' => [
	                'min' => 1,
	                'max' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-list .connector' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_list_connector_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'px' => [
				    'min' => 1,
				    'max' => 1000,
			    ],
			    '%' => [
				    'min' => 1,
				    'max' => 100,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list .connector' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_list_connector_top',
		    [
			    'label'     => esc_html__('Top Offset', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'     => [
				    'px' => [
					    'min' => 1,
					    'max' => 1000,
				    ],
				    '%' => [
					    'min' => 1,
					    'max' => 100,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-list .connector' => 'top: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_connector_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-list .connector'
		    ]
	    );

	    $this->add_control(
		    'crust_list_connector_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-list .connector' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_list_connector_shadow',
			    'selector' => '{{WRAPPER}} .crust-list .connector',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start connector dark mode
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'crust_section_list_style_dark_connector',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_list_connector_dark_color',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .connector',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_list_connector_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-list .connector'
		    ]
	    );
	    /**
	     * ------------------------------
	     *end connector dark mode
	     * ------------------------------
	     */

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $last_border = ($settings['remove_border'] === 'yes' ) ? 'no-last-border' : '';
	    $icon_anim = ($settings['media_hover_animation'] ) ? 'crust-list-anim-' . $settings['media_hover_animation'] : '';

        $this->add_render_attribute(
            'crust_list',
            [
                'id'    => 'crust-list-' . esc_attr($this->get_id()),
                'class' => [
                    'crust-list',
	                $icon_anim,
	                $last_border,
                ]
            ]
        );

        $this->add_render_attribute('crust_list_item', 'class', 'crust-list-item');

        $html = '<ul '. $this->get_render_attribute_string('crust_list') .'>';
            $i = 0;
            foreach ($settings['crust_list'] as $index => $item) {

                $this->add_render_attribute('crust_list_icon' . $i, 'class', 'crust-list-icon');
                $this->add_render_attribute('crust_list_title' . $i, 'class', 'crust-list-title');
                $this->add_render_attribute('crust_list_content' . $i, 'class', 'crust-list-content');

                $title_tag = $settings['crust_list_title_tag'];
	            $content_tag = $settings['crust_list_content_tag'];

                if ($item['crust_list_link']['url']) {
                    $this->add_render_attribute('crust_list_title_anchor' . $i, 'href', esc_url($item['crust_list_link']['url']));

                    if ($item['crust_list_link']['is_external']) {
                        $this->add_render_attribute('crust_list_title_anchor' . $i, 'target', '_blank');
                    }

                    if ($item['crust_list_link']['nofollow']) {
                        $this->add_render_attribute('crust_list_title_anchor' . $i, 'rel', 'nofollow');
                    }
                }

                $feature_icon_tag = 'span';

                if ($item['crust_list_link']['url']) {
                    $this->add_render_attribute('crust_list_link' . $i, 'href', $item['crust_list_link']['url']);

                    if ($item['crust_list_link']['is_external']) {
                        $this->add_render_attribute('crust_list_link' . $i, 'target', '_blank');
                    }

                    if ($item['crust_list_link']['nofollow']) {
                        $this->add_render_attribute('crust_list_link' . $i, 'rel', 'nofollow');
                    }
                    $feature_icon_tag = 'a';
                }

	            $media_html = '<div class="crust-list-icon-box">';
		            $media_html .= '<div class="crust-list-icon-inner">';

			            $media_html .= '<' . $feature_icon_tag . ' ' . $this->get_render_attribute_string('crust_list_icon' . $i) . ' ' .$this->get_render_attribute_string('crust_list_link' . $i).'>';

			            if ( $item['crust_list_icon_type'] == 'icon' && isset($item['crust_list_icon']) ) {

				            if ( isset($item['crust_list_icon']['value']['url'])) {
					            $media_html .= '<img src="' . esc_url($item['crust_list_icon']['value']['url']) . '" alt="' . esc_attr(get_post_meta($item['crust_list_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
				            } else {
					            $media_html .= '<i class="' . esc_attr($item['crust_list_icon']['value']) . '" aria-hidden="true"></i>';
				            }

			            } else if ($item['crust_list_icon_type'] == 'image') {

				            $this->add_render_attribute(
					            'feature_list_image' . $i,
					            [
						            'src'   => esc_url($item['crust_list_img']['url']),
						            'class' => 'crust-list-img',
						            'alt'   => esc_attr(get_post_meta($item['crust_list_img']['id'], '_wp_attachment_image_alt', true))
					            ]
				            );

				            $media_html .= '<img ' . $this->get_render_attribute_string('feature_list_image' . $i) . '>';

			            } else if ($item['crust_list_icon_type'] == 'number') {

				            $media_html .= '<span>'. $item['crust_list_number'] .'</span>';
			            }

	                    $media_html .= '</'.$feature_icon_tag.'>';

			        $media_html .= '</div>';
		            if ('yes' == $settings['crust_list_connector']) {
			            $media_html .= '<span class="connector"></span>';
		            }
	            $media_html .= '</div>';

                $html .= '<li class="crust-list-item">';

                    $html .= ( $settings['crust_list_icon_position'] == 'left' ) ? $media_html : '';

                    $html .= '<div class="crust-list-content-box">';

						if( $item['crust_list_title'] ){
							$html .= '<' . $title_tag . ' ' . $this->get_render_attribute_string('crust_list_title' . $i) .'>';

								$html .= (! empty($item['crust_list_link']['url'])) ? "<a {$this->get_render_attribute_string('crust_list_title_anchor'.$i)}>" : '';
									$html .= $item['crust_list_title'];
								$html .= (! empty($item['crust_list_link']['url'])) ? "</a>" : '';

							$html .= '</'.$title_tag.'>';
						}

	                    if( $item['crust_list_content'] ) {
		                    $html .= '<'.$content_tag.' ' . $this->get_render_attribute_string( 'crust_list_content' . $i ) . '>' . $item['crust_list_content'] . '</'.$content_tag.'>';
	                    }

                    $html .= '</div>';

	                $html .= ( $settings['crust_list_icon_position'] == 'right' ) ? $media_html : '';

                $html .= '</li>';
            $i++;
        }

        $html .= '</ul>';

        echo $html;

    }

    protected function _content_template() { }
}
