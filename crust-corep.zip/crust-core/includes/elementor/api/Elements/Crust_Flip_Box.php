<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Flip_Box extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-flip-box', false, true);
        return ['crust-flip-box'];
    }

    public function get_name()
    {
        return 'crust-flip-box';
    }

    public function get_title()
    {
        return esc_html__('Flip Box', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-flip-box';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Flipbox Image Settings
         */
        $this->start_controls_section(
            'crust_core_section_flipbox_content_settings',
            [
                'label' => esc_html__('Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_core_flipbox_type',
            [
                'label'       => esc_html__('Type', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'animate-left',
                'label_block' => false,
                'options'     => [
                    'animate-left'     => esc_html__('Flip Left', 'crust-core'),
                    'animate-right'    => esc_html__('Flip Right', 'crust-core'),
                    'animate-up'       => esc_html__('Flip Top', 'crust-core'),
                    'animate-down'     => esc_html__('Flip Bottom', 'crust-core'),
                    'animate-push crust-animate-slide-up'     => esc_html__('Push Up', 'crust-core'),
                    'animate-push crust-animate-slide-down'     => esc_html__('Push Down', 'crust-core'),
                    'animate-push crust-animate-slide-left'     => esc_html__('Push Left', 'crust-core'),
                    'animate-push crust-animate-slide-right'     => esc_html__('Push Right', 'crust-core'),
                    'animate-zoom-in'  => esc_html__('Zoom In', 'crust-core'),
                    'animate-zoom-out' => esc_html__('Zoom Out', 'crust-core'),
                ],
            ]
        );

        $this->start_controls_tabs('icon_image_front_back');

        $this->start_controls_tab(
            'front',
            [
                'label' => __('Front', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_core_flipbox_img_or_icon',
            [
                'label'   => esc_html__('Icon Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'none' => __('None', 'crust-core'),
                    'img'  => __('Image', 'crust-core'),
                    'icon' => __('Icon', 'elementor')
                ],
                'default' => 'icon',
            ]
        );

        $this->add_control(
            'crust_core_flipbox_image',
            [
                'label'     => esc_html__('Image', 'crust-core'),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'crust_core_flipbox_img_or_icon' => 'img'
                ]
            ]
        );

        $this->add_control(
            'crust_core_flipbox_icon_new',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-award',
                    'library' => 'fontawesome',
                ],
                'condition'        => [
                    'crust_core_flipbox_img_or_icon' => 'icon'
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_core_flipbox_image_resizer',
            [
                'label'     => esc_html__('Image Resizer', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => '100'
                ],
                'range'     => [
                    'px' => [
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image > img.crust-flipbox-image-as-icon' => 'width: {{SIZE}}{{UNIT}};'
                ],
                'condition' => [
                    'crust_core_flipbox_img_or_icon' => 'img'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'thumbnail',
                'default'   => 'full',
                'condition' => [
                    'crust_core_flipbox_image[url]!' => '',
                    'crust_core_flipbox_img_or_icon' => 'img'
                ],
            ]
        );




	    $this->end_controls_tab();

        $this->start_controls_tab(
            'back',
            [
                'label' => __('Back', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_core_flipbox_img_or_icon_back',
            [
                'label'   => esc_html__('Icon Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'none' => __('None', 'crust-core'),
                    'img'  => __('Image', 'crust-core'),
                    'icon' => __('Icon', 'elementor')
                ],
                'default' => 'icon'
            ]
        );

        $this->add_control(
            'crust_core_flipbox_image_back',
            [
                'label'     => esc_html__('Image', 'crust-core'),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'crust_core_flipbox_img_or_icon_back' => 'img'
                ]
            ]
        );

        $this->add_control(
            'crust_core_flipbox_icon_back_new',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
	                'value'   => 'fad fa-box-full',
	                'library' => 'fontawesome',
                ],
                'condition'        => [
                    'crust_core_flipbox_img_or_icon_back' => 'icon'
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_core_flipbox_image_resizer_back',
            [
                'label'     => esc_html__('Image Resizer', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => '100'
                ],
                'range'     => [
                    'px' => [
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image > img.crust-flipbox-image-as-icon' => 'width: {{SIZE}}{{UNIT}};'
                ],
                'condition' => [
                    'crust_core_flipbox_img_or_icon_back' => 'img'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'thumbnail_back',
                'default'   => 'full',
                'condition' => [
                    'crust_core_flipbox_image[url]!'      => '',
                    'crust_core_flipbox_img_or_icon_back' => 'img'
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * Flipbox Content
         */
        $this->start_controls_section(
            'crust_core_flipbox_content',
            [
                'label' => esc_html__('Content', 'crust-core'),
            ]
        );

        $this->start_controls_tabs('crust_core_flipbox_content_tabs');

        $this->start_controls_tab(
            'crust_core_flipbox_content_front',
            [
                'label' => __('Front', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_core_flipbox_front_title',
            [
                'label'       => esc_html__('Front Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Awesome Designs', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_title_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h5',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_core_flipbox_front_text',
            [
                'label'       => esc_html__('Front Text', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => __('Mauris in quam tristique, dignissim urna felis.', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_content_alignment',
		    [
			    'label'        => esc_html__('Content Alignment', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'default'      => 'center',
			    'selectors' => [
				    '{{WRAPPER}} .crust-flip-box .crust-flip-front-wrap' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'flipbox_front_content_v_align',
		    [
			    'label'        => esc_html__('Vertical Align', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    'flex-start'   => [
					    'title' => esc_html__('Top', 'crust-core'),
					    'icon'  => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-v-align-middle',
				    ],
				    'flex-end'  => [
					    'title' => esc_html__('Bottom', 'crust-core'),
					    'icon'  => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-flip-box .crust-flip-front-wrap' => 'align-items: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_tab();


        $this->start_controls_tab(
            'crust_core_flipbox_content_back',
            [
                'label' => __('Back', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_core_flipbox_back_title',
            [
                'label'       => esc_html__('Back Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Cleaner Code', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_rear_title_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h5',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_core_flipbox_back_text',
            [
                'label'       => esc_html__('Back Text', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => __('Mauris in quam tristique, dignissim urna felis.', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_back_content_alignment',
		    [
			    'label'        => esc_html__('Content Alignment', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'default'      => 'center',
			    'selectors' => [
				    '{{WRAPPER}} .crust-flip-box .crust-flip-back-wrap' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'flipbox_back_content_v_align',
		    [
			    'label'        => esc_html__('Vertical Align', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => true,
			    'options'      => [
				    'flex-start'   => [
					    'title' => esc_html__('Top', 'crust-core'),
					    'icon'  => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-v-align-middle',
				    ],
				    'flex-end'  => [
					    'title' => esc_html__('Bottom', 'crust-core'),
					    'icon'  => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-flip-box .crust-flip-back-wrap' => 'align-items: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * ----------------------------------------------
         * Flipbox Link
         * ----------------------------------------------
         */
        $this->start_controls_section(
            'crust_core_flixbox_link_section',
            [
                'label' => esc_html__('Link', 'elementor')
            ]
        );

        $this->add_control(
            'flipbox_link_type',
            [
                'label'   => __('Link Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none'   => __('None', 'crust-core'),
                    'title'  => __('Title', 'crust-core'),
                    'button' => __('Button', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'flipbox_link',
            [
                'label'       => __('Link', 'elementor'),
                'type'        => Controls_Manager::URL,
                'placeholder' => 'https://www.your-link.com',
                'default'     => [
                    'url' => '#',
                ],
                'condition'   => [
                    'flipbox_link_type!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'flipbox_button_text',
            [
                'label'     => __('Button Text', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'dynamic'   => [
                    'active' => true,
                ],
                'default'   => __('Get Started', 'crust-core'),
                'condition' => [
                    'flipbox_link_type' => 'button',
                ],
            ]
        );

        $this->add_control(
            'button_icon_new',
            [
                'label'            => __('Button Icon', 'crust-core'),
                'type'             => Controls_Manager::ICONS,
                'condition'        => [
                    'flipbox_link_type' => 'button',
                ],
            ]
        );

        $this->add_control(
            'button_icon_position',
            [
                'label'     => __('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'after',
                'options'   => [
                    'after'  => __('After', 'crust-core'),
                    'before' => __('Before', 'crust-core'),
                ],
                'condition' => [
                    'flipbox_link_type' => 'button',
                    'button_icon!'      => '',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Flipbox Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_core_section_flipbox_style_settings',
            [
                'label' => esc_html__('Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 250
			    ],
			    'range'     => [
				    'px' => [
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-flip-box' => 'height: {{SIZE}}px;',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_flipbox_wrap_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-padding' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_core_flipbox_styling_tabs');

	    $this->start_controls_tab(
		    'crust_core_flipbox_styling_front',
		    [
			    'label' => __('Front', 'crust-core')
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_front_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-flip-front-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_flipbox_front_padding',
		    [
			    'label'      => esc_html__('Content Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_filbpox_border',
			    'label'    => esc_html__('Border Style', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-flip-front-wrap',
		    ]
	    );

	    $this->add_control(
		    'crust_core_flipbox_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_core_flipbox_shadow',
			    'selector' => '{{WRAPPER}} .crust-flip-front-wrap'
		    ]
	    );
		$this->add_responsive_control(
	    'crust_core_section_flipbox_style_dark_settings',
	    [
		    'label'      => esc_html__('Dark Mode', 'elementor'),
		    'type'       => Controls_Manager::HEADING,
		    'separator'   => 'before',

	    ]
    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_front_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap',
		    ]
	    );



	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_filbpox_dark_border',
			    'label'    => esc_html__('Border Style', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap',
		    ]
	    );




	    $this->end_controls_tab();

	    $this->start_controls_tab(
		    'crust_core_flipbox_styling_back',
		    [
			    'label' => __('Back', 'crust-core')
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_back_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-flip-back-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_flipbox_back_padding',
		    [
			    'label'      => esc_html__('Content Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-back-wrap'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_filbpox_back_border',
			    'label'    => esc_html__('Border Style', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-flip-back-wrap',
		    ]
	    );

	    $this->add_control(
		    'crust_core_flipbox_back_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-back-wrap'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_core_flipbox_back_shadow',
			    'selector' => '{{WRAPPER}} .crust-flip-back-wrap'
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_core_flipbox_styling_dark_back',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_back_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_core_filbpox_back_dark_border',
			    'label'    => esc_html__('Border Style', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->end_controls_tabs();





	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Flip Box Icon Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_core_section_flipbox_icon_style_settings',
            [
                'label'     => esc_html__('Icon Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('crust_core_section_icon_style_settings');
        $this->start_controls_tab(
            'crust_core_section_icon_front_style_settings',
            [
                'label' => esc_html__('Front', 'crust-core')
            ]
        );

        /**
         * Icon
         */
        $this->add_control(
            'crust_core_flipbox_front_icon_heading',
            [
                'label'     => esc_html__('Icon Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'crust_core_flipbox_front_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_core_flipbox_img_or_icon' => 'icon'
                ]
            ]
        );

        $this->add_control(
            'crust_core_flipbox_front_icon_size',
            [
                'label'      => esc_html__('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'step' => 1,
                        'max'  => 300,
                    ],
                ],
                'selectors'  => [
	                '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
	                '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image i' => 'line-height: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'crust_core_flipbox_img_or_icon' => 'icon'
                ]
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_front_icon_font_size',
		    [
			    'label'      => esc_html__('Font Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'default'    => [
				    'size' => 50,
				    'unit' => 'px'
			    ],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'step' => 1,
					    'max'  => 150,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image i' => 'font-size: {{SIZE}}{{UNIT}};',
			    ],
			    'condition'  => [
				    'crust_core_flipbox_img_or_icon' => 'icon'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_core_flipbox_front_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'crust_core_flipbox_icon_front_border',
                'label'     => esc_html__('Border', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image',
                'condition' => [
                    'crust_core_flipbox_img_or_icon' => 'icon'
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_core_flipbox_icon_front_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_icon_front_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};overflow: hidden;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_core_front_icon_flipbox_shadow',
			    'selector' => '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image'
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_core_section_flipbox_icon_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_core_flipbox_front_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_core_flipbox_img_or_icon' => 'icon'
			    ]
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_icon_front_dark_border',
			    'label'     => esc_html__('Border', 'crust-core'),
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap .crust-flip-icon-image',
			    'condition' => [
				    'crust_core_flipbox_img_or_icon' => 'icon'
			    ]
		    ]
	    );



	    $this->end_controls_tab();

        $this->start_controls_tab(
            'crust_core_section_icon_back_style_settings',
            [
                'label' => esc_html__('Back', 'crust-core')
            ]
        );

        /**
         * Icon
         */
        $this->add_control(
            'crust_core_flipbox_back_icon_heading',
            [
                'label'     => esc_html__('Icon Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'crust_core_flipbox_back_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_core_flipbox_img_or_icon_back' => 'icon'
                ]
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_back_icon_size',
		    [
			    'label'      => esc_html__('Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'step' => 1,
					    'max'  => 300,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image i' => 'line-height: {{SIZE}}{{UNIT}};',
			    ],
			    'condition'  => [
				    'crust_core_flipbox_img_or_icon' => 'icon'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_core_flipbox_back_icon_font_size',
            [
                'label'      => esc_html__('Font Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'default'    => [
                    'size' => 50,
                    'unit' => 'px'
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'step' => 1,
                        'max'  => 150,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image i'   => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'crust_core_flipbox_img_or_icon_back' => 'icon'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'crust_core_flipbox_back_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'crust_core_flipbox_icon_back_border',
                'label'     => esc_html__('Border', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image',
                'condition' => [
                    'crust_core_flipbox_img_or_icon' => 'icon'
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_core_flipbox_icon_back_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_icon_back_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};overflow: hidden;',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_core_back_icon_flipbox_shadow',
			    'selector' => '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image'
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_core_section_icon_back_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_core_flipbox_back_icon_dark_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_core_flipbox_img_or_icon_back' => 'icon'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'      => 'crust_core_flipbox_icon_back_dark_border',
			    'label'     => esc_html__('Border', 'crust-core'),
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap .crust-flip-icon-image',
			    'condition' => [
				    'crust_core_flipbox_img_or_icon' => 'icon'
			    ]
		    ]
	    );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Flip Box Title Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_core_section_flipbox_title_style_settings',
            [
                'label' => esc_html__('Color &amp; Typography', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->start_controls_tabs('crust_core_section_flipbox_typo_style_settings');
        $this->start_controls_tab(
            'crust_core_section_flipbox_typo_style_front_settings',
            [
                'label' => esc_html__('Front', 'crust-core')
            ]
        );

        /**
         * Title
         */
        $this->add_control(
            'crust_core_flipbox_front_title_heading',
            [
                'label' => esc_html__('Title Style', 'crust-core'),
                'type'  => Controls_Manager::HEADING
            ]
        );

        $this->add_control(
            'crust_core_flipbox_front_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-heading' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_core_flipbox_front_title_typography',
                'selector' => '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-heading'
            ]
        );

	    $this->add_responsive_control(
		    'crust_core_flipbox_front_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        /**
         * Content
         */
        $this->add_control(
            'crust_core_flipbox_front_content_heading',
            [
                'label' => esc_html__('Content Style', 'crust-core'),
                'type'  => Controls_Manager::HEADING
            ]
        );

        $this->add_control(
            'crust_core_flipbox_front_content_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-content' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_core_flipbox_front_content_typography',
                'selector' => '{{WRAPPER}} .crust-flip-front-wrap .crust-flip-content'
            ]
        );
	    $this->add_responsive_control(
		    'crust_core_section_flipbox_title_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_core_flipbox_front_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap .crust-flip-heading' => 'color: {{VALUE}};',
			    ]
		    ]
	    );


	    $this->add_control(
		    'crust_core_flipbox_front_content_dark_color',
		    [
			    'label'     => esc_html__('Content Style Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-front-wrap .crust-flip-content' => 'color: {{VALUE}};',
			    ]
		    ]
	    );



        $this->end_controls_tab();

        $this->start_controls_tab(
            'crust_core_section_flipbox_typo_style_back_settings',
            [
                'label' => esc_html__('Back', 'crust-core')
            ]
        );

        /**
         * Title
         */
        $this->add_control(
            'crust_core_flipbox_back_title_heading',
            [
                'label'     => esc_html__('Title Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_core_flipbox_back_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-heading' => 'color: {{VALUE}};',
                ]
            ]
        );



        /**
         * Content
         */
        $this->add_control(
            'crust_core_flipbox_back_content_heading',
            [
                'label'     => esc_html__('Content Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_core_flipbox_back_content_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-content' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_core_flipbox_back_content_typography',
                'selector' => '{{WRAPPER}} .crust-flip-back-wrap .crust-flip-content'
            ]
        );
	    $this->add_responsive_control(
		    'crust_core_section_flipbox_typo_style_back_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_core_flipbox_back_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap .crust-flip-heading' => 'color: {{VALUE}};',
			    ]
		    ]
	    );


	    $this->add_control(
		    'crust_core_flipbox_back_content_dark_color',
		    [
			    'label'     => esc_html__('Content Style Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-flip-back-wrap .crust-flip-content' => 'color: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->end_controls_tab();
        $this->end_controls_tabs();


        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Flip Box Button Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_core_section_flipbox_button_style_settings',
            [
                'label'     => esc_html__('Button Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'flipbox_link_type' => 'button'
                ]
            ]
        );

        $this->start_controls_tabs('flipbox_button_style_settings');

        $this->start_controls_tab(
            'flipbox_button_normal_style',
            [
                'label' => __('Normal', 'elementor')
            ]
        );
        $this->add_responsive_control(
            'crust_core_flipbox_button_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_core_flipbox_button_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );

        $this->add_control(
            'crust_core_flipbox_button_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_core_flipbox_button_bg_color',
            [
                'label'     => esc_html__('Background', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button' => 'background: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_core_flipbox_button_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-flip-box .flipbox-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_core_flipbox_button_typography',
                'selector' => '{{WRAPPER}} .crust-flip-box .flipbox-button'
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'flipbox_button_hover_style',
            [
                'label' => __('Hover', 'elementor')
            ]
        );
        $this->add_control(
            'crust_core_flipbox_button_hover_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_core_flipbox_button_hover_bg_color',
            [
                'label'     => esc_html__('Background', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .crust-flip-box .flipbox-button:hover' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render()
    {

        $settings          = $this->get_settings_for_display();
        $flipbox_image     = $this->get_settings('crust_core_flipbox_image');
        $flipbox_image_url = Group_Control_Image_Size::get_attachment_image_src($flipbox_image['id'], 'thumbnail', $settings);
	    $flipbox_image_url = (empty($flipbox_image_url)) ? $flipbox_image['url'] : $flipbox_image_url;

	    $title_tag = $settings[ 'crust_core_flipbox_title_tag' ];
	    $rear_title_tag = $settings[ 'crust_core_flipbox_rear_title_tag' ];

        $front_icon  = $settings['crust_core_flipbox_icon_new'];

        if ($settings['flipbox_link_type'] != 'none') {
            if ( ! empty($settings['flipbox_link']['url'])) {
                if ($settings['flipbox_link_type'] == 'title') {
                    $this->add_render_attribute(
                        'flipbox-link-container',
                        [
                            'class' => 'flipbox-linked-title',
                            'href'  => $settings['flipbox_link']['url']
                        ]
                    );

                    if ($settings['flipbox_link']['is_external']) {
                        $this->add_render_attribute('flipbox-link-container', 'target', '_blank');
                    }

                    if ($settings['flipbox_link']['nofollow']) {
                        $this->add_render_attribute('flipbox-link-container', 'rel', 'nofollow');
                    }
                } else if ($settings['flipbox_link_type'] == 'button') {
                    $this->add_render_attribute(
                        'flipbox-button-container',
                        [
                            'class' => 'flipbox-button',
                            'href'  => $settings['flipbox_link']['url']
                        ]
                    );

                    if ($settings['flipbox_link']['is_external']) {
                        $this->add_render_attribute('flipbox-button-container', 'target', '_blank');
                    }

                    if ($settings['flipbox_link']['nofollow']) {
                        $this->add_render_attribute('flipbox-button-container', 'rel', 'nofollow');
                    }
                }
            }
        }

		if ( isset($settings['crust_core_flipbox_image_back']) ){

        $flipbox_image_back     = $settings['crust_core_flipbox_image_back'];
        $flipbox_back_image_url = Group_Control_Image_Size::get_attachment_image_src($flipbox_image_back['id'], 'thumbnail_back', $settings);
        $flipbox_back_image_url = empty($flipbox_back_image_url) ? $flipbox_image_back['url'] : $flipbox_back_image_url;
        if ('img' == $settings['crust_core_flipbox_img_or_icon_back']) {
            $this->add_render_attribute(
                'flipbox-back-icon-image-container',
                [
                    'src' => $flipbox_back_image_url,
                    'alt' => esc_attr(get_post_meta($flipbox_image_back['id'], '_wp_attachment_image_alt', true))
                ]
            );
        }
		};

        $this->add_render_attribute(
            'crust_flip_container',
            [
                'class' => [
                    'crust-flip-box',
                    'crust-animate-flip',
                    'crust-' . esc_attr($settings['crust_core_flipbox_type'])
                ]
            ]
        );

        $html = '<div class="crust-flip-box-wrap">';

            $html .= '<div ' . ' ' . $this->get_render_attribute_string('crust_flip_container') .'>';
	            $html .= '<div class="crust-flip-front-wrap">';
	                $html .= '<div class="crust-flip-inner">';
                        $html .= '<div class="crust-flip-icon-image">';
                            if ( 'icon' === $settings['crust_core_flipbox_img_or_icon'] ) {
                                if ( $front_icon ) {
                                    if ( isset( $settings['crust_core_flipbox_icon_new']['value']['url'] ) ) {
                                        $html .= '<img class="crust-flipbox-svg-icon" src="' . esc_attr( $settings['crust_core_flipbox_icon_new']['value']['url'] ) . '"
                                             alt="' . esc_attr( get_post_meta( $settings['crust_core_flipbox_icon_new']['value']['id'], '_wp_attachment_image_alt', true ) ) . '"/>';
                                    } else {
                                        $html .= '<i class="' . esc_attr( $settings['crust_core_flipbox_icon_new']['value'] ) . '"></i>';
                                    }
                                }
                            } elseif ('img' === $settings['crust_core_flipbox_img_or_icon']) {
                                $html .= '<img class="crust-flipbox-image-as-icon" src="' . esc_url( $flipbox_image_url ) . '" alt="' . esc_attr( get_post_meta( $flipbox_image['id'], '_wp_attachment_image_alt', true ) ) . '">';
                            }
                        $html .= '</div>';
                        $html .= ( $settings['crust_core_flipbox_front_title'] != '' ) ? '<'.$title_tag .' class="crust-flip-heading">'. esc_html__($settings['crust_core_flipbox_front_title'], 'crust-core') .'</'.
                                                                                   $title_tag .'>' : '';
					    if( $settings['crust_core_flipbox_front_text'] ){
								    $html .= '<div class="crust-flip-content">';
								        $html .= $settings['crust_core_flipbox_front_text'];
								    $html .= '</div>';
							    }

                    $html .= '</div>';
                $html .= '</div>';

                $html .= '<div class="crust-flip-back-wrap">';
                    $html .= '<div class="crust-flip-inner">';
                        if ( 'none' != $settings['crust_core_flipbox_img_or_icon_back'] ) :
                            $html .= '<div class="crust-flip-icon-image">';
                                if ('img' == $settings['crust_core_flipbox_img_or_icon_back']) :
                                    $html .= '<img class="crust-flipbox-image-as-icon" '. $this->get_render_attribute_string('flipbox-back-icon-image-container') .'>';
                                elseif ('icon' == $settings['crust_core_flipbox_img_or_icon_back']):
                                    if ($front_icon) {
                                        if (isset($settings['crust_core_flipbox_icon_back_new']['value']['url'])) :
                                            $html .= '<img class="crust-flipbox-svg-icon" src="'. esc_attr($settings['crust_core_flipbox_icon_back_new']['value']['url']) .'"
                                                 alt="'. esc_attr(get_post_meta($settings['crust_core_flipbox_icon_back_new']['value']['id'], '_wp_attachment_image_alt', true)) .'"/>';
                                        else :
                                            $html .= '<i class="'. esc_attr($settings['crust_core_flipbox_icon_back_new']['value']) .'"></i>';
                                        endif;
                                    }
                                endif;
                            $html .= '</div>';
                        endif;

                        $html .=  ( $settings['flipbox_link_type'] == 'title' ) ? '<a' . ' ' . $this->get_render_attribute_string('flipbox-link-container') .'>' : '';
                            $html .= '<'. $rear_title_tag . ' class="crust-flip-heading">';
                                $html .= ( $settings['crust_core_flipbox_back_title'] ) ? esc_html__( $settings['crust_core_flipbox_back_title'], 'crust-core' ) : '';
                            $html .= '</'. $rear_title_tag .'>';
                        $html .=  ( $settings['flipbox_link_type'] == 'title' ) ? '</a>' : '';

                        if( $settings['crust_core_flipbox_back_text'] ){
                            $html .= '<div class="crust-flip-content">';
                                $html .= $settings['crust_core_flipbox_back_text'];
                            $html .= '</div>';
                        }

                        if ($settings['flipbox_link_type'] == 'button' && ! empty($settings['flipbox_button_text'])) {
                            $html .= '<a ' . $this->get_render_attribute_string( 'flipbox-button-container' ) . '>';
                            if ( 'before' == $settings['button_icon_position'] ) {
	                            if ( $settings['button_icon_new'] ) {
		                            $html .= '<i class="' . $settings['button_icon_new']['value'] . '"></i>';
	                            }
                            }
                            $html .= esc_attr( $settings['flipbox_button_text'] );
                            if ( 'after' == $settings['button_icon_position'] ) {
	                            if ( $settings['button_icon_new'] ) {
		                            $html .= '<i class="' . $settings['button_icon_new']['value'] . '"></i>';
	                            }
                            }
                            $html .= '</a>';
                        }
	                $html .= '</div>';
                $html .= '</div>';

	        $html .= '</div>';

	    $html .= '</div>';

	    echo $html;

    }

}
