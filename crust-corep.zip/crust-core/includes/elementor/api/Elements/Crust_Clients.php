<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Widget_Base;

class Crust_Clients extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-clients'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-clients', false, true);
        return ['crust-clients'];
    }

    public function get_name()
    {
        return 'crust-clients';
    }

    public function get_title()
    {
        return esc_html__('Clients', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-logo';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Content Settings
         */
        $this->start_controls_section(
            'crust_clients_settings',
            [
                'label' => esc_html__('Settings', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_client_type',
            [
                'label'       => esc_html__('Type', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'grid',
                'label_block' => false,
                'options'     => [
                    'grid'      => esc_html__('Grid', 'crust-core'),
                    'carousel'  => esc_html__('Carousel', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_client_row',
            [
                'label'       => esc_html__('Items Per Row', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => '4',
                'label_block' => false,
                'options'     => [
                    '1' => esc_html__('1 Client', 'crust-core'),
                    '2' => esc_html__('2 Clients', 'crust-core'),
                    '3' => esc_html__('3 Clients', 'crust-core'),
                    '4' => esc_html__('4 Clients', 'crust-core'),
                    '5' => esc_html__('5 Clients', 'crust-core'),
                    '6' => esc_html__('6 Clients', 'crust-core'),
                ],
                'condition' => [
                    'crust_client_type' => 'grid'
                ]
            ]
        );

	    $this->add_control(
		    'client_tablet',
		    [
			    'label'       => esc_html__('Tablet Items', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__('Default', 'crust-core'),
				    '1' => esc_html__('1 Client', 'crust-core'),
				    '2' => esc_html__('2 Clients', 'crust-core'),
				    '3' => esc_html__('3 Clients', 'crust-core'),
				    '4' => esc_html__('4 Clients', 'crust-core'),
				    '5' => esc_html__('5 Clients', 'crust-core'),
				    '6' => esc_html__('6 Clients', 'crust-core'),
			    ],
			    'condition' => [
				    'crust_client_type' => 'grid'
			    ]
		    ]
	    );

	    $this->add_control(
		    'client_mobile',
		    [
			    'label'       => esc_html__('Mobile Items', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__('Default', 'crust-core'),
				    '1' => esc_html__('1 Client', 'crust-core'),
				    '2' => esc_html__('2 Clients', 'crust-core'),
				    '3' => esc_html__('3 Clients', 'crust-core'),
				    '4' => esc_html__('4 Clients', 'crust-core'),
				    '5' => esc_html__('5 Clients', 'crust-core'),
				    '6' => esc_html__('6 Clients', 'crust-core'),
			    ],
			    'condition' => [
				    'crust_client_type' => 'grid'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_client_hover_animation',
		    [
			    'label'       => esc_html__('Hover Animation', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => '',
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__('None', 'crust-core'),
				    'slide' => esc_html__('Slide', 'crust-core'),
				    'scale-sm' => esc_html__('Scale Small', 'crust-core'),
				    'scale-lg' => esc_html__('Scale Large', 'crust-core'),
				    'tilt' => esc_html__('tilt', 'crust-core'),
				    'grayscale' => esc_html__("Grayscale",'crust'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'fade_others',
		    [
			    'label' => esc_html__( 'Fade Others', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
			    'default'       => 'yes',
		    ]
	    );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_client_img', [
			    'label'       => esc_html__('Image', 'crust-core'),
			    'type'        => Controls_Manager::MEDIA,
			    'label_block' => true,
			    'default'     => [
				    'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_client_name', [
			    'label'       => esc_html__('Name', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Name', 'crust-core'),
			    'dynamic'     => ['active' => true],
		    ]
	    );

	    $repeater->add_control(
		    'crust_client_link', [
			    'label'         => esc_html__('Link', 'crust-core'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'default'       => [
				    'url'         => '#',
				    'is_external' => '',
			    ],
			    'show_external' => true,
		    ]
	    );

        $this->add_control(
            'crust_client_imgs',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_client_name}}',
            ]
        );

        $this->add_responsive_control(
            'crust_client_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'flex-start' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'     => 'center',
                'selectors'   => [
                    '{{WRAPPER}} .crust-clients-wrap' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->crust_core_slider_settings( 'crust_client_type' );

        /**
         * -------------------------------------------
         * Tab Style
         * -------------------------------------------
         */
	    $this->start_controls_section(
		    'crust_client_wrap_settings',
		    [
			    'label' => esc_html__('Wrapper Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_client_wrap_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-clients-wrap,{{WRAPPER}} .crust-carousel .swiper-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_client_wrap_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-clients-wrap,{{WRAPPER}} .crust-carousel .swiper-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_section();
///normal////
        $this->start_controls_section(
            'crust_client_style_settings',
            [
                'label' => esc_html__('Item Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'crust_client_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-client-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_client_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-client-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->start_controls_tabs('crust_client_tabs');

        $this->start_controls_tab('client_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'client_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-client-item'
		    ]
	    );


        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'client_border',
                'selector' => '{{WRAPPER}} .crust-client-item',
            ]
        );

        $this->add_responsive_control(
            'client_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-client-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'client_box_shadow',
                'selector' => '{{WRAPPER}} .crust-client-item',
            ]
        );
	    //////normal heading//////
	    $this->add_responsive_control(
		    'crust_client_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'client_normal_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-client-item'
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-client-item',
		    ]
	    );

	    ////////////

        $this->end_controls_tab();
///hover///
        $this->start_controls_tab('client_hover', ['label' => esc_html__('Hover', 'elementor')]);


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'client_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-client-item:hover'
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'client_hover_border',
                'selector' => '{{WRAPPER}} .crust-client-item:hover',
            ]
        );

        $this->add_responsive_control(
            'client_border_hover_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-client-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'client_hover_box_shadow',
                'selector' => '{{WRAPPER}} .crust-client-item:hover',
            ]
        );
	    //////hover heading//////
	    $this->add_responsive_control(
		    'crust_client_style_hover_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'client_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-client-item:hover'
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'client_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-client-item:hover',
		    ]
	    );

	    ////////////

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->crust_core_slider_styling('crust_client_type');

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rows = 'crust-grid-rows-' . $settings['crust_client_row'];
	    $others = ( $settings['fade_others'] == 'yes' ) ? ' crust-fade-others' : '';
        $hover = ( '' !== $settings['crust_client_hover_animation'] ) ? 'crust-clients-hover-' . $settings['crust_client_hover_animation'] : '';
        $this->add_render_attribute('crust-clients', 'class', [
            'crust-clients-wrap',
            $hover,
            $rows,
            $others
        ]);

	    if( $settings['client_tablet'] ){
		    $this->add_render_attribute('crust-clients', 'data-items-tab', $settings['client_tablet']);
	    }

	    if( $settings['client_mobile'] ){
		    $this->add_render_attribute('crust-clients', 'data-items-mob', $settings['client_mobile']);
	    }

        $this->add_render_attribute('crust_carousel', 'class', [
            'swiper-container',
	        $hover,
	        $others,
            'crust-carousel',
        ]);
        $html = '';
        if( 'carousel' === $settings['crust_client_type'] ) {
            $this->crust_core_slider_attributes();
            $html .= '<div class="crust-carousel-wrapper">';
                $html .= '<div ' . $this->get_render_attribute_string('crust_carousel') . '>';

                    $html .= '<div class="swiper-wrapper">';
                        $html .= $this->_render_client($settings);
                    $html .= '</div>';

           //     $html .= $this->crust_carousel_nav();
	         $html .=  apply_filters('crust_carousel_nav_site',$settings);


	        $html .= '</div>';
            $html .= '</div>';

        } else {
            $html = '<div ' . $this->get_render_attribute_string('crust-clients') . '>';
                $html .= $this->_render_client($settings);
            $html .= '</div>';
        }

        echo $html;


    }

    protected function _render_client($settings)
    {
        $class   = ( 'carousel' === $settings['crust_client_type'] ) ? ' swiper-slide' : '';
        $class  .= ( $settings['crust_client_hover_animation'] === 'tilt' ) ? ' js-tilt' : '';
        $html = '';
        foreach ($settings['crust_client_imgs'] as $client_img) {
            $src      = $client_img['crust_client_img']['url'];
            $name     = $client_img['crust_client_name'];
            $link     = $client_img['crust_client_link']['url'];
            $target   = $client_img['crust_client_link']['is_external'] ? 'target="_blank"' : '';
            $nofollow = $client_img['crust_client_link']['nofollow'] ? 'rel="nofollow"' : '';
            $html .= '<div class="crust-client-item'.$class.'">';
                $html .= '<a href="' . esc_url($link) . '" ' . $target . ' ' . $nofollow . '>';
                    $html .= ( $settings['crust_client_hover_animation'] == 'slide' ) ? '<img alt="'. esc_attr($name) .'" src="'.esc_url($src).'" class="crust-hidden-client" />' : '';
                    $html .= '<img alt="'. esc_attr($name) .'" src="'.esc_url($src).'" class="crust-img-client" />';
                $html .= '</a>';
            $html .= '</div>';
        }

        return $html;

    }

}
