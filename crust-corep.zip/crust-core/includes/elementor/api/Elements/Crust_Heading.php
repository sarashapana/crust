<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Heading extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-heading';
    }

    public function get_title()
    {
        return esc_html__('Heading', 'crust-core');
    }

	public function get_icon()
	{
		return 'eicon-animated-headline';
	}

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Heading Content Settings
         */
        $this->start_controls_section(
            'crust_section_head_content_settings',
            [
                'label' => esc_html__('Content Settings', 'crust-core')
            ]
        );

	    $this->add_control(
		    'crust_head_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    ''       => esc_html__('Default', 'crust-core'),
				    'style1' => esc_html__('Head Line', 'crust-core'),
				    'style5' => esc_html__('Rectangle', 'crust-core'),
				    'style6' => esc_html__('Two Rectangles', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_head_last_title',
            [
                'label'       => esc_html__('Text', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => esc_html__('Crust Heading Element', 'crust-core'),
                'dynamic'     => ['action' => true]
            ]
        );

	    $this->add_control(
		    'crust_head_link',
		    [
			    'label'     => esc_html__('Link', 'elementor'),
			    'type'      => Controls_Manager::URL,
			    'placeholder' => __( 'Paste URL or type', 'crust-core' ),
			    'show_external' => true,
			    'default' => [
				    'url' => '',
			    ],
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style ( Heading Style )
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_head_style_settings',
            [
                'label' => esc_html__('Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_head_content_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'default'      => 'center',
			    'selectors' => [
				    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_head_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h2',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_head_base_title_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-heading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_head_first_title_typography',
                'selector' => '{{WRAPPER}} .crust-heading, {{WRAPPER}} .crust-heading span',
            ]
        );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_head_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_head_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_head_border',
			    'selector' => '{{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_control(
		    'crust_head_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-heading' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_head_shadow',
			    'selector' => '{{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_section_head_style_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_head_base_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-heading' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_head_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-heading',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_head_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-heading',
		    ]
	    );

        $this->end_controls_section();

	    // Line
	    $this->start_controls_section(
		    'crust_head_line_styles',
		    [
			    'label' => esc_html__('Lines Styling', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition'    => [
				    'crust_head_style!' => ['','style6'],
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_head_line_fill',
		    [
			    'label'     => esc_html__('Fill Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line path' => 'fill: {{VALUE}};',
				    '{{WRAPPER}} .crust-heading.crust-head-style5 .head-svg-line rect' => 'fill: {{VALUE}};',
			    ],
			    'condition'    => [
				    'crust_head_style!' => ['','style5'],
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_head_rect_fill',
		    [
			    'label'     => esc_html__('Background Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-heading.crust-head-style5 .head-svg-line.head-rectangle' => 'background-color: {{VALUE}};',
			    ],
			    'condition'    => [
				    'crust_head_style' => 'style5',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_size',
		    [
			    'label' => esc_html__( 'Size', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'default' => [
				    'size' => 170,
				    'unit' => 'px',
			    ],
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line' => 'width: {{SIZE}}{{UNIT}};'
			    ],
			    'condition'    => [
				    'crust_head_style!' => ['','style5'],
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_width',
		    [
			    'label' => esc_html__( 'Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'default' => [
				    'size' => 170,
				    'unit' => 'px',
			    ],
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line.head-rectangle' => 'width: {{SIZE}}{{UNIT}};'
			    ],
			    'condition'    => [
				    'crust_head_style' => 'style5',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_height',
		    [
			    'label' => esc_html__( 'Height', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line.head-rectangle' => 'height: {{SIZE}}{{UNIT}};'
			    ],
			    'condition'    => [
				    'crust_head_style' => 'style5',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line.head-rectangle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'crust_head_style' => 'style5'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_head_line_shadow',
			    'selector' => '{{WRAPPER}} .head-svg-line.head-rectangle',
			    'condition' => [
				    'crust_head_style' => 'style5'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_rotate',
		    [
			    'label' => __( 'Rotate', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'deg' => [
					    'min' => -360,
					    'max' => 360,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => [ 'deg' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line' => 'transform: rotate({{SIZE}}deg)',
			    ],
		    ]
	    );

	    $start = is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );
	    $end = ! is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );

	    $this->add_control(
		    'crust_head_line_offset_orientation_h',
		    [
			    'label' => __( 'Horizontal Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'options' => [
				    'start' => [
					    'title' => $start,
					    'icon' => 'eicon-h-align-left',
				    ],
				    'end' => [
					    'title' => $end,
					    'icon' => 'eicon-h-align-right',
				    ],
			    ],
			    'classes' => 'elementor-control-start-end',
			    'render_type' => 'ui',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_offset_x',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .head-svg-line' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .head-svg-line' => 'left:auto;right: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_line_offset_orientation_h!' => 'end',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_offset_x_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .head-svg-line' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .head-svg-line' => 'right:auto;left: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_line_offset_orientation_h' => 'end',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_head_line_offset_orientation_v',
		    [
			    'label' => __( 'Vertical Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'options' => [
				    'start' => [
					    'title' => __( 'Top', 'elementor' ),
					    'icon' => 'eicon-v-align-top',
				    ],
				    'end' => [
					    'title' => __( 'Bottom', 'elementor' ),
					    'icon' => 'eicon-v-align-bottom',
				    ],
			    ],
			    'render_type' => 'ui',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_offset_y',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line' => 'top: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_line_offset_orientation_v!' => 'end',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_line_offset_y_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-line' => 'top:auto;bottom: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_line_offset_orientation_v' => 'end',
			    ],
		    ]
	    );

	    $this->add_control(
		    'line_index',
		    [
			    'label'      => esc_html__('Z-index', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'range'      => [
				    'px' => [
					    'max' => 100,
					    'min' => -100,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .head-svg-line' => 'z-index: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    // Style 6 Image
	    $this->start_controls_section(
		    'crust_head_img_styles',
		    [
			    'label' => esc_html__('Style 6 Image Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition'    => [
				    'crust_head_style' => 'style6',
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_head_img_fill',
		    [
			    'label'     => esc_html__('Fill Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-img path' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_size',
		    [
			    'label' => esc_html__( 'Size', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-img' => 'width: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_rotate',
		    [
			    'label' => __( 'Rotate', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'deg' => [
					    'min' => -360,
					    'max' => 360,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => [ 'deg' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-img' => 'transform: rotate({{SIZE}}deg)',
			    ],
		    ]
	    );

	    $starts = is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );
	    $ends = ! is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );

	    $this->add_control(
		    'crust_head_img_offset_orientation_h',
		    [
			    'label' => __( 'Horizontal Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'options' => [
				    'start' => [
					    'title' => $starts,
					    'icon' => 'eicon-h-align-left',
				    ],
				    'end' => [
					    'title' => $ends,
					    'icon' => 'eicon-h-align-right',
				    ],
			    ],
			    'classes' => 'elementor-control-start-end',
			    'render_type' => 'ui',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_offset_x',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .head-svg-img' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .head-svg-img' => 'left:auto;right: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_img_offset_orientation_h!' => 'end',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_offset_x_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .head-svg-img' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .head-svg-img' => 'right:auto;left: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_img_offset_orientation_h' => 'end',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_head_img_offset_orientation_v',
		    [
			    'label' => __( 'Vertical Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'options' => [
				    'start' => [
					    'title' => __( 'Top', 'elementor' ),
					    'icon' => 'eicon-v-align-top',
				    ],
				    'end' => [
					    'title' => __( 'Bottom', 'elementor' ),
					    'icon' => 'eicon-v-align-bottom',
				    ],
			    ],
			    'render_type' => 'ui',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_offset_y',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-img' => 'top: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_img_offset_orientation_v!' => 'end',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_head_img_offset_y_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .head-svg-img' => 'top:auto;bottom: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_head_img_offset_orientation_v' => 'end',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_head_bg_settings',
		    [
			    'label' => esc_html__('Text Effects', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'head_use_bg',
		    [
			    'label'        => __('Use Background', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'head_bg_type',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-heading',
			    'condition'        => [
				    'head_use_bg' => 'yes',
			    ],
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_head_bg_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',
			    'condition'        => [
				    'head_use_bg' => 'yes',
			    ],

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'head_bg_dark_type',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-heading',
			    'condition'        => [
				    'head_use_bg' => 'yes',
			    ],
		    ]
	    );
	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
		$class    = 'crust-heading';
	    $class   .= ( $settings['crust_head_style'] ) ? ' crust-head-' . $settings['crust_head_style'] : '';
		$class   .= ( $settings['head_use_bg'] === 'yes' ) ? ' crust-heading-with-bg' : '';
		$tag      = $settings['crust_head_tag'];
	    $target   = $settings['crust_head_link']['is_external'] ? ' target="_blank"' : '';
	    $nofollow = $settings['crust_head_link']['nofollow'] ? ' rel="nofollow"' : '';
	    $link     = ( $settings['crust_head_link']['url'] ) ? $settings['crust_head_link']['url'] : '';

	    switch ($settings['crust_head_style']){
		    case 'style1':
			    $svg = '<svg xmlns="http://www.w3.org/2000/svg" class="head-svg-line" viewBox="0 0 247.12 10.96"><path d="M83.33,1.5C98.63,1.08,113.9,0,129.22,0c15,.25,30,0,45,.21,6.1.73,12.25,0,18.34.76,10.9,1.1,21.83,2.25,32.79,2.39,7.25.71,14.71-.24,21.75,2.06-8.61,2.17-17.51.9-26.26.91-6.45-.49-12.92-.49-19.36-1.12-15.28-.59-30.56.18-45.84.27-18.51.7-37,1.12-55.47,2.55-20,.56-40,2.38-60.07,2.41-2.63.16-5.26.5-7.91.43-10.47-.16-21.16.94-31.43-1.7A37.13,37.13,0,0,1,0,5c.61-1,1.36-1.87,2.05-2.8,4.09-.94,8.11.53,12.17.8,7.47.76,15,.14,22.45.25,15.55-.78,31.12-.64,46.66-1.76"></path></svg>';
			    break;

		    case 'style2':
			    $svg = '<svg xmlns="http://www.w3.org/2000/svg" class="head-svg-line" viewBox="0 0 159 67"><path d="M39.259,22.318l158.9-19.466L182,69.983,48.952,66.415Z" /></svg>';
			    break;

		    case 'style3':
			    $svg = '<svg xmlns="http://www.w3.org/2000/svg" class="head-svg-line" viewBox="0 0 173 26"><path d="M58.76,111.758c21.64-17.1,94.43-25.016,167.682-5.69-81.88-38.942-167.886-11.755-173-1.427C58.765,111.748,58.765,111.748,58.76,111.758Z" transform="translate(-53.442 -85.758)" /></svg>';
			    break;

		    case 'style4':
			    $svg = '<svg xmlns="http://www.w3.org/2000/svg" class="head-svg-line" viewBox="0 0 143 18"><path d="M4.4,0C22.283,11.359,82.451,16.614,143,3.779,55.406,31.322,4.227,11.586,0,4.727,5.883,2.921,3.872,5.268,4.4,0Z" transform="translate(143 18) rotate(-180)" /></svg>';
			    break;

		    case 'style5':
			    $svg = '<span class="head-svg-line head-rectangle"></span>';
			    break;

		    case 'style6':
			    $svg = '<svg xmlns="http://www.w3.org/2000/svg" class="head-svg-img" viewBox="0 0 31 31"><path d="M19.288,31H0V11.711H9.645v9.644h9.644V31h0ZM11.711,19.289V0H31V19.289Z"></path></svg>';
			    break;

		    default:
			    $svg = '';
	    }

	    if( $settings['crust_head_last_title'] ){
		    $output = '<'. $tag .' class="'. $class .'">';
			    $output .= ( $link ) ? '<a href="'.esc_url($link).'"' . $target . $nofollow . '>' : '';
			        $output .= wp_kses( $settings['crust_head_last_title'], crust_allowed_tags() );
			    $output .= ( $link ) ? '</a>' : '';
			    $output .= ($settings['crust_head_style']) ? $svg : '';
		    $output .= '</'. $tag .'>';
		    echo $output;
	    }
    }

}
