<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use \Elementor\Widget_Base;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

class Crust_Popup extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-popup';
    }

    public function get_title()
    {
        return esc_html__('Popup', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-popup', true, true);
        do_action('enqueue_crust_assets','crust-button', false, true);
        return ['crust-popup'];
    }

    protected function register_controls()
    {

	    $this->start_controls_section(
		    'crust_modal_img_settings',
		    [
			    'label' => esc_html__('Main Image', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'crust_popup_image',
		    [
			    'label'   => __('Image', 'crust-core'),
			    'type'    => Controls_Manager::MEDIA,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Image_Size::get_type(),
		    [
			    'name'      => 'thumbnail',
			    'default'   => 'full',
			    'condition' => [
				    'crust_popup_image[url]!' => '',
			    ],
		    ]
	    );

	    $this->crust_animations( 'popup_img' );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_modal_section_button_settings',
            [
                'label' => esc_html__('Button', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'button_type',
		    [
			    'label'   => esc_html__('Type', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'default' => 'crust-btn',
			    'options' => [
				    'crust-btn'        => esc_html__('Normal Button', 'crust-core'),
				    'crust-modal-icon' => esc_html__('Icon', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_modal_button_text',
            [
                'label'       => esc_html__('Text', 'elementor'),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Open Dialog',
                'dynamic' => [
                    'active' => true,
                ],
	            'condition' => [
	            	'button_type' => 'crust-btn'
	            ]
            ]
        );

        $this->add_control(
            'modal_button_style',
            [
                'label'   => esc_html__('Animation Style', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
	                ''              => esc_html__('Default', 'crust-core'),
	                'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
	                'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
	                'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
	                'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
	                'btn-greip'     => esc_html__('Greip', 'crust-core'),
	                'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
                ],
                'condition' => [
	                'button_type' => 'crust-btn'
                ],
            ]
        );

        $this->add_control(
            'crust_modal_button_size',
            [
                'label' => __( 'Size', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'xs' => esc_html__('Extra Small', 'crust-core'),
                    'sm' => esc_html__('Small', 'crust-core'),
                    'md' => esc_html__('Medium', 'crust-core'),
                    'lg' => esc_html__('Large', 'crust-core'),
                    'xl' => esc_html__('Extra Large', 'crust-core'),
                ],
                'condition' => [
	                'button_type' => 'crust-btn'
                ],
            ]
        );

	    $this->add_control(
		    'crust_modal_icon_style',
		    [
			    'label' => __( 'Style', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => 'md',
			    'options' => [
				    ''         => esc_html__('Default', 'crust-core'),
				    'circle'   => esc_html__('Dashed Circle', 'crust-core'),
				    'triangle' => esc_html__('Triangle', 'crust-core'),
				    'outline' => esc_html__( 'Outlined', 'crust-core' ),
			    ],
			    'condition' => [
				    'button_type' => 'crust-modal-icon'
			    ],
		    ]
	    );

        $this->add_control(
            'crust_modal_button_icon',
            [
                'label'     => esc_html__('Icon', 'elementor'),
                'type'      => Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'crust_modal_button_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'crust_modal_button_icon[value]!' => '',
	                'crust_modal_button_text!'        => '',
                    'button_type'                     => 'crust-btn'
                ],
            ]
        );

        $this->add_control(
            'crust_modal_button_icon_block',
            [
                'label'         => esc_html__('Block Icon', 'crust-core'),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'YES', 'crust-core' ),
                'label_off'     => esc_html__( 'NO', 'crust-core' ),
                'return_value'  => 'yes',
                'default'       => 'no',
                'condition'     => [
                    'crust_modal_button_icon[value]!' => '',
                    'crust_modal_button_text!'        => '',
                    'button_type'                     => 'crust-btn'
                ],
            ]
        );

	    $this->crust_animations( 'popup_btn' );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_modal_section_content_settings',
            [
                'label' => esc_html__('Popup', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_modal_animation',
            [
                'label'       => esc_html__('Animation', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'crust-effect-1',
                'label_block' => false,
                'options'     => [
                    'crust-effect-1' => esc_html__('Fade in And Scale', 'crust-core'),
                    'crust-effect-2' => esc_html__('Slide in (right)', 'crust-core'),
                    'crust-effect-3' => esc_html__('Slide in (Bottom)', 'crust-core'),
                    'crust-effect-4' => esc_html__('Newspaper', 'crust-core'),
                    'crust-effect-5' => esc_html__('Fall', 'crust-core'),
                    'crust-effect-6' => esc_html__('Side Fall', 'crust-core'),
                    'crust-effect-7' => esc_html__('Sticky Up', 'crust-core'),
                    'crust-effect-8' => esc_html__('3D Flip (horizontal)', 'crust-core'),
                    'crust-effect-9' => esc_html__('3D Flip (vertical)', 'crust-core'),
                    'crust-effect-10' => esc_html__('3D Sign', 'crust-core'),
                    'crust-effect-11' => esc_html__('Super Scaled', 'crust-core'),
                    'crust-effect-13' => esc_html__('3D Slit', 'crust-core'),
                    'crust-effect-14' => esc_html__('3D Rotate Bottom', 'crust-core'),
                    'crust-effect-15' => esc_html__('3D Rotate In Left', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_modal_conent_type',
            [
                'label'   => __('Content Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'content'  => __('Content', 'crust-core'),
                    'template' => __('Saved Templates', 'crust-core'),
                ],
                'default' => 'content',
            ]
        );

        $this->add_control(
            'crust_modal_primary_templates',
            [
                'label'     => __('Choose Template', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->crust_core_get_page_templates(),
                'dynamic' => [
	                'active' => false,
                ],
                'condition' => [
                    'crust_modal_conent_type' => 'template',
                ],
            ]
        );
        $this->add_control(
            'crust_modal_content_text',
            [
                'label'       => esc_html__('Content', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => esc_html__('Donec sed odio dui. Vivamus sagittis lacus vel augue laoreet rutrum.', 'crust-core'),
                'condition'   => [
                    'crust_modal_conent_type' => 'content',
                ],
            ]
        );

        $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_pop_img_styling',
		    [
			    'label' => esc_html__('Main Image', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_popup_image[url]!' => '',
			    ],
		    ]
	    );

	    $this->add_control(
		    'tilt_box',
		    [
			    'label'        => __('Hover Tilt', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pop_img_width',
		    [
			    'label'     => __('Width', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'size_units' => ['px','%'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pop-img-wrap img' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pop_img_height',
		    [
			    'label'     => __('Height', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'size_units' => ['px','%'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pop-img-wrap img' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_img_tabs');

	    $this->start_controls_tab('img_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'comp_wrap_border',
			    'selector' => '{{WRAPPER}} .crust-pop-img-inner',
		    ]
	    );

	    $this->add_responsive_control(
		    'comp_wrap_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pop-img-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'comp_wrap_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-pop-img-inner',
		    ]
	    );
	    $this->add_responsive_control(
		    'comp_wrap_dark',
		    [
			    'label'      => esc_html__(' Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'comp_wrap_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pop-img-inner',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->start_controls_tab('img_hover', ['label' => esc_html__('Hover', 'elementor')]);
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'comp_wrap_hover_border',
			    'selector' => '{{WRAPPER}} .crust-pop-img-inner:hover',
		    ]
	    );

	    $this->add_responsive_control(
		    'comp_wrap_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pop-img-inner:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'comp_wrap_hover_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-pop-img-inner:hover',
		    ]
	    );
	    $this->add_responsive_control(
		    'comp_wrap_hover_dark',
		    [
			    'label'      => esc_html__(' Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
		$this->add_group_control(
	    Group_Control_Border::get_type(),
	    [
		    'name'     => 'comp_wrap_hover_dark_border',
		    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pop-img-inner:hover',
	    ]
    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();
	    $this->end_controls_section();

        // Button Style
        $this->start_controls_section(
            'crust_modal_section_button_styling',
            [
                'label' => esc_html__('Button', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_modal_button_typography',
                'selector' => '{{WRAPPER}} .crust-modal-btn',
                'condition' => [
	                'button_type' => 'crust-btn'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'crust_modal_button_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-modal-btn,{{WRAPPER}} .crust-modal-btn.btn-bestia > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-btn'
			    ],
		    ]
	    );

        $this->start_controls_tabs('crust_modal_button_tabs');

        $this->start_controls_tab('normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_control(
            'crust_modal_button_text_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-modal-btn' => 'color: {{VALUE}};',
                ],
                'default'   => '#fff',
                'condition' => [
	                'button_type' => 'crust-btn'
                ]
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_button_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [
					    'default' => 'classic'
				    ],
				    'color' => [
					    'default' => '#12D0DE'
				    ],
			    ],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia), {{WRAPPER}} .crust-btn.btn-hyperion:before,
					{{WRAPPER}} .crust-btn.btn-anthe::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'modal_button_border',
                'selector' => '{{WRAPPER}} .crust-modal-btn',
            ]
        );

        $this->add_responsive_control(
            'modal_button_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-modal-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'modal_button_shadow',
                'selector' => '{{WRAPPER}} .crust-modal-btn',
            ]
        );
		//normal
	    $this->add_responsive_control(
		    'crust_modal_section_button_dark_styling',
		    [
			    'label'      => esc_html__(' Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_modal_button_text_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn' => 'color: {{VALUE}};',
			    ],

			    'condition' => [
				    'button_type' => 'crust-btn'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_button_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [

				    ],
				    'color' => [

				    ],
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.btn-hyperion):not(.btn-bestia), body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion:before,
					body.crust-dark {{WRAPPER}} .crust-btn.btn-anthe::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'modal_button_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-modal-btn',
		    ]
	    );

        $this->end_controls_tab();

        $this->start_controls_tab('modal_button_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_control(
            'modal_button_hover_color',
            [
                'label'     => esc_html__('Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-modal-btn:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
	                'button_type' => 'crust-btn'
                ]
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_button_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-btn:not(.styled-btn):hover, {{WRAPPER}} .crust-btn.btn-hyperion,{{WRAPPER}} .crust-btn::before,{{WRAPPER}} .crust-btn::after,
					{{WRAPPER}} .crust-btn.btn-anthe:hover::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,{{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

        $this->add_control(
            'modal_button_hover_border_color',
            [
                'label'     => esc_html__('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-modal-btn:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'modal_button_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-modal-btn:hover',
            ]
        );

	    //hover
	    $this->add_responsive_control(
		    'modal_button_dark_hover',
		    [
			    'label'      => esc_html__(' Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'modal_button_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn:hover' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-btn'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_button_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-btn:not(.styled-btn):hover, body.crust-dark {{WRAPPER}} .crust-btn.btn-hyperion,body.crust-dark {{WRAPPER}} .crust-btn::before,body.crust-dark {{WRAPPER}} .crust-btn::after,
					body.crust-dark {{WRAPPER}} .crust-btn.btn-anthe:hover::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::before,body.crust-dark {{WRAPPER}} .crust-btn.btn-bestia .bestia-bg::after'
		    ]
	    );

	    $this->add_control(
		    'modal_button_hover_border_dark_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn:hover' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();

	    $this->end_controls_section();

        // Icon Style
	    $this->start_controls_section(
		    'modal_icon_styling',
		    [
			    'label' => esc_html__('Icon', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->start_controls_tabs('modal_icon_tabs');

	    $this->start_controls_tab('icon_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_responsive_control(
		    'modal_icon_width',
		    [
			    'label'      => esc_html__('Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min' => 10,
					    'max' => 1500,
				    ],
				    '%' => [
					    'min' => 1,
					    'max' => 100,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon, {{WRAPPER}} .crust-modal-icon' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'modal_icon_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min' => 10,
					    'max' => 1500,
				    ],
				    '%' => [
					    'min' => 1,
					    'max' => 100,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon, {{WRAPPER}} .crust-modal-icon' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'modal_icon_size',
		    [
			    'label'      => esc_html__('Font Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%', 'rem', 'em'],
			    'default'    => [
				    'size' => 1,
				    'unit' => 'rem',
			    ],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%'  => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'condition' => [
				    'crust_modal_button_icon[value]!' => '',
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon'   => 'font-size: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-modal-btn img' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'modal_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'modal_icon_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_icon_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [
					    'default' => 'classic'
				    ],
				    'color' => [
					    'default' => '#12D0DE'
				    ],
			    ],
			    'selector' => '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_icon_circle_color',
		    [
			    'label'     => esc_html__('Circle Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} span.crust-icon-mod.circle svg circle' => 'stroke: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-modal-icon',
				    'crust_modal_icon_style' => 'circle',
			    ],
			    'default'   => '#19D0D6'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_icon_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} span.crust-icon-mod.triangle svg path' => 'fill: {{VALUE}};stroke: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-modal-icon',
				    'crust_modal_icon_style' => 'triangle',
			    ],
			    'default'   => '#19D0D6'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_scale_hover',
		    [
			    'label' => esc_html__( 'Hover Scale', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'default' => 'yes',
			    'return_value' => 'yes',
			    'condition' => [
				    'button_type' => 'crust-modal-icon',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_modal_animate_circle',
		    [
			    'label' => esc_html__( 'Animate Circle', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'condition' => [
				    'crust_modal_icon_style' => 'circle',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_modal_button_border',
			    'selector' => '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon,{{WRAPPER}} .crust-modal-btn span.crust-icon-mod.outline',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_modal_button_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon,{{WRAPPER}} .crust-modal-btn span.crust-icon-mod.outline' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_modal_button_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-modal-btn i.crust-btn-icon',
		    ]
	    );
		/////normal
	    $this->add_control(
		    'crust_modal_icon_dark_circle_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'modal_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn i.crust-btn-icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'modal_icon_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'fields_options' => [
				    'background' => [
					    'default' => 'classic'
				    ],
				    'color' => [
					    'default' => '#12D0DE'
				    ],
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-modal-btn i.crust-btn-icon'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_dark_icon_circle_color',
		    [
			    'label'     => esc_html__('Circle Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} span.crust-icon-mod.circle svg circle' => 'stroke: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-modal-icon',
				    'crust_modal_icon_style' => 'circle',
			    ],
			    'default'   => '#19D0D6'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_icon_dark_triangle_color',
		    [
			    'label'     => esc_html__('Triangle Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} span.crust-icon-mod.triangle svg path' => 'fill: {{VALUE}};stroke: {{VALUE}};',
			    ],
			    'condition' => [
				    'button_type' => 'crust-modal-icon',
				    'crust_modal_icon_style' => 'triangle',
			    ],
			    'default'   => '#19D0D6'
		    ]
	    );
//////////////////////////////////////////////////////////

	    $this->end_controls_tab();

	    $this->start_controls_tab('modal_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'crust_modal_button_hover_icon_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn:hover i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_modal_button_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_button_hover_border_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon,{{WRAPPER}} .crust-modal-btn:hover span.crust-icon-mod.outline' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_modal_button_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon,{{WRAPPER}} .crust-modal-btn:hover span.crust-icon-mod.outline' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_modal_button_box_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon',
		    ]
	    );
		////////dark hover
	    $this->add_control(
		    'crust_modal_icon_dark_hover_circle_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_modal_button_hover_dark_icon_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn:hover i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_modal_button_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon'
		    ]
	    );

	    $this->add_control(
		    'crust_modal_button_hover_dark_border_color',
		    [
			    'label'     => esc_html__('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-modal-btn:hover i.crust-btn-icon,body.crust-dark {{WRAPPER}} .crust-modal-btn:hover span.crust-icon-mod.outline' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

        // Popup Style
        $this->start_controls_section(
            'crust_modal_section_content_styling',
            [
                'label' => esc_html__('Popup', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_responsive_control(
            'crust_modal_content_max_width',
            [
                'label'      => esc_html__('Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min' => 10,
                        'max' => 1500,
                    ],
                    'em' => [
                        'min' => 1,
                        'max' => 80,
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_modal_content_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
            ]
        );

        $this->add_control(
            'crust_modal_content_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
            ]
        );

        $this->add_control(
            'crust_modal_content_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
            ]
        );

        $this->add_responsive_control(
            'crust_modal_content_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
            ]
        );

        $this->add_responsive_control(
            'crust_modal_content_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
            ]
        );
		/////popup
	    $this->add_control(
		    'crust_modal_content_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_modal_content_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
		    ]
	    );

	    $this->add_control(
		    'crust_modal_content_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
		    ]
	    );

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $content_type  = $settings['crust_modal_conent_type'];
        $modal_text    = $settings['crust_modal_content_text'];
        $prim_temp     = $settings['crust_modal_primary_templates'];
        $animation     = esc_attr($settings['crust_modal_animation']);
	    $icon_style    = $settings['crust_modal_icon_style'];
	    $anim_circle   = $settings['crust_modal_animate_circle'];
        $type          = $settings['button_type'];

	    $pop_image = $settings['crust_popup_image'];
	    $pop_image_url = Group_Control_Image_Size::get_attachment_image_src($pop_image['id'], 'thumbnail', $settings);
	    if (empty($pop_image_url)) {
		    $pop_image_url = $pop_image['url'];
	    } else{
		    $pop_image_url = $pop_image_url;
	    }

        // popup styles
	    $width = $settings['crust_modal_content_max_width'];
	    $width = ($width['size']) ? 'max-width: ' . $width['size'].$width['unit'].';' : '';
	    $align = $settings['crust_modal_content_alignment'];
	    $align = ( $align ) ? 'text-align: ' . $align . ';' : '';
	    $color = $settings['crust_modal_content_color'];
	    $color = ( $color ) ? 'color: ' . $color . ';' : '';
	    $bg = $settings['crust_modal_content_background'];
	    $bg = ( $bg ) ? 'background-color: ' . $bg . ';' : '';
	    $color_dark = $settings['crust_modal_content_dark_color'];
	    $color_dark = ( $color_dark ) ? 'color: ' . $color_dark . ';' : '';
	    $bg_dark = $settings['crust_modal_content_dark_background'];
	    $bg_dark = ( $bg_dark ) ? 'background-color: ' . $bg_dark . ';' : '';
	    $padding = $settings['crust_modal_content_padding'];
	    $padding = ( $padding['top'] || $padding['right'] || $padding['bottom'] || $padding['left'] ) ? 'padding: ' . $padding['top'].$padding['unit'] .' '. $padding['right'].$padding['unit'] .' '. $padding['bottom'].$padding['unit'] .' '. $padding['left'].$padding['unit'] . ';' : '';
	    $radius = $settings['crust_modal_content_border_radius'];
	    $radius = ( $radius['top'] || $radius['right'] || $radius['bottom'] || $radius['left'] ) ? 'border-radius: ' . $radius['top'].$radius['unit'] .' '. $radius['right'].$radius['unit'] .' '. $radius['bottom'].$radius['unit'] .' '. $radius['left'].$radius['unit'] . ';' : '';
	    $mod_style = $width . $align . $color . $bg . $padding . $radius . $color_dark . $bg_dark;

	    if ( has_shortcode($modal_text, 'video') || has_shortcode($modal_text, 'audio' ) || has_shortcode( $modal_text, 'embed' ) ){
		    $modal_text = do_shortcode( $modal_text );
		    $modal_text = str_replace('<p></p>','', $modal_text );
	    }

	    $class = 'crust-modal-btn ' . $type;
	    $class .= ( $type === 'crust-btn' && $settings['modal_button_style'] ) ? ' styled-btn ' . $settings['modal_button_style'] : '';
	    $class .= ( $settings['crust_modal_button_size'] !== 'md' && $type === 'crust-btn' ) ? ' crust-btn-size-' . $settings['crust_modal_button_size'] : '';
	    $class .= ( 'yes' === $settings['crust_modal_button_icon_block'] && $type === 'crust-btn' ) ? ' crust-btn-block-icon' : '';
	    $class .= ( $settings['crust_modal_scale_hover'] ) ? ' crust-hover-scale' : '';

	    $buttons_atts = '';
	    $buttons_atts .= ( $mod_style ) ? ' data-modal-style="'.$mod_style.'"' : '';
	    $buttons_atts .= ( $animation ) ? ' data-modal-animation="'.$animation.'"' : '';
	    $buttons_atts .= ( $content_type ) ? ' data-modal-type="'.$content_type.'"' : '';
	    $buttons_atts .= ( $modal_text && $content_type == 'content' ) ? ' data-modal-text="'.$modal_text.'"' : '';
	    $buttons_atts .= ( $prim_temp && $content_type == 'template' ) ? ' data-modal-temp="'.$prim_temp.'"' : '';
	    $buttons_atts .= ' data-editor="elm" data-modal-id=""';

        $ic     = $settings['crust_modal_button_icon']['value'];
        $ic_svg = isset($ic['url']) ? $ic['url'] : '';

        $iconoutput = '';
	    $iconclass = 'crust-btn-icon';
        $icondir    = $settings['crust_modal_button_icon_alignment'];
        $iconclass .= ( $ic && ! $ic_svg ) ? ' ' . $settings['crust_modal_button_icon']['value'] : '';
        $iconclass .= ( $icondir ) ? ' crust-btn-icon-'.$icondir : '';

        if (isset($settings['crust_modal_button_icon']['value']['url'])) {
            $iconoutput .= '<img src="'. esc_attr($settings['crust_modal_button_icon']['value']['url']) .'" class="'. esc_attr($iconclass) .'" alt="'.esc_attr(get_post_meta($settings['crust_modal_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
        } else {
            $iconoutput .= ( ! empty($settings['crust_modal_button_icon']['value'])) ? '<i class="'. esc_attr($iconclass) .'"></i>' : '';
        }
        
        $icon_styles = '';
        if( $icon_style === 'circle' ){
        	$icon_styles = '<svg xmlns="http://www.w3.org/2000/svg"><circle cx="50%" cy="50%" r="50%"></circle></svg>';
        } else if( $icon_style === 'triangle' ){
        	$icon_styles = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M 70,50 10,90 10,10 z"></path></svg>';
        }

	    $img_class = 'crust-pop-img-wrap';

	    $img_inner = 'crust-pop-img-inner';
	    $img_inner .= ( $settings['tilt_box'] == 'yes' ) ? ' js-tilt' : '';
	    $img_inner_atts = ( $settings['tilt_box'] === 'yes' ) ? ' data-tilt-scale="1.05" data-tilt-max="4" data-tilt-speed="1000" data-tilt-perspective="1000"' : '';

        $mod_icon_class = 'crust-icon-mod';
	    $mod_icon_class .= ' ' . $icon_style;
	    $mod_icon_class .= ( $anim_circle === 'yes' ) ? ' circle-anim' : '';

	    $btn_wrap_class = 'crust-pop-btn-wrap';

	    $wrapper   = 'crust-popup-wrapper';
	    $wrapper  .= ( $pop_image_url ) ? ' crust-pop-wrap-abs' : '';

	    $this->crust_animation_attributes( 'popup_img' );

	    $output = '<div class="'. $wrapper .'">';

	        $output .= ( $pop_image_url ) ? '<div class="'.$img_class.'"'. $this->get_render_attribute_string('popup_img') .'><div class="'.$img_inner.'"'.$img_inner_atts.'><img src="'. esc_url($pop_image_url) .'" alt="'. esc_attr(get_post_meta($pop_image['id'], '_wp_attachment_image_alt', true)) .'" /></div></div>' : '';

		    $output .= '<div class="'. $btn_wrap_class .'"'. $this->get_render_attribute_string('popup_btn') .'>';
				$output .= '<a class="'. $class .'" href="#"'. $buttons_atts .'>';
		            $output .= ( $settings['modal_button_style'] == 'btn-bestia' ) ? '<b class="bestia-bg"></b>' : '';
			        $output .= ( $type === 'crust-modal-icon' ) ? '<span class="'.esc_attr( $mod_icon_class ).'">'. $icon_styles .'</span>' : '';
		            $output .= ( $type === 'crust-btn' ) ? '<span><span>' : '';
		                $output .= ($settings['crust_modal_button_icon_alignment'] == 'left' || $type !== 'crust-btn' ) ? $iconoutput : '';
		                $output .= ($settings['crust_modal_button_text'] && $type === 'crust-btn' ) ? '<span>' . $settings['crust_modal_button_text'] . '</span>' : '';
		                $output .= ($settings['crust_modal_button_icon_alignment'] == 'right') ? $iconoutput : '';
		            $output .= ( $type === 'crust-btn' ) ? '</span></span>' : '';
		        $output .= '</a>';
	        $output .= '</div>';

	    $output .= '</div>';

        echo $output;

    }

}
