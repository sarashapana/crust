<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Progress_Bar extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-progress-bar'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-progress-bar', true, true);
        return ['crust-progress-bar'];
    }

    public function get_name()
    {
        return 'crust-progress-bar';
    }

    public function get_title()
    {
        return esc_html__('Progress Bar', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-skill-bar';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT TAB
        /*-----------------------------------------------------------------------------------*/
        
        $this->start_controls_section(
            'progress_bar_section_layout',
            [
                'label' => esc_html__('Layout', 'crust-core'),
            ]
        );

        // Progressbar Layout Options
        $options = apply_filters(
            'add_crust_progress_layout',
            [
                'layouts'    => [
                    'line'             => esc_html__('Line', 'crust-core'),
                    'circle'           => esc_html__('Circle', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'progress_bar_layout',
            [
                'label'   => esc_html__('Layout', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options['layouts'],
                'default' => 'line',
            ]
        );

	    $this->add_control(
		    'progress_bar_style',
		    [
			    'label'   => esc_html__('Style', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    'default' => esc_html__('Default', 'crust-core'),
				    'triangle' => esc_html__('Triangle', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'progress_bar_title',
            [
                'label'     => esc_html__('Title', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__('Progress Bar', 'crust-core'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_title_html_tag',
            [
                'label'   => esc_html__('Title HTML Tag', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h1'   => __('H1', 'crust-core'),
                    'h2'   => __('H2', 'crust-core'),
                    'h3'   => __('H3', 'crust-core'),
                    'h4'   => __('H4', 'crust-core'),
                    'h5'   => __('H5', 'crust-core'),
                    'h6'   => __('H6', 'crust-core'),
                    'div'  => __('div', 'crust-core'),
                    'span' => __('span', 'crust-core'),
                    'p'    => __('p', 'crust-core'),
                ],
                'default' => 'span',
            ]
        );

        $this->add_control(
            'progress_bar_value',
            [
                'label'      => esc_html__('Counter Value', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range'      => [
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => '%',
                    'size' => 60,
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_show_count',
            [
                'label'        => esc_html__('Display Count', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'progress_bar_animation_duration',
            [
                'label'      => esc_html__('Animation Duration', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 1000,
                        'max'  => 10000,
                        'step' => 100,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 1000,
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_prefix_label',
            [
                'label'     => esc_html__('Prefix Label', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'progress_bar_layout' => 'half_circle',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_suffix_label',
            [
                'label'     => esc_html__('Suffix Label', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'progress_bar_layout' => 'half_circle',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        /**
         * Style Tab: General(Line)
         */
        $this->start_controls_section(
            'progress_bar_section_icon',
            [
                'label'     => __('Icon', 'elementor'),
                'condition' => [
                    'progress_bar_layout' => 'circle',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-rocket-launch',
                    'library' => 'fontawesome',
                ],
                'condition'        => [
                    'progress_bar_layout' => 'circle'
                ]
            ]
        );

        $this->add_responsive_control(
            'progress_bar_icon_size',
            [
                'label'      => esc_html__('Icon Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'rem', 'em'],
                'default'    => [
                    'size' => 2.5,
                    'unit' => 'rem',
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'condition'        => [
                    'progress_bar_layout' => 'circle'
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner-content i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-progressbar-circle-inner-content img' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'progress_bar_icon_indent',
            [
                'label'     => esc_html__('Icon Margin', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 200,
                    ],
                ],
                'condition'        => [
                    'progress_bar_layout' => 'circle'
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner-content i' => 'margin-bottom: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner-content i' => 'color: {{VALUE}};',
                ],
                'default'   => '#19D0D6'
            ]
        );


	    $this->add_responsive_control(
		    'progress_bar_section_icon_head',
		    [
			    'label'      => esc_html__(' dark mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );




	    $this->add_control(
		    'progress_bar_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark{{WRAPPER}} .crust-progressbar-circle-inner-content i' => 'color: {{VALUE}};',
			    ],

		    ]
	    );

        $this->end_controls_section();

        /**
         * Style Tab: General(Line)
         */
        $this->start_controls_section(
            'progress_bar_section_style_general_line',
            [
                'label'     => __('Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'progress_bar_layout' => 'line',
                ],
            ]
        );

        $this->add_responsive_control(
            'progress_bar_line_alignment',
            [
                'label'   => __('Alignment', 'elementor'),
                'type'    => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left'   => [
                        'title' => __('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => __('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'condition' => [
                    'progress_bar_layout' => 'line',
                ],
                'default' => 'left',
            ]
        );

        $this->add_control(
            'progress_bar_line_width',
            [
                'label'      => __('Width', 'elementor'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 100,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min'  => 1,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-line-container' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_line_height',
            [
                'label'      => __('Bar Height', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-line' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_line_bg_color',
            [
                'label'     => __('Bar Background Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#e2e8f2',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-line' => 'background-color: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_progress_border',
			    'selector' => '{{WRAPPER}} .crust-progressbar-line',
		    ]
	    );

        $this->add_responsive_control(
            'progress_bar_line_border_radius',
            [
                'label'      => esc_html__('Bar Border Radius', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-line' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_line_fill_height',
            [
                'label'      => __('Fill Height', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-line-fill' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

	    $this->add_control(
		    'progress_bar_line_margin',
		    [
			    'label'      => __('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-progressbar-line-fill' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'progress_bar_line_fill_color',
                'label'     => __('Fill Color', 'crust-core'),
                'types'     => ['classic', 'gradient'],
                'exclude'   => [
                    'image',
                ],
                'condition' => [
                	'progress_bar_layout' => 'line',
	                'progress_bar_style!' => 'triangle',
                ],
                'selector'  => '{{WRAPPER}} .crust-progressbar-line-fill',
            ]
        );

	    $this->add_control(
		    'tri_color_1',
		    [
			    'label'     => __('Fill Color 1', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'condition' => [
				    'progress_bar_style' => 'triangle',
			    ],
			    'separator' => 'after',
		    ]
	    );

	    $this->add_control(
		    'tri_color_2',
		    [
			    'label'     => __('Fill Color 2', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'condition' => [
				    'progress_bar_style' => 'triangle',
			    ],
			    'separator' => 'after',
		    ]
	    );

        $this->add_responsive_control(
            'progress_bar_fill_border_radius',
            [
                'label'      => esc_html__('Fill Border Radius', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-line-fill' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_line_fill_stripe',
            [
                'label'        => __('Show Stripe', 'crust-core'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'separator'    => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_line_fill_stripe_animate',
            [
                'label'     => __('Stripe Animation', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'normal'  => __('Left To Right', 'crust-core'),
                    'reverse' => __('Right To Left', 'crust-core'),
                    'none'    => __('Disabled', 'crust-core'),
                ],
                'default'   => 'none',
                'condition' => [
                    'progress_bar_line_fill_stripe' => 'yes'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'progress_bar_section_style_general_dark_line',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );




	    $this->add_control(
		    'progress_bar_line_bg_dark_color',
		    [
			    'label'     => __('Bar Background Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-line' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_progress_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-progressbar-line',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'progress_bar_line_fill_dark_color',
			    'label'     => __('Fill Color', 'crust-core'),
			    'types'     => ['classic', 'gradient'],
			    'exclude'   => [
				    'image',
			    ],
			    'condition' => [
				    'progress_bar_layout' => 'line',
				    'progress_bar_style!' => 'triangle',
			    ],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-progressbar-line-fill',
		    ]
	    );

	    $this->add_control(
		    'tri_color_dark_1',
		    [
			    'label'     => __('Fill Color 1', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'condition' => [
				    'progress_bar_style' => 'triangle',
			    ],
			    'separator' => 'after',
		    ]
	    );

	    $this->add_control(
		    'tri_color_dark_2',
		    [
			    'label'     => __('Fill Color 2', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'condition' => [
				    'progress_bar_style' => 'triangle',
			    ],
			    'separator' => 'after',
		    ]
	    );

        $this->end_controls_section();

        /**
         * Style Tab: Style(Circle)
         */
        $this->start_controls_section(
            'progress_bar_section_style_general_circle',
            [
                'label'     => __('Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'progress_bar_layout' => ['circle', 'half_circle'],
                ],
            ]
        );

        $this->add_responsive_control(
            'progress_bar_circle_alignment',
            [
                'label'   => __('Alignment', 'elementor'),
                'type'    => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'flex-start'   => [
                        'title' => __('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'  => [
                        'title' => __('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'center',
               'selectors' => [
                   '{{WRAPPER}} .crust-progressbar-circle-container' => 'justify-content: {{VALUE}};',
               ]
            ]
        );

        $this->add_control(
            'progress_bar_circle_size',
            [
                'label'      => __('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 50,
                        'max'  => 700,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 250,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-circle'            => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-progressbar-half-circle'       => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}} / 2 * 1{{UNIT}});',
                    '{{WRAPPER}} .crust-progressbar-half-circle-after' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-progressbar-circle-shadow'     => 'width: calc({{SIZE}}{{UNIT}} + 20px); height: calc({{SIZE}}{{UNIT}} + 20px);',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_control(
            'progress_bar_circle_bg_color',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner' => 'background-color: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'progress_bar_circle_stroke_width',
            [
                'label'      => __('Stroke Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner' => 'border-width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_circle_stroke_color',
            [
                'label'     => __('Stroke Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#eee',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-circle-inner' => 'border-color: {{VALUE}}',
                ],
                'separator'  => 'after',
            ]
        );

        $this->add_control(
            'progress_bar_circle_line_width',
            [
                'label'      => __('Fill Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-progressbar-circle-half'  => 'border-width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_circle_fill_color',
            [
                'label'     => __('Fill Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#19D0D6',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-circle-half' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'progress_bar_circle_box_shadow',
                'label'     => __('Box Shadow', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-progressbar-circle-shadow',
                'condition' => [
                    'progress_bar_layout' => 'circle',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'progress_bar_section_style_general_dark_circle',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );





	    $this->add_control(
		    'progress_bar_circle_bg_dark_color',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-circle-inner' => 'background-color: {{VALUE}}',
			    ],
			    'separator' => 'after',
		    ]
	    );
	    $this->add_control(
		    'progress_bar_circle_stroke_dark_color',
		    [
			    'label'     => __('Stroke Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-circle-inner' => 'border-color: {{VALUE}}',
			    ],
			    'separator'  => 'after',
		    ]
	    );

	    $this->add_control(
		    'progress_bar_circle_fill_dark_color',
		    [
			    'label'     => __('Fill Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-circle-half' => 'border-color: {{VALUE}}',
			    ],
			    'separator' => 'after',
		    ]
	    );

        $this->end_controls_section();

        /**
         * Style Tab: Typography
         */
        $this->start_controls_section(
            'progress_bar_section_style_typography',
            [
                'label' => __('Typography', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'progress_bar_title_typography',
                'label'    => __('Title', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-progressbar-title',
            ]
        );

        $this->add_responsive_control(
            'progress_bar_title_margin',
            [
                'label'      => esc_html__('Title Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_title_color',
            [
                'label'     => __('Title Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-title' => 'color: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'progress_bar_count_typography',
                'label'    => __('Counter', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-progressbar-count-wrap',
            ]
        );

        $this->add_control(
            'progress_bar_count_color',
            [
                'label'     => __('Counter Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-count-wrap' => 'color: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'progress_bar_after_typography',
                'label'     => __('Prefix/Postfix', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-progressbar-half-circle-after span',
                'condition' => [
                    'progress_bar_layout' => 'half_circle',
                ],
            ]
        );

        $this->add_control(
            'progress_bar_after_color',
            [
                'label'     => __('Prefix/Postfix Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-progressbar-half-circle-after' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'progress_bar_layout' => 'half_circle',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'progress_bar_section_style_dark_typography',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );





	    $this->add_control(
		    'progress_bar_title_dark_color',
		    [
			    'label'     => __('Title Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-title' => 'color: {{VALUE}}',
			    ],

		    ]
	    );



	    $this->add_control(
		    'progress_bar_count_dark_color',
		    [
			    'label'     => __('Counter Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-count-wrap' => 'color: {{VALUE}}',
			    ],
			    'separator' => 'after',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'      => 'progress_bar_after_dark_typography',
			    'label'     => __('Prefix/Postfix', 'crust-core'),
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-progressbar-half-circle-after span',
			    'condition' => [
				    'progress_bar_layout' => 'half_circle',
			    ],
		    ]
	    );

	    $this->add_control(
		    'progress_bar_after_dark_color',
		    [
			    'label'     => __('Prefix/Postfix Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-progressbar-half-circle-after' => 'color: {{VALUE}}',
			    ],
			    'condition' => [
				    'progress_bar_layout' => 'half_circle',
			    ],
		    ]
	    );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings       = $this->get_settings_for_display();
        $wrap_classes   = ['crust-progressbar'];
        $circle_wrapper = [];
        $html           = '';
        $tag            = $settings['progress_bar_title_html_tag'];

        if ($settings['progress_bar_layout'] == 'line') {
            $wrap_classes[] = 'crust-progressbar-line';
            $wrap_classes   = apply_filters('crust_core_progressbar_rainbow_wrap_class', $wrap_classes, $settings);

            $container_class = 'crust-progressbar-line-container';
	        $container_class .= ( $settings['progress_bar_line_alignment'] ) ? ' ' . $settings['progress_bar_line_alignment'] : '';
	        $container_class .= ( $settings['progress_bar_style'] ) ? ' crust-progressbar-' . $settings['progress_bar_style'] : '';

            if ($settings['progress_bar_line_fill_stripe'] == 'yes') {
                $wrap_classes[] = 'crust-progressbar-line-stripe';
            }

            if ($settings['progress_bar_line_fill_stripe_animate'] == 'normal') {
                $wrap_classes[] = 'crust-progressbar-line-animate';
            } elseif ($settings['progress_bar_line_fill_stripe_animate'] == 'reverse') {
                $wrap_classes[] = 'crust-progressbar-line-animate-rtl';
            }

            $this->add_render_attribute(
                'crust-progressbar-line',
                [
                    'class'         => $wrap_classes,
                    'data-layout'   => 'line',
                    'data-count'    => $settings['progress_bar_value']['size'],
                    'data-duration' => $settings['progress_bar_animation_duration']['size'],
                ]
            );

            $this->add_render_attribute(
                'crust-progressbar-line-fill',
                [
                    'class' => 'crust-progressbar-line-fill',
                    'style' => '-webkit-transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;-o-transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;',
                ]
            );

	        $id = uniqid( 'crst-prgrs-' );

            $html .= '<div class="' . $container_class . '">';

                $html .= ( $settings['progress_bar_title'] ) ? '<'.$tag.' class="crust-progressbar-title">'.$settings['progress_bar_title'].'</'.$tag.'>' : '';

                $html .= '<div ' . $this->get_render_attribute_string('crust-progressbar-line') . '>';

			        if( $settings['progress_bar_style'] == 'triangle' ){

				        $tri_color_1 = $settings['tri_color_1'] ? $settings['tri_color_1'] : '#b9d114';
				        $tri_color_2 = $settings['tri_color_2'] ? $settings['tri_color_2'] : '#19D0D6';

				        $html .= '<span ' . $this->get_render_attribute_string( 'crust-progressbar-line-fill' ) . '>
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none" viewBox="0 0 736 24.052">
									  <defs>
									    <linearGradient id="'.$id.'" x1="1" y1="0.5" x2="0" y2="0.5" gradientUnits="objectBoundingBox">
									      <stop offset="0" stop-color="'.$tri_color_1.'"/>
									      <stop offset="1" stop-color="'.$tri_color_2.'"/>
									    </linearGradient>
									  </defs>
									  <path d="M736,0V24.052H0Z" fill="url(#'.$id.')"/>
									</svg>';
				            $html .= ( $settings['progress_bar_show_count'] ) ? '<span class="crust-progressbar-count-wrap"><span class="crust-progressbar-count">0</span><span class="suffix">' . $settings['progress_bar_value']['unit'] . '</span></span>' : '';
				        $html .= '</span>';

			        } else {
				        $html .= ( $settings['progress_bar_show_count'] ) ? '<span class="crust-progressbar-count-wrap"><span class="crust-progressbar-count">0</span><span class="suffix">' . $settings['progress_bar_value']['unit'] . '</span></span>' : '';
				        $html .= '<span ' . $this->get_render_attribute_string( 'crust-progressbar-line-fill' ) . '></span>';
			        }

                $html .= '</div>';

            $html .= '</div>';
        }
        
        if ($settings['progress_bar_layout'] == 'circle') {
            $wrap_classes[] = 'crust-progressbar-circle';
            $wrap_classes   = apply_filters('crust_core_progressbar_circle_fill_wrap_class', $wrap_classes, $settings);
            $this->add_render_attribute(
                'crust-progressbar-circle',
                [
                    'class'         => $wrap_classes,
                    'data-layout'   => $settings['progress_bar_layout'],
                    'data-count'    => $settings['progress_bar_value']['size'],
                    'data-duration' => $settings['progress_bar_animation_duration']['size'],
                ]
            );

            $html .= '<div class="crust-progressbar-circle-container ' . $settings['progress_bar_circle_alignment'] . '">';
                $html .= '<div ' . $this->get_render_attribute_string('crust-progressbar-circle') . '>';

                    $html .= '<div class="crust-progressbar-circle-pie">';
                        $html .= '<div class="crust-progressbar-circle-half-left crust-progressbar-circle-half"></div>';
                        $html .= '<div class="crust-progressbar-circle-half-right crust-progressbar-circle-half"></div>';
                    $html .= '</div>';

                    $html .= '<div class="crust-progressbar-circle-inner"></div>';

                    $html .= '<div class="crust-progressbar-circle-inner-content">';
                        if (isset($settings['progress_bar_icon']['value']['url'])) {
                            $html .= '<img src="'. esc_attr($settings['progress_bar_icon']['value']['url']) .'" alt="'.esc_attr(get_post_meta($settings['progress_bar_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
                        } else {
                            $html .= ( $settings['progress_bar_icon']['value'] ) ? '<i class="'. esc_attr($settings['progress_bar_icon']['value']) .'"></i>' : '';
                        }
                        $html .= ( $settings['progress_bar_title'] ) ? '<'.$tag.' class="crust-progressbar-title">'.$settings['progress_bar_title'].'</'.$tag.'>' : '';
                        $html .= ( $settings['progress_bar_show_count'] ) ? '<span class="crust-progressbar-count-wrap"><span class="crust-progressbar-count">0</span><span class="suffix">' . $settings['progress_bar_value']['unit'] . '</span></span>' : '';
                    $html .= '</div>';

                $html .= '</div>';
            $html .= '</div>';

        }

        if ($settings['progress_bar_layout'] == 'half_circle') {
            $wrap_classes[] = 'crust-progressbar-half-circle';
            $wrap_classes   = apply_filters('crust_core_progressbar_half_circle_wrap_class', $wrap_classes, $settings);

            $this->add_render_attribute(
                'crust-progressbar-circle-half',
                [
                    'class' => 'crust-progressbar-circle-half',
                    'style' => '-webkit-transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;-o-transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;transition-duration:' . $settings['progress_bar_animation_duration']['size'] . 'ms;',
                ]
            );

            $this->add_render_attribute(
                'crust-progressbar-half-circle',
                [
                    'class'         => $wrap_classes,
                    'data-layout'   => $settings['progress_bar_layout'],
                    'data-count'    => $settings['progress_bar_value']['size'],
                    'data-duration' => $settings['progress_bar_animation_duration']['size'],
                ]
            );

            $html .= '<div class="crust-progressbar-circle-container ' . $settings['progress_bar_circle_alignment'] . '">';
                $html .= '<div ' . $this->get_render_attribute_string('crust-progressbar-half-circle') . '>';
                    $html .= '<div class="crust-progressbar-circle">';
                        $html .= '<div class="crust-progressbar-circle-pie">';
                            $html .= '<div ' . $this->get_render_attribute_string('crust-progressbar-circle-half') . '></div>';
                        $html .= '</div>';
                        $html .= '<div class="crust-progressbar-circle-inner"></div>';
                    $html .= '</div>';
                    $html .= '<div class="crust-progressbar-circle-inner-content">';
                        $html .= ( $settings['progress_bar_title'] ) ? '<'.$tag.' class="crust-progressbar-title">'.$settings['progress_bar_title'].'</'.$tag.'>' : '';
                        $html .= ( $settings['progress_bar_show_count'] ) ? '<span class="crust-progressbar-count-wrap"><span class="crust-progressbar-count">0</span><span class="suffix">' . $settings['progress_bar_value']['unit'] . '</span></span>' : '';
                    $html .= '</div>';
                $html .= '</div>';
                $html .= '<div class="crust-progressbar-half-circle-after">';
                    $html .= ($settings['progress_bar_prefix_label']) ? '<span class="crust-progressbar-prefix-label">'.$settings['progress_bar_prefix_label'].'</span>' : '';
                    $html .= ($settings['progress_bar_suffix_label']) ? '<span class="crust-progressbar-suffix-label">'.$settings['progress_bar_suffix_label'].'</span>' : '';
                $html .= '</div>';
            $html .= '</div>';

        }

        echo $html;

    }
}
