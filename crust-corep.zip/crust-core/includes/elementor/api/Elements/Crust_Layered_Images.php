<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;

class Crust_Layered_Images extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-layered-images';
    }

	public function get_script_depends()
	{
		return ['crust-layered-images'];
	}

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-layered-images', true, false);
		return ['crust-layered-images'];
	}

    public function get_title()
    {
        return esc_html__('Layered Images', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-product-related';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_main_settings',
			[
				'label' => esc_html__('Images', 'crust-core')
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label'       => esc_html__('Image', 'crust-core'),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
				],
			]
		);

		$repeater->add_control(
			'width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'%' => [
						'max' => 100,
						'min' => 1,
					],
				]
			]
		);

		$repeater->add_control(
			'height',
			[
				'label'      => esc_html__('Height', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'%' => [
						'max' => 100,
						'min' => 1,
					],
				]
			]
		);

		$repeater->add_control(
			'tilt_box', [
				'label'        => esc_html__('Hover Tilt', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'z_index',
			[
				'label'     => esc_html__('Z-Index', 'elementor'),
				'type'      => Controls_Manager::NUMBER,
			]
		);

		$repeater->add_control(
			'h_of',
			[
				'label'      => esc_html__('Horizontal Offset (%)', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['%'],
				'range'      => [
					'%' => [
						'max' => 100,
						'min' => -100,
					],
				]
			]
		);

		$repeater->add_control(
			'v_of',
			[
				'label'      => esc_html__('Vertical Offset (%)', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['%'],
				'range'      => [
					'%' => [
						'max' => 100,
						'min' => -100,
					],
				]
			]
		);

		$repeater->add_control(
			'rotate',
			[
				'label'      => esc_html__('Rotate', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'max' => 360,
						'min' => -360,
					],
				]
			]
		);

		$repeater->add_control(
			'continuous_rotate', [
				'label'        => esc_html__('Continuous Rotate', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'img_animation',
			[
				'label' => __( 'Animation', 'crust-core' ),
				'type' => \Elementor\Controls_Manager::ANIMATION,
				'prefix_class' => 'animated ',
			]
		);

		$repeater->add_control(
			'animation_delay',
			[
				'label'     => esc_html__('Delay (ms)', 'elementor'),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '',
				'condition' => [
					'img_animation!' => ''
				],
			]
		);

		$this->add_control(
			'images',
			[
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_comp_wrap_settings',
			[
				'label' => esc_html__('Image Layer', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'comp_wrap_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-layered-images .crust-image-layer img',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'comp_wrap_border',
				'selector' => '{{WRAPPER}} .crust-layered-images .crust-image-layer img',
			]
		);

		$this->add_responsive_control(
			'comp_wrap_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-layered-images .crust-image-layer img,{{WRAPPER}} .crust-layered-images .js-tilt-glare' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'comp_wrap_box_shadow',
				'selector' => '{{WRAPPER}} .crust-layered-images .crust-image-layer img',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'label'    => esc_html__('Hover Shadow', 'elementor'),
				'name'     => 'comp_wrap_hover_box_shadow',
				'selector' => '{{WRAPPER}} .crust-layered-images .crust-image-layer:hover img',
			]
		);
		/**
		 * -------------------------------------------
		 * Image Layer Style dark
		 * -------------------------------------------
		 */



		$this->add_control(
			'comp_wrap_dark_head',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'comp_wrap_dark_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-layered-images .crust-image-layer img',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'comp_wrap_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-layered-images .crust-image-layer img',
			]
		);

		$this->end_controls_section();

	}

    protected function render()
    {

	    $settings = $this->get_settings_for_display();

	    $output = '<div class="crust-layered-images">';
		    $class = 'crust-image-layer';
	        $in_class = 'crust-layers-inner';

	        $i = 0;
		    foreach ($settings['images'] as $image) {
			    $i++;
			    $hfs = isset( $image['h_of']['size']) ? $image['h_of']['size'] : "";
			    $vfs = isset( $image['v_of']['size']) ? $image['v_of']['size'] : "";
			    $hf = ($hfs) ? 'left: '.$hfs.'%;' : '';
			    $vf = ($vfs) ? 'top: '.$vfs.'%;' : '';
			    $tilt = (isset($image['tilt_box']) && $image['tilt_box'] === 'yes' ) ? ' js-tilt' : '';
			    $zindex = (isset($image['z_index']) && $image['z_index'] ) ? ' z-index: ' . $image['z_index'] . ';' : '';
			    $rotate = (isset($image['rotate']['size']) && $image['rotate']['size'] ) ? ' transform: rotate(' . $image['rotate']['size'] . 'deg);' : '';
			    $imgs = ( $image['image']['url'] ) ? '<img src="' . $image['image']['url'] . '">' : '';
			    $lay_img = wp_get_attachment_image_src($image['image']['id'], 'full');
			    $ww = isset($lay_img) ? $lay_img[1] : '';
			    $ht = isset($lay_img) ? $lay_img[2] : '';
			    $wid = ( isset($image['width']['size']) && $image['width']['size'] ) ? $image['width']['size'] : $ww;
			    $hei = ( isset($image['height']['size']) && $image['height']['size'] ) ? $image['height']['size'] : $ht;
			    $withtilt = (isset($image['tilt_box']) && $image['tilt_box'] && !$rotate ) ? 'with-tilt' : '';

			    $this->add_render_attribute(
				    'img' . $i,
				    [
				    	'class' => [
				    		$class,
						    $withtilt
					    ],
				    ]
			    );

			    $this->add_render_attribute( 'img_wrap' . $i, [
				    'class' => $in_class
		        ]);

			    if ( $image['img_animation'] ) {
				    $this->add_render_attribute('img' . $i, [
				    	'class' => 'crust-fx animate__animated',
					    'data-animate' => $image['img_animation']
				    ]);
			    }

			    if( $image['continuous_rotate'] === 'yes' ) {
				    $this->add_render_attribute( 'img_wrap' . $i, [
					    'class' => 'crust-continuous-rotate'
				    ]);
			    }

			    if ( $image['animation_delay'] ) {
				    $this->add_render_attribute('img' . $i, [
					    'data-animation-delay' => $image['animation_delay']
				    ]);
			    }

			    if( $wid || $hei || $hf || $vf || $zindex ){
				    $this->add_render_attribute(
					    'img' . $i,
					    [
						    'style' => 'width:'.$wid.'px;height:'.$hei.'px;'.$hf.$vf.$zindex,
					    ]
				    );
			    }

			    if( $rotate ){
				    $this->add_render_attribute(
					    'img_wrap' . $i,
					    [
						    'style' => $rotate,
					    ]
				    );
			    } else {
			    	if( $tilt ){
					    $this->add_render_attribute(
						    'img_wrap' . $i,
						    [
						    	'class' => [
								    $tilt
							    ],
							    'data-tilt-max' => '4',
							    'data-tilt-scale' => '1.05',
							    'data-tilt-speed' => '1000',
							    'data-tilt-perspective' => '800',
						    ]
					    );
				    }
			    }

			    $output .= '<div ' .$this->get_render_attribute_string( 'img' . $i ).'>';
				    $output .= '<div ' .$this->get_render_attribute_string( 'img_wrap' . $i ).'>';
				        $output .= $imgs;
				    $output .= '</div>';
			    $output .= '</div>';

		    }
	    $output .= '</div>';

	    echo $output;

    }

}
