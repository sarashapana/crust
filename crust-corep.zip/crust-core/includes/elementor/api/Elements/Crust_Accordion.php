<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Accordion extends Widget_Base
{

	use \Crust_Core\Traits\Helper;

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-accordion', true, true);
		return ['crust-accordion'];
	}

	public function get_name()
	{
		return 'crust-accordion';
	}

	public function get_title()
	{
		return esc_html__('Accordion', 'crust-core');
	}

	public function get_icon()
	{
		return 'eicon-accordion';
	}

	public function get_categories()
	{
		return ['crust'];
	}

	protected function register_controls()
	{
		/**
		 * Accordion Settings
		 */
		$this->start_controls_section(
			'crust_section_settings',
			[
				'label' => esc_html__('General Settings', 'crust-core'),
			]
		);
		$this->add_control(
			'crust_accordion_style',
			[
				'label'       => esc_html__('Style', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'label_block' => false,
				'options'     => [
					''          => esc_html__('Default', 'crust-core'),
					'creative'  => esc_html__('Creative', 'crust-core'),
					'fancy'     => esc_html__('Fancy', 'crust-core'),
				],
			]
		);
		$this->add_control(
			'crust_accordion_type',
			[
				'label'       => esc_html__('Type', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'accordion',
				'label_block' => false,
				'options'     => [
					'accordion' => esc_html__('Accordion', 'crust-core'),
					'toggle'    => esc_html__('Toggle', 'crust-core'),
				],
			]
		);
		$this->add_control(
			'crust_accordion_icon_show',
			[
				'label'        => esc_html__('Show Toggle Icon', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'crust_accordion_icon',
			[
				'label'            => esc_html__('Toggle Icon', 'crust-core'),
				'type'             => Controls_Manager::ICONS,
				'default'          => [
					'value'   => 'fad fa-plus-square',
					'library' => 'dutone',
				],
				'condition'        => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'toggle_alt_icon',
			[
				'label'            => esc_html__('Alt Toggle Icon', 'crust-core'),
				'type'             => Controls_Manager::ICONS,
				'default'          => [
					'value'   => 'fad fa-minus-square',
					'library' => 'dutone',
				],
				'condition'        => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'crust_accordion_toggle_speed',
			[
				'label'       => esc_html__('Toggle Speed (ms)', 'crust-core'),
				'type'        => Controls_Manager::NUMBER,
				'label_block' => false,
				'default'     => 300,
			]
		);
		$this->end_controls_section();

		/**
		 * Accordion Content Settings
		 */
		$this->start_controls_section(
			'crust_section_accordion_content_settings',
			[
				'label' => esc_html__('Content Settings', 'crust-core'),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'crust_accordion_tab_default_active', [
				'label'        => esc_html__('Active by Default', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'crust_accordion_tab_icon_show', [
				'label'        => esc_html__('Show Tab Icon', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'crust_accordion_tab_title_icon', [
				'label'            => esc_html__('Icon', 'elementor'),
				'type'             => Controls_Manager::ICONS,
				'default'          => [
					'value'   => 'fad fa-alarm-clock',
					'library' => 'fontawesome',
				],
				'condition'        => [
					'crust_accordion_tab_icon_show' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'crust_accordion_tab_title', [
				'label'   => esc_html__('Title', 'crust-core'),
				'type'    => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Tab Title', 'crust-core'),
				'dynamic' => ['active' => true],
			]
		);

		$repeater->add_control(
			'crust_accordion_text_type', [
				'label'   => esc_html__('Content Type', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'content'  => esc_html__('Content', 'crust-core'),
					'template' => esc_html__('Saved Templates', 'crust-core'),
				],
				'default' => 'content',
			]
		);

		$repeater->add_control(
			'crust_core_primary_templates', [
				'label'     => esc_html__('Choose Template', 'crust-core'),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->crust_core_get_page_templates(),
				'condition' => [
					'crust_accordion_text_type' => 'template',
				],
			]
		);

		$repeater->add_control(
			'crust_accordion_tab_content', [
				'label'     => esc_html__('Tab Content', 'crust-core'),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__(
					'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio, neque qui velit. Magni dolorum quidem ipsam eligendi, totam, facilis laudantium cum accusamus ullam voluptatibus commodi numquam, error, est. Ea, consequatur.',
					'crust-core'
				),
				'dynamic'   => ['active' => true],
				'condition' => [
					'crust_accordion_text_type' => 'content',
				],
			]
		);

		$this->add_control(
			'crust_accordion_tab',
			[
				'type'        => Controls_Manager::REPEATER,
				'seperator'   => 'before',
				'default'     => [
					['crust_accordion_tab_title' => esc_html__('How can I register on site ?', 'crust-core')],
					['crust_accordion_tab_title' => esc_html__('What are the main theme features ?', 'crust-core')],
					['crust_accordion_tab_title' => esc_html__('Is it free or will be charged in future ?', 'crust-core')],
				],
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{crust_accordion_tab_title}}',
			]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Accordion Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
			'crust_section_accordions_tab_style_settings',
			[
				'label' => esc_html__('Tab Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'crust_title_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'span',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_accordion_tab_title_typography',
				'selector' => '{{WRAPPER}} .crust-accordion .crust-tab-title .crust-accordion-title',
			]
		);
		$this->add_responsive_control(
			'crust_accordion_tab_icon_size',
			[
				'label'      => esc_html__('Icon Size', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => 16,
					'unit' => 'px',
				],
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_accordion_icon_margin',
			[
				'label'      => esc_html__('Icon Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title i.crust-accordion-icon,{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_accordion_tab_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'crust_accordion_tab_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->start_controls_tabs('crust_accordion_header_tabs');
		# Normal State Tab
		$this->start_controls_tab('crust_accordion_header_normal', ['label' => esc_html__('Normal', 'elementor')]);
		$this->add_control(
			'crust_accordion_tab_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f1f1f1',
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_tab_bgtype',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title',
			]
		);
		$this->add_control(
			'crust_accordion_tab_text_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-accordion-title' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'crust_accordion_tab_icon_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_tab_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title',
			]
		);
		$this->add_responsive_control(
			'crust_accordion_tab_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_accordion_tab_shadow',
				'selector'  => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title',
			]
		);
////		======================================================================

		$this->add_control(
			'crust_accordion_normal_dark_tab_head',
			[
				'label'     => esc_html__( 'Dark Mode', 'crust-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'crust_accordion_normal_dark_tab_color',
			[
				'label'     => esc_html__( 'Background Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_normal_dark_tab_bgtype',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title',
			]
		);
		$this->add_control(
			'crust_accordion_normal_dark_tab_text_color',
			[
				'label'     => esc_html__( 'Color', 'crust-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title'                        => 'color: {{VALUE}};',
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-accordion-title' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'crust_accordion_normal_dark_tab_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'crust-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_normal_dark_tab_border',
				'label'    => esc_html__( 'Border', 'crust-core' ),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title',
			]
		);
////	    ======================================================================
		$this->end_controls_tab();

		# Hover State Tab
		$this->start_controls_tab(
			'crust_accordion_header_hover',
			[
				'label' => esc_html__('Hover', 'elementor'),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_tab_bgtype_hover',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover',
			]
		);
		$this->add_control(
			'crust_accordion_tab_text_color_hover',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover,{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-accordion-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'crust_accordion_tab_icon_color_hover',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_tab_border_hover',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover',
			]
		);
		$this->add_responsive_control(
			'crust_accordion_tab_border_radius_hover',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_accordion_tab_hover_shadow',
				'selector'  => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover',
			]
		);

//		=================================================================================================
		$this->add_control(
			'crust_accordion_hover_dark_tab_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_dark_tab_bgtype_hover',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover',
			]
		);
		$this->add_control(
			'crust_accordion_dark_tab_text_color_hover',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover,body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-accordion-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'crust_accordion_dark_tab_icon_color_hover',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_dark_tab_border_hover',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover',
			]
		);
//		=================================================================================================
		$this->end_controls_tab();

		#Active State Tab
		$this->start_controls_tab(
			'crust_accordion_header_active',
			[
				'label' => esc_html__('Active', 'crust-core'),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_tab_bgtype_active',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active',
			]
		);
		$this->add_control(
			'crust_accordion_tab_text_color_active',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active' => 'color: {{VALUE}};',
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-accordion-title' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'crust_accordion_tab_icon_color_active',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_tab_border_active',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active',
			]
		);
		$this->add_responsive_control(
			'crust_accordion_tab_border_radius_active',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_accordion_tab_active_shadow',
				'selector'  => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active',
			]
		);

////		======================================================================
		$this->add_control(
			'crust_accordion_active_dark_tab_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_dark_tab_bgtype_active',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active',
			]
		);
		$this->add_control(
			'crust_accordion_dark_tab_text_color_active',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active' => 'color: {{VALUE}};',
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-accordion-title' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'crust_accordion_dark_tab_icon_color_active',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active > i.crust-accordion-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_dark_tab_border_active',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active',
			]
		);
////	    ======================================================================
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Accordion Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
			'crust_section_accordion_tab_content_style_settings',
			[
				'label' => esc_html__('Content Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_content_bgtype',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
			]
		);

		$this->add_control(
			'crust_accordion_content_text_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_accordion_content_typography',
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
			]
		);
		$this->add_responsive_control(
			'crust_accordion_content_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'crust_accordion_content_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'crust_accordion_content_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_accordion_content_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_accordion_content_shadow',
				'selector'  => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
				'separator' => 'before',
			]
		);

//		===================================================================================
		$this->add_control(
			'crust_accordion_dark_content_dark_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_accordion_dark_content_bgtype',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
			]
		);

		$this->add_control(
			'crust_accordion_dark_content_text_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content' => 'color: {{VALUE}};',
				],
			]
		);$this->add_group_control(
		Group_Control_Border::get_type(),
		[
			'name'     => 'crust_accordion_dark_content_border',
			'label'    => esc_html__('Border', 'crust-core'),
			'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-content',
		]
	);

//     ====================================================================================
		$this->end_controls_section();

		/**
		 * Accordion Caret Settings
		 */
		$this->start_controls_section(
			'crust_section_accordion_caret_settings',
			[
				'label' => esc_html__('Toggle Caret Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_responsive_control(
			'crust_accordion_tab_toggle_width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'crust_accordion_tab_toggle_height',
			[
				'label'      => esc_html__('Height', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'crust_accordion_tab_toggle_icon_size',
			[
				'label'      => esc_html__('Icon Size', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-alt-toggle-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title > img'      => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'crust_accordion_tab_toggle_icon_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_core_tabs_tab_toggle_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->start_controls_tabs('crust_caret_tabs');

		$this->start_controls_tab('crust_caret_tabs_normal', ['label' => esc_html__('Normal', 'elementor')]);

		$this->add_control(
			'crust_core_tabs_tab_toggle_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_background',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_border',
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);
//		============================================================================================
		$this->add_control(
			'crust_tabs_tab_toggle_normal_dark_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'crust_core_tabs_tab_toggle_dark_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_dark_background',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);
//	    ============================================================================================

		$this->end_controls_tab();

		$this->start_controls_tab('crust_caret_tabs_hover', ['label' => esc_html__('Hover', 'elementor')]);

		$this->add_control(
			'crust_core_tabs_tab_hover_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons i' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_hover_toggle_background',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_hover_toggle_border',
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);
//		============================================================================================
		$this->add_control(
			'crust_tabs_tab_toggle_dark_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'crust_core_tabs_tab_hover_dark_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons i' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_hover_dark_toggle_background',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_hover_dark_toggle_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title:hover .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);
//	    ===============================================================================================

		$this->end_controls_tab();

		$this->start_controls_tab('crust_caret_tabs_active', ['label' => esc_html__('Active', 'elementor')]);

		$this->add_control(
			'crust_core_tabs_tab_toggle_active_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons i' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_active_toggle_background',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_active_toggle_border',
				'selector' => '{{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);
		/*
		 * Dark
		 * */
		$this->add_control(
			'crust_tabs_tab_toggle_dark_active_head',
			[
				'label'     => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'crust_core_tabs_tab_toggle_active_dark_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons i' => 'color: {{VALUE}};',
				],
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_active_dark_toggle_background',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_core_tabs_tab_toggle_active_dark_toggle_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-accordion .crust-accordion-item .crust-tab-title.active .crust-toggle-icons',
				'condition' => [
					'crust_accordion_icon_show' => 'yes',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$id_int   = substr($this->get_id_int(), 0, 3);
		$tag      = $settings['crust_title_tag'];

		$this->add_render_attribute(
			'crust-accordion',
			[
				'id'                    => 'crust-accordion-' . esc_attr($this->get_id()),
				'class'                 => [ 'crust-accordion', $settings['crust_accordion_style'] ],
				'data-accordion-id'     => esc_attr($this->get_id()),
				'data-accordion-type'   => esc_attr($settings['crust_accordion_type']),
				'data-toogle-speed'     => esc_attr($settings['crust_accordion_toggle_speed']),
			]
		);

		$html = '<div '. $this->get_render_attribute_string("crust-accordion").'>';

		foreach ($settings['crust_accordion_tab'] as $index => $tab) {
			$tab_count               = $index + 1;
			$tab_title_setting_key   = $this->get_repeater_setting_key('crust_accordion_tab_title', 'crust_accordion_tab', $index);
			$tab_content_setting_key = $this->get_repeater_setting_key('crust_accordion_tab_content', 'crust_accordion_tab', $index);

			$tab_title_class   = ['crust-tab-title'];
			$tab_content_class = ['crust-tab-content', 'crust-clearfix'];

			if ($tab['crust_accordion_tab_default_active'] == 'yes') {
				$tab_title_class[]   = 'active-default';
				$tab_content_class[] = 'active-default';
			}

			$this->add_render_attribute(
				$tab_title_setting_key,
				[
					'id'            => 'crust-tab-title-' . $id_int . $tab_count,
					'class'         => $tab_title_class,
					'tabindex'      => $id_int . $tab_count,
					'data-tab'      => $tab_count,
					'aria-controls' => 'crust-tab-content-' . $id_int . $tab_count,
				]
			);

			$this->add_render_attribute(
				$tab_content_setting_key,
				[
					'id'              => 'crust-tab-content-' . $id_int . $tab_count,
					'class'           => $tab_content_class,
					'data-tab'        => $tab_count,
					'aria-labelledby' => 'crust-tab-title-' . $id_int . $tab_count,
				]
			);

			$html .= '<div class="crust-accordion-item">';
			$html .= '<div ' . $this->get_render_attribute_string($tab_title_setting_key) . '>';

			if ($tab['crust_accordion_tab_icon_show'] === 'yes') {
				if (isset($tab['crust_accordion_tab_title_icon']['value']['url'])) {
					$html .= '<img src="' . $tab['crust_accordion_tab_title_icon']['value']['url'] . '" class="crust-accordion-icon" />';
				} else {
					$html .= '<i class="' . $tab['crust_accordion_tab_title_icon']['value'] . ' crust-accordion-icon"></i>';
				}
			}

			$html .= '<'.$tag.' class="crust-accordion-title">';
			$html .= $tab['crust_accordion_tab_title'];
			$html .= '</'.$tag.'>';

			if ($settings['crust_accordion_icon_show'] === 'yes') {
				$html .= '<span class="crust-toggle-icons">';
				if (isset($settings['crust_accordion_icon']['value']['url'])) {
					$html .= '<img src="' . $settings['crust_accordion_icon']['value']['url'] . '" />';
					$html .= ( $settings['toggle_alt_icon'] ) ? '<i class="crust-alt-toggle-icon '. $settings['toggle_alt_icon'] .'"></i>' : '';
				} else {
					$html .= '<i class="' . $settings['crust_accordion_icon']['value'] . ' crust-toggle-icon"></i>';
					$html .= ( $settings['toggle_alt_icon']['value'] ) ? '<i class="crust-alt-toggle-icon '. $settings['toggle_alt_icon']['value'] .'"></i>' : '';
				}
				$html .= '</span>';
			}

			$html .= '</div>';

			$html .= '<div ' . $this->get_render_attribute_string($tab_content_setting_key) . '>';
			if ('content' == $tab['crust_accordion_text_type']) {
				$html .= do_shortcode($tab['crust_accordion_tab_content']);
			} elseif ('template' == $tab['crust_accordion_text_type']) {
				if ( ! empty($tab['crust_core_primary_templates'])) {
					$crust_core_template_id = $tab['crust_core_primary_templates'];
					$crust_core_frontend    = new Frontend;
					$html .= $crust_core_frontend->get_builder_content($crust_core_template_id, true);
				}
			}
			$html .= '</div>';
			$html .= '</div>';
		}

		$html .= '</div>';

		echo $html;

	}

}
