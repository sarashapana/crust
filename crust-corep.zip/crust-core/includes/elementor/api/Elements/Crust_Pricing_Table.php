<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Pricing_Table extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
	    do_action('enqueue_crust_assets','crust-pricing', false, true);
        return ['crust-pricing'];
    }

    public function get_name()
    {
        return 'crust-pricing';
    }

    public function get_title()
    {
        return esc_html__('Pricing Table', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-price-table';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Pricing Table Settings
         */
        $this->start_controls_section(
            'crust_section_pricing_settings',
            [
                'label' => esc_html__('Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_icon_show',
            [
                'label'        => __('Show Icon', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

	    $this->add_control(
		    'crust_pricing_btn_show',
		    [
			    'label'        => __('Show Button', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
			    'default'      => 'yes'
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_bottom_show',
		    [
			    'label'        => __('Bottom Divider', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes'
		    ]
	    );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_pricing_icon',
            [
                'label' => esc_html__('Icon', 'elementor'),
                'condition'        => [
                    'crust_pricing_icon_show' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_icon_type',
            [
                'label'       => esc_html__('Icon Type', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'icon'  => [
                        'title' => esc_html__('Icon', 'elementor'),
                        'icon'  => 'fa fa-star',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'crust-core'),
                        'icon'  => 'fa fa-picture-o',
                    ]
                ],
                'default'     => 'icon',
            ]
        );

        $this->add_control(
            'crust_pricing_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fas fa-home',
                    'library' => 'fa-solid',
                ],
                'condition'        => [
                    'crust_pricing_icon_type' => 'icon',
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_image',
            [
                'name'      => 'crust_tabs_tab_title_image',
                'label'     => esc_html__('Image', 'crust-core'),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'crust_pricing_icon_type' => 'image',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'thumbnail',
                'default'   => 'full',
                'condition' => [
                    'crust_pricing_icon_type' => 'image',
                    'crust_pricing_image[url]!' => '',
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_icon_position',
            [
                'label'       => esc_html__('Position', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'top',
                'label_block' => false,
                'options'     => [
                    'top' => esc_html__('Top', 'crust-core'),
                    'after-title' => esc_html__('After Title', 'crust-core'),
                    'after-price' => esc_html__('After Price', 'crust-core'),
                    'after-list' => esc_html__('After List', 'crust-core'),
                    'bottom' => esc_html__('Bottom', 'crust-core'),
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_pricing_title',
            [
                'label' => esc_html__('Title', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_title',
            [
                'label'       => esc_html__('Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Basic Plan', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_title_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h4',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_sub_title',
            [
                'label'       => esc_html__('Sub Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('For Small Business.', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_pricing_subtitle_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h6',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ]
            ]
        );

        $this->end_controls_section();

        /**
         * Pricing Table Price
         */
        $this->start_controls_section(
            'crust_section_pricing_price',
            [
                'label' => esc_html__('Price', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_regular_text',
            [
                'label'       => esc_html__('Regular Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('Regular', 'crust-core'),
                'condition'   => [
                    'crust_pricing_onsale' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_price',
            [
                'label'       => esc_html__('Price', 'crust-core'),
                'type'        => Controls_Manager::NUMBER,
                'label_block' => false,
                'default'     => esc_html__('9.99', 'crust-core')
            ]
        );
        $this->add_control(
            'crust_pricing_onsale',
            [
                'label'        => __('Sale?', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'crust_pricing_onsale_price',
            [
                'label'       => esc_html__('Sale Price', 'crust-core'),
                'type'        => Controls_Manager::NUMBER,
                'label_block' => false,
                'default'     => esc_html__('6.99', 'crust-core'),
                'condition'   => [
                    'crust_pricing_onsale' => 'yes'
                ]
            ]
        );
        $this->add_control(
            'crust_pricing_price_cur',
            [
                'label'       => esc_html__('Price Currency', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('$', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_pricing_price_cur_placement',
            [
                'label'       => esc_html__('Currency Placement', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'left',
                'label_block' => false,
                'options'     => [
                    'left'  => esc_html__('Left', 'crust-core'),
                    'right' => esc_html__('Right', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_price_period',
            [
                'label'       => esc_html__('Price Period (per)', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('mo.', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_period_separator',
            [
                'label'       => esc_html__('Period Separator', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('/', 'crust-core')
            ]
        );

        $this->end_controls_section();

        /**
         * Pricing Table Feature
         */
        $this->start_controls_section(
            'crust_section_pricing_feature',
            [
                'label' => esc_html__('Feature List', 'crust-core')
            ]
        );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_pricing_item', [
			    'label'       => esc_html__('List Item', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Pricing table list item', 'crust-core')
		    ]
	    );

	    $repeater->add_control(
		    'crust_pricing_list_icon', [
			    'label'            => esc_html__('List Icon', 'crust-core'),
			    'type'             => Controls_Manager::ICONS,
			    'default'          => [
				    'value'   => 'fa fa-check',
				    'library' => 'fa-solid',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_pricing_icon_mood', [
			    'label'        => esc_html__('Item Active?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'return_value' => 'yes',
			    'default'      => 'yes'
		    ]
	    );

	    $repeater->add_control(
		    'crust_pricing_list_icon_color', [
			    'label'   => esc_html__('Icon Color', 'crust-core'),
			    'type'    => Controls_Manager::COLOR,
		    ]
	    );

        $this->add_control(
            'crust_pricing_items',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    ['crust_pricing_item' => '1GB Storage'],
                    ['crust_pricing_item' => '500 MB Bandwidth'],
                    ['crust_pricing_item' => '25 FTP Accounts'],
                    ['crust_pricing_item' => '25 Email Accounts'],
                    ['crust_pricing_item' => '24/7 support']
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_pricing_item}}',
            ]
        );

        $this->end_controls_section();

	    /**
	     * Pricing Table Additional Feature
	     */
	    $this->start_controls_section(
		    'crust_pricing_additional_feature',
		    [
			    'label' => esc_html__('Additional Features', 'crust-core')
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_title',
		    [
			    'label'       => esc_html__('Title', 'elementor'),
			    'type'        => Controls_Manager::TEXT,
			    'default'     => 'Additional Features',
			    'label_block' => true,
		    ]
	    );

	    $repeater2 = new \Elementor\Repeater();

	    $repeater2->add_control(
		    'crust_pricing_additional_item', [
			    'label'       => esc_html__('List Item', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => esc_html__('Feature item', 'crust-core')
		    ]
	    );

	    $repeater2->add_control(
		    'crust_pricing_additional_list_icon', [
			    'label'            => esc_html__('List Icon', 'crust-core'),
			    'type'             => Controls_Manager::ICONS,
			    'default'          => [
				    'value'   => 'fa fa-check',
				    'library' => 'fa-solid',
			    ],
		    ]
	    );

	    $repeater2->add_control(
		    'crust_pricing_additional_icon_mood', [
			    'label'        => esc_html__('Item Active?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'return_value' => 'yes',
			    'default'      => 'yes'
		    ]
	    );

	    $repeater2->add_control(
		    'crust_pricing_additional_list_icon_color', [
			    'label'   => esc_html__('Icon Color', 'crust-core'),
			    'type'    => Controls_Manager::COLOR,
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_items',
		    [
			    'type'        => Controls_Manager::REPEATER,
			    'seperator'   => 'before',
			    'fields'      => $repeater2->get_controls(),
			    'title_field' => '{{crust_pricing_additional_item}}',
		    ]
	    );

	    $this->end_controls_section();

        /**
         * Pricing Table Footer
         */
        $this->start_controls_section(
            'crust_section_pricing_footerr',
            [
                'label' => esc_html__('Button', 'crust-core')
            ]
        );

	    $this->add_control(
		    'button_hover_style',
		    [
			    'label'   => esc_html__('Hover Style', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
				    'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
				    'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
				    'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
				    'btn-greip'     => esc_html__('Greip', 'crust-core'),
				    'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_pricing_button_icon',
            [
                'label'            => esc_html__('Button Icon', 'crust-core'),
                'type'             => Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'crust_pricing_button_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'crust_pricing_button_icon!' => '',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_button_icon_indent',
            [
                'label'     => esc_html__('Icon Spacing', 'elementor'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 60,
                    ],
                ],
                'condition' => [
                    'crust_pricing_button_icon!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-button i.fa-icon-left'  => 'margin-right: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-pricing-button i.fa-icon-right' => 'margin-left: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_btn',
            [
                'label'       => esc_html__('Button Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Choose Plan', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_pricing_btn_link',
            [
                'label'         => esc_html__('Button Link', 'crust-core'),
                'type'          => Controls_Manager::URL,
                'label_block'   => true,
                'default'       => [
                    'url'         => '#',
                    'is_external' => '',
                ],
                'show_external' => true,
            ]
        );

        $this->end_controls_section();

        /**
         * Pricing Table Rebon
         */
        $this->start_controls_section(
            'crust_section_pricing_featured',
            [
                'label' => esc_html__('Featured', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_pricing_featured',
            [
                'label'        => esc_html__('Featured?', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
            'crust_pricing_featured_styles',
            [
                'label'     => esc_html__('Ribbon Style', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'ribbon-1',
                'options'   => [
                    'ribbon-1' => esc_html__('Style 1', 'crust-core'),
                    'ribbon-2' => esc_html__('Style 2', 'crust-core'),
                    'ribbon-3' => esc_html__('Style 3', 'crust-core'),
	                'image'    => esc_html__( 'Image', 'crust-core')
                ],
                'condition' => [
                    'crust_pricing_featured' => 'yes',
                ],
            ]
        );

	    $this->add_control(
		    'crust_pricing_ribbon_image',
		    [
			    'label'   => __('Image', 'crust-core'),
			    'type'    => Controls_Manager::MEDIA,
			    'condition'   => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles' => 'image'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_ribbon_image_width',
		    [
			    'label'     => esc_html__('Max. Width', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 500,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item img.crust-pricing-ribbon'   => 'max-width: {{SIZE}}{{UNIT}};',
			    ],
			    'condition'   => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles' => 'image',
				    'crust_pricing_ribbon_image!' => ''
			    ]
		    ]
	    );

        $this->add_control(
            'crust_pricing_featured_tag_text',
            [
                'label'       => esc_html__('Featured Tag Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => esc_html__('Featured', 'crust-core'),
                'selectors'   => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item.featured .crust-ribbon:before' => 'content: "{{VALUE}}";',
                ],
                'condition'   => [
                    'crust_pricing_featured'        => 'yes',
	                'crust_pricing_featured_styles!' => 'image'
                ]
            ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Pricing Table Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_style_settings',
            [
                'label' => esc_html__('Item Box Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_responsive_control(
            'crust_pricing_content_alignment',
            [
                'label'        => esc_html__('Content Alignment', 'crust-core'),
                'type'         => Controls_Manager::CHOOSE,
                'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
                    'left'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],

                ],
                'default'      => 'center',
                'prefix_class' => 'crust-pricing-content-align-',
            ]
        );

	    $this->start_controls_tabs('crust_pricing_tabs');

	    $this->start_controls_tab('crust_pricing_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_responsive_control(
		    'crust_pricing_container_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_container_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_border',
			    'label'    => esc_html__('Border Type', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3' => 'border-radius: 0 {{RIGHT}}{{UNIT}} 0 0;'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'crust_pricing_shadow',
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Tab Style (item box) dark normal
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_container_dark_normal_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_dark_normal_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_dark_normal_border',
			    'label'    => esc_html__('Border Type', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item',
		    ]
	    );
	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_responsive_control(
		    'crust_pricing_hover_container_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_hover_container_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_hover_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_hover_border',
			    'label'    => esc_html__('Border Type', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_pricing_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Tab Style (item box) dark hover
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_container_dark_hover_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_dark_hover_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_dark_hover_border',
			    'label'    => esc_html__('Border Type', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Pricing Table Icon Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_icon_settings',
            [
                'label'     => esc_html__('Icon Settings', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
	            'condition' => [
	            	'crust_pricing_icon_show' => 'yes'
	            ]
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_icon_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'crust-core'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],

			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon' => 'justify-content: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_pricing_icon_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_icon_size',
		    [
			    'label'     => esc_html__('Icon Size', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 30
			    ],
			    'range'     => [
				    'px' => [
					    'max' => 500,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_icon_area_width',
		    [
			    'label'     => esc_html__('Icon Area Width', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 80
			    ],
			    'range'     => [
				    'px' => [
					    'max' => 500,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon' => 'width: {{SIZE}}px;',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_icon_area_height',
		    [
			    'label'     => esc_html__('Icon Area Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 80
			    ],
			    'range'     => [
				    'px' => [
					    'max' => 500,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon' => 'height: {{SIZE}}px;',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_pricing_icon_tabs');

	    $this->start_controls_tab('crust_pricing_icon_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon',
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_icon_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_pricing_icon_type' => 'icon',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_shadow',
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Tab Style (Pricing Table Icon Style) dark normal
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_section_pricing_icon_dark_normal_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_dark_normal_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon',
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_icon_dark_normal_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_pricing_icon_type' => 'icon',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_icon_dark_normal_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-icon .icon',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon',
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_icon_hover_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_pricing_icon_type' => 'icon',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_icon_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_icon_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_hover_shadow',
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Tab Style (Pricing Table Icon Style) dark hover
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_section_pricing_icon_dark_hover_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_icon_dark_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon',
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_icon_dark_hover_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_pricing_icon_type' => 'icon',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_icon_dark_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-icon .icon',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Style (Header)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_header_style_settings',
            [
                'label' => esc_html__('Header', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_header_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
				'default' => 'center',
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_header_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_header_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_pricing_header_shadow',
                'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .header',
            ]
        );

	    $this->start_controls_tabs('crust_pricing_header_tabs');

	    $this->start_controls_tab('crust_pricing_header_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_header_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .header',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_header_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .header',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_header_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Header) dark normal
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_section_pricing_header_dark_normal_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_header_dark_bg_normal',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .header',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_header_dark_normal_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .header',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_header_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_header_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .header',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_header_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .header',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_header_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Header) dark hover
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_section_pricing_header_dark_hover_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_header_dark_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .header',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_header_dark_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .header',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

	    $this->add_control(
		    'crust_pricing_title_heading',
		    [
			    'label'     => esc_html__('Title Style', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

        $this->add_control(
            'crust_pricing_header_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .header .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_title_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .header .title',
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_pricing_subtitle_heading',
            [
                'label'     => esc_html__('Subtitle Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'crust_pricing_subtitle_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .header .subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'crust_pricing_subtitle_typography',
                'selector'  => '{{WRAPPER}} .crust-pricing-item .header .subtitle',
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_subtitle_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .header .subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Title & Subtitle ) dark
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_title_heading_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_header_title_dark_color',
		    [
			    'label'     => esc_html__('Title Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .header .title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_subtitle_dark_color',
		    [
			    'label'     => esc_html__('Subtitle Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .header .subtitle' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();


        /**
         * -------------------------------------------
         * Style (Pricing)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_title_style_settings',
            [
                'label' => esc_html__('Pricing', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_price_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
				'default' => 'center',
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_price_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_price_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_pricing_price_tabs');

	    $this->start_controls_tab('crust_pricing_price_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_price_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_price_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_price_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_pricing_price_shadow',
                'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Style (Pricing) dark normal
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_price_tabs_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_price_bg_dark_normal',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_price_normal_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-pricing-tag',
		    ]
	    );


	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_price_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_price_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_price_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_price_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_pricing_price_hover_shadow',
                'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Style (Pricing) dark hover
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_price_tabs_hover_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_price_bg_dark_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_price_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .crust-pricing-tag',
		    ]
	    );


	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->add_control(
            'crust_pricing_price_tag_onsale_heading',
            [
                'label'     => esc_html__('Original Price', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_pricing_pricing_onsale_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .muted-price' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_price_tag_onsale_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .muted-price',
            ]
        );

        $this->add_control(
            'crust_pricing_price_tag_heading',
            [
                'label'     => esc_html__('Sale Price', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_pricing_pricing_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .price-tag' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_price_tag_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .price-tag',
            ]
        );

        $this->add_control(
            'crust_pricing_price_currency_heading',
            [
                'label'     => esc_html__('Currency', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_pricing_pricing_curr_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .price-tag .price-currency' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_price_cur_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .price-currency',
            ]
        );

        $this->add_responsive_control(
            'crust_pricing_price_cur_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-pricing-item .price-currency' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_pricing_period_heading',
            [
                'label'     => esc_html__('Pricing Period', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_pricing_pricing_period_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .price-period' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_price_preiod_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .price-period',
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_preiod_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-item .price-period' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_preiod_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-item .price-period' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_pricing_preiod_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-pricing-item .price-period',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_pricing_preiod_border',
			    'selector' => '{{WRAPPER}} .crust-pricing-item .price-period',
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_preiod_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-item .price-period' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'period_block',
		    [
			    'label'         => esc_html__('Display Block ?', 'crust-core'),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Pricing) dark
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_price_tag_sale_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_pricing_onsale_dark_color',
		    [
			    'label'     => esc_html__('Original Price Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .muted-price' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_pricing_dark_color',
		    [
			    'label'     => esc_html__('Sale Price Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .price-tag' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_pricing_curr_dark_color',
		    [
			    'label'     => esc_html__('Currency Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .price-tag .price-currency' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_price_period_dark_head',
		    [
			    'label'      => esc_html__('Pricing Period', 'elementor'),
			    'type'       => Controls_Manager::HEADING,


		    ]
	    );
	    $this->add_control(
		    'crust_pricing_pricing_period_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .price-period' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_pricing_preiod_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing-item .price-period',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_pricing_preiod_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing-item .price-period',
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Style (Feature List)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_style_featured_list_settings',
            [
                'label' => esc_html__('Price List', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_list_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
				'default' => 'center',
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body ul li' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_list_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_list_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_pricing_list_tabs');

	    $this->start_controls_tab('crust_pricing_list_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_list_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .body',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_list_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .body',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_list_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Feature List) dark normal
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_list_tab_dark_normal_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_list_dark_normal_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_list_dark_normal_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_list_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_list_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_list_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_list_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Feature List) dark hover
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_list_tab_dark_hover_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_list_dark_hover_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_list_dark_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body',
		    ]
	    );

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

	    $this->add_responsive_control(
		    'crust_pricing_list_item_margin',
		    [
			    'label'      => esc_html__('Item Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_list_item_padding',
		    [
			    'label'      => esc_html__('Item Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_list_item_color',
		    [
			    'label'     => esc_html__('Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body ul li' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_list_alt_item_color',
		    [
			    'label'     => esc_html__('Alternate Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body ul li:nth-child(even)' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_list_item_bg_color',
		    [
			    'label'     => esc_html__('Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body ul li' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_list_alt_item_bg_color',
		    [
			    'label'     => esc_html__('Alternate Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body ul li:nth-child(even)' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_pricing_list_divider_color',
            [
                'label'     => esc_html__('Divider Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body ul li' => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_list_disable_item_color',
            [
                'label'     => esc_html__('Disable item color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item ul li.disable-item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_list_item_icon_size',
            [
                'label'     => esc_html__('Icon Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing-item .body ul li .li-icon img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-pricing-item .body ul li .li-icon i'   => 'font-size: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_list_item_typography',
                'selector' => '{{WRAPPER}} .crust-pricing-item .body ul li',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Style (list_item) dark
	     * -------------------------------------------
	     */

	    $this->add_control(
		    'crust_pricing_list_item_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_item_dark_color',
		    [
			    'label'     => esc_html__('Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body ul li' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_alt_item_dark_color',
		    [
			    'label'     => esc_html__('Alternate Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body ul li:nth-child(even)' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_item_dark_bg_color',
		    [
			    'label'     => esc_html__('Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body ul li' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_alt_item_dark_bg_color',
		    [
			    'label'     => esc_html__('Alternate Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body ul li:nth-child(even)' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_dark_divider_color',
		    [
			    'label'     => esc_html__('Divider Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body ul li' => 'border-bottom-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_list_disable_dark_item_color',
		    [
			    'label'     => esc_html__('Disable item color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item ul li.disable-item' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Style (Additional Features)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_pricing_style_additional_featured_list',
		    [
			    'label' => esc_html__('Additional Features', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_title_tag',
		    [
			    'label'       => esc_html__('Title HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h6',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_title_color',
		    [
			    'label'     => esc_html__('Title Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-additional-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_title_typography',
			    'selector' => '{{WRAPPER}} .crust-pricing-additional-title, {{WRAPPER}} .crust-pricing-additional-title span',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_text_shadow',
			    'label'      => esc_html__('Title Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_padding',
		    [
			    'label'      => esc_html__('Title Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-additional-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_title_margin',
		    [
			    'label'      => esc_html__('Title Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-additional-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_head_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_pricing_additional_head_border',
			    'selector' => '{{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Additional Features)
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_additional_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_title_dark_color',
		    [
			    'label'     => esc_html__('Title Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-additional-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_dark_head_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_pricing_additional_head_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_head_radius',
		    [
			    'label'      => esc_html__('Title Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing-additional-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_pricing_additional_head_shadow',
			    'selector' => '{{WRAPPER}} .crust-pricing-additional-title',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
				'default' => 'center',
				'separator'  => 'before',
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_pricing_additional_list_tabs');

	    $this->start_controls_tab('crust_pricing_additional_list_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_additional_list_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_list_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Additional Features list tap) dark normal
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_additional_list_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_additional_list_normal_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_list_normal_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap',
		    ]
	    );


	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_additional_list_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_additional_list_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_list_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body .crust-pricing-additional-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Additional Features list tap) dark hover
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_additional_list_hover_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_additional_list_hover_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body .crust-pricing-additional-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_list_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .body .crust-pricing-additional-wrap',
		    ]
	    );


	    $this->end_controls_tab();
	    $this->end_controls_tabs();

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_item_margin',
		    [
			    'label'      => esc_html__('Item Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_additional_list_item_padding',
		    [
			    'label'      => esc_html__('Item Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_item_color',
		    [
			    'label'     => esc_html__('Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_alt_item_color',
		    [
			    'label'     => esc_html__('Alternate Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li:nth-child(even)' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_item_bg_color',
		    [
			    'label'     => esc_html__('Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_alt_item_bg_color',
		    [
			    'label'     => esc_html__('Alternate Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li:nth-child(even)' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_divider_color',
		    [
			    'label'     => esc_html__('Divider Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'border-bottom-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_disable_item_color',
		    [
			    'label'     => esc_html__('Disable item color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item ul li.disable-item' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_item_icon_size',
		    [
			    'label'     => esc_html__('Icon Size', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'max' => 50,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li .li-icon img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li .li-icon i'   => 'font-size: {{SIZE}}{{UNIT}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_pricing_additional_list_item_typography',
			    'selector' => '{{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li',
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Additional Features list item) dark
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_additional_list_item_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_pricing_additional_list_item_dark_color',
		    [
			    'label'     => esc_html__('Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_list_alt_item_dark_color',
		    [
			    'label'     => esc_html__('Alternate Item Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li:nth-child(even)' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_list_item_dark_bg_color',
		    [
			    'label'     => esc_html__('Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_list_alt_item_dark_bg_color',
		    [
			    'label'     => esc_html__('Alternate Item BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing-item .body .crust-pricing-additional-wrap ul li:nth-child(even)' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_list_divider_dark_color',
		    [
			    'label'     => esc_html__('Divider Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .body .crust-pricing-additional-wrap ul li' => 'border-bottom-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_additional_list_disable_item_dark_color',
		    [
			    'label'     => esc_html__('Disable item color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item ul li.disable-item' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Style (Ribbon)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_featured_ribbon',
            [
                'label' => esc_html__('Ribbon', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition'   => [
	                'crust_pricing_featured'        => 'yes',
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_ribbon_size',
            [
                'label'     => esc_html__('Font Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 10
                ],
                'range'     => [
                    'px' => [
                        'max' => 18,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:before' => 'font-size: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'font-size: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3:before' => 'font-size: {{SIZE}}px;',
                ],
                'condition'   => [
	                'crust_pricing_featured'        => 'yes',
	                'crust_pricing_featured_styles!' => 'image'
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_ribbon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:before' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3:before' => 'color: {{VALUE}};',
                ],
                'condition'   => [
	                'crust_pricing_featured'        => 'yes',
	                'crust_pricing_featured_styles!' => 'image'
                ]
            ]
        );

        $this->add_control(
            'crust_pricing_featured_tag_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:after'  => 'border-bottom-color: {{VALUE}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before'  => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3:after'  => 'border-right-color: {{VALUE}};',
                ],
                'condition'   => [
	                'crust_pricing_featured'        => 'yes',
	                'crust_pricing_featured_styles!' => 'image'
                ]
            ]
        );
	    /**
	     * -------------------------------------------
	     * Style (Ribbon) dark
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_section_pricing_featured_ribbon_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_pricing_ribbon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:before' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3:before' => 'color: {{VALUE}};',
			    ],
			    'condition'   => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => 'image'
			    ]
		    ]
	    );
	    $this->add_control(
		    'crust_pricing_featured_tag_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:before' => 'background: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-1:after'  => 'border-bottom-color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before'  => 'background-color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-3:after'  => 'border-right-color: {{VALUE}};',
			    ],
			    'condition'   => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => 'image'
			    ]
		    ]
	    );

	    $start = is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );
	    $end = ! is_rtl() ? __( 'Right', 'elementor' ) : __( 'Left', 'elementor' );

	    $this->add_control(
		    'crust_pricing_ribbon_offset_orientation_h',
		    [
			    'label' => __( 'Horizontal Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'default' => 'end',
			    'options' => [
				    'start' => [
					    'title' => $start,
					    'icon' => 'eicon-h-align-left',
				    ],
				    'end' => [
					    'title' => $end,
					    'icon' => 'eicon-h-align-right',
				    ],
			    ],
			    'classes' => 'elementor-control-start-end',
			    'render_type' => 'ui',
			    'condition' => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_ribbon_offset_x',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'default' => [
				    'size' => '0',
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .crust-pricing-ribbon' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .crust-pricing-ribbon' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'left:auto;right: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_pricing_ribbon_offset_orientation_h!' => 'end',
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_ribbon_offset_x_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 0.1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'default' => [
				    'size' => '0',
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    'body:not(.rtl) {{WRAPPER}} .crust-pricing-ribbon' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .crust-pricing-ribbon' => 'right:auto;left: {{SIZE}}{{UNIT}}',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'left:auto;right: {{SIZE}}{{UNIT}}',
				    'body.rtl {{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'right:auto;left: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_pricing_ribbon_offset_orientation_h' => 'end',
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_pricing_ribbon_offset_orientation_v',
		    [
			    'label' => __( 'Vertical Orientation', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'default' => 'start',
			    'options' => [
				    'start' => [
					    'title' => __( 'Top', 'elementor' ),
					    'icon' => 'eicon-v-align-top',
				    ],
				    'end' => [
					    'title' => __( 'Bottom', 'elementor' ),
					    'icon' => 'eicon-v-align-bottom',
				    ],
			    ],
			    'render_type' => 'ui',
			    'condition' => [
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_ribbon_offset_y',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'default' => [
				    'size' => '0',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-ribbon' => 'top: {{SIZE}}{{UNIT}}',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'top: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_pricing_ribbon_offset_orientation_v!' => 'end',
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_ribbon_offset_y_end',
		    [
			    'label' => __( 'Offset', 'elementor' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => -1000,
					    'max' => 1000,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => -200,
					    'max' => 200,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'default' => [
				    'size' => '0',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing-ribbon' => 'top:auto;bottom: {{SIZE}}{{UNIT}}',
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .crust-ribbon-2:before' => 'top:auto;bottom: {{SIZE}}{{UNIT}}',
			    ],
			    'condition' => [
				    'crust_pricing_ribbon_offset_orientation_v' => 'end',
				    'crust_pricing_featured'        => 'yes',
				    'crust_pricing_featured_styles!' => ['ribbon-1','ribbon-3']
			    ],
		    ]
	    );

        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Style (Footer)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_section_pricing_footer_style_settings',
		    [
			    'label' => esc_html__('Footer', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_footer_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', 'rem', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_footer_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('crust_pricing_footer_tabs');

	    $this->start_controls_tab('crust_pricing_footer_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_footer_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item .footer',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_footer_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item .footer',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_footer_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item .footer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Footer) dark
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_footer_bg_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_footer_bg_normal_dark',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .footer',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_footer_border_normal_dark',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item .footer',
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_pricing_footer_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_footer_bg_hover',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .footer',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_footer_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .footer',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_footer_hover_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-item:hover .footer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * Style (Footer) dark hover
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_footer_bg_hover_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_footer_bg_hover_dark',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .footer',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_footer_border_hover_dark',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-item:hover .footer',
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();

	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Button Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_pricing_btn_style_settings',
            [
                'label' => esc_html__('Button', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_content_button_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
				'default' => 'center' ,
			    'prefix_class' => 'crust-pricing-button-align-',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_btn_width',
		    [
			    'label'     => esc_html__('Max. Width', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 500,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-button'   => 'max-width: {{SIZE}}{{UNIT}};width: 100%;',
			    ]
		    ]
	    );

        $this->add_responsive_control(
            'crust_pricing_btn_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button,{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_pricing_btn_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'crust_pricing_btn_icon_size',
            [
                'label'     => esc_html__('Icon Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 20,
                    'unit' => 'px'
                ],
                'range'     => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button i'   => 'font-size: {{SIZE}}{{UNIT}};'
                ],
                'condition' => [
	                'crust_pricing_button_icon!' => ''
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_pricing_btn_typography',
                'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-button',
            ]
        );

        $this->start_controls_tabs('crust_core_cta_button_tabs');

        // Normal State Tab
        $this->start_controls_tab('crust_pricing_btn_normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_control(
            'crust_pricing_btn_normal_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_btn_normal_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-button:not(.btn-hyperion):not(.btn-bestia), 
									{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-hyperion:before,
									{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-anthe::before,
									{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_pricing_btn_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-button',
            ]
        );

	    $this->add_responsive_control(
		    'crust_pricing_btn_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-button,{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_pricing_btn_shadow',
                'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-button',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Tab Style (Button Style) dark normal
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_btn_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_btn_normal_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#fff',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_btn_normal_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button:not(.btn-hyperion):not(.btn-bestia), 
									body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-hyperion:before,
									body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-anthe::before,
									body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_btn_normal_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button',
		    ]
	    );

        $this->end_controls_tab();

        // Hover State Tab
        $this->start_controls_tab('crust_pricing_btn_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_control(
            'crust_pricing_btn_hover_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-pricing .crust-pricing-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_btn_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-button:not(.styled-btn):hover, {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-hyperion,
					{{WRAPPER}} .crust-pricing .crust-pricing-button::before,{{WRAPPER}} .crust-pricing .crust-pricing-button::after,
					{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-anthe:hover::before,{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg::before,
					{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg::after',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_btn_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-pricing .crust-pricing-button:hover',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_pricing_btn_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-pricing .crust-pricing-button:hover,{{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia:hover .bestia-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_pricing_btn_hover_shadow',
                'selector'  => '{{WRAPPER}} .crust-pricing .crust-pricing-button:hover',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Tab Style (Button Style) dark hover
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_pricing_btn_hover_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_pricing_btn_hover_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_pricing_btn_hover_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button:not(.styled-btn):hover, body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-hyperion,
					body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button::before,{{WRAPPER}} .crust-pricing .crust-pricing-button::after,
					body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-anthe:hover::before,body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg::before,
					body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button.btn-bestia .bestia-bg::after',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_pricing_btn_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-pricing .crust-pricing-button:hover',
		    ]
	    );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Bottom Divider Style
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_pricing_bottom_divider_settings',
		    [
			    'label'     => esc_html__('Bottom Divider Style', 'crust-core'),
			    'tab'       => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_pricing_bottom_show' => 'yes'
			    ]
		    ]
	    );

	    $this->crust_divider_settings();

	    $this->add_responsive_control(
		    'crust_pricing_bottom_divider_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-divider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /**
	     * -------------------------------------------
	     * TBottom Divider Style dark
	     * -------------------------------------------
	     */



	    $this->add_control(
		    'btn_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'base_color_dark',
		    [
			    'label'     => esc_html__('Base Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} svg.crust-divider .crust-base-fill' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'div_style!' => ['style4','style5']
			    ]
		    ]
	    );
	    $this->add_control(
		    'layer_1_color_dark',
		    [
			    'label'     => esc_html__('Layer 1 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} svg.crust-divider .crust-div-1-top' => 'fill: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'layer_2_color_dark',
		    [
			    'label'     => esc_html__('Layer 2 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} svg.crust-divider .crust-div-1-middle' => 'fill: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'layer_3_color_dark',
		    [
			    'label'     => esc_html__('Layer 3 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} svg.crust-divider .crust-div-1-bottom' => 'fill: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'layer_4_color_dark',
		    [
			    'label'     => esc_html__('Layer 4 Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} svg.crust-divider .crust-div-1-bottom2' => 'fill: {{VALUE}};',
			    ],
			    'condition' => [
				    'div_style' => 'style4',
			    ]
		    ]
	    );


	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings          = $this->get_settings_for_display();
        $pricing_image     = ( isset($settings['crust_pricing_image']) ) ? $settings['crust_pricing_image'] : '' ;
        $pricing_image_url = ($pricing_image) ? Group_Control_Image_Size::get_attachment_image_src($pricing_image['id'], 'thumbnail', $settings) : '';
        $featured_class    = ('yes' === $settings['crust_pricing_featured'] ? 'featured ' : '');
        $title_tag         = $settings['crust_pricing_title_tag'];
        $subtitle_tag      = $settings['crust_pricing_subtitle_tag'];
        $icon_position     = $settings['crust_pricing_icon_position'];
	    $ribbon_image      = ( isset($settings['crust_pricing_ribbon_image']) ) ? $settings['crust_pricing_ribbon_image'] : '';
	    $ribbon_image_url  = ( $ribbon_image ) ? Group_Control_Image_Size::get_attachment_image_src($ribbon_image['id'], 'thumbnail', $settings) : '';
        $html = '';

        $html .= '<div class="crust-pricing">';
            $html .= '<div class="crust-pricing-item '. esc_attr($featured_class) .'">';
                $html .= ('yes' === $settings['crust_pricing_featured'] ) ? '<span class="crust-ribbon crust-'. $settings['crust_pricing_featured_styles'] .'"></span>' : '';
                $html .= ( $ribbon_image_url ) ? '<img class="crust-pricing-ribbon" src="'. esc_url($ribbon_image_url) .'" alt="'. esc_attr(get_post_meta($ribbon_image['id'], '_wp_attachment_image_alt', true)) .'" />' : '';
                $html .= ( 'top' == $icon_position ) ? $this->render_icon() : '';
                $html .= '<div class="header">';
                    $html .= ( $settings['crust_pricing_title'] ) ? '<'.$title_tag.' class="title">'. $settings['crust_pricing_title'] .'</'.$title_tag.'>' : '';
                    $html .= ( $settings['crust_pricing_sub_title'] ) ? '<'.$subtitle_tag.' class="subtitle">'. $settings['crust_pricing_sub_title'] .'</'.$subtitle_tag.'>' : '';
                $html .= '</div>';
                $html .= ( 'after-title' == $icon_position ) ? $this->render_icon() : '';
                $html .= $this->render_price();
                $html .= ( 'after-price' == $icon_position ) ? $this->render_icon() : '';
                $html .= '<div class="body">';
                    $html .= $this->render_feature_list($settings, $this);
                    $html .= $this->render_additional_feature_list($settings, $this);
                $html .= '</div>';
                $html .= ( 'after-list' == $icon_position ) ? $this->render_icon() : '';
                if('yes' === $settings['crust_pricing_btn_show']){
	                $html .= '<div class="footer">';
		                $html .= $this->render_footer_button();
	                $html .= '</div>';
                }

                $html .= ( 'bottom' == $icon_position ) ? $this->render_icon() : '';
            $html .= '</div>';

        $html .= '</div>';

	    if ( 'yes' == $settings['crust_pricing_bottom_show'] ) {
		    $div_style = $settings['div_style'];
		    $div_layers = $settings['layers_no'];

		    $div_class = 'crust-divider';
		    $div_class .= ( '1' === $settings['flip_horizontal'] ) ? ' crust-horizontal-flip'  : '';
		    $div_class .= ( '1' === $settings['flip_vertical'] )   ? ' crust-vertical-flip'    : '';
		    $div_class .= ( '1' === $settings['full_width'] )      ? ' full-divider'           : '';
		    $div_class .= ( $div_style ) ? ' crust-divider-' . $div_style : '';

		    $f_col = ( $settings['layer_1_color'] === '' ) ? '#12d0de' : $settings['layer_1_color'];
		    $s_col = ( $settings['layer_2_color'] === '' ) ? '#b9d114' : $settings['layer_2_color'];
		    $first_color = ( $div_style == 'style0' ) ? $f_col : '';
		    $second_color = ( $div_style == 'style0' ) ? $s_col : '';
		    $html .= apply_filters('crust_ele_divider_site_markup',$div_style, $div_layers, $div_class, $first_color, $second_color);
	    }

        echo $html;

    }

    protected function render_icon()
    {

        $settings = $this->get_settings_for_display();

        if ($settings['crust_pricing_icon_show'] === 'yes') {

            $html = '<div class="crust-pricing-icon">';
                $html .= '<span class="icon">';

                    if ($settings['crust_pricing_icon_type'] === 'icon') {
                        if ($settings['crust_pricing_icon']) {
                            if (isset($settings['crust_pricing_icon']['value']['url'])) {
                                $html .= '<img src="' . $settings['crust_pricing_icon']['value']['url'] . '"/>';
                            } else {
                                $html .= '<i class="' . $settings['crust_pricing_icon']['value'] . '"></i>';
                            }
                        }
                    } elseif ($settings['crust_pricing_icon_type'] === 'image') {
                        $pricing_image_url = Group_Control_Image_Size::get_attachment_image_src($settings['crust_pricing_image']['id'], 'thumbnail', $settings);
                        if (empty($pricing_image_url)) {
                            $pricing_image_url = $settings['crust_pricing_image']['url'];
                        } else{
                            $pricing_image_url = $pricing_image_url;
                        }
                        $html .= '<img src="' . esc_attr($pricing_image_url) . '" alt="' . esc_attr(get_post_meta($settings['crust_pricing_image']['id'], '_wp_attachment_image_alt', true)) . '">';
                    }

                $html .= '</span>';
            $html .= '</div>';

            return $html;

        }

    }

    protected function render_price()
    {

        $settings = $this->get_settings_for_display();

        $period_class = 'price-period';
	    $period_class .= ( $settings['period_block'] ) ? ' crust-period-block' : '';

        $html = '<div class="crust-pricing-tag">';
            $html .= '<span class="price-tag">';

                if ('yes' === $settings['crust_pricing_onsale']) {

                    if ($settings['crust_pricing_price_cur_placement'] == 'left') {

                        $html .= '<span class="price-currency">' . $settings['crust_pricing_price_cur'] . '</span>' . '<span class="price-sale">' .$settings['crust_pricing_onsale_price'] . '</span>';
                        $html .= '<span class="'.$period_class.'">'. $settings['crust_pricing_period_separator'] . $settings['crust_pricing_price_period'] .'</span>';

                        $html .= '<del class="muted-price">';
                            $html .= ($settings['crust_pricing_regular_text']) ? $settings['crust_pricing_regular_text'] . ' ' : '';
                            $html .= '<span class="muted-price-currency">' . $settings['crust_pricing_price_cur'] . '</span>' . $settings['crust_pricing_price'];
                            $html .= '<span class="'.$period_class.'">'. $settings['crust_pricing_period_separator'] . $settings['crust_pricing_price_period'] .'</span>';
                        $html .= '</del>';

                    } elseif ($settings['crust_pricing_price_cur_placement'] == 'right') {

                        $html .= '<span class="price-sale">' .$settings['crust_pricing_onsale_price'] . '</span>' . '<span class="price-currency">' . $settings['crust_pricing_price_cur'] . '</span>';
                        $html .= '<span class="'.$period_class.'">'. $settings['crust_pricing_period_separator'] . $settings['crust_pricing_price_period'] .'</span>';

                        $html .= '<del class="muted-price">';
                            $html .= ($settings['crust_pricing_regular_text']) ? $settings['crust_pricing_regular_text'] . ' ' : '';
                            $html .= '<span class="muted-price-currency">' . $settings['crust_pricing_price_cur'] . '</span>' . $settings['crust_pricing_price'];
                            $html .= '<span class="'.$period_class.'">'. $settings['crust_pricing_period_separator'] . $settings['crust_pricing_price_period'] .'</span>';
                        $html .= '</del>';

                    }

                } else {

                    if ($settings['crust_pricing_price_cur_placement'] == 'left') {
                        $html .= '<span class="price-currency">' . $settings['crust_pricing_price_cur'] . '</span>' . $settings['crust_pricing_price'];
                    } elseif ($settings['crust_pricing_price_cur_placement'] == 'right') {
                        $html .= $settings['crust_pricing_price'] . '<span class="price-currency">' . $settings['crust_pricing_price_cur'] . '</span>';
                    }
                    $html .= '<span class="'.$period_class.'">'. $settings['crust_pricing_period_separator'] . $settings['crust_pricing_price_period'] .'</span>';

                }

            $html .= '</span>';
        $html .= '</div>';

        return $html;

    }

    protected function render_feature_list($settings, $obj)
    {
        if (empty($settings['crust_pricing_items'])) {
            return;
        }

        $counter = 0;

        $html = '<ul>';
            foreach ($settings['crust_pricing_items'] as $item) {

                if ('yes' !== $item['crust_pricing_icon_mood']) {
                    $obj->add_render_attribute('pricing_feature_item' . $counter, 'class', 'disable-item');
                }

                $html .= '<li ' . $obj->get_render_attribute_string('pricing_feature_item' . $counter) . '>';
					$ic_color = ( $item['crust_pricing_list_icon_color'] ) ? ' style="color:' . esc_attr($item['crust_pricing_list_icon_color']) . '"' : '';
                    $html .= '<span class="li-icon"'.$ic_color.'>';
                        if ($item['crust_pricing_list_icon']) {
                            if (isset($item['crust_pricing_list_icon']['value']['url'])) {
                                $html .= '<img src="' . esc_url($item['crust_pricing_list_icon']['value']['url']) . '" alt="' . esc_attr(get_post_meta($item['crust_pricing_list_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
                            } else {
                                $html .= '<i class="' . $item['crust_pricing_list_icon']['value'] . '"></i>';
                            }
                        }
                    $html .= '</span>';

                    $html .= $item['crust_pricing_item'];
                $html .= '</li>';
                $counter++;
            }
        $html .= '</ul>';

        return $html;

    }

	protected function render_additional_feature_list($settings, $obj)
	{
		if (empty($settings['crust_pricing_additional_items'])) {
			return;
		}

		$counter = 0;

		$tag = $settings['crust_pricing_additional_title_tag'];

		$html = '<div class="crust-pricing-additional-wrap">';

			$html .= ( $settings['crust_pricing_additional_title'] ) ? '<'.$tag.' class="crust-pricing-additional-title">'. $settings['crust_pricing_additional_title'] .'</'.$tag.'>' : '';
			$html .= '<ul>';
			foreach ($settings['crust_pricing_additional_items'] as $item) {

				if ('yes' !== $item['crust_pricing_additional_icon_mood']) {
					$obj->add_render_attribute('pricing_additional_feature_item' . $counter, 'class', 'disable-item');
				}

				$html .= '<li ' . $obj->get_render_attribute_string('pricing_additional_feature_item' . $counter) . '>';
				$ic_color = ( $item['crust_pricing_additional_list_icon_color'] ) ? ' style="color:' . esc_attr($item['crust_pricing_additional_list_icon_color']) . '"' : '';
				$html .= '<span class="li-icon"'.$ic_color.'>';
				if ($item['crust_pricing_additional_list_icon']) {
					if (isset($item['crust_pricing_additional_list_icon']['value']['url'])) {
						$html .= '<img src="' . esc_url($item['crust_pricing_additional_list_icon']['value']['url']) . '" alt="' . esc_attr(get_post_meta($item['crust_pricing_additional_list_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
					} else {
						$html .= '<i class="' . $item['crust_pricing_additional_list_icon']['value'] . '"></i>';
					}
				}
				$html .= '</span>';

				$html .= $item['crust_pricing_additional_item'];
				$html .= '</li>';
				$counter++;
			}
			$html .= '</ul>';

		$html .= '</div>';

		return $html;

	}

    protected function render_footer_button()
    {
        $settings  = $this->get_settings_for_display();
        $target    = $settings['crust_pricing_btn_link']['is_external'] ? 'target="_blank"' : '';
        $nofollow  = $settings['crust_pricing_btn_link']['nofollow'] ? 'rel="nofollow"' : '';

	    $btn_class = 'crust-btn crust-pricing-button';
	    $btn_class .= ( $settings['button_hover_style'] ) ? ' styled-btn' : '';
	    $btn_class .= ( $settings['button_hover_style'] ) ? ' ' . $settings['button_hover_style'] : '';

        $html = '<a href="'. esc_url($settings['crust_pricing_btn_link']['url']) .'" '.$target . $nofollow.' class="'.$btn_class.'">';
	        $html .= ( $settings['button_hover_style'] == 'btn-bestia' ) ? '<b class="bestia-bg"></b>' : '';
            $html .= '<span><span>';
                if ($settings['crust_pricing_button_icon'] && 'left' == $settings['crust_pricing_button_icon_alignment']) {

                    if (isset($settings['crust_pricing_button_icon']['value']['url'])) {
                        $html .= '<img src="' . esc_url($settings['crust_pricing_button_icon']['value']['url']) . '" class="fa-icon-left" alt="' . esc_attr(get_post_meta
                            ($settings['crust_pricing_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
                    } else {
                        $html .= '<i class="' . esc_attr($settings['crust_pricing_button_icon']['value']) . ' fa-icon-left"></i>';
                    }

                }

                $html .= $settings['crust_pricing_btn'];

                if ($settings['crust_pricing_button_icon'] && 'right' == $settings['crust_pricing_button_icon_alignment']){

                    if (isset($settings['crust_pricing_button_icon']['value']['url'])) {
                        $html .= '<img src="' . esc_url($settings['crust_pricing_button_icon']['value']['url']) . '" class="fa-icon-right" alt="' . esc_attr(get_post_meta
                            ($settings['crust_pricing_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) . '"/>';
                    } else {
                        $html .= '<i class="' . esc_attr($settings['crust_pricing_button_icon']['value']) . ' fa-icon-right"></i>';
                    }

                }
            $html .= '</span></span>';
        $html .= '</a>';

        return $html;

    }

}
