<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use \Elementor\Widget_Base;

class Crust_Splitter extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-splitter';
    }

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-splitter', true, false);
		return [
			'crust-splitter',
		];
	}

    public function get_title()
    {
        return esc_html__('Crust splitter', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

	    /**
	     * Content Settings
	     */
	    $this->start_controls_section(
		    'crust_splitter_settings',
		    [
			    'label' => esc_html__('Settings', 'crust-core')
		    ]
	    );

	    $this->add_control(
		    'splitter_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => 'crust_select_control',
			    'label_block' => false,
			    'options'     => [
			    	''          => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/none.svg'],
				    'shape-1'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-1.svg'],
				    'shape-2'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-2.svg'],
				    'shape-3'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-3.svg'],
				    'shape-4'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-4.svg'],
				    'shape-5'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-5.svg'],
				    'shape-6'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-6.svg'],
				    'shape-7'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-7.svg'],
				    'shape-8'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-8.svg'],
				    'shape-9'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-9.svg'],
				    'shape-10'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-10.svg'],
				    'shape-10-1' => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-10-1.svg'],
				    'shape-11'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-11.svg'],
				    'shape-12'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-12.svg'],
				    'shape-13'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-13.svg'],
				    'shape-14'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-14.svg'],
				    'shape-15'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-15.svg'],
				    'shape-16'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-16.svg'],
				    'shape-17'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-17.svg'],
				    'shape-18'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-18.svg'],
				    'shape-19'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-19.svg'],
				    'shape-20'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-20.svg'],
				    'shape-21'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-21.svg'],
				    'shape-22'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-22.svg'],
				    'shape-23'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-23.svg'],
				    'shape-24'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-24.svg'],
				    'shape-25'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-25.svg'],
				    'shape-26'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-26.svg'],
				    'shape-27'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-27.svg'],
				    'shape-28'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-28.svg'],
				    'shape-29'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-29.svg'],
				    'shape-30'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-30.svg'],
				    'shape-31'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-31.svg'],
				    'shape-32'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-32.svg'],
				    'shape-33'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-33.svg'],
				    'shape-34'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-34.svg'],
				    'shape-35'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-35.svg'],
				    'shape-36'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-36.svg'],
				    'shape-37'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-37.svg'],
				    'shape-38'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-38.svg'],
				    'shape-39'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-39.svg'],
				    'shape-40'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-40.svg'],
				    'shape-41'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-41.svg'],
				    'shape-42'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-42.svg'],
				    'shape-43'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-43.svg'],
				    'shape-44'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-44.svg'],
				    'shape-45'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-45.svg'],
				    'shape-46'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-46.svg'],
				    'shape-47'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-47.svg'],
				    'shape-48'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-48.svg'],
				    'shape-49'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-49.svg'],
				    'shape-50'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-50.svg'],
				    'shape-51'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-51.svg'],
				    'shape-52'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-52.svg'],
				    'shape-53'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-53.svg'],
				    'shape-54'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-54.svg'],
				    'shape-55'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-55.svg'],
				    'shape-56'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-56.svg'],
				    'shape-57'   => ['image' => CRUST_CORE_URI . 'assets/front/images/splitter/shape-57.svg'],
			    ],
		    ]
	    );

	    $this->add_control(
		    'split_hover',
		    [
			    'label'       => esc_html__('Hover Animation', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    ''       => esc_html__('None', 'crust-core'),
				    'scale'  => esc_html__('Grow', 'crust-core'),
				    'shrink' => esc_html__('Shrink', 'crust-core'),
				    'tilt'   => esc_html__('Tilt Effect', 'crust-core'),
			    ],
		    ]
	    );


	    $this->add_control(
		    'type',
		    [
			    'label'       => esc_html__('Object Type', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    "default"     => "image",
			    'options'     => [
				    'image'   => esc_html__('Image', 'crust-core'),
				    'video'   => esc_html__('Video', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'image',
		    [
			    'label'     => esc_html__('Image', 'crust-core'),
			    'type'      => Controls_Manager::MEDIA,
			    'condition' => [
				    'type' => 'image'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Image_Size::get_type(),
		    [
			    'name'      => 'thumbnail',
			    'default'   => 'full',
			    'condition' => [
				    'image[url]!' => '',
				    'type' => 'image',
			    ]
		    ]
	    );

	    /*$this->add_control(
		    'link_type',
		    [
			    'label'       => esc_html__('Link Type', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    ''          => esc_html__('None', 'crust-core'),
				    'link'   => esc_html__('Normal Link', 'crust-core'),
				    'box'   => esc_html__('Light Box', 'crust-core'),
			    ],
			    'condition' => [
				    'type' => 'image'
			    ]
		    ]
	    );

	    $this->add_control(
		    'link',
		    [
			    'label'     => esc_html__('Link', 'elementor'),
			    'type'      => Controls_Manager::URL,
			    'placeholder' => __( 'Paste URL or type', 'crust-core' ),
			    'show_external' => true,
			    'default' => [
				    'url' => '',
			    ],
			    'condition' => [
				    'link_type' => 'link'
			    ]
		    ]
	    );*/

	    $this->add_control(
		    'video_type',
		    [
			    'label' => __( 'Source', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => 'youtube',
			    'options' => [
				    'youtube' => __( 'YouTube', 'elementor' ),
				    'hosted' => __( 'Self Hosted', 'elementor' ),
			    ],
			    'condition' => [
				    'type' => 'video'
			    ],
			    'frontend_available' => true,
		    ]
	    );

	    $this->add_control(
		    'youtube_url',
		    [
			    'label' => __( 'Link', 'elementor' ),
			    'type' => Controls_Manager::TEXT,
			    'dynamic' => [
				    'active' => true,
				    'categories' => [
					    TagsModule::POST_META_CATEGORY,
					    TagsModule::URL_CATEGORY,
				    ],
			    ],
			    'placeholder' => __( 'Enter your URL', 'elementor' ) . ' (YouTube)',
			    'default' => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
			    'label_block' => true,
			    'condition' => [
				    'type' => 'video',
				    'video_type' => 'youtube',
			    ],
			    'frontend_available' => true,
		    ]
	    );

	    $this->add_control(
		    'hosted_url',
		    [
			    'label' => __( 'Choose File', 'elementor' ),
			    'type' => Controls_Manager::MEDIA,
			    'dynamic' => [
				    'active' => true,
				    'categories' => [
					    TagsModule::MEDIA_CATEGORY,
				    ],
			    ],
			    'media_type' => 'video',
			    'condition' => [
				    'type' => 'video',
				    'video_type' => 'hosted',
			    ],
		    ]
	    );

	    $this->add_control(
		    'ratio',
		    [
			    'label' => __( 'Aspect Ratio', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => '169',
			    'options' => [
				    '169' => __( '16:9', 'elementor' ),
				    '43' => __( '4:3', 'elementor' ),
				    '85' => __( '8:5', 'elementor' ),
				    '916' => __( '9:16', 'elementor' ),
				    '34' => __( '3:4', 'elementor' ),
				    '58' => __( '5:8', 'elementor' ),
			    ],
		    ]
	    );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_splitter_style',
            [
                'label' => esc_html__('General Styles', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'h_flip',
		    [
			    'label'     => __('Horizontal Flip', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'v_flip',
		    [
			    'label'     => __('Vertical Flip', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_responsive_control(
		    'splitter_rotate',
		    [
			    'label'      => esc_html__('Rotate', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 360,
					    'step' => 1,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-splitter'   => 'transform: rotate({{SIZE}}deg);',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'splitter_rotate_inner',
		    [
			    'label'      => esc_html__('Rotate Inner', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 360,
					    'step' => 1,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-splitter .crust-split-object-wrap *'   => 'transform: rotate({{SIZE}}deg);',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'splitter_width',
		    [
			    'label'      => esc_html__('Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 1920,
					    'step' => 1,
				    ],
				    '%'  => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-splitter'   => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'splitter_height',
		    [
			    'label'      => esc_html__('Height', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 2000,
					    'step' => 1,
				    ],
				    '%'  => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-splitter'   => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_splitter_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-splitter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    $this->crust_particles_settings('splitter');

	    $this->start_controls_section(
		    'crust_splitter_overlay',
		    [
			    'label' => esc_html__('Overlay', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'label' => esc_html__('Overlay', 'crust-core'),
			    'name'     => 'crust_splitter_over',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-split-container:before',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_splitter_hover_overlay',
		    [
			    'label'      => esc_html__('Hover', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'label' => esc_html__('Overlay Hover', 'crust-core'),
			    'name'     => 'crust_splitter_hover_over',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-splitter:hover .crust-split-container:before',
		    ]
	    );

	    /**
	     * ----------------------------
	     *start overlay dark
	     * ---------------------------
	     */

	    $this->add_responsive_control(
		    'crust_splitter_dark_overlay',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'label' => esc_html__('Overlay', 'crust-core'),
			    'name'     => 'crust_splitter_dark_over',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-split-container:before',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_splitter_dark_hover_overlay',
		    [
			    'label'      => esc_html__('Hover', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'label' => esc_html__('Overlay Hover', 'crust-core'),
			    'name'     => 'crust_splitter_hover_dark_over',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-splitter:hover .crust-split-container:before',
		    ]
	    );

	    /**
	     * ----------------------------
	     *end overlay dark
	     * ---------------------------
	     */

        $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_splitter_border',
		    [
			    'label' => esc_html__('Border', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_splitter_border',
			    'selector' => '{{WRAPPER}} .crust-splitter',
		    ]
	    );

	    /**
	     * ----------------------------
	     *start border dark
	     * ---------------------------
	     */

	    $this->add_responsive_control(
		    'crust_splitter_dark_border',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_splitter_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-splitter',
		    ]
	    );


	    /**
	     * ----------------------------
	     *end border dark
	     * ---------------------------
	     */

	    $this->end_controls_section();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();
	    $split_atributes = [];

	    // Particles...
	    if( $settings['crust_particles_splitter'] ){
		    $split_line = $settings['crust_particles_line_color_splitter'];
		    $split_color_array = [];

		    $crust_particles_color = $settings['crust_particles_colors_repeat_splitter'];
		    if ( is_array( $crust_particles_color ) ) {
			    foreach ( $crust_particles_color as $item ) {
				    $split_color_array[] = $item['crust_particles_color_splitter'];
			    }
			    $split_color_array = implode( ',', $split_color_array );
		    }

		    wp_enqueue_script( 'crust-particles',   CRUST_CORE_URI . 'assets/front/js/vendor/particles.min.js', ['jquery'], null, true );
		    $split_atributes[] = 'data-id="split-'.$this->get_id().'"';
		    $split_atributes[] = 'data-particles-mode="'.$settings['crust_particles_mode_splitter'].'"';
		    $split_atributes[] = 'data-particles-shape="'.$settings['crust_particles_shape_splitter'].'"';
		    $split_atributes[] = 'data-particles-color="'.$split_color_array.'"';
		    $split_atributes[] = 'data-particles-number="'.$settings['crust_particles_number_splitter'].'"';
		    $split_atributes[] = 'data-particles-size="'.$settings['crust_particles_size_splitter'].'"';
		    $split_atributes[] = ( $split_line ) ? 'data-particles-line-color="'.$split_line.'"' : '';
		    if( $settings['crust_particles_shape_splitter'] == 'image' && $settings['part_image_splitter']['url'] ){
			    $split_atributes[] = ( $settings['part_image'] ) ? 'data-particles-image="'.$settings['part_image_splitter']['url'].'"' : '';
			    $split_atributes[] = ( $settings['img_width'] ) ? 'data-particles-image-width="'.$settings['crust_particles_image_width_splitter'].'"' : '';
			    $split_atributes[] = ( $settings['img_height'] ) ? 'data-particles-image-height="'.$settings['crust_particles_image_height_splitter'].'"' : '';
		    }

	    }

	    $split_url = CRUST_CORE_URI . 'assets/front/images/splitter/' . $settings['splitter_style'] . '.svg';
	    $split_atributes[] = ' style="mask-image: url('.$split_url.');-webkit-mask-image: url('.$split_url.');"';

	    $class  = 'crust-splitter crust-splitter-' . $settings['type'] . ' crust-splitter-' . $settings['splitter_style'];
	    $class .= ( $settings['split_hover'] ) ? ' crust-split-' . $settings['split_hover'] : '';
	    $class .= ( $settings['h_flip'] ) ? ' crust-split-h-flip' : '';
	    $class .= ( $settings['v_flip'] ) ? ' crust-split-v-flip' : '';
	    $class .= ( $settings['type'] == 'video' ) ? ' crust-ratio-' . $settings['ratio'] : '';
	    $split_inner = 'crust-split-inner';

	    $container_class = 'crust-split-container';
	    $split_inner .= ( $settings['crust_particles_splitter'] ) ? ' crust-particles-section' : '';

	    $obj_wrap = 'crust-split-object-wrap';
	    $obj_wrap .= ( $settings['split_hover'] == 'tilt' ) ? ' js-tilt-split' : '';
	    $tilt_atributes = ( $settings['split_hover'] == 'tilt' ) ? ' data-tilt-scale="1.1" data-tilt-max="10" data-tilt-speed="1000" data-tilt-perspective="1000"' : '';

	    $html = '<div class="'.$class.'">';

		    $html .= '<div class="'.$split_inner.'"'.implode( ' ', $split_atributes ).'>';

			    $html .= '<div class="'.$container_class.'">';

				    if( $settings['type'] === 'image' ){

					    $image     = $this->get_settings('image');
					    $image_url = Group_Control_Image_Size::get_attachment_image_src($image['id'], 'thumbnail', $settings);
					    $image_url = (empty($image_url)) ? $image['url'] : $image_url;

					    //$html .= ( $settings['link_type'] === 'link' && strlen( $settings['link'] ) > 0 && strlen( $url['url'] ) > 0 ) ? '<a href="' . esc_attr( $url['url'] ) . '" ' . $rel . ' title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' : '';
					    //$html .= ( $settings['link_type'] === 'box') ? '<a class="crust-zoom-link" href="'.esc_url($img_url).'">' : '';
					    $html .= '<div class="'.$obj_wrap.'"'.$tilt_atributes.'><img alt="" src="'.$image_url.'" /></div>';
					    //$html .= ( $settings['link_type'] === 'box') ? '</a>' : '';
					    //$html .= ( $settings['link_type'] === 'link' && strlen( $settings['link'] ) > 0 && strlen( $url['url'] ) > 0 ) ? '</a>' : '';

				    } else if( $settings['type'] === 'video' ){

					    if ( 'youtube' === $settings['video_type'] ) {
						    $vid_ID = substr($settings['youtube_url'], strrpos($settings['youtube_url'], '/') + 1);
						    $html .= '<div class="'.$obj_wrap.'"'.$tilt_atributes.'><iframe src="'.esc_url($settings['youtube_url']).'?autoplay=1&playlist='.$vid_ID.'&mute=1&enablejsapi=0&loop=1&modestbranding=1" frameborder="0" allow="autoplay"></iframe></div>';
					    } else if ( 'hosted' === $settings['video_type'] ) {
						    $html .= '<div class="'.$obj_wrap.'"'.$tilt_atributes.'><video  preload="auto" loop autoplay muted src="'.$settings['hosted_url']['url'].'"></video></div>';
					    }

				    }

			    $html .= '</div>';

		    $html .= '</div>';

	    $html .= '</div>';

	    echo $html;

    }

}
