<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Plugin;
use \Elementor\Widget_Base;

class Crust_Info_Box extends Widget_Base
{

	use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-info-box', true, true);
        return ['crust-info-box'];
    }

    public function get_name()
    {
        return 'crust-info-box';
    }

    public function get_title()
    {
        return esc_html__('Info Box', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-info-box';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

	    $this->start_controls_section(
		    'crust_section_infobox_settings',
		    [
			    'label' => esc_html__('Settings', 'crust-core')
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_type',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'classic',
			    'options'     => [
				    'classic' => esc_html__('Classic', 'crust-core'),
				    'creative' => esc_html__('Creative', 'crust-core'),
				    'modern' => esc_html__('Modern', 'crust-core'),
				    'overlay' => esc_html__('Overlay', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tilt',
		    [
			    'label'        => __('Hover Tilt', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_control(
		    'tilt_grow',
		    [
			    'label'        => __('Tilt Grow', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
			    'condition'   => [
				    'crust_infobox_tilt' => 'yes'
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_show_infobox_button',
		    [
			    'label'     => __('Show More Button', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'link',
		    [
			    'label'         => esc_html__('Link', 'elementor'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'default'       => [
				    'url'         => 'http://',
				    'is_external' => '',
			    ],
			    'show_external' => true,
		    ]
	    );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_infobox_image',
            [
                'label' => esc_html__('Media', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_infobox_layout',
            [
                'label'       => esc_html__('Media', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'icon'   => [
                        'title' => esc_html__('Icon', 'elementor'),
                        'icon'  => 'fa fa-info-circle',
                    ],
                    'img'    => [
                        'title' => esc_html__('Image', 'crust-core'),
                        'icon'  => 'fa fa-picture-o',
                    ],
                    'number' => [
                        'title' => esc_html__('Number', 'crust-core'),
                        'icon'  => 'fa fa-sort-numeric-desc',
                    ],
                    'none'   => [
                        'title' => esc_html__('None', 'crust-core'),
                        'icon'  => 'fa fa-ban',
                    ],
                ],
                'default'     => 'icon',
            ]
        );

	    $this->add_control(
		    'crust_infobox_style',
		    [
			    'label'       => esc_html__('Position', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'default'     => 'img-on-top',
			    'options'     => [
				    'img-on-top'   => esc_html__('Top', 'crust-core'),
				    'img-on-left'  => esc_html__('Left', 'crust-core'),
				    'img-on-right' => esc_html__('Right', 'crust-core'),
				    'img-on-bottom' => esc_html__('Bottom', 'crust-core'),
			    ],
			    'condition'   => [
				    'crust_infobox_layout!' => 'none'
			    ],
		    ]
	    );

	    $this->add_control(
		    'media_link',
		    [
			    'label'     => __('Is Linkable ?', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
			    'condition'   => [
				    'crust_infobox_layout!' => 'none'
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'icon_vertical_align',
            [
                'label'       => __('Vertical Align', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'condition'   => [
                    'crust_infobox_style!' => ['img-on-top','img-on-bottom'],
	                'crust_infobox_layout!' => 'none'
                ],
                'options'      => [
                    'flex-start'    => [
                        'title' => __('Top', 'crust-core'),
                        'icon'  => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => __('Middle', 'crust-core'),
                        'icon'  => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => __('Bottom', 'crust-core'),
                        'icon'  => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors'            => [
                    '{{WRAPPER}} .crust-infobox-content-wrap' => 'align-items: {{VALUE}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_icon_alignment',
            [
                'label'        => esc_html__('Horizontal Align', 'crust-core'),
                'type'         => Controls_Manager::CHOOSE,
                'label_block'  => false,
                'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
                    'flex-start'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'selectors'            => [
                    '{{WRAPPER}} .crust-infobox .infobox-icon' => 'justify-content: {{VALUE}};'
                ],
                'condition'    => [
	                'crust_infobox_layout!' => 'none',
	                'crust_infobox_style' => ['img-on-top','img-on-bottom'],
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-bring-forward',
                    'library' => 'fontawesome',
                ],
                'condition'        => [
                    'crust_infobox_layout' => 'icon',
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_image',
            [
                'label'     => esc_html__('Image', 'crust-core'),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'crust_infobox_layout' => 'img'
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_number',
            [
                'label'     => esc_html__('Number', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'crust_infobox_layout' => 'number'
                ]
            ]
        );

        $this->crust_animations( 'infobox_icon' );

        $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_infobox_title_settings',
		    [
			    'label' => esc_html__('Title', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_title',
		    [
			    'label'       => esc_html__('Title', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'dynamic'     => [
				    'active' => true
			    ],
			    'default'     => esc_html__('Infobox Title goes here', 'crust-core')
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_title_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'h5',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'div' => esc_html__('div', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
				    'p' => esc_html__('p', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'title_link',
		    [
			    'label'     => __('Is Linkable ?', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('Yes', 'crust-core'),
			    'label_off' => __('No', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip',
		    [
			    'label'       => esc_html__('Tooltip', 'crust-core'),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
		    ]
	    );

	    $this->crust_animations( 'infobox_title' );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_infobox_content',
            [
                'label' => esc_html__('Text', 'crust-core'),
            ]
        );

        $this->add_control(
            'crust_show_infobox_content',
            [
                'label'        => __('Show Text', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'label_on'     => __('Show', 'crust-core'),
                'label_off'    => __('Hide', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'crust_infobox_text_type',
            [
                'label'   => __('Content Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'content'  => __('Content', 'crust-core'),
                    'template' => __('Saved Templates', 'crust-core'),
                ],
                'default' => 'content',
                'condition' => [
                    'crust_show_infobox_content' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_primary_templates',
            [
                'label'     => __('Choose Template', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->crust_core_get_page_templates(),
                'condition' => [
                    'crust_show_infobox_content' => 'yes',
                    'crust_infobox_text_type' => 'template',
                ],
            ]
        );
        $this->add_control(
            'crust_infobox_text',
            [
                'label'       => esc_html__('Content', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true
                ],
                'default'     => esc_html__('Donec sed odio dui. Vivamus sagittis lacus vel augue laoreet rutrum.', 'crust-core'),
                'condition'   => [
                    'crust_show_infobox_content' => 'yes',
                    'crust_infobox_text_type' => 'content',
                ],
            ]
        );

        $this->crust_animations( 'infobox_text' );

        $this->end_controls_section();

        /**
         * ----------------------------------------------
         * Button
         * ----------------------------------------------
         */
        $this->start_controls_section(
            'crust_infobox_button',
            [
                'label' => esc_html__('More Button', 'crust-core'),
                'condition' => [
				    'crust_show_infobox_button!' => ''
			    ]
            ]
        );

        $this->add_control(
            'infobox_button_text',
            [
                'label'       => __('Text', 'elementor'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Read More',
                'placeholder' => __('Enter button text', 'crust-core'),
                'condition'   => [
                    'crust_show_infobox_button' => 'yes'
                ]
            ]
        );

	    $this->add_control(
		    'crust_infobox_button_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__('Default', 'crust-core'),
				    'normal-btn' => esc_html__('Normal Button', 'crust-core'),
				    'enlarge-dot' => esc_html__('Enlarge Dot', 'crust-core'),
				    'animate-more' => esc_html__('Animated Icon', 'crust-core'),
				    'with-line' => esc_html__('With Line', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_hover_style',
		    [
			    'label'   => esc_html__('Hover Style', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
				    'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
				    'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
				    'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
				    'btn-greip'     => esc_html__('Greip', 'crust-core'),
				    'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
			    ],
			    'condition' => [
				    'crust_infobox_button_style' => 'normal-btn'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_infobox_button_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'condition'        => [
                    'crust_show_infobox_button' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_infobox_button_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'crust_infobox_button_icon!' => '',
                    'crust_show_infobox_button'  => 'yes'
                ],
            ]
        );


        $this->crust_animations( 'infobox_button_wrap' );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Info Box Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_infobox_style_settings',
            [
                'label'     => esc_html__('Box Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'crust_infobox_height',
		    [
			    'label'     => esc_html__('Height', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'default'   => [
				    'size' => 350
			    ],
			    'range'     => [
				    'px' => [
					    'max' => 1000,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay' => 'height: {{SIZE}}px;',
			    ],
			    'condition' => [
				    'crust_infobox_type' => 'overlay'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'box_vertical_align',
		    [
			    'label'       => __('Vertical Align', 'crust-core'),
			    'type'        => Controls_Manager::CHOOSE,
			    'label_block' => false,
			    'condition'   => [
				    'crust_infobox_style!' => ['img-on-top','img-on-bottom'],
			    ],
			    'options'      => [
				    'flex-start'    => [
					    'title' => __('Top', 'crust-core'),
					    'icon'  => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => __('Middle', 'crust-core'),
					    'icon'  => 'eicon-v-align-middle',
				    ],
				    'flex-end' => [
					    'title' => __('Bottom', 'crust-core'),
					    'icon'  => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors'            => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-content-wrap' => 'align-items: {{VALUE}};'
			    ],
		    ]
	    );

        $this->start_controls_tabs('crust_infobox_controls');

        $this->start_controls_tab(
            'crust_infobox_normal',
            [
                'label' => esc_html__('Normal', 'elementor'),
            ]
        );

	    $this->add_responsive_control(
		    'crust_infobox_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_infobox_bg_color',
                'types'     => ['classic', 'gradient'],
                'default'   => 'classic',
                'selector'  => '{{WRAPPER}} .crust-infobox',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_infobox_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-infobox'
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-infobox' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_infobox_shadow',
                'selector' => '{{WRAPPER}} .crust-infobox',
            ]
        );
		//////////normal//////////
	    $this->add_responsive_control(
		    'crust_infobox_dark_normal',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox'
		    ]
	    );
	    ////////////////////

        $this->end_controls_tab();

        $this->start_controls_tab(
            'crust_infobox_hover',
            [
                'label' => esc_html__('Hover', 'elementor'),
            ]
        );

	    $this->add_control(
		    'crust_infobox_transform_top',
		    [
			    'label'      => esc_html__('Transform Top', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'max' => 200,
					    'min' => -200,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover' => 'transform: translateY({{SIZE}}{{UNIT}});',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_hover_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_hover_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_infobox_hover_bg_color',
                'types'     => ['classic', 'gradient'],
                'default'   => 'classic',
                'selector'  => '{{WRAPPER}} .crust-infobox:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_infobox_hover_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-infobox:hover'
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_hover_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
	                '{{WRAPPER}} .crust-infobox:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_infobox_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-infobox:hover',
            ]
        );
		//////////hover////////
	    $this->add_responsive_control(
		    'crust_infobox_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_hover_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_dark_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox:hover'
		    ]
	    );

	    //////////////////

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Info Box Icon Style
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_section_infobox_icon_style_settings',
		    [
			    'label'     => esc_html__('Icon Style', 'crust-core'),
			    'tab'       => Controls_Manager::TAB_STYLE,
			    'condition'    => [
				    'crust_infobox_layout!' => 'none',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_infobox_number_icon_typography',
			    'selector' => '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-number',
			    'condition' => [
				    'crust_infobox_layout' => 'number'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Image_Size::get_type(),
		    [
			    'name'      => 'thumbnail',
			    'default'   => 'full',
			    'condition' => [
				    'crust_infobox_image[url]!' => '',
				    'crust_infobox_layout' => 'img',
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_image_animate',
		    [
			    'label'        => __('Animate On Hover', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'condition' => [
				    'crust_infobox_layout' => 'img',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_size',
		    [
			    'label'     => __('Size', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min'  => 10,
					    'max'  => 500,
					    'step' => 1,
				    ]
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon i' => 'font-size: {{SIZE}}px;line-height: {{SIZE}}px;',
				    '{{WRAPPER}} .crust-infobox .infobox-icon-wrap img' => 'max-width: {{SIZE}}px;',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_wrapper_width',
		    [
			    'label'     => __('Wrapper Size', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ]
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap .crust-infobox-img-wrap' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
			    ],
			    'condition' => [
				    'crust_infobox_layout' => 'img'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_width',
		    [
			    'label'     => __('Width', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ]
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap' => 'width: {{SIZE}}px;height: {{SIZE}}px;text-align: center;',
				    '{{WRAPPER}} .crust-infobox .infobox-icon i' => 'line-height: {{SIZE}}px;',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_height',
		    [
			    'label'     => __('Height', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ]
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap' => 'height: {{SIZE}}px;',
				    '{{WRAPPER}} .crust-infobox .infobox-icon i' => 'line-height: {{SIZE}}px;',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_overflow',
		    [
			    'label'   => esc_html__('Overflow', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'hidden'         => esc_html__('Hidden', 'crust-core'),
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap' => 'overflow: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_icon_hover_effect',
		    [
			    'label'   => esc_html__('Hover Animation', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('None', 'crust-core'),
				    'scale'         => esc_html__('Grow', 'crust-core'),
				    'shrink'         => esc_html__('Shrink', 'crust-core'),
				    'rotate'        => esc_html__('Rotate', 'crust-core'),
				    'spin'          => esc_html__('Spin', 'crust-core'),
				    'pulse'         => esc_html__('Pulse', 'crust-core'),
				    'slide-right'   => esc_html__( "Slide Right","crust-core"),
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_image_shape',
		    [
			    'label'        => __('Shape Over ?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'condition' => [
				    'crust_infobox_layout' => 'img',
			    ]
		    ]
	    );

	    $this->start_controls_tabs('crust_infobox_icon_style_controls');

	    $this->start_controls_tab(
		    'crust_infobox_icon_normal',
		    [
			    'label' => esc_html__('Normal', 'elementor'),
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_icon_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon i'                                    => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-infobox.icon-beside-title .infobox-content .crust-infobox-title figure i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .infobox-icon .infobox-icon-number' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_icon_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-infobox .infobox-icon-wrap'
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_img_border_radius',
		    [
			    'label'      => esc_html__('Image Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'condition' => [
				    'crust_infobox_layout' => 'img',
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap .crust-infobox-img-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_img_margin',
		    [
			    'label'      => esc_html__('Image Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'condition' => [
				    'crust_infobox_layout' => 'img',
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap .crust-infobox-img-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_img_bg_color',
		    [
			    'label'     => esc_html__('Image Background Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap .crust-infobox-img-wrap' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_icon_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .infobox-icon-wrap',
		    ]
	    );
		////////normal//////
	    $this->add_responsive_control(
		    'crust_infobox_icon_dark_normal',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_icon_dark_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-icon i'                                    => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-infobox.icon-beside-title .infobox-content .crust-infobox-title figure i' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .infobox-icon .infobox-icon-number' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_icon_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_icon_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-icon-wrap'
		    ]
	    );
	    $this->add_control(
		    'crust_infobox_img_dark_bg_color',
		    [
			    'label'     => esc_html__('Image Background Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-icon .infobox-icon-wrap .crust-infobox-img-wrap' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    ////////////////////

	    $this->end_controls_tab();


	    $this->start_controls_tab(
		    'crust_infobox_icon_hover',
		    [
			    'label' => esc_html__('Hover', 'elementor'),
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_icon_hover_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover .infobox-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_icon_hover_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .infobox-icon i'                                    => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-infobox.icon-beside-title:hover .infobox-content .crust-infobox-title figure i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_icon_hover_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-infobox:hover .infobox-icon .infobox-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_hover_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-infobox:hover .infobox-icon-wrap'
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_hover_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover .infobox-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_img_hover_border_radius',
		    [
			    'label'      => esc_html__('Image Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'condition' => [
				    'crust_infobox_layout' => 'img',
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox:hover .infobox-icon-wrap img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_icon_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox:hover .infobox-icon-wrap',
		    ]
	    );
		///////hover/////
	    $this->add_responsive_control(
		    'crust_infobox_icon_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .infobox-icon i'                                    => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-infobox.icon-beside-title:hover .infobox-content .crust-infobox-title figure i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_icon_hover_dark_bg_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox:hover .infobox-icon .infobox-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_hover_dark_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox:hover .infobox-icon-wrap'
		    ]
	    );

	    /////////////////

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Info Box Title Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_infobox_title_style_settings',
            [
                'label' => esc_html__('Title', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

	    $this->add_responsive_control(
		    'crust_infobox_title_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => false,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-title' => 'text-align: {{VALUE}}'
			    ],
		    ]
	    );

        $this->add_control(
            'crust_infobox_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-infobox .crust-infobox-title, {{WRAPPER}} .crust-infobox .crust-infobox-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_infobox_title_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-title:hover, {{WRAPPER}} .crust-infobox .crust-infobox-title:hover a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_title_box_hover_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_infobox_title_typography',
                'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-title',
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_title_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-infobox .crust-infobox-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_infobox_title_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_title_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .crust-infobox-title',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_title_border',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-title',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_title_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_title_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-title',
		    ]
	    );
		//////////////////
	    $this->add_responsive_control(
		    'crust_section_infobox_title_dark_style_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_title_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title,body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_title_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title:hover,body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title:hover a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_infobox_title_box_hover_dark_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_title_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_title_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-title',
		    ]
	    );

	    //////////////////

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Info Box Tooltip Style)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_infobox_tooltip_styles',
		    [
			    'label' => esc_html__('Tooltip', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_control(
		    'tootip_hover',
		    [
			    'label'         => esc_html__('Visible on Hover ?', 'crust-core'),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_tooltip_position',
		    [
			    'label'        => esc_html__('Position', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => false,
			    'default'      => 'right',
			    'options'      => [
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],

			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox-title:hover .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_box_hover_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_infobox_tooltip_typography',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_tooltip_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_tooltip_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_tooltip_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_tooltip_border',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_tooltip_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_tooltip_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );
		/////////////
	    $this->add_responsive_control(
		    'crust_infobox_tooltip_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox-title:hover .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_tooltip_box_hover_dark_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-tip-inner' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_tooltip_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_tooltip_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-tip-inner',
		    ]
	    );
	    /////////////

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Info Box Text Style)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_infobox_text_settings',
		    [
			    'label' => esc_html__('Text', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_content_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => false,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-text' => 'text-align: {{VALUE}}'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_infobox_content_typography',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_content_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_content_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_text_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_text_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_text_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_text_border',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_text_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_text_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );
		////////////////
	    $this->add_responsive_control(
		    'crust_infobox_text_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_content_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_content_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_text_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_text_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-text',
		    ]
	    );
	    /////////////////

	    $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style ( Info Box Button Style )
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_infobox_button_settings',
            [
                'label'     => esc_html__('Button Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'crust_show_infobox_button' => 'yes'
                ]
            ]
        );

	    $this->add_responsive_control(
		    'crust_infobox_button_alignment',
		    [
			    'label'        => esc_html__('Alignment', 'elementor'),
			    'type'         => Controls_Manager::CHOOSE,
			    'label_block'  => false,
			    'options'      => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'   => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .infobox-button'  => 'text-align: {{VALUE}};'
			    ],
		    ]
	    );

	    $this->add_control(
		    'btn_width',
		    [
			    'label'       => esc_html__('Width', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'default'     => '',
			    'options'     => [
				    ''   => esc_html__('Default', 'crust-core'),
				    'full'  => esc_html__('Full Width', 'crust-core'),
				    'custom' => esc_html__('Custom', 'crust-core'),
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'btn_custom_width',
		    [
			    'label'      => __('Custom Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', '%'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .infobox-button .crust-infobox-button' => 'width: {{SIZE}}{{UNIT}};',
			    ],
			    'condition'        => [
				    'btn_width' => 'custom',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_infobox_button_typography',
                'selector' => '{{WRAPPER}} .crust-infobox .infobox-button .crust-infobox-button .infobox-button-text',
            ]
        );

        $this->add_responsive_control(
            'crust_creative_button_margin',
            [
                'label'      => esc_html__('Margin', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-infobox .infobox-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'crust_creative_button_padding',
            [
                'label'      => esc_html__('Padding', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:not(.btn-bestia), 
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('infobox_button_styles_controls_tabs');

        $this->start_controls_tab(
            'infobox_button_normal',
            [
                'label' => esc_html__('Normal', 'elementor')
            ]
        );

        $this->add_control(
            'crust_infobox_button_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-infobox .crust-infobox-button' => 'color: {{VALUE}};'
                ]
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_button_background',
			    'types'     => ['classic', 'gradient'],
			    'default'   => 'classic',
			    'selector'  => '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:not(.btn-hyperion):not(.btn-bestia), 
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-hyperion:before,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-anthe:before,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_infobox_button_border',
                'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button',
            ]
        );

        $this->add_control(
            'crust_infobox_button_line_color',
            [
                'label'     => esc_html__('Line Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .infobox-button.with-line a.crust-infobox-button .crust-btn-line' => 'background-color: {{VALUE}};',
                ],
                'condition'        => [
                    'crust_infobox_button_style' => 'with-line',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_button_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button,{{WRAPPER}} .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button',
            ]
        );
		////////normal///////
	    $this->add_responsive_control(
		    'infobox_button_dark_normal',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_button_dark_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:not(.btn-hyperion):not(.btn-bestia), 
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-hyperion:before,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-anthe:before,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_button_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button',
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_line_dark_color',
		    [
			    'label'     => esc_html__('Line Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .infobox-button.with-line a.crust-infobox-button .crust-btn-line' => 'background-color: {{VALUE}};',
			    ],
			    'condition'        => [
				    'crust_infobox_button_style' => 'with-line',
			    ],
		    ]
	    );

	    //////////////////

        $this->end_controls_tab();

        $this->start_controls_tab(
            'infobox_button_hover',
            [
                'label' => esc_html__('Hover', 'elementor')
            ]
        );

	    $this->add_control(
		    'crust_infobox_button_hover_btn_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:hover' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_infobox_button_hover_text_color',
            [
                'label'     => esc_html__('Box Hover Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
	                '{{WRAPPER}} .crust-infobox:hover .crust-infobox-button' => 'color: {{VALUE}};'
                ]
            ]
        );

	    $this->add_control(
		    'crust_infobox_button_hover_dots_color',
		    [
			    'label'     => esc_html__('Dots Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button span.crust-dots-wrap i' => 'background-color: {{VALUE}} !important;'
			    ],
			    'condition' => [
			    	'crust_infobox_button_style' => 'animate-more'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_button_hover_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:not(.styled-btn):hover, 
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-hyperion,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button::before,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button::after,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-anthe:hover:before,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg::before,
					{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg::after',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_infobox_button_hover_border',
                'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover',
            ]
        );

        $this->add_control(
            'crust_infobox_button_line_hover_color',
            [
                'label'     => esc_html__('Line Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .infobox-button.with-line a.crust-infobox-button .crust-btn-line:before' => 'background-color: {{VALUE}};',
                ],
                'condition'        => [
                    'crust_infobox_button_style' => 'with-line',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_infobox_button_hover_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
	                '{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:hover,{{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia:hover .bestia-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_hover_box_shadow',
                'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover',
            ]
        );
		//////////hover//////
	    $this->add_responsive_control(
		    'infobox_button_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_btn_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:hover' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_text_dark_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-button' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_dots_dark_color',
		    [
			    'label'     => esc_html__('Dots Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button span.crust-dots-wrap i' => 'background-color: {{VALUE}} !important;'
			    ],
			    'condition' => [
				    'crust_infobox_button_style' => 'animate-more'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_button_hover_dark_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button:not(.styled-btn):hover, 
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-hyperion,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button::before,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button::after,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-anthe:hover:before,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg::before,
					body.crust-dark {{WRAPPER}} .crust-infobox .infobox-button a.crust-infobox-button.btn-bestia .bestia-bg::after',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_button_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button:hover',
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_line_hover_dark_color',
		    [
			    'label'     => esc_html__('Line Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .infobox-button.with-line a.crust-infobox-button .crust-btn-line:before' => 'background-color: {{VALUE}};',
			    ],
			    'condition'        => [
				    'crust_infobox_button_style' => 'with-line',
			    ],
		    ]
	    );
	    /////////////////////

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Info Box Button Icon Styles)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_infobox_btn_icon_settings',
		    [
			    'label' => esc_html__('Button Icon', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_infobox_button_icon!' => ''
			    ]
		    ]
	    );

	    $this->start_controls_tabs('infobox_btn_icon_tabs');

	    $this->start_controls_tab( 'infobox_btn_icon_normal', [ 'label' => esc_html__('Normal', 'elementor') ] );

	    $this->add_responsive_control(
		    'crust_infobox_button_icon_size',
		    [
			    'label'      => __('Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'default'    => [
				    'size' => 16,
				    'unit' => 'px',
			    ],
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button .crust-btn-icon-wrap i'   => 'font-size: {{SIZE}}{{UNIT}};',
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button .crust-btn-icon-wrap img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_creative_button_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_creative_button_icon_padding',
		    [
			    'label'      => esc_html__('Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_icon_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_btn_icon_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_border',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_btn_icon_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-btn-icon-wrap',
		    ]
	    );
		///////////normal/////////
	    $this->add_responsive_control(
		    'infobox_btn_icon_dark_normal',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_button_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_btn_icon_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-btn-icon-wrap',
		    ]
	    );

	    ///////////////////////////

	    $this->end_controls_tab();

	    $this->start_controls_tab( 'infobox_btn_icon_hover', [ 'label' => esc_html__('Hover', 'elementor') ] );

	    $this->add_responsive_control(
		    'infobox_hover_btn_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_icon_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_box_icon_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-button i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_btn_icon_hover_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_hover_border',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_btn_icon_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap',
		    ]
	    );
		//////hover///////
	    $this->add_responsive_control(
		    'infobox_btn_icon_dark_hover',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_button_hover_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_button_hover_box_icon_dark_color',
		    [
			    'label'     => esc_html__('Box Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-button i' => 'color: {{VALUE}};'
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_btn_icon_hover_dark-bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_btn_icon_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-button:hover .crust-btn-icon-wrap',
		    ]
	    );
	    //////////////////

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Tab Style (Info Box Overlay Styles)
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_infobox_overlay_settings',
		    [
			    'label' => esc_html__('Overlay Settings', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_infobox_type' => 'overlay'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_overlay_align',
		    [
			    'label' => __( 'Vertical Align', 'elementor' ),
			    'type' => Controls_Manager::CHOOSE,
			    'toggle' => false,
			    'default' => 'center',
			    'options' => [
				    'flex-start' => [
					    'title' => __( 'Top', 'elementor' ),
					    'icon' => 'eicon-v-align-top',
				    ],
				    'center' => [
					    'title' => __( 'Center', 'elementor' ),
					    'icon' => 'eicon-v-align-middle',
				    ],
				    'flex-end' => [
					    'title' => __( 'Bottom', 'elementor' ),
					    'icon' => 'eicon-v-align-bottom',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay' => 'justify-content: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_overlay_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .infobox-content-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_overlay_scale',
		    [
			    'label'        => __('Hover Scale BG', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes'
		    ]
	    );

	    $this->start_controls_tabs('crust_overlay_tabs');

	    $this->start_controls_tab('crust_overlay_tab', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_responsive_control(
		    'overlay_opacity',
		    [
			    'label'     => esc_html__('Opacity', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1,
					    'step' => .01,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap' => 'opacity: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_overlay_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_overlay_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
		/////////normal//////
	    $this->add_responsive_control(
		    'crust_infobox_overlay_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_overlay_dark_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap',
		    ]
	    );

	    /////////////////////

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_overlay_hover_tab', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_responsive_control(
		    'overlay_hover_opacity',
		    [
			    'label'     => esc_html__('Opacity', 'crust-core'),
			    'type'      => Controls_Manager::SLIDER,
			    'range'     => [
				    'px' => [
					    'min' => 0,
					    'max' => 1,
					    'step' => .01,
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay:hover .crust-overlay-img-wrap' => 'opacity: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_overlay_hover_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap .crust-overlay-img',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_overlay_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay:hover .crust-overlay-img-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
		//////hover//////
	    $this->add_responsive_control(
		    'crust_infobox_overlay_dark_hover_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_overlay_hover_dark_background',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-overlay-img-wrap .crust-overlay-img',
		    ]
	    );
	    /////////////////

	    $this->end_controls_tab();
	    $this->end_controls_tabs();

	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_infobox_content_style_settings',
		    [
			    'label' => esc_html__('Overlay Content', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_infobox_type' => 'overlay'
			    ]
		    ]
	    );

	    $this->add_control(
		    'content_hover_visible',
		    [
			    'label'         => esc_html__('Visible On Hover', 'crust-core'),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
			    'condition'     => [
				    'crust_infobox_type' => 'overlay',
			    ]
		    ]
	    );

	    $this->add_control(
		    'content_hover_dir',
		    [
			    'label' => __( 'Direction', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => 'to-right',
			    'options' => [
				    'to-right' => esc_html__('To Right', 'crust-core'),
				    'to-left' => esc_html__('To Left', 'crust-core'),
				    'to-top' => esc_html__('To Top', 'crust-core'),
				    'to-bottom' => esc_html__('To Bottom', 'crust-core'),
			    ],
			    'condition' => [
				    'content_hover_visible!' => ''
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_content_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_content_hover_margin',
		    [
			    'label'      => esc_html__('Hover Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay:hover .crust-infobox-content-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_content_only_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_content_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_content_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap'
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_infobox_content_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_infobox_content_shadow',
			    'selector' => '{{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap',
		    ]
	    );
		////////////////////
	    $this->add_responsive_control(
		    'crust_section_infobox_content_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_infobox_content_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_infobox_content_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-infobox.crust-infobox-overlay .crust-infobox-content-wrap'
		    ]
	    );
	    ////////////////////

	    $this->end_controls_section();

	    /**
	     * -------------------------------------------
	     * Info Box Creative Divider Style
	     * -------------------------------------------
	     */
	    $this->start_controls_section(
		    'crust_infobox_creative_settings',
		    [
			    'label'     => esc_html__('Creative Divider Style', 'crust-core'),
			    'tab'       => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_infobox_type' => 'creative'
			    ]
		    ]
	    );

	    $this->crust_divider_settings();

	    $this->add_responsive_control(
		    'crust_infobox_creative_divider_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-divider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->end_controls_section();

	    /* Modern Icon Style */
	    $this->start_controls_section(
		    'crust_section_infobox_modern_icon_style_settings',
		    [
			    'label' => esc_html__('Modern Icon Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'crust_infobox_type' => 'modern'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_modern_icon_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#e8ecf3',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox .crust-infobox-modern-icon i' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-infobox .crust-infobox-modern-icon svg *' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_modern_icon_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-modern-icon i' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-infobox:hover .crust-infobox-modern-icon svg *' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );
		///////////////////
	    $this->add_responsive_control(
		    'crust_section_infobox_modern_icon_style_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_infobox_modern_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#e8ecf3',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-modern-icon i' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-infobox .crust-infobox-modern-icon svg *' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_infobox_modern_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-modern-icon i' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-infobox:hover .crust-infobox-modern-icon svg *' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );
	    /////////////////////

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings   = $this->get_settings_for_display();
        $type       = $settings['crust_infobox_type'];
        $order      = $settings['crust_infobox_style'];
        $html = $link = $link_close = '';

	    $boxClass  = ( $settings['content_hover_visible'] ) ? ' crust-box-content-hover' : '';
	    $boxClass .= ( $settings['content_hover_dir'] ) ? ' crust-' . $settings['content_hover_dir'] : '';
	    $boxClass .= ( $settings['crust_infobox_icon_hover_effect'] ) ? ' crust-animate-icon-' . $settings['crust_infobox_icon_hover_effect'] : '';
	    $boxClass .= ( $settings['crust_infobox_image_shape'] ) ? ' crust-shape-over' : '';
	    $boxClass .= (  $settings['crust_overlay_scale'] === 'yes' ) ? ' crust-hover-scale-bg' : '';
	    $boxClass .= ( $settings['crust_infobox_tilt'] === 'yes' ) ? ' js-tilt' : '';

        $this->add_render_attribute('crust_infobox', 'class', [
                'crust-infobox',
                'crust-infobox-' . $type,
	            $boxClass,
                $settings['crust_infobox_style'],
            ]
        );

        if( $settings['tilt_grow'] === 'yes' ){
	        $this->add_render_attribute('crust_infobox',  [
	        	'data-tilt-scale' => '1.05',
		        'data-tilt-max' => '4',
		        'data-tilt-speed' => '1000',
		        'data-tilt-perspective' => '800',
	        ]);
        }

        if ('img-on-right' == $settings['crust_infobox_style']) {
            $this->add_render_attribute('crust_infobox', 'class', 'icon-on-right');
        }

        $html .= '<div '. $this->get_render_attribute_string('crust_infobox').'>';
            $html .= ( $type === 'overlay' ) ? '<div class="crust-overlay-img-wrap"><div class="crust-overlay-img"></div></div>' : '';
            $html .= ( $type === 'overlay' ) ? '<div class="infobox-content-inner">'  :'';
                $html .= '<div class="crust-infobox-content-wrap">';
	                $html .= ( 'img-on-bottom' !== $order ) ? $this->render_infobox_icon() : '';
                    $html .= $this->render_infobox_content();
					$html .= ( 'img-on-bottom' === $order ) ? $this->render_infobox_icon() : '';
                $html .= '</div>';
            $html .= ( $type === 'overlay' ) ? '</div>' : '';

            $html .= $this->render_modern_icon();

            if ( 'creative' == $type ) {
	            $div_style = $settings['div_style'];
	            $div_layers = $settings['layers_no'];

	            $div_class = 'crust-divider';
	            $div_class .= ( '1' === $settings['flip_horizontal'] ) ? ' crust-horizontal-flip'  : '';
	            $div_class .= ( '1' === $settings['flip_vertical'] )   ? ' crust-vertical-flip'    : '';
	            $div_class .= ( '1' === $settings['full_width'] )      ? ' full-divider'           : '';
	            $div_class .= ( $div_style ) ? ' crust-divider-' . $div_style : '';

	            $f_col = ( $settings['layer_1_color'] === '' ) ? '#12d0de' : $settings['layer_1_color'];
	            $s_col = ( $settings['layer_2_color'] === '' ) ? '#b9d114' : $settings['layer_2_color'];
	            $first_color = ( $div_style == 'style0' ) ? $f_col : '';
	            $second_color = ( $div_style == 'style0' ) ? $s_col : '';
	            $html .= apply_filters('crust_ele_divider_site_markup', $div_style, $div_layers, $div_class, $first_color, $second_color );
            }
        $html .= '</div>';

        echo $html;

    }

    protected function render_infobox_icon()
    {
        $settings = $this->get_settings_for_display();

        if ('none' == $settings['crust_infobox_layout']) {
            return;
        }

	    if( $settings['link']['url'] && $settings['media_link'] == 'yes' ){
		    $target   = $settings['link']['is_external'] ? ' target="_blank"' : '';
		    $nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
		    $link = '<a href="'.esc_url($settings['link']['url']).'"'.$target.$nofollow.'>';
		    $link_close = ( $settings['link'] ) ? '</a>' : '';
	    } else {
	    	$link = $link_close = '';
	    }

        $this->crust_animation_attributes( 'infobox_icon' );

        $infobox_image     = $this->get_settings('crust_infobox_image');
        $infobox_image_url = Group_Control_Image_Size::get_attachment_image_src($infobox_image['id'], 'thumbnail', $settings);
        $infobox_image_url = (empty($infobox_image_url)) ? $infobox_image['url'] : $infobox_image_url;
        $infobox_icon = $settings['crust_infobox_icon'];
        $width = (!empty($settings['crust_infobox_icon_width']['size'])) ? 'crust-infobox-icon-width' : '';
        $img_animate = ( $settings['crust_infobox_image_animate'] ) ? 'animate-img' : '';

        $this->add_render_attribute(
            'infobox_icon',
            [
                'class' => [
                    'infobox-icon',
                    'infobox-icon-type-' . $settings['crust_infobox_layout'],
	                $img_animate,
                    $width
                ]
            ]
        );

        if ($infobox_icon) {
            $icon = $settings['crust_infobox_icon']['value'];

            if (isset($icon['url'])) {
                $this->add_render_attribute(
                    'icon_or_image',
                    [
                        'src' => $icon['url'],
                        'alt' => esc_attr(get_post_meta($icon['id'], '_wp_attachment_image_alt', true))
                    ]
                );
                $icon_tag = '<img ' . $this->get_render_attribute_string('icon_or_image') . '/>';
            } else {
                $this->add_render_attribute('icon_or_image', 'class', $icon);
                $icon_tag = '<i ' . $this->get_render_attribute_string('icon_or_image') . '></i>';
            }
        } else {
            $icon_tag = '<i class="' . esc_attr($settings['crust_infobox_icon']) . '"></i>';
        }

        $html = '<div '. $this->get_render_attribute_string('infobox_icon') .'>';

            $html .= ( '' !== $settings['crust_infobox_layout'] ) ? '<div class="infobox-icon-wrap">' : '';
                $html .= ( 'img' == $settings['crust_infobox_layout'] ) ? $link . '<span class="crust-infobox-img-wrap"><img class="infobox-icon-image" src="'. esc_url($infobox_image_url) .'" alt="'. esc_attr(get_post_meta($infobox_image['id'], '_wp_attachment_image_alt', true)) .'"></span>' . $link_close
	                : '';
            	$html .= ( 'icon' == $settings['crust_infobox_layout'] ) ? $link . $icon_tag . $link_close : '';
            	$html .= ( 'number' == $settings['crust_infobox_layout'] ) ? $link . '<span class="infobox-icon-number">'. esc_attr($settings['crust_infobox_number']) .'</span>' . $link_close : '';
	        $html .= ( '' !== $settings['crust_infobox_layout'] ) ? '</div>' : '';

        $html .= '</div>';

        return $html;

    }

	protected function render_modern_icon()
	{
		$settings = $this->get_settings_for_display();
		$html = '';
		if( 'icon' == $settings['crust_infobox_layout'] && 'modern' == $settings['crust_infobox_type'] ){
			$html .= '<div class="crust-infobox-modern-icon">';
				$html .= $this->render_infobox_modern_icon();
			$html .= '</div>';
			return $html;
		}
	}

	protected function render_infobox_modern_icon()
	{
		$settings = $this->get_settings_for_display();
		$html = '';
		if ('none' == $settings['crust_infobox_layout']) {
			return;
		}

		$infobox_image     = $this->get_settings('crust_infobox_image');
		$infobox_image_url = Group_Control_Image_Size::get_attachment_image_src($infobox_image['id'], 'thumbnail', $settings);
		$infobox_image_url = (empty($infobox_image_url)) ? $infobox_image['url'] : $infobox_image_url;
		$infobox_icon = $settings['crust_infobox_icon'];

		if ($infobox_icon) {
			$icon = $settings['crust_infobox_icon']['value'];

			if (isset($icon['url'])) {
				$this->add_render_attribute(
					'icon_or_image_modern',
					[
						'src' => $icon['url'],
						'alt' => esc_attr(get_post_meta($icon['id'], '_wp_attachment_image_alt', true))
					]
				);
				$icon_tag = '<img ' . $this->get_render_attribute_string('icon_or_image_modern') . '/>';
			} else {
				$this->add_render_attribute('icon_or_image_modern', 'class', $icon);
				$icon_tag = '<i ' . $this->get_render_attribute_string('icon_or_image_modern') . '></i>';
			}
		} else {
			$icon_tag = '<i class="' . esc_attr($settings['crust_infobox_icon']) . '"></i>';
		}

		$html .= ( 'img' == $settings['crust_infobox_layout'] ) ? '<img class="infobox-icon-image" src="'. esc_url($infobox_image_url) .'" alt="'. esc_attr(get_post_meta($infobox_image['id'], '_wp_attachment_image_alt', true)) .'">' : '';
		$html .= ( 'icon' == $settings['crust_infobox_layout'] ) ? $icon_tag : '';
		$html .= ( 'number' == $settings['crust_infobox_layout'] ) ? '<span class="infobox-icon-number">'. esc_attr($settings['crust_infobox_number']) .'</span>' : '';

		return $html;

	}

    protected function render_infobox_content()
    {
        $settings = $this->get_settings_for_display();
        $tag      = $settings['crust_infobox_title_tag'];
		$html     = '';
        $this->add_render_attribute('infobox_text', 'class', 'crust-infobox-text');
        $this->add_render_attribute('infobox_content_wrap', 'class', 'crust-infobox-content');

        $this->add_render_attribute('infobox_title', 'class', 'crust-infobox-title' );

        if( $settings['crust_infobox_tooltip'] ){
	        $title_class = ( $settings['crust_infobox_tooltip'] ) ? ' crust-box-tooltip-' . $settings['crust_tooltip_position'] : '';
	        $title_class .= ( $settings['tootip_hover'] ) ? ' crust-box-tooltip-hover' : '';
	        $this->add_render_attribute('infobox_title', 'class', $title_class );
        }

	    if( $settings['link']['url'] && $settings['title_link'] == 'yes' ){
		    $target   = $settings['link']['is_external'] ? ' target="_blank"' : '';
		    $nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
		    $link = '<a href="'.esc_url($settings['link']['url']).'"'.$target.$nofollow.'>';
		    $link_close = ( $settings['link'] ) ? '</a>' : '';
	    } else {
		    $link = $link_close = '';
	    }

        $this->crust_animation_attributes( 'infobox_title' );

        $html .= '<div '.$this->get_render_attribute_string('infobox_content_wrap').'>';

            $html .= '<'.$tag. ' ' .$this->get_render_attribute_string('infobox_title').'>';
            $html .= $link;
	            $html .= ( $settings['crust_infobox_tooltip'] && $settings['crust_tooltip_position'] == 'left' ) ? '<span class="crust-infobox-tooltip"><span class="crust-infobox-tip-inner">' . $settings['crust_infobox_tooltip'] . '</span></span>' : '';
                $html .= ( $settings['crust_infobox_title'] ) ? '<span class="crust-infobox-title-text">' . $settings['crust_infobox_title'] . '</span>' : '';
	            $html .= ( $settings['crust_infobox_tooltip'] && $settings['crust_tooltip_position'] == 'right' ) ? '<span class="crust-infobox-tooltip"><span class="crust-infobox-tip-inner">' . $settings['crust_infobox_tooltip'] . '</span></span>' : '';
	        $html .= $link_close;
            $html .= '</'.$tag.'>';

            if ('yes' == $settings['crust_show_infobox_content']) {
                $this->crust_animation_attributes( 'infobox_text' );
                $html .= '<div ' .$this->get_render_attribute_string('infobox_text').'>';
                    if ('content' === $settings['crust_infobox_text_type']) {
                        if ( ! empty($settings['crust_infobox_text'])) {
                            $html .= $settings['crust_infobox_text'];
                        }
                    } else if ('template' === $settings['crust_infobox_text_type']) {
                        if (!empty($settings['crust_primary_templates'])) {
                            $crust_template_id = $settings['crust_primary_templates'];
                            $html .= Plugin::$instance->frontend->get_builder_content($crust_template_id, true);
                        }
                    }
                $html .= '</div>';
            }

            $html .= $this->render_infobox_button();

        $html .= '</div>';

        return $html;
    }

    protected function render_infobox_button()
    {
        $settings = $this->get_settings_for_display();
        if ('yes' != $settings['crust_show_infobox_button']) {
            return;
        }

        $style = $settings['crust_infobox_button_style'];

        $this->crust_animation_attributes( 'infobox_button_wrap' );

	    $wrap_class = 'crust-btn-icon-wrap';
        $button_icon = $settings['crust_infobox_button_icon'];

        $this->add_render_attribute('infobox_button', 'class', 'crust-infobox-button');

        if ($settings['link']['url']) {
            $this->add_render_attribute('infobox_button', 'href', esc_url($settings['link']['url']));
        }

        if ('on' == $settings['link']['is_external']) {
            $this->add_render_attribute('infobox_button', 'target', '_blank');
        }

        if ('on' == $settings['link']['nofollow']) {
            $this->add_render_attribute('infobox_button', 'rel', 'nofollow');
        }

        $btn_class = 'infobox-button';
        $btn_class .= ( '' !== $settings['crust_infobox_button_style'] ) ? ' ' . $settings['crust_infobox_button_style'] : '';
	    $btn_class .= ( $settings['btn_width'] === 'full' ) ? ' full-btn' : '';

	    $this->add_render_attribute('infobox_button_wrap', 'class', [
            $btn_class
        ]);

	    if( $style == 'normal-btn' ){
		    $this->add_render_attribute('infobox_button', 'class', 'crust-btn ' . $settings['button_hover_style'] );
	    }

	    if( $settings['button_hover_style'] ){
		    $this->add_render_attribute('infobox_button', 'class', 'styled-btn' );
	    }

	    if( $settings['crust_infobox_button_style'] == 'animate-more' ){
		    $this->add_render_attribute('infobox_button', 'class', 'crust-animate-more' );
	    }

	    if ($button_icon) {
		    $icon_output = '<span class="'. esc_attr( $wrap_class ) .'">';
		    if (isset($settings['crust_infobox_button_icon']['value']['url'])) {
			    $icon_output .= '<img class="crust_infobox_button_icon_left" src="'. esc_attr($settings['crust_infobox_button_icon']['value']['url']) .'" alt="'. esc_attr(get_post_meta
				    ($settings['crust_infobox_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'"/>';
			    $icon_output .= ( $settings['crust_infobox_button_style'] == 'animate-more' ) ? '<span class="crust-dots-wrap"><i></i><i></i><i></i></span>' : '';
		    } else {
			    $icon_output .= '<i class="'. esc_attr($settings['crust_infobox_button_icon']['value']) .'"></i>';
			    $icon_output .= ( $settings['crust_infobox_button_style'] == 'animate-more' ) ? '<span class="crust-dots-wrap"><i></i><i></i><i></i></span>' : '';
		    }
		    $icon_output .= '</span>';
	    }

        $html = '<div '. $this->get_render_attribute_string( 'infobox_button_wrap') .'>';
            $html .= '<a '. $this->get_render_attribute_string('infobox_button'). '>';

			    $html .= ( $settings['button_hover_style'] == 'btn-bestia' ) ? '<b class="bestia-bg"></b>' : '';
			    $html .= ( $style == 'normal-btn' ) ? "<span><span>" : '';

                $html .= ('left' == $settings['crust_infobox_button_icon_alignment']) ? $icon_output : '';

                $html .= ( $settings['infobox_button_text'] ) ? '<span class="infobox-button-text">'. esc_attr($settings['infobox_button_text']) .'</span>' : '';

                $html .= ( 'with-line' == $settings['crust_infobox_button_style'] ) ? '<span class="crust-btn-line"></span>' : '';

                $html .= ('right' == $settings['crust_infobox_button_icon_alignment']) ? $icon_output : '';

	            $html .= ( $style == 'normal-btn' ) ? "</span></span>" : '';

            $html .= '</a>';
        $html .= '</div>';

        return $html;
    }

}
