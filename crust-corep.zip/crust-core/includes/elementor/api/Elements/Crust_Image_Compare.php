<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;

class Crust_Image_Compare extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-image-compare';
    }

	public function get_script_depends()
	{
		return ['crust-image-compare'];
	}

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-image-compare', true, true);
		return ['crust-image-compare'];
	}

    public function get_title()
    {
        return esc_html__('Image Compare', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-dual-button';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_main_img_settings',
			[
				'label' => esc_html__('Main Image', 'crust-core')
			]
		);

		$this->add_control(
			'image', [
				'label'       => esc_html__('Image', 'crust-core'),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
				],
			]
		);

		$this->add_control(
			'main_text',
			[
				'label'     => esc_html__('Text', 'crust-core'),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__('Before Crust.', 'crust-core'),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'main_tag',
			[
				'label'   => esc_html__('HTML Tag', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'h1'   => __('H1', 'crust-core'),
					'h2'   => __('H2', 'crust-core'),
					'h3'   => __('H3', 'crust-core'),
					'h4'   => __('H4', 'crust-core'),
					'h5'   => __('H5', 'crust-core'),
					'h6'   => __('H6', 'crust-core'),
					'div'  => __('div', 'crust-core'),
					'span' => __('span', 'crust-core'),
					'p'    => __('p', 'crust-core'),
				],
				'default' => 'h5',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'main_typo',
				'label'    => __('Typography', 'crust-core'),
				'selector' => '{{WRAPPER}} .main-compare-title',
			]
		);

		$this->add_control(
			'main_color',
			[
				'label'     => __('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-compare-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_sec_img_settings',
			[
				'label' => esc_html__('Second Image', 'crust-core'),
			]
		);

		$this->add_control(
			'sec_image', [
				'label'       => esc_html__('Image', 'crust-core'),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/gallery-placeholder.jpg',
				],
			]
		);

		$this->add_control(
			'sec_text',
			[
				'label'     => esc_html__('Text', 'crust-core'),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__('After Crust.', 'crust-core'),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sec_tag',
			[
				'label'   => esc_html__('HTML Tag', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'h1'   => __('H1', 'crust-core'),
					'h2'   => __('H2', 'crust-core'),
					'h3'   => __('H3', 'crust-core'),
					'h4'   => __('H4', 'crust-core'),
					'h5'   => __('H5', 'crust-core'),
					'h6'   => __('H6', 'crust-core'),
					'div'  => __('div', 'crust-core'),
					'span' => __('span', 'crust-core'),
					'p'    => __('p', 'crust-core'),
				],
				'default' => 'h5',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sec_typo',
				'label'    => __('Typography', 'crust-core'),
				'selector' => '{{WRAPPER}} .second-compare-title',
			]
		);

		$this->add_control(
			'sec_color',
			[
				'label'     => __('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .second-compare-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'crust_comp_wrap_settings',
			[
				'label' => esc_html__('Wrapper Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'comp_wrap_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-compare-container',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'comp_wrap_border',
				'selector' => '{{WRAPPER}} .crust-compare-container',
			]
		);

		$this->add_responsive_control(
			'comp_wrap_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'comp_wrap_box_shadow',
				'selector' => '{{WRAPPER}} .crust-compare-container',
			]
		);

		/**
		 *-----------------------------
		 *end wrap dark
		 *-----------------------------
		 * **/

		$this->add_responsive_control(
		'crust_comp_wrap_dark_settings',
		[
		'label'      => esc_html__('Dark Mode', 'crust-dark'),
		'type'       => Controls_Manager::HEADING,
		'separator' => 'before',

		]
		);

		$this->add_group_control(
		Group_Control_Background::get_type(),
		[
		'name'     => 'comp_wrap_dark_bg',
		'types'    => ['classic', 'gradient'],
		'selector' => 'body.crust-dark {{WRAPPER}} .crust-compare-container',
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(),
		[
		'name'     => 'comp_wrap_dark_border',
		'selector' => 'body.crust-dark {{WRAPPER}} .crust-compare-container',
		]
		);

		/**
		 *-----------------------------
		 *end wrap dark
		 *-----------------------------
		 **/

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_div_settings',
			[
				'label' => esc_html__('Divider', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'div_width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle:before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'div_bg_color',
			[
				'label'     => __('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'div_act_bg_color',
			[
				'label'     => __('Acrive Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle.draggable:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		/**
		 *-----------------------------
		 *start divider dark
		 *-----------------------------
		 **/

		$this->add_responsive_control(
			'crust_div_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-dark'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'div_bg_dark_color',
			[
				'label'     => __('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-compare-handle:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'div_act_bg_dark_color',
			[
				'label'     => __('Acrive Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-compare-handle.draggable:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		/**
		 *-----------------------------
		 *end divider dark
		 *-----------------------------
		 **/



		$this->end_controls_section();

		$this->start_controls_section(
			'crust_circl_settings',
			[
				'label' => esc_html__('Circle', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon',
			[
				'label'     => esc_html__('Icon', 'elementor'),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
                    'value'   => 'fa fa-arrows',
                    'library' => 'fontawesome',
                ]
			]
		);

		$this->add_control(
			'circl_width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'circl_height',
			[
				'label'      => esc_html__('Height', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label'      => esc_html__('Size', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_rotate',
			[
				'label'      => esc_html__('Rotate', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon i' => 'transform: rotate({{SIZE}}deg);',
				],
			]
		);

		$this->add_control(
			'circ_icon_color',
			[
				'label'     => __('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'circ_bg_color',
			[
				'label'     => __('Background Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'circ_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-compare-handle .crust-com-icon'
			]
		);

		$this->add_responsive_control(
			'circ_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-compare-handle .crust-com-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'circ_shadow',
				'selector' => '{{WRAPPER}} .crust-compare-handle i',
			]
		);

		/**
		 *-----------------------------
		 *start icon dark
		 *-----------------------------
		 **/

		$this->add_responsive_control(
			'crust_circl_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-dark'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'circ_icon_dark_color',
			[
				'label'     => __('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-compare-handle .crust-com-icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'circ_bg_dark_color',
			[
				'label'     => __('Background Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-compare-handle .crust-com-icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'circ_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-compare-handle .crust-com-icon'
			]
		);
		/**
		 *-----------------------------
		 *end icon dark
		 *-----------------------------
		 **/

		$this->end_controls_section();

	}

    protected function render()
    {

        $settings = $this->get_settings_for_display();

	    $img = ( $settings['image']['url'] ) ? '<img src="' . $settings['image']['url'] . '" />' : '';
	    $sec_img = ( $settings['sec_image']['url'] ) ? '<img src="' . $settings['sec_image']['url'] . '">' : '';
	    $iconoutput = '';
	    $class = 'crust-compare-container';

	    if (isset($settings['icon']['value']['url'])) {
		    $iconoutput .= '<img src="'. esc_attr($settings['icon']['value']['url']) .'" alt="'.esc_attr(get_post_meta($settings['icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
	    } else {
		    $iconclass = ( $settings['icon']['value'] ) ? ' ' . $settings['icon']['value'] : '';
		    $iconoutput .= ( ! empty($settings['icon']['value'])) ? '<i class="'.$iconclass.'"></i>' : '';
	    }

	    $main_tag = $settings['main_tag'];
	    $second_tag = $settings['sec_tag'];

	    $html = '<figure class="'.$class.'">';
            $html .= $img;
            $html .= '<'.$main_tag.' class="crust-compare-label main-compare-title" data-type="original">'.esc_html($settings['main_text']).'</'.$main_tag.'>';
    
            $html .= '<div class="crust-compare-resize">';
                $html .= $sec_img;
                $html .= '<'.$second_tag.' class="crust-compare-label second-compare-title" data-type="modified">'.esc_html($settings['sec_text']).'</'.$second_tag.'>';
            $html .= '</div>';
    
            $html .= '<span class="crust-compare-handle">';
                $html .= ( $settings['icon'] ) ? '<span class="crust-com-icon">'.$iconoutput.'</span>' : '';
            $html .= '</span>';
	    $html .= '</figure>';
	    
	    echo  $html;

    }

}
