<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;

class Crust_Cart extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-cart';
    }

    public function get_title()
    {
        return esc_html__('Woo Header Cart', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-cart';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_section_cart_content_settings',
			[
				'label' => esc_html__('General', 'crust-core')
			]
		);

		$this->add_control(
			'crust_cart_content',
			[
				'label'        => esc_html__('You need to customize the header cart style from Theme Options.', 'crust-core'),
				'type'         => Controls_Manager::HEADING,
			]
		);

		$this->end_controls_section();

	}

    protected function render()
    {

	    if ( class_exists('Woocommerce') ){

		    if ( function_exists( 'yith_wishlist_constructor' ) ) {
			    echo do_action('crust_site_header_wishlist_button');
		    }
		    echo do_action('crust_site_header_cart');

	    } else {
		    echo '<p>'. esc_html__( 'Please Install and Activate WooCommerce Plugin.' , 'crust-core' ) .'</p>';
	    }

    }

}
