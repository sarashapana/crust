<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use \Elementor\Widget_Base;

class Crust_Video extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-video';
    }

    public function get_title()
    {
        return esc_html__('Video', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_video_content',
            [
                'label' => esc_html__('General', 'crust-core'),
            ]
        );

	    $this->add_control(
		    'mode',
		    [
			    'label'   => esc_html__('Mode', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    '' => esc_html__('Normal', 'elementor'),
				    'popup' => esc_html__('Popup', 'elementor'),
			    ]
		    ]
	    );

	    $this->add_control(
		    'video_type',
		    [
			    'label' => __( 'Source', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => 'youtube',
			    'options' => [
				    'youtube' => __( 'YouTube', 'elementor' ),
				    'hosted' => __( 'Self Hosted', 'elementor' ),
			    ],
			    'frontend_available' => true,
		    ]
	    );

	    $this->add_control(
		    'youtube_url',
		    [
			    'label' => __( 'Link', 'elementor' ),
			    'type' => Controls_Manager::TEXT,
			    'dynamic' => [
				    'active' => true,
				    'categories' => [
					    TagsModule::POST_META_CATEGORY,
					    TagsModule::URL_CATEGORY,
				    ],
			    ],
			    'placeholder' => __( 'Enter your URL', 'elementor' ) . ' (YouTube)',
			    'default' => 'https://www.youtube.com/embed/XHOmBV4js_E',
			    'label_block' => true,
			    'condition' => [
				    'video_type' => 'youtube',
			    ],
			    'frontend_available' => true,
		    ]
	    );

	    $this->add_control(
		    'hosted_url',
		    [
			    'label' => __( 'Choose File', 'elementor' ),
			    'type' => Controls_Manager::MEDIA,
			    'dynamic' => [
				    'active' => true,
				    'categories' => [
					    TagsModule::MEDIA_CATEGORY,
				    ],
			    ],
			    'media_type' => 'video',
			    'condition' => [
				    'video_type' => 'hosted',
			    ],
		    ]
	    );

	    $this->add_control(
		    'autoplay', [
			    'label'        => esc_html__('Autoplay', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_control(
		    'muted', [
			    'label'        => esc_html__('Muted', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_control(
		    'controls', [
			    'label'        => esc_html__('Controls', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'yes',
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_control(
		    'ratio',
		    [
			    'label' => __( 'Aspect Ratio', 'elementor' ),
			    'type' => Controls_Manager::SELECT,
			    'default' => '169',
			    'options' => [
				    '169' => __( '16:9', 'elementor' ),
				    '43' => __( '4:3', 'elementor' ),
				    '85' => __( '8:5', 'elementor' ),
				    '916' => __( '9:16', 'elementor' ),
				    '34' => __( '3:4', 'elementor' ),
				    '58' => __( '5:8', 'elementor' ),
			    ],
		    ]
	    );

        $this->end_controls_section();

        // Button
	    $this->start_controls_section(
		    'crust_icon_settings',
		    [
			    'label'     => esc_html__('Button', 'elementor'),
			    'tab'       => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'mode' => 'popup'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_icon_width',
		    [
			    'label'     => esc_html__('Width (px)', 'elementor'),
			    'type'      => Controls_Manager::NUMBER,
			    'selectors' => [
				    '{{WRAPPER}} .crust-play-video' => 'width: {{VALUE}}px;',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'button_icon_height',
		    [
			    'label'     => esc_html__('Height (px)', 'elementor'),
			    'type'      => Controls_Manager::NUMBER,
			    'selectors' => [
				    '{{WRAPPER}} .crust-play-video' => 'height: {{VALUE}}px;line-height: {{VALUE}}px;',
			    ]
		    ]
	    );

	    $this->start_controls_tabs('crust_button_icon_tabs');

	    $this->start_controls_tab('icon_normal', ['label' => esc_html__('Normal', 'elementor')]);

	    $this->add_responsive_control(
		    'button_icon_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-play-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_control(
		    'button_icon_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    '{{WRAPPER}} .crust-play-video .play-triangle'   => 'background-color: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_icon_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-play-video',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_border',
			    'selector' => '{{WRAPPER}} .crust-play-video',
		    ]
	    );

	    $this->add_responsive_control(
		    'button_icon_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-play-video' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'button_icon_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-play-video',
		    ]
	    );
		//////////////////////
	    $this->add_responsive_control(
		    'button_icon_normal_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'button_icon_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    'body.crust-dark {{WRAPPER}} .crust-play-video .play-triangle'   => 'background-color: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_icon_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-play-video',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-play-video',
		    ]
	    );
	    //////////////////////

	    $this->end_controls_tab();

	    $this->start_controls_tab('button_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'button_icon_hover_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    '{{WRAPPER}} .crust-play-video:hover .play-triangle'   => 'background-color: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_icon_hover_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-play-video:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_hover_border',
			    'selector' => '{{WRAPPER}} .crust-play-video:hover',
		    ]
	    );

	    $this->add_responsive_control(
		    'button_icon_border_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-play-video:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'button_icon_hover_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-play-video:hover',
		    ]
	    );

		//////////////////////////
	    $this->add_responsive_control(
		    'button_icon_hover_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'button_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors'  => [
				    'body.crust-dark {{WRAPPER}} .crust-play-video:hover .play-triangle'   => 'background-color: {{SIZE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'button_icon_hover_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-play-video:hover',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_icon_hover_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-play-video:hover',
		    ]
	    );
	    /// //////////////////////

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

	    // Button
	    $this->start_controls_section(
		    'crust_wrap_settings',
		    [
			    'label'     => esc_html__('Wrapper', 'elementor'),
			    'tab'       => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'wrap_width',
		    [
			    'label'     => esc_html__('Width', 'elementor'),
			    'type'      => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 2000,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				    '{{WRAPPER}} {{WRAPPER}} .crust-video-wrapper, {{WRAPPER}} .play-perspective, {{WRAPPER}} .play-triangle' => 'width: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'wrap_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-video-wrapper .crust-ext-player,{{WRAPPER}} .crust-video-wrapper video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'wrap_padding',
		    [
			    'label'      => esc_html__('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-video-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'wrap_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-video-wrapper',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'wrap_border',
			    'selector' => '{{WRAPPER}} .crust-video-wrapper',
		    ]
	    );

	    $this->add_responsive_control(
		    'wrap_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-video-wrapper,{{WRAPPER}} .crust-play-video .play-triangle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'wrap_shadow',
			    'selector' => '{{WRAPPER}} .crust-video-wrapper',
		    ]
	    );

///////////////////////////////////////////////////////////////////////////
	    $this->add_responsive_control(
		    'crust_wrap_dark_settings',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'wrap_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-video-wrapper',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'wrap_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-video-wrapper',
		    ]
	    );

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

	    $type = $settings['video_type'];
	    $auto = ( $settings['autoplay'] == 'yes' ) ? ' autoplay' : '';
	    $muted = ( $settings['muted'] == 'yes' ) ? ' muted' : '';
		$iframe_auto = ( $settings['autoplay'] == 'yes' ) ? 'autoplay=1' : '';
	    $class = 'crust-video-widget';
	    $class .= ' crust-ratio-' . $settings['ratio'];

	    $controls = ( $settings['controls'] == 'yes' ) ? ' controls' : '';

	    $output = '<div class="'.$class.'">';

		    $video = '<div class="crust-video-wrapper">';
			    if ( 'youtube' === $type ) {
				    $vid_ID = substr($settings['youtube_url'], strrpos($settings['youtube_url'], '/') + 1);
				    $video .= '<iframe class="crust-ext-player" src="'.esc_url($settings['youtube_url']).'?'.$iframe_auto.'&playlist='.$vid_ID.'&enablejsapi=0&loop=1&modestbranding=1" frameborder="0" allow="autoplay"></iframe>';
			    } else if ( 'hosted' === $settings['video_type'] ) {
				    $video .= '<video preload="metadata" loop '.$controls.$auto.$muted.' src="'.$settings['hosted_url']['url'].'"></video>';
			    }

		    $video .= '</div>';

		    if( $settings['mode'] == 'popup' ){
			    $output .= '<div class="crust-play-video">';
				    $output .= '<div class="play-perspective">';
					    $output .= '<button class="play-close"></button>';
					    $output .= '<div class="play-triangle">';
						    $output .= '<div class="play-video">';
						        $output .= $video;
						    $output .= '</div>';
					    $output .= '</div>';
				    $output .= '</div>';
			    $output .= '</div>';
		    } else {
			    $output .= $video;
		    }

	    $output .= '</div>';

	    echo $output;

    }

}
