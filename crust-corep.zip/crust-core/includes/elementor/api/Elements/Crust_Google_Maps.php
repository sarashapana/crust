<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;

class Crust_Google_Maps extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-google-maps';
    }

	public function get_script_depends()
	{
		return ['crust-google-maps'];
	}

	public function get_style_depends()
	{

		do_action('enqueue_crust_assets','crust-google-maps', true, false);
		return ['crust-google-maps'];

	}

    public function get_title()
    {
        return esc_html__('Google Maps', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-google-maps';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_gmaps_settings',
			[
				'label' => esc_html__('Settings', 'crust-core')
			]
		);

		$this->add_control(
			'api_key',
			[
				'label'       => esc_html__('API Key', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'zoom',
			[
				'label' => __( 'Zoom', 'elementor' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 10,
				'min' => 0,
				'step' => 1,
			]
		);

		$this->add_control(
			'type',
			[
				'label'     => esc_html__('Map Type', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'roadmap',
				'options'   => [
					'roadmap' => esc_html__('Road Map', 'crust-core'),
					'satellite' => esc_html__('Satellite', 'crust-core'),
					'hybrid' => esc_html__('Hybrid', 'crust-core'),
					'terrain' => esc_html__('Terrain', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'latitude',
			[
				'label'       => esc_html__('Latitude', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '51.508742'
			]
		);

		$this->add_control(
			'longitude',
			[
				'label'       => esc_html__('Longitude', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '-0.120850'
			]
		);

		$this->add_control(
			'address',
			[
				'label'       => esc_html__('Address', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'icon', [
				'label'       => esc_html__('Icon', 'crust-core'),
				'type'        => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'show_labels',
			[
				'label'        => __('Show Labels', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'zoom_control',
			[
				'label'        => __('Zoom Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'map_control',
			[
				'label'        => __('Map Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'scale_control',
			[
				'label'        => __('Scale Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'street_control',
			[
				'label'        => __('StreetView Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'rotate_control',
			[
				'label'        => __('Rotate Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'fullscreen_control',
			[
				'label'        => __('Fullscreen Control', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'return_value' => 'yes',
			]
		);




		$this->end_controls_section();

		/** Styling **/
		$this->start_controls_section(
			'crust_gmap_style_settings',
			[
				'label' => esc_html__('Container', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__('Height', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 2000,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-map-wrapper .crust-gmap'   => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_gmap_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-map-wrapper .crust-gmap',
			]
		);

		$this->add_control(
			'crust_gmap_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-map-wrapper .crust-gmap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_gmap_shadow',
				'selector' => '{{WRAPPER}} .crust-map-wrapper .crust-gmap',
			]
		);

		$this->add_responsive_control(
			'crust_gmap_style_dark_settings',
			[
				'label'      => esc_html__(' dark mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_gmap_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-map-wrapper .crust-gmap',
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'crust_gmap_colors',
			[
				'label' => esc_html__('Colors ', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'colors',
			[
				'label'     => esc_html__('Colors', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'' => esc_html__('Classic', 'crust-core'),
					'sliver' => esc_html__('Sliver', 'crust-core'),
					'dark' => esc_html__('Dark', 'crust-core'),
					'retro' => esc_html__('Retro', 'crust-core'),
					'custom' => esc_html__('Custom', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'map_txt_color',
			[
				'label'     => esc_html__('Text Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4f4f4f',
				'condition' => [
					'colors' => 'custom'
				]
			]
		);

		$this->add_control(
			'map_color',
			[
				'label'     => esc_html__('Water Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ff5b4a',
				'condition' => [
					'colors' => 'custom'
				]
			]
		);

		$this->add_control(
			'map_road_color',
			[
				'label'     => esc_html__('Road Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'condition' => [
					'colors' => 'custom'
				]
			]
		);

		$this->add_control(
			'map_bg_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f2f2f2',
				'condition' => [
					'colors' => 'custom'
				]
			]
		);

		$this->add_responsive_control(
			'crust_gmap_dark_colors',
			[
				'label'      => esc_html__(' dark mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);

		$this->add_control(
			'dark_colors',
			[
				'label'     => esc_html__('Colors', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'' => esc_html__('Classic', 'crust-core'),
					'sliver' => esc_html__('Sliver', 'crust-core'),
					'dark' => esc_html__('Dark', 'crust-core'),
					'retro' => esc_html__('Retro', 'crust-core'),
					'custom' => esc_html__('Custom', 'crust-core'),
				],
			]
		);





		$this->end_controls_section();
		
		$this->start_controls_section(
			'crust_gmap_address_style',
			[
				'label' => esc_html__('Address ', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_gmap_address_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .crust-map-location' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_gmap_address_typography',
				'selector' => '{{WRAPPER}} .crust-map-location',
			]
		);

		$this->add_responsive_control(
			'crust_gmap_address_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-map-location' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_gmap_address_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-map-location' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'gmap_address_width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 2000,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-map-location'   => 'width: {{SIZE}}{{UNIT}};margin-left: auto;margin-right: auto;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_gmap_address_bg',
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .crust-map-location',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_gmap_address_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-map-location',
			]
		);

		$this->add_control(
			'crust_gmap_address_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-map-location' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_gmap_address_shadow',
				'selector' => '{{WRAPPER}} .crust-map-location',
			]
		);

		$this->add_responsive_control(
			'crust_gmap_address_dark_style',
			[
				'label'      => esc_html__(' dark mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'crust_gmap_address_dark_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-map-location' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_gmap_address_dark_typography',
				'selector' => 'body.crust-dark  {{WRAPPER}} .crust-map-location',
			]
		);



		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_gmap_address_dark_bg',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark  {{WRAPPER}} .crust-map-location',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_gmap_address_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark  {{WRAPPER}} .crust-map-location',
			]
		);



		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		wp_enqueue_script('google-maps-api', 'https://maps.googleapis.com/maps/api/js?key='. $settings['api_key'] , ['jquery'], '', true );
		$icon = ( $settings['icon']['url'] ) ? $settings['icon']['url'] : '';

		$attributes = ( $settings['colors'] ) ? ' data-styles= "'.$settings['colors'].'"' : '';
		$attributes .= ( $settings['zoom'] ) ? ' data-zoom= "'.$settings['zoom'].'"' : '';
		$attributes .= ( $settings['latitude'] ) ? ' data-latitude= "'.$settings['latitude'].'"' : '';
		$attributes .= ( $settings['longitude'] ) ? ' data-longitude= "'.$settings['longitude'].'"' : '';
		$attributes .= ( $settings['address'] ) ? ' data-address= "'.$settings['address'].'"' : '';
		$attributes .= ( $icon ) ? ' data-icon= "'.$icon.'"' : ' data-icon= "'.CRUST_CORE_URI . '/assets/front/images/gmap-pin.png"';
		$attributes .= ( $settings['show_labels'] === 'yes' ) ? ' data-labels= "on"' : ' data-labels= "off"';
		$attributes .= ( $settings['zoom_control'] ) ? ' data-zoom-control= "'.$settings['zoom_control'].'"' : '';
		$attributes .= ( $settings['map_control'] ) ? ' data-map-control= "'.$settings['map_control'].'"' : '';
		$attributes .= ( $settings['scale_control'] ) ? ' data-scale-control= "'.$settings['scale_control'].'"' : '';
		$attributes .= ( $settings['street_control'] ) ? ' data-street-control= "'.$settings['street_control'].'"' : '';
		$attributes .= ( $settings['rotate_control'] ) ? ' data-rotate-control= "'.$settings['rotate_control'].'"' : '';
		$attributes .= ( $settings['fullscreen_control'] ) ? ' data-fullscreen-control= "'.$settings['fullscreen_control'].'"' : '';
		$attributes .= ( $settings['map_color'] ) ? ' data-color= "'.$settings['map_color'].'"' : '';
		$attributes .= ( $settings['map_bg_color'] ) ? ' data-bg-color= "'.$settings['map_bg_color'].'"' : '';
		$attributes .= ( $settings['map_txt_color'] ) ? ' data-txt-color= "'.$settings['map_txt_color'].'"' : '';
		$attributes .= ( $settings['map_road_color'] ) ? ' data-road-color= "'.$settings['map_road_color'].'"' : '';
		$attributes .= ( $settings['type'] ) ? ' data-type= "'.$settings['type'].'"' : '';

		$class = 'crust-map-wrapper';

		$html = '<div class="'.$class.'">';
			$html .= '<div class="crust-gmap"'.$attributes.'></div>';
			$html .= ( $settings['address'] ) ? '<div class="crust-map-location">'.esc_html__($settings['address']).'</div>' : '';
		$html .= '</div>';

		echo $html;

	}

}
