<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Team extends Widget_Base
{

	use \Crust_Core\Traits\Helper;

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-team', false, true);
		return ['crust-team'];
	}

	public function get_name()
	{
		return 'crust-team';
	}

	public function get_title()
	{
		return esc_html__('Team Member', 'crust-core');
	}

	public function get_icon()
	{
		return 'eicon-person';
	}

	public function get_categories()
	{
		return ['crust'];
	}


	protected function register_controls()
	{
		$this->start_controls_section(
			'crust_section_team_settings',
			[
				'label' => esc_html__('Settings', 'crust-core')
			]
		);

		$this->add_control(
			'crust_team_preset',
			[
				'label'   => esc_html__('Style', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'crust-team-classic',
				'options' => [
					'crust-team-classic'   => esc_html__('Classic', 'crust-core'),
					'crust-team-overlay'  => esc_html__('Overlay', 'crust-core'),
					'crust-team-modern'   => esc_html__('Modern', 'crust-core'),
					'crust-team-creative' => esc_html__('Creative', 'crust-core'),
				]
			]
		);

		$this->add_control(
			'crust_team_order',
			[
				'label'   => esc_html__('Order', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'img_title_content_icon',
				'options' => [
					'img_title_content_icon' => esc_html__('Image/Title/Content/Icons', 'crust-core'),
					'img_title_icon_content' => esc_html__('Image/Title/Icons/Content', 'crust-core'),
					'img_icon_title_content' => esc_html__('Image/Icons/Title/Content', 'crust-core'),
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-classic'
				]
			]
		);

		$this->add_control(
			'crust_team_image',
			[
				'label'   => __('Image', 'crust-core'),
				'type'    => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'crust_team_alt_image',
			[
				'label'   => __('Alternate Image', 'crust-core'),
				'type'    => Controls_Manager::MEDIA,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'thumbnail',
				'default'   => 'full',
				'condition' => [
					'crust_team_image[url]!' => '',
				],
			]
		);

		$this->add_control(
			'crust_team_name',
			[
				'label'   => esc_html__('Name', 'crust-core'),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__('Maverick Sosa', 'crust-core'),
			]
		);

		$this->add_control(
			'crust_team_link',
			[
				'label'         => esc_html__('Link', 'elementor'),
				'type'          => Controls_Manager::URL,
				'label_block'   => true,
				'show_external' => true,
			]
		);

		$this->add_control(
			'crust_team_job_title',
			[
				'label'   => esc_html__('Job Position', 'crust-core'),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__('Co-Founder', 'crust-core'),
			]
		);

		$this->add_control(
			'crust_team_description',
			[
				'label'   => esc_html__('Description', 'crust-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing.', 'crust-core'),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_team_social_profiles',
			[
				'label' => esc_html__('Social Profiles', 'crust-core')
			]
		);

		$this->add_control(
			'crust_team_enable_social_profiles',
			[
				'label'   => esc_html__('Display Social Profiles', 'crust-core'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'social_icon', [
				'label'            => esc_html__('Icon', 'elementor'),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'social',
				'default'          => [
					'value'   => 'fab fa-wordpress',
					'library' => 'fa-brands',
				],
			]
		);

		$repeater->add_control(
			'link', [
				'label'       => esc_html__('Link', 'elementor'),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				'default'     => [
					'url'         => '',
					'is_external' => 'true',
				],
				'placeholder' => esc_html__('Place URL here', 'crust-core'),
			]
		);

		$this->add_control(
			'crust_team_social_profile_links',
			[
				'type'        => Controls_Manager::REPEATER,
				'condition'   => [
					'crust_team_enable_social_profiles!' => '',
				],
				'default'     => [
					[
						'social_icon' => [
							'value'   => 'fab fa-facebook-f',
							'library' => 'fa-brands'
						]
					],
					[
						'social_icon' => [
							'value'   => 'fab fa-twitter',
							'library' => 'fa-brands'
						]
					],
					[
						'social_icon' => [
							'value'   => 'fab fa-instagram',
							'library' => 'fa-brands'
						]
					]
				],
				'fields'      => $repeater->get_controls(),
				'title_field' => '<i class="{{ social_icon.value }}"></i>',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_section_team_style',
			[
				'label' => esc_html__('Box Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_team_tilt',
			[
				'label'        => esc_html__('Tilt Effect', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__('Yes', 'crust-core'),
				'label_off'    => esc_html__('No', 'crust-core'),
				'return_value' => 'yes',
				'condition'  => [
					'crust_team_preset' => 'crust-team-overlay'
				]
			]
		);

		$this->add_responsive_control(
			'crust_team_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-item-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('crust_team_tabs');

		$this->start_controls_tab('crust_team_normal', ['label' => esc_html__('Normal', 'elementor')]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-item-inner',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-team-item .crust-team-item-inner',
			]
		);

		$this->add_control(
			'crust_team_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-item-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-item-inner',
			]
		);
		/**
		 * ----------------------------
		 *start box dark style normal
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_dark_normal_style',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_dark_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-item-inner',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-item-inner',
			]
		);
		/**
		 * ----------------------------
		 *end box dark style normal
		 * ---------------------------
		 */

		$this->end_controls_tab();

		$this->start_controls_tab('crust_team_hover', ['label' => esc_html__('Hover', 'elementor')]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_hover_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .crust-team-item:hover .crust-team-item-inner',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_hover_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-team-item:hover .crust-team-item-inner',
			]
		);

		$this->add_control(
			'crust_team_border_hover_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-item-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'crust_team_border_hover_margin',
			[
				'label'     => esc_html__('Margin Top', 'crust-core'),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-item-inner' => 'transform: translateY({{VALUE}}px);',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_hover_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-item:hover .crust-team-item-inner',
			]
		);
		/**
		 * ----------------------------
		 *start box dark style hover
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_dark_hover_style',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_hover_dark_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-item-inner',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_hover_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-item-inner',
			]
		);
		/**
		 * ----------------------------
		 *end box dark style hover
		 * ---------------------------
		 */

		$this->end_controls_tab();


		$this->end_controls_tabs();

		$this->add_control(
			'divider_base_color',
			[
				'label'     => esc_html__('Divider Base Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item.crust-team-modern svg.crust-divider .crust-base-fill' => 'fill: {{VALUE}};',
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-modern'
				]
			]
		);

		$this->add_control(
			'crust_team_divider_color',
			[
				'label'     => esc_html__('Divider Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item.crust-team-modern svg.crust-divider .crust-div-1-bottom' => 'fill: {{VALUE}};',
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-modern'
				]
			]
		);

		$this->add_control(
			'crust_team_divider_height',
			[
				'label'     => esc_html__('Divider Height', 'elementor'),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item.crust-team-modern svg.crust-divider' => 'height: {{VALUE}}px;max-height: {{VALUE}}px;margin-top: -{{VALUE}}px;',
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-modern'
				]
			]
		);

		/**
		 * ----------------------
		 *start divider dark color
		 * -----------------------
		 */
		$this->add_control(
			'divider_base_dark_color',
			[
				'label'     => esc_html__('Divider Base Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item.crust-team-modern svg.crust-divider .crust-base-fill' => 'fill: {{VALUE}};',
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-modern'
				]
			]
		);

		$this->add_control(
			'crust_team_divider_dark_color',
			[
				'label'     => esc_html__('Divider Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item.crust-team-modern svg.crust-divider .crust-div-1-bottom' => 'fill: {{VALUE}};',
				],
				'condition'  => [
					'crust_team_preset' => 'crust-team-modern'
				]
			]
		);
		/**
		 * ----------------------
		 *end divider dark color
		 * -----------------------
		 */

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_section_team_image_styles',
			[
				'label' => esc_html__('Member Image Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'crust_team_image_width',
			[
				'label'      => esc_html__('Image Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => 100,
					'unit' => '%',
				],
				'range'      => [
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'size_units' => ['%', 'px'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item figure img' => 'width:{{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'crust_team_preset!' => 'crust-team-circle'
				]
			]
		);

		$this->add_control(
			'crust_team_image_alignment',
			[
				'label'        => esc_html__('Alignment', 'elementor'),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
					'left'     => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'right'    => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item figure' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_image_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_image_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_image_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-team-item .crust-team-image',
			]
		);

		$this->add_control(
			'crust_team_circle_color',
			[
				'label'     => esc_html__('Circle Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'crust_team_preset' => 'crust-team-creative'
				],
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-creative-team-bg .crust-team-circle' => 'stroke: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_image_animate',
			[
				'label'        => __('Animate On Hover', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
			]
		);

		$this->add_control(
			'crust_team_image_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_image_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-image',
			]
		);

		/**
		 * ----------------------------
		 *start img style
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_image_dark_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,

			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_image_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-image',
			]
		);

		$this->add_control(
			'crust_team_circle_dark_color',
			[
				'label'     => esc_html__('Circle Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'crust_team_preset' => 'crust-team-creative'
				],
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-creative-team-bg .crust-team-circle' => 'stroke: {{VALUE}};',
				],
			]
		);
		/**
		 * ----------------------------
		 *end img style
		 * ---------------------------
		 */

		$this->add_control(
			'crust_section_overlay',
			[
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'label'     => __('Overlay', 'crust-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_overlay_background',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-image:after',
			]
		);
		/**
		 * ----------------------------
		 *start overlay style
		 * ---------------------------
		 */
		$this->add_responsive_control(
			'crust_section_team_overlay_dark_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_overlay_dark_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-image:after',

			]
		);
		/**
		 * ----------------------------
		 *end overlay style
		 * ---------------------------
		 */

		$this->add_control(
			'crust_section_overlay_hover',
			[
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'label'     => __('Overlay Hover', 'crust-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_hover_overlay_background',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-team-item:hover .crust-team-image:after',
			]
		);

		$this->crust_animations( 'team_image' );
		/**
		 * ----------------------------
		 *start overlay hover style
		 * ---------------------------
		 */
		$this->add_responsive_control(
			'crust_section_team_overlay_hover_dark_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_hover_overlay_dark_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-image:after',
			]
		);
		/**
		 * ----------------------------
		 *end overlay hover style
		 * ---------------------------
		 */

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_section_team_members_typography',
			[
				'label' => esc_html__('Title & Position', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_team_name_heading',
			[
				'label' => __('Name', 'crust-core'),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'crust_team_visible_name',
			[
				'label'        => __('Always Visible', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'condition' => [
					'crust_team_preset' => 'crust-team-overlay'
				]
			]
		);

		$this->add_control(
			'crust_team_name_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'h5',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'crust_team_name_alignment',
			[
				'label'        => esc_html__('Alignment', 'elementor'),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [

					'flex-start'     => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'    => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-name' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-name,{{WRAPPER}} .crust-team-item .crust-team-name a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_bg_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-name' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-name' => 'color: {{VALUE}};',
					'{{WRAPPER}} .crust-team-item:hover .crust-team-name a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_hover_bg_color',
			[
				'label'     => esc_html__('Hover BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-name' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_team_name_typography',
				'selector' => '{{WRAPPER}} .crust-team-item .crust-team-name',
			]
		);

		$this->add_responsive_control(
			'crust_team_name_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_name_hover_margin',
			[
				'label'      => esc_html__('Hover Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_name_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_name_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-name' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_name_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-name',
			]
		);

		$this->add_control(
			'crust_team_name_hover_shad',
			[
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'label'     => __('Hover', 'crust-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_team_name_hover_shadow',
				'selector' => '{{WRAPPER}} .crust-team-item:hover .crust-team-name',
			]
		);

		$this->crust_animations( 'team_name' );

		$this->add_control(
			'crust_team_position_heading',
			[
				'label'     => __('Job Position', 'crust-core'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before'
			]
		);

		$this->add_control(
			'crust_team_visible_position',
			[
				'label'        => __('Always Visible', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'condition' => [
					'crust_team_preset' => 'crust-team-overlay'
				]
			]
		);

		$this->add_control(
			'crust_team_position_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'h6',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'crust_team_position_alignment',
			[
				'label'        => esc_html__('Alignment', 'elementor'),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
					'flex-start'     => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'    => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-position' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-position span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_bg_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-position span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-position span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_hover_bg_color',
			[
				'label'     => esc_html__('Hover BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-position span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_team_position_typography',
				'selector' => '{{WRAPPER}} .crust-team-item .crust-team-position span',
			]
		);

		$this->add_responsive_control(
			'crust_team_position_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-position span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_position_hover_margin',
			[
				'label'      => esc_html__('Hover Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-position span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_position_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-position span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_position_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-position span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_position_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-position span',
			]
		);

		$this->add_control(
			'crust_team_position_hover_shad',
			[
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'label'     => __('Hover', 'crust-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_team_position_hover_shadow',
				'selector' => '{{WRAPPER}} .crust-team-item:hover .crust-team-position span',
			]
		);

		$this->crust_animations( 'team_position' );
		/**
		 * ----------------------------
		 *start section team member typography dark
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_members_dark_typography',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_team_name_dark_color',
			[
				'label'     => esc_html__('Name Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-name,body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-name a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_bg_dark_color',
			[
				'label'     => esc_html__('Name Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-name' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_hover_dark_color',
			[
				'label'     => esc_html__('Name Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-name' => 'color: {{VALUE}};',
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-name a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_name_hover_bg_dark_color',
			[
				'label'     => esc_html__('Name Hover BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-name' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'crust_team_position_dark_color',
			[
				'label'     => esc_html__('Job Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-position span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_bg_dark_color',
			[
				'label'     => esc_html__('Job Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-position span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_hover_dark_color',
			[
				'label'     => esc_html__('Job Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-position span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_position_hover_bg_dark_color',
			[
				'label'     => esc_html__('Job Hover BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-position span' => 'background-color: {{VALUE}};',
				],
			]
		);

		/**
		 * ----------------------------
		 *end section team member typography dark
		 * ---------------------------
		 */

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_section_team_members_styles_general',
			[
				'label' => esc_html__('Content', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_team_visible_desc',
			[
				'label'        => __('Always Visible', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'condition' => [
					'crust_team_preset' => 'crust-team-overlay'
				]
			]
		);

		$this->add_control(
			'crust_team_description_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-content .crust-team-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_description_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item:hover .crust-team-content .crust-team-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_team_description_typography',
				'selector' => '{{WRAPPER}} .crust-team-item .crust-team-content .crust-team-text',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_content_background',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-team-item .crust-team-content-inner',
			]
		);

		$this->add_control(
			'crust_team_content_alignment',
			[
				'label'        => esc_html__('Alignment', 'elementor'),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
					'left'     => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'right'    => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-content-inner' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_content_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-content-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_content_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-content-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_content_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-content-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_text_margin',
			[
				'label'      => esc_html__('Text Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_text_padding',
			[
				'label'      => esc_html__('Text Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-item .crust-team-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->crust_animations( 'team_content' );
		/**
		 * ----------------------------
		 *start section team member general dark
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_content_dark_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_team_description_dark_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-content .crust-team-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_description_hover_dark_color',
			[
				'label'     => esc_html__('Hover Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item:hover .crust-team-content .crust-team-text' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_team_content_dark_background',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-content-inner',
			]
		);
		/**
		 * ----------------------------
		 *end section team member general dark
		 * ---------------------------
		 */

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_section_team_members_social_profiles_styles',
			[
				'label' => esc_html__('Social Profiles', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_team_visible_socials',
			[
				'label'        => __('Always Visible', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Yes', 'crust-core'),
				'label_off'    => __('No', 'crust-core'),
				'condition' => [
					'crust_team_preset' => 'crust-team-overlay'
				]
			]
		);

		$this->add_control(
			'crust_team_socials_alignment',
			[
				'label'        => esc_html__('Alignment', 'elementor'),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
					'flex-start'     => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'    => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-social-profiles' => 'align-self: {{VALUE}};justify-content: {{VALUE}};',
				],

			]
		);

		$this->add_responsive_control(
			'crust_team_social_profiles_padding',
			[
				'label'      => esc_html__('Container Margin', 'crust-core'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-social-profiles' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_wrap_icon_background',
			[
				'label'     => esc_html__('Container BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-profiles' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'label'    => esc_html__('Container Border', 'elementor'),
				'name'     => 'crust_team_social_wrap_icon_border',
				'selector' => '{{WRAPPER}} .crust-team-social-profiles',
			]
		);

		$this->add_control(
			'crust_team_social_wrap_icon_border_radius',
			[
				'label'     => esc_html__('Container Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-profiles' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'label'     => esc_html__('Container Box Shadow', 'elementor'),
				'name'      => 'crust_team_social_wrap_icon_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-social-profiles',
			]
		);

		$this->add_control(
			'crust_team_social_icon_size',
			[
				'label'     => esc_html__('Icon Width', 'crust-core'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default'   => [
					'size' => 30,
					'unit' => 'px'
				],
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a'   => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_font',
			[
				'label'     => esc_html__('Font Size', 'crust-core'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default'   => [
					'size' => 15,
					'unit' => 'px'
				],
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .crust-team-social-link > a img' => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'crust_team_social_icons_margin',
			[
				'label'      => esc_html__('Icon Margin', 'crust-core'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .crust-team-content .crust-team-social-profiles li.crust-team-social-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		/**
		 * ----------------------------
		 *start section social profiles dark
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_section_team_social_profiles_dark_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,


			]
		);


		$this->add_control(
			'crust_team_social_wrap_icon_dark_background',
			[
				'label'     => esc_html__('Container BG Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-social-profiles' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_social_profiles_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-team-social-link > a',
			]
		);

		/**
		 * ----------------------------
		 *end section social profiles dark
		 * ---------------------------
		 */

		$this->add_control(
			'crust_team_social_icon_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a i' => 'color: {{VALUE}};',

				],
			]
		);
		$this->start_controls_tabs('crust_team_social_icons_style_tabs');

		$this->start_controls_tab('normal', ['label' => esc_html__('Normal', 'elementor')]);

		$this->add_control(
			'crust_team_social_normal_icon_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a i' => 'color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_background',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_social_icon_border',
				'selector' => '{{WRAPPER}} .crust-team-social-link > a',
			]
		);

		$this->add_control(
			'crust_team_social_icon_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_social_icon_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-social-link > a',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_team_social_icon_typography',
				'selector' => '{{WRAPPER}} .crust-team-social-link > a',
			]
		);
		/**
		 * ----------------------------
		 *start section team member social dark normal
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_team_social_icons_style_dark_normal_tabs',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);

		$this->add_control(
			'crust_team_social_icon_dark_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-social-link > a i' => 'color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_dark_background',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-social-link > a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_team_social_icon_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-team-social-link > a',
			]
		);


		/**
		 * ----------------------------
		 *end section team member social dark normal
		 * ---------------------------
		 */
		$this->end_controls_tab();

		$this->start_controls_tab('crust_team_social_icon_hover', ['label' => esc_html__('Hover', 'elementor')]);

		$this->add_control(
			'crust_team_social_icon_hover_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-social-profiles li a:hover,{{WRAPPER}} .crust-team-item .crust-team-social-profiles li a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_background',
			[
				'label'     => esc_html__('Background Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-team-item .crust-team-social-link > a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-team-social-link > a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_team_social_icon_hover_shadow',
				'selector'  => '{{WRAPPER}} .crust-team-social-link > a:hover',
			]
		);
		/**
		 * ----------------------------
		 *start section team member social dark hover
		 * ---------------------------
		 */

		$this->add_responsive_control(
			'crust_team_social_icons_style_dark_hover_tabs',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_dark_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-social-profiles li a:hover,{{WRAPPER}} .crust-team-item .crust-team-social-profiles li a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_dark_background',
			[
				'label'     => esc_html__('Background Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-item .crust-team-social-link > a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_team_social_icon_hover_border_dark_color',
			[
				'label'     => esc_html__('Border Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-team-social-link > a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);


		/**
		 * ----------------------------
		 *end section team member social dark hover
		 * ---------------------------
		 */




		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->crust_animations( 'team_social' );

		$this->end_controls_section();

	}


	protected function render()
	{
		$settings          = $this->get_settings_for_display();
		$style             = $settings['crust_team_preset'];

		$team_member_image = $this->get_settings('crust_team_image');
		$team_alt_image    = $this->get_settings('crust_team_alt_image');
		$img_animate       = ( $settings['crust_team_image_animate'] ) ? ' animate-img' : '';

		$vis_name = $settings['crust_team_visible_name'];
		$vis_pos = $settings['crust_team_visible_position'];
		$vis_dsc = $settings['crust_team_visible_desc'];
		$vis_soc = $settings['crust_team_visible_socials'];

		$this->add_render_attribute('team_image', 'class', ['crust-team-image', esc_attr($img_animate)] );
		$this->crust_animation_attributes( 'team_image' );

		$team_member_image_url = Group_Control_Image_Size::get_attachment_image_src($team_member_image['id'], 'thumbnail', $settings);
		if (empty($team_member_image_url)) {
			$team_member_image_url = $team_member_image['url'];
		} else{
			$team_member_image_url = $team_member_image_url;
		}

		$team_alt_image_url = Group_Control_Image_Size::get_attachment_image_src($team_alt_image['id'], 'thumbnail', $settings);
		if (empty($team_alt_image_url)) {
			$team_alt_image_url = $team_alt_image['url'];
		} else{
			$team_alt_image_url = $team_alt_image_url;
		}

		$team_member_classes = $this->get_settings('crust_team_preset') . " " . $this->get_settings('crust_team_image_rounded');
		$team_member_classes .= ( $settings['crust_team_alt_image']['url'] !== '' ) ? ' crust-team-has-alt' : '';
		$team_member_classes .= ( $settings['crust_team_enable_social_profiles'] != 'yes' ) ? ' crust-no-team-socials' : '';
		$team_member_classes .= ( 'yes' === $vis_name ) ? ' visible-name' : '';
		$team_member_classes .= ( 'yes' === $vis_pos ) ? ' visible-position' : '';
		$team_member_classes .= ( 'yes' === $vis_dsc ) ? ' visible-desc' : '';
		$team_member_classes .= ( 'yes' === $vis_soc ) ? ' visible-socials' : '';

		$inner_team = 'crust-team-item-inner';
		$inner_team .= ( $settings['crust_team_tilt'] === 'yes' ) ? ' js-tilt' : '';

		$this->add_render_attribute('team_position', 'class', 'crust-team-position' );
		$this->crust_animation_attributes( 'team_position' );

		$this->add_render_attribute('team_content', 'class', 'crust-team-text' );
		$this->crust_animation_attributes( 'team_content' );

		$svg = '<svg class="crust-divider crust-divider-style1 crust-horizontal-flip" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 199" preserveAspectRatio="none"><path class="crust-base-fill" d="M-0.1-0.1l1920,199.9H-0.1V-0.1z"></path><g><path class="crust-div-1-bottom" d="M0,0l937,97.6L0.2,199.9L0,0z"></path></g></svg>';

		$html = '<div id="crust-team-'. esc_attr($this->get_id()) .'" class="crust-team-item '. $team_member_classes .'">';
		$html .= '<div class="'.esc_attr($inner_team).'">';
		$html .= '<div '.$this->get_render_attribute_string('team_image').'>';
		if( $style === 'crust-team-creative' ){
			$html .= '<svg class="crust-creative-team-bg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 350"><g class="crust-team-circle"><circle cx="175" cy="175" r="175" stroke="none"/><circle cx="175" cy="175" r="165" fill="none"/></g></svg>';
		}

		if( $style === 'crust-team-modern' ){
			$html .= '<div class="crust-team-modern-name-wrap">';
			$html .= $this->_team_name($settings);
			$html .= $this->_team_position($settings);
			$html .= '</div>';
			$html .= $this->_social_icons();
		}
		$html .= '<figure>';
		$html .= '<img src="'. esc_url($team_member_image_url) .'" alt="'. esc_attr(get_post_meta($team_member_image['id'], '_wp_attachment_image_alt', true)) .'">';
		$html .= ( $team_alt_image_url ) ? '<div class="crust-alt-team-img"><img src="'. esc_url($team_alt_image_url) .'" alt="'. esc_attr(get_post_meta($team_alt_image['id'], '_wp_attachment_image_alt', true)) .'"></div>' : '';
		$html .= '</figure>';

		if( $style === 'crust-team-creative' ) {
			$html .= '<div class="crust-creative-team-name">';
			$html .= $this->_team_name($settings);
			$html .= $this->_team_position($settings);
			$html .= '</div>';
		}

		$html .= ( $style === 'crust-team-modern' ) ? $svg : '';
		$html .= '</div>';

		if( $style !== 'crust-team-modern' ) {
			$html .= '<div class="crust-team-content">';
			$html .= '<div class="crust-team-content-inner">';

			if ( $style === 'crust-team-creative' ) {

				$html .= $this->_social_icons();
				$html .= ( $settings['crust_team_description'] ) ? '<div ' . $this->get_render_attribute_string( 'team_content' ) . '>' . $settings['crust_team_description'] . '</div>' : '';

			} else if ( $style === 'crust-team-classic' ) {
				if ( $settings['crust_team_order'] === 'img_title_icon_content' ) {

					$html .= $this->_team_name( $settings );
					$html .= $this->_team_position( $settings );
					$html .= $this->_social_icons();
					$html .= ( $settings['crust_team_description'] ) ? '<div ' . $this->get_render_attribute_string( 'team_content' ) . '>' . $settings['crust_team_description'] . '</div>' : '';

				} elseif ( $settings['crust_team_order'] === 'img_title_content_icon' ) {

					$html .= $this->_team_name( $settings );
					$html .= $this->_team_position( $settings );
					$html .= ( $settings['crust_team_description'] ) ? '<div ' . $this->get_render_attribute_string( 'team_content' ) . '>' . $settings['crust_team_description'] . '</div>' : '';
					$html .= $this->_social_icons();

				} else {

					$html .= $this->_social_icons();
					$html .= $this->_team_name( $settings );
					$html .= $this->_team_position( $settings );
					$html .= ( $settings['crust_team_description'] ) ? '<div ' . $this->get_render_attribute_string( 'team_content' ) . '>' . $settings['crust_team_description'] . '</div>' : '';

				}

			} else if ( $style === 'crust-team-modern' ) {

			} else {

				$html .= $this->_team_name( $settings );
				$html .= $this->_team_position( $settings );
				$html .= ( $settings['crust_team_description'] ) ? '<div ' . $this->get_render_attribute_string( 'team_content' ) . '>' . $settings['crust_team_description'] . '</div>' : '';
				$html .= $this->_social_icons();

			}
			$html .= '</div>';
			$html .= '</div>';
		}
		$html .= '</div>';
		$html .= '</div>';

		echo $html;

	}

	protected function _team_name($settings){

		$target   = $settings['crust_team_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['crust_team_link']['nofollow'] ? ' rel="nofollow"' : '';
		$name_tag = $settings['crust_team_name_tag'];

		$this->add_render_attribute('team_name', 'class', 'crust-team-name' );
		$this->crust_animation_attributes( 'team_name' );

		if ( '' != $settings['crust_team_name'] ){
			$html = '<'.$name_tag.' '.$this->get_render_attribute_string('team_name').'>';
			$html .= ('' != $settings['crust_team_link']['url']) ? '<a href="'.esc_url($settings['crust_team_link']['url']).'"'.$target.$nofollow.'>' : '';
			$html .= $settings['crust_team_name'];
			$html .= ('' != $settings['crust_team_link']['url']) ? '</a>' : '';
			$html .= '</'.$name_tag.'>';
			return $html;
		}

	}

	protected function _team_position($settings){

		$pos_tag = $settings['crust_team_position_tag'];
		return '<'.$pos_tag.' '.$this->get_render_attribute_string('team_position').'><span>'. $settings['crust_team_job_title'] .'</span></'.$pos_tag.'>';

	}

	protected function _social_icons()
	{

		$settings = $this->get_settings_for_display();
		$html     = '';

		$this->add_render_attribute('team_social', 'class', 'crust-team-social-profiles' );
		$this->crust_animation_attributes( 'team_social' );

		if ( ! empty($settings['crust_team_enable_social_profiles'])) {
			$html .= '<ul '.$this->get_render_attribute_string('team_social').'>';
			foreach ($settings['crust_team_social_profile_links'] as $item) {
				if ( ! empty($item['social_icon'])) {
					$target = $item['link']['is_external'] ? ' target="_blank"' : '';
					$html .= '<li class="crust-team-social-link">';
					$html .= '<a href="'. esc_attr($item['link']['url']) .'" '. $target .'>';
					if (isset($item['social_icon']['value']['url'])) {
						$html .= '<img src="'. esc_attr($item['social']['value']['url']) .'" alt="'. esc_attr(get_post_meta($item['social']['value']['id'], '_wp_attachment_image_alt', true)) .'"/>';
					} else {
						$html .= '<i class="'. esc_attr($item['social_icon']['value']) .'"></i>';
					}
					$html .= '</a>';
					$html .= '</li>';
				}
			}
			$html .= '</ul>';
		}

		return $html;

	}

}
