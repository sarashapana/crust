<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use Elementor\Plugin;
use \Elementor\Widget_Base;

class Crust_Notification_Bar extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-notification-bar';
    }

	public function get_script_depends()
	{
		return ['crust-notification-bar'];
	}

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-notification-bar', true, true);
		return ['crust-notification-bar'];
	}

    public function get_title()
    {
        return esc_html__('Notification Bar', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-posts-ticker';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_note_bar_settings',
			[
				'label' => esc_html__('Content Settings', 'crust-core')
			]
		);

		$this->add_control(
			'type',
			[
				'label'     => esc_html__('Type', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'primary',
				'options'   => [
					'primary' => esc_html__('Primary', 'crust-core'),
					'secondary' => esc_html__('Secondary', 'crust-core'),
					'success' => esc_html__('Success', 'crust-core'),
					'danger' => esc_html__('Danger', 'crust-core'),
					'info' => esc_html__('Info', 'crust-core'),
					'warning' => esc_html__('Warning', 'crust-core'),
					'light' => esc_html__('Light', 'crust-core'),
					'dark' => esc_html__('Dark', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'crust_note_bar_align',
			[
				'label'       => esc_html__('Horizontal Align', 'elementor'),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'note-bar-left' => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'fa fa-align-left',
					],
					'note-bar-center'     => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'fa fa-align-center',
					],
					'note-bar-right'   => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'     => 'note-bar-left',
			]
		);

		$this->add_responsive_control(
			'icon_vertical_align',
			[
				'label'       => __('Vertical Align', 'crust-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'      => [
					'flex-start'    => [
						'title' => __('Top', 'crust-core'),
						'icon'  => 'eicon-v-align-top',
					],
					'center' => [
						'title' => __('Middle', 'crust-core'),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => __('Bottom', 'crust-core'),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors'            => [
					'{{WRAPPER}} .crust-note-bar' => 'align-items: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'crust_note_bar_content_type',
			[
				'label'   => __('Content Type', 'crust-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'content'  => __('Content', 'crust-core'),
					'template' => __('Saved Templates', 'crust-core'),
				],
				'default' => 'content',
			]
		);

		$this->add_control(
			'crust_note_bar_templates',
			[
				'label'     => __('Choose Template', 'crust-core'),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->crust_core_get_page_templates(),
				'condition' => [
					'crust_note_bar_content_type' => 'template',
				],
			]
		);
		
		$this->add_control(
			'crust_note_bar_content',
			[
				'label'       => esc_html__('Content', 'crust-core'),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'default'     => esc_html__('We offer awesome designs with huge availabilities that help you create unlimited websites.', 'crust-core'),
				'separator'   => 'after',
				'condition' => [
					'crust_note_bar_content_type' => 'content',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_show_button',
			[
				'label'     => esc_html__('Show Button', 'crust-core'),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => __('yes', 'crust-core'),
				'label_off' => __('no', 'crust-core'),
				'default'   => 'yes'
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cookies_section',
			[
				'label' => esc_html__('Cookies', 'crust-core'),
			]
		);

		$this->add_control(
			'use_cookies',
			[
				'label'     => esc_html__('Enable Cookies', 'crust-core'),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => __('yes', 'crust-core'),
				'label_off' => __('no', 'crust-core'),
			]
		);

		$this->add_control(
			'cookie_name',
			[
				'label'       => esc_html__('Cookies Name ( Must be Unique )', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
				'condition'   => [
					'use_cookies' => 'yes'
				]
			]
		);

		$this->add_control(
			'expires',
			[
				'label' => __( 'Expires days', 'elementor' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 10,
				'min' => 0,
				'step' => 1,
				'condition'   => [
					'use_cookies' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_note_bar',
			[
				'label' => esc_html__('Button', 'crust-core'),
				'condition'   => [
					'crust_note_bar_show_button' => 'yes'
				]
			]
		);

		$this->add_control(
			'crust_note_bar_btn_text',
			[
				'label'       => esc_html__('Button Text', 'crust-core'),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__('Join us Now', 'crust-core'),
				'condition'   => [
					'crust_note_bar_show_button' => 'yes'
				]
			]
		);

		$this->add_control(
			'crust_note_bar_btn_link',
			[
				'label'         => esc_html__('Button Link', 'crust-core'),
				'type'          => Controls_Manager::URL,
				'label_block'   => true,
				'default'       => [
					'url'         => '#',
					'is_external' => '',
				],
				'show_external' => true,
				'condition'   => [
					'crust_note_bar_show_button' => 'yes'
				]
			]
		);

		$this->add_control(
			'crust_note_bar_use_button_icon',
			[
				'label'     => esc_html__('Use Icon', 'crust-core'),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => __('yes', 'crust-core'),
				'label_off' => __('no', 'crust-core'),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'crust_note_bar_button_icon',
			[
				'label'            => esc_html__('Icon', 'elementor'),
				'type'             => Controls_Manager::ICONS,
				'default'          => [
					'value'   => 'fad fa-bell',
					'library' => 'duotone',
				],
				'condition'   => [
					'crust_note_bar_use_button_icon' => 'yes'
				]
			]
		);

		$this->add_control(
			'crust_note_bar_button_icon_alignment',
			[
				'label'     => esc_html__('Icon Position', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'left',
				'options'   => [
					'left'  => esc_html__('Before', 'crust-core'),
					'right' => esc_html__('After', 'crust-core'),
				],
				'condition' => [
					'crust_note_bar_button_icon[value]!' => '',
					'crust_note_bar_use_button_icon' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_button_icon_size',
			[
				'label'      => esc_html__('Size', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'rem', 'em'],
				'default'    => [
					'size' => '',
					'unit' => 'rem',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'condition' => [
					'crust_note_bar_button_icon[value]!' => '',
					'crust_note_bar_use_button_icon' => 'yes'
				],
				'selectors'  => [
					'{{WRAPPER}} i.crust-btn-icon'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} img.crust-btn-icon' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		/** Styling **/
		$this->start_controls_section(
			'crust_note_bar_style_settings',
			[
				'label' => esc_html__('Container', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label'      => esc_html__('Width', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 2000,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-note-bar'   => 'width: {{SIZE}}{{UNIT}};margin-left: auto;margin-right: auto;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_note_bar_bg',
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .crust-note-bar',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_note_bar_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-note-bar',
			]
		);

		$this->add_control(
			'crust_note_bar_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_note_bar_shadow',
				'selector' => '{{WRAPPER}} .crust-note-bar',
			]
		);
		/**
		 *-------------------------------
		 *start container dark
		 *-------------------------------
		 **/
		$this->add_responsive_control(
			'crust_note_bar_style_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_note_bar_dark_bg',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-note-bar',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_note_bar_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-note-bar',
			]
		);


		/**
		 *-------------------------------
		 *end container dark
		 *-------------------------------
		 **/


		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Button Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
			'crust_note_bar_close_btn_styles',
			[
				'label' => esc_html__('Close Button', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_close_btn_size',
			[
				'label'     => __('Size', 'crust-core'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 10,
						'max'  => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .crust-close-note-bar' => 'width: {{SIZE}}px;height: {{SIZE}}px;line-height: {{SIZE}}px;',
				]
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_close_btn_font_size',
			[
				'label'     => __('Font Size', 'crust-core'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 10,
						'max'  => 500,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .crust-close-note-bar' => 'font-size: {{SIZE}}px;',
				]
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_close_btn_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-close-note-bar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_close_btn_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-close-note-bar' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_note_bar_close_btn_bg',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => '{{WRAPPER}} .crust-close-note-bar',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_note_bar_close_btn_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-close-note-bar'
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_close_btn_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-close-note-bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'crust_note_bar_close_btn_shadow',
				'selector' => '{{WRAPPER}} .crust-infobox .infobox-icon-wrap',
			]
		);

		/**
		 *-------------------------------
		 *start close button dark
		 *-------------------------------
		 **/
		$this->add_responsive_control(
			'crust_note_bar_close_btn_dark_style',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_note_bar_close_btn_dark_color',
			[
				'label'     => esc_html__('Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-close-note-bar' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_note_bar_close_btn_dark_bg',
				'types'     => ['classic', 'gradient'],
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-close-note-bar',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_note_bar_close_btn_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-close-note-bar'
			]
		);

		/**
		 *-------------------------------
		 *end close button dark
		 *-------------------------------
		 **/

		$this->end_controls_section();
		
		$this->start_controls_section(
			'crust_note_bar_content_style',
			[
				'label' => esc_html__('Content Style ', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'crust_note_bar_content_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-note-bar-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_note_bar_content_typography',
				'selector' => '{{WRAPPER}} .crust-note-bar .crust-note-bar-text',
			]
		);

		/**
		 *-------------------------------
		 *start content dark
		 *-------------------------------
		 **/
		$this->add_responsive_control(
			'crust_note_bar_content_dark_style',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_note_bar_content_dark_color',
			[
				'label'     => esc_html__('Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-note-bar-text' => 'color: {{VALUE}};',
				],
			]
		);

		/**
		 *-------------------------------
		 *end content dark
		 *-------------------------------
		 **/

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Button Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
			'crust_note_bar_btn_styles',
			[
				'label' => esc_html__('Button Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'crust_note_bar_show_button' => 'yes'
				]
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_btn_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-note-bar .crust-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_btn_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-note-bar .crust-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'crust_note_bar_btn_typography',
				'selector' => '{{WRAPPER}} .crust-note-bar .crust-btn',
			]
		);

		$this->add_responsive_control(
			'crust_note_bar_btn_icon_margin',
			[
				'label'      => esc_html__('Icon Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} i.crust-btn-icon'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} img.crust-btn-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('crust_note_bar_button_tabs');

		// Normal State Tab
		$this->start_controls_tab('crust_note_bar_btn_normal', ['label' => esc_html__('Normal', 'elementor')]);

		$this->add_control(
			'crust_note_bar_btn_normal_text_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn' => 'color: {{VALUE}};',
				],
				'default'   => '#fff'
			]
		);

		$this->add_control(
			'crust_note_bar_btn_normal_bg_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#19D0D6',
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_cat_btn_normal_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-note-bar .crust-btn',
			]
		);

		$this->add_control(
			'crust_note_bar_btn_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_note_bar_button_shadow',
				'selector'  => '{{WRAPPER}} .crust-note-bar .crust-btn',
			]
		);

		/**
		 *-------------------------------
		 *start button style dark normal
		 *-------------------------------
		 **/
		$this->add_responsive_control(
			'crust_note_bar_btn_dark_normal_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_note_bar_btn_normal_text_dark_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_btn_normal_bg_dark_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_cat_btn_normal_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn',
			]
		);
		/**
		 *-------------------------------
		 *end button style dark normal
		 *-------------------------------
		 **/

		$this->end_controls_tab();

		// Hover State Tab
		$this->start_controls_tab('crust_note_bar_btn_hover', ['label' => esc_html__('Hover', 'elementor')]);

		$this->add_control(
			'crust_note_bar_btn_hover_top',
			[
				'label'      => esc_html__('Margin Top', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'max' => 100,
						'min' => -100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'transform: translateY({{SIZE}}{{UNIT}});-webkit-transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_btn_hover_text_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_btn_hover_bg_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#B9D114',
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_cat_btn_hover_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => '{{WRAPPER}} .crust-note-bar .crust-btn:hover',
			]
		);

		$this->add_control(
			'crust_note_bar_btn_hover_border_radius',
			[
				'label'     => esc_html__('Border Radius', 'elementor'),
				'type'      => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'crust_note_bar_hover_button_shadow',
				'selector'  => '{{WRAPPER}} .crust-note-bar .crust-btn:hover',
				'separator' => 'before'
			]
		);
		/**
		 *-------------------------------
		 *start button style dark hover
		 *-------------------------------
		 **/
		$this->add_responsive_control(
			'crust_note_bar_btn_dark_hover_styles',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_control(
			'crust_note_bar_btn_hover_text_dark_color',
			[
				'label'     => esc_html__('Text Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_note_bar_btn_hover_bg_dark_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn:hover' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_cat_btn_hover_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-note-bar .crust-btn:hover',
			]
		);
		/**
		 *-------------------------------
		 *end button style dark hover
		 *-------------------------------
		 **/

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();

		$class  = 'crust-note-bar';
		$class .= ' ' . $settings['crust_note_bar_align'];
		$class .= ' crust-note-' . $settings['type'];

		$attributes = '';
		if ( $settings['use_cookies'] ) {
			$attributes .= ( $settings['cookie_name'] ) ? ' data-name="'. $settings['cookie_name'] .'"' : '';
			$attributes .= ( $settings['expires'] ) ? ' data-days="'. $settings['expires'] .'"' : '';
		}

		$html = '<div class="'.esc_attr($class).'"'.$attributes.'>';
			$html .= '<span class="crust-close-note-bar"><i class="fad fa-times"></i></span>';
			$html .= '<div class="crust-note-bar-content">';
				if ('content' === $settings['crust_note_bar_content_type']) {
					if ( ! empty($settings['crust_note_bar_content'])) {
						$html .= '<div class="crust-note-bar-text">'.$settings['crust_note_bar_content'].'</div>';
					}
				} else if ('template' === $settings['crust_note_bar_content_type']) {
					if (!empty($settings['crust_note_bar_templates'])) {
						$crust_template_id = $settings['crust_note_bar_templates'];
						$html .= Plugin::$instance->frontend->get_builder_content($crust_template_id, true);
					}
				}

			$html .= '</div>';

			if( $settings['crust_note_bar_show_button'] === 'yes' && 'content' === $settings['crust_note_bar_content_type'] ){
				$target   = $settings['crust_note_bar_btn_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $settings['crust_note_bar_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
				$html .= '<a href="'.esc_url($settings['crust_note_bar_btn_link']['url']).'"'.$target.$nofollow.' class="btn crust-btn">';
					$html .= ( $settings['crust_note_bar_use_button_icon'] === 'yes' && $settings['crust_note_bar_button_icon_alignment'] == 'left') ? $this->render_btn_icon() : '';
					$html .= $settings['crust_note_bar_btn_text'];
					$html .= ( $settings['crust_note_bar_use_button_icon'] === 'yes' && $settings['crust_note_bar_button_icon_alignment'] == 'right') ? $this->render_btn_icon() : '';
				$html .= '</a>';
			}


		$html .= '</div>';

		echo $html;

	}

	protected function render_btn_icon()
	{

		$settings   = $this->get_settings_for_display();
		$iconoutput = '';
		$icondir    = $settings['crust_note_bar_button_icon_alignment'];
		$iconclass  = ( $settings['crust_note_bar_button_icon']['value'] ) ? $settings['crust_note_bar_button_icon']['value'] : '';

		$this->add_render_attribute('crust_note_bar_button_icon',
			[
				'class' => ['crust-btn-icon', esc_attr($iconclass), 'crust-btn-icon-'.esc_attr($icondir)],
			]
		);

		if (isset($settings['crust_note_bar_button_icon']['value']['url'])) {
			$iconoutput .= '<img src="'. esc_attr($settings['crust_note_bar_button_icon']['value']['url']) .'"'. $this->get_render_attribute_string("crust_note_bar_button_icon") .' alt="'.esc_attr(get_post_meta($settings['crust_note_bar_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
		} else {
			$iconoutput .= ( ! empty($settings['crust_note_bar_button_icon']['value'])) ? '<i '. $this->get_render_attribute_string("crust_note_bar_button_icon") .'></i>' : '';
		}

		return $iconoutput;

	}

}
