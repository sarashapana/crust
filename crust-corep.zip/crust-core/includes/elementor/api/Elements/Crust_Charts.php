<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Charts extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-charts'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-charts', true, true);
        return ['crust-charts'];
    }

    public function get_name()
    {
        return 'crust-charts';
    }

    public function get_title()
    {
        return esc_html__('Charts', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-counter-circle';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT TAB
        /*-----------------------------------------------------------------------------------*/
        
        $this->start_controls_section(
            'chart_section_layout',
            [
                'label' => esc_html__('Settings', 'crust-core'),
            ]
        );

        $this->add_control(
            'chart_title',
            [
                'label'     => esc_html__('Title', 'crust-core'),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__('Chart Title', 'crust-core'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'chart_title_html_tag',
            [
                'label'   => esc_html__('Title HTML Tag', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h1'   => __('H1', 'crust-core'),
                    'h2'   => __('H2', 'crust-core'),
                    'h3'   => __('H3', 'crust-core'),
                    'h4'   => __('H4', 'crust-core'),
                    'h5'   => __('H5', 'crust-core'),
                    'h6'   => __('H6', 'crust-core'),
                    'div'  => __('div', 'crust-core'),
                    'span' => __('span', 'crust-core'),
                    'p'    => __('p', 'crust-core'),
                ],
                'default' => 'h5',
            ]
        );

        $this->add_control(
            'chart_value',
            [
                'label'      => esc_html__('Value', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range'      => [
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => '%',
                    'size' => 60,
                ],
                'separator'  => 'before',
            ]
        );

        $this->end_controls_section();

        /**
         * Style Tab: Style(Circle)
         */
        $this->start_controls_section(
            'chart_section_style_general_circle',
            [
                'label'     => __('Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'chart_circle_size',
            [
                'label'      => __('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 50,
                        'max'  => 700,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'separator'  => 'before',
            ]
        );

	    $this->add_control(
		    'chart_circle_line_width',
		    [
			    'label'      => __('Line Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'default'    => [
				    'unit' => 'px',
				    'size' => 25,
			    ]
		    ]
	    );

	    $this->add_control(
		    'chart_line_cap',
		    [
			    'label'   => esc_html__('Line Cap', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    'round'   => __('Round', 'crust-core'),
				    'butt'   => __('Butt', 'crust-core'),
				    'square'   => __('Square', 'crust-core'),
			    ],
			    'default' => 'round',
		    ]
	    );

        $this->add_control(
            'chart_circle_stroke_color',
            [
                'label'     => __('Stroke Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#eee',
                'separator'  => 'after',
            ]
        );

	    $this->add_control(
		    'chart_circle_color_1',
		    [
			    'label'     => __('Fill Color 1', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#19D0D6',
		    ]
	    );

	    $this->add_control(
		    'chart_circle_color_2',
		    [
			    'label'     => __('Fill Color 2', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#B8D114',
		    ]
	    );

	    $this->add_control(
		    'chart_circle_color_3',
		    [
			    'label'     => __('Fill Color 3', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#19D0D6',
		    ]
	    );
		////////////

	    $this->add_responsive_control(
		    'chart_section_style_general_dark_circle',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'chart_circle_stroke_color_dark',
		    [
			    'label'     => __('Stroke Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'separator'  => 'after',
		    ]
	    );

	    $this->add_control(
		    'chart_circle_color_1_dark',
		    [
			    'label'     => __('Fill Color 1', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
		    ]
	    );

	    $this->add_control(
		    'chart_circle_color_2_dark',
		    [
			    'label'     => __('Fill Color 2', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
		    ]
	    );

	    $this->add_control(
		    'chart_circle_color_3_dark',
		    [
			    'label'     => __('Fill Color 3', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
		    ]
	    );

	    ////////////

        $this->end_controls_section();

        /**
         * Style Tab: Typography
         */
        $this->start_controls_section(
            'chart_section_style_typography',
            [
                'label' => __('Typography', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'chart_title_typography',
                'label'    => __('Title', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-chart-title',
            ]
        );

        $this->add_responsive_control(
            'chart_title_margin',
            [
                'label'      => esc_html__('Title Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .crust-chart-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'chart_title_color',
            [
                'label'     => __('Title Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-chart-title' => 'color: {{VALUE}}',

                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'chart_value_typography',
			    'label'    => __('Counter', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-chart-val-wrap',
		    ]
	    );

        $this->add_control(
            'chart_count_color',
            [
                'label'     => __('Counter Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-chart-val-wrap' => 'color: {{VALUE}}',
                ],
            ]
        );


	    $this->add_responsive_control(
		    'chart_counter_margin',
		    [
			    'label'      => esc_html__('Counter Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-chart-val-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    /////////////////
	    $this->add_responsive_control(
		    'chart_section_style_dark_count_typography',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,

		    ]
	    );

	    $this->add_control(
		    'chart_title_dark_color',
		    [
			    'label'     => __('Title Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-chart-title' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'chart_count_dark_color',
		    [
			    'label'     => __('Counter Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-chart-val-wrap' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    /////////////////

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings       = $this->get_settings_for_display();
        $tag            = $settings['chart_title_html_tag'];
        
        $this->add_render_attribute(
            'crust-chart-circle',
            [
                'class'         => 'crust-chart-circle',
	            'data-count'    => '.' . $settings['chart_value']['size'],
				'data-size'     => $settings['chart_circle_size']['size'],
				'data-thickness' => $settings['chart_circle_line_width']['size'],
                'data-stroke'    => $settings['chart_circle_stroke_color'],
                'data-cap'      => $settings['chart_line_cap'],
                'data-grad-1'   => $settings['chart_circle_color_1'],
                'data-grad-2'   => $settings['chart_circle_color_2'],
                'data-grad-3'   => $settings['chart_circle_color_3'],
            ]
        );

        $html = '<div class="crust-chart-wrap">';

            $html .= '<div ' . $this->get_render_attribute_string('crust-chart-circle') . '>';
	            $html .= '<span class="crust-chart-val-wrap"><span class="crust-chart-value"></span><i>%</i></span>';
            $html .= '</div>';

            $html .= '<div class="crust-chart-content">';
                $html .= ( $settings['chart_title'] ) ? '<'.$tag.' class="crust-chart-title">'.$settings['chart_title'].'</'.$tag.'>' : '';
            $html .= '</div>';

        $html .= '</div>';

        echo $html;

    }
}
