<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;

class Crust_Logo extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-logo';
    }

    public function get_title()
    {
        return esc_html__('Site Logo', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_section_logo_style',
            [
                'label' => esc_html__('Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'section_logo_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
				'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .crust-site-brand' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_logo_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-brand' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_menu_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-brand' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {

	    echo apply_filters( 'crust_header_logo', '');

    }

}
