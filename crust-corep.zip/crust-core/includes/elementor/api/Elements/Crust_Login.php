<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Login extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-login';
    }

    public function get_title()
    {
        return esc_html__('Login/Register', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-lock';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

	    /**
	     * Style Tab: Form Container
	     * -------------------------------------------------
	     */
	    $this->start_controls_section(
		    'section_container_style',
		    [
			    'label' => __('Form Container', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'crust_contact_form_labels_color',
		    [
			    'label'     => __('Labels Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form,{{WRAPPER}} .crust-login-form a' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'labels_typography',
			    'selector' => '{{WRAPPER}} .crust-login-form'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_login_background',
			    'label'    => __('Background', 'crust-core'),
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-login-form',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_login_alignment',
		    [
			    'label'       => esc_html__('Form Alignment', 'crust-core'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'left'    => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'  => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'   => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form' => 'text-align: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_login_max_width',
		    [
			    'label'      => esc_html__('Form Max Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => ['px', 'em', '%'],
			    'range'      => [
				    'px' => [
					    'min' => 10,
					    'max' => 1500,
				    ],
				    'em' => [
					    'min' => 1,
					    'max' => 80,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form' => 'width: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_login_margin',
		    [
			    'label'      => esc_html__('Form Margin', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_login_padding',
		    [
			    'label'      => esc_html__('Form Padding', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_login_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'separator'  => 'before',
			    'size_units' => ['px'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_login_border',
			    'selector' => '{{WRAPPER}} .crust-login-form',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_login_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-login-form',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start container dark mode
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'section_container_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_contact_form_labels_dark_color',
		    [
			    'label'     => __('Labels Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form,body.crust-dark {{WRAPPER}} .crust-login-form a' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_login_dark_background',
			    'label'    => __('Background', 'crust-core'),
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-login-form',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_login_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-login-form',
		    ]
	    );

	    /**
	     * ------------------------------
	     *end container dark mode
	     * ------------------------------
	     */

	    $this->end_controls_section();

	    /**
	     * Style Tab: Input & Textarea
	     * -------------------------------------------------
	     */
	    $this->start_controls_section(
		    'section_fields_style',
		    [
			    'label' => __('Inputs Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'text_align',
		    [
			    'label'     => __('Text Align', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'default'   => 'left',
			    'options'   => [
				    'left'   => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'right'  => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'text-align: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->start_controls_tabs('tabs_fields_style');

	    $this->start_controls_tab(
		    'tab_fields_normal',
		    [
			    'label' => __('Normal', 'elementor'),
		    ]
	    );

	    $this->add_control(
		    'field_bg',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'field_text_color',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'color: {{VALUE}}',
			    ],
			    'separator' => 'before',
		    ]
	    );

	    $this->add_responsive_control(
		    'field_margin',
		    [
			    'label'      => __('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'field_padding',
		    [
			    'label'      => __('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'text_indent',
		    [
			    'label'      => __('Text Indent', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 60,
					    'step' => 1,
				    ],
				    '%'  => [
					    'min'  => 0,
					    'max'  => 30,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'text-indent: {{SIZE}}{{UNIT}}',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'input_width',
		    [
			    'label'      => __('Input Width', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 1200,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'width: {{SIZE}}{{UNIT}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'field_border',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',
			    'default'     => '1px',
			    'selector'    => '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select',
			    'separator'   => 'before',
		    ]
	    );

	    $this->add_control(
		    'field_radius',
		    [
			    'label'      => __('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'      => 'field_typography',
			    'label'     => __('Typography', 'crust-core'),
			    'selector'  => '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select',
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'field_box_shadow',
			    'selector'  => '{{WRAPPER}} .crust-login-form input[type="text"], {{WRAPPER}} .crust-login-form input[type="email"], {{WRAPPER}} .crust-login-form [type="password"], {{WRAPPER}} .crust-login-form select',
			    'separator' => 'before',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start menu item dark mode normal
	     * ------------------------------
	     */

	  $this->add_responsive_control(
		  'tab_fields_dark_normal',
		  [
			  'label'      => esc_html__('Dark Mode', 'elementor'),
			  'type'       => Controls_Manager::HEADING,
			  'separator' => 'before',

		  ]
	  );
	    $this->add_control(
		    'field_dark_bg',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="text"],body.crust-dark {{WRAPPER}} .crust-login-form input[type="email"],body.crust-dark {{WRAPPER}} .crust-login-form [type="password"],body.crust-dark {{WRAPPER}} .crust-login-form select' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'field_text_dark_color',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="text"], body.crust-dark {{WRAPPER}} .crust-login-form input[type="email"],body.crust-dark {{WRAPPER}} .crust-login-form [type="password"],body.crust-dark {{WRAPPER}} .crust-login-form select' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'field_dark_border',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',
			    'selector'    => 'body.crust-dark {{WRAPPER}} .crust-login-form input[type="text"], body.crust-dark {{WRAPPER}} .crust-login-form input[type="email"], body.crust-dark {{WRAPPER}} .crust-login-form [type="password"], body.crust-dark {{WRAPPER}} .crust-login-form select',
		    ]
	    );

	    /**
	     * ------------------------------
	     *end menu item dark mode normal
	     * ------------------------------
	     */


	    $this->end_controls_tab();

	    $this->start_controls_tab(
		    'tab_fields_focus',
		    [
			    'label' => __('Focus', 'crust-core'),
		    ]
	    );

	    $this->add_control(
		    'field_bg_focus',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input:focus, {{WRAPPER}} .crust-login-form select:focus' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'input_border_focus',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',
			    'default'     => '1px',
			    'selector'    => '{{WRAPPER}} .crust-login-form input:focus, {{WRAPPER}} .crust-login-form select:focus',
			    'separator'   => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'focus_box_shadow',
			    'selector'  => '{{WRAPPER}} .crust-login-form input:focus, {{WRAPPER}} .crust-login-form select:focus',
			    'separator' => 'before',
		    ]
	    );

	    /**
	     * ------------------------------
	     *start menu item dark mode focus
	     * ------------------------------
	     */

	    $this->add_responsive_control(
		    'tab_fields_dark_focus',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'field_bg_dark_focus',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input:focus,body.crust-dark {{WRAPPER}} .crust-login-form select:focus' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'input_border_dark_focus',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',
			    'selector'    => 'body.crust-dark {{WRAPPER}} .crust-login-form input:focus,body.crust-dark {{WRAPPER}} .crust-login-form select:focus',
		    ]
	    );

	    /**
	     * ------------------------------
	     *end menu item dark mode focus
	     * ------------------------------
	     */

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

	    /**
	     * Style Tab: Placeholder Section
	     */
	    $this->start_controls_section(
		    'section_placeholder_style',
		    [
			    'label' => __('Placeholder', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_control(
		    'text_color_placeholder',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input::-webkit-input-placeholder' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'      => 'typography_placeholder',
			    'label'     => __('Typography', 'crust-core'),
			    'selector'  => '{{WRAPPER}} .crust-login-form input::-webkit-input-placeholder',
		    ]
	    );
	    /**
	     * ------------------------------
	     *start placeholder dark mode
	     * ------------------------------
	     */



	    $this->add_responsive_control(
		    'section_placeholder_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'text_color_dark_placeholder',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input::-webkit-input-placeholder' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    /**
	     * ------------------------------
	     *end placeholder dark mode
	     * ------------------------------
	     */

	    $this->end_controls_section();

	    /**
	     * Style Tab: Submit Button
	     */
	    $this->start_controls_section(
		    'section_submit_button_style',
		    [
			    'label' => __('Submit Button', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

	    $this->add_responsive_control(
		    'button_align',
		    [
			    'label'     => __('Alignment', 'elementor'),
			    'type'      => Controls_Manager::CHOOSE,
			    'default'   => 'center',
			    'options'   => [
					'' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start'   => [
					    'title' => __('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center' => [
					    'title' => __('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'  => [
					    'title' => __('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'align-self: {{VALUE}};',
			    ],
			    'condition' => [
				    'display' => 'block'
			    ]
		    ]
	    );

	    $this->add_control(
		    'button_width_type',
		    [
			    'label'        => __('Width', 'elementor'),
			    'type'         => Controls_Manager::SELECT,
			    'options'      => [
				    ''           => __('Default', 'crust-core'),
				    'full-width' => __('Full Width', 'crust-core'),
				    'custom'     => __('Custom', 'crust-core'),
			    ],
			    'condition' => [
				    'display' => 'block'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'button_width',
		    [
			    'label'      => __('Width', 'elementor'),
			    'type'       => Controls_Manager::SLIDER,
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 1200,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'width: {{SIZE}}{{UNIT}}',
			    ],
			    'condition'  => [
				    'button_width_type' => 'custom',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('tabs_button_style');

	    $this->start_controls_tab(
		    'tab_button_normal',
		    [
			    'label' => __('Normal', 'elementor'),
		    ]
	    );

	    $this->add_control(
		    'button_bg_color_normal',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_text_color_normal',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_border_normal',
			    'label'    => __('Border', 'crust-core'),
			    'default'  => '1px',
			    'selector' => '{{WRAPPER}} .crust-login-form input[type="submit"]',
		    ]
	    );

	    $this->add_control(
		    'button_border_radius',
		    [
			    'label'      => __('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_padding',
		    [
			    'label'      => __('Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_margin',
		    [
			    'label'      => __('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'      => 'button_typography',
			    'label'     => __('Typography', 'crust-core'),
			    'selector'  => '{{WRAPPER}} .crust-login-form input[type="submit"]',
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'      => 'button_box_shadow',
			    'selector'  => '{{WRAPPER}} .crust-login-form input[type="submit"]',
			    'separator' => 'before',
		    ]
	    );

	    /**
	     * ------------------------------
	     *start submit button dark mode normal
	     * ------------------------------
	     */

	    $this->add_responsive_control(
		    'section_submit_button_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_control(
		    'button_bg_color_dark_normal',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_text_color_dark_normal',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_border_dark_normal',
			    'label'    => __('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]',
		    ]
	    );

	    /**
	     * ------------------------------
	     *end submit button dark mode normal
	     * ------------------------------
	     */

	    $this->end_controls_tab();

	    $this->start_controls_tab(
		    'tab_button_hover',
		    [
			    'label' => __('Hover', 'elementor'),
		    ]
	    );

	    $this->add_control(
		    'button_bg_color_hover',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_text_color_hover',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_border_color_hover',
		    [
			    'label'     => __('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'border-color: {{VALUE}}',
			    ],
		    ]
	    );
	    /**
	     * ------------------------------
	     *start submit button dark mode hover
	     * ------------------------------
	     */

	    $this->add_responsive_control(
		    'section_submit_button_hover_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'button_bg_color_dark_hover',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_text_color_dark_hover',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_border_color_dark_hover',
		    [
			    'label'     => __('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-login-form input[type="submit"]:hover' => 'border-color: {{VALUE}}',
			    ],
		    ]
	    );



	    /**
	     * ------------------------------
	     *end submit button dark mode hover
	     * ------------------------------
	     */

	    $this->end_controls_tab();

	    $this->end_controls_tabs();

	    $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if ( function_exists( 'crust_login_form') ){
            echo crust_login_form();
        }

    }

}
