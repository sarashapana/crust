<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Cta extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-cta', false, true);
        return ['crust-cta'];
    }

    public function get_name()
    {
        return 'crust-cta';
    }

    public function get_title()
    {
        return esc_html__('Call to Action', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Call to Action Content Settings
         */
        $this->start_controls_section(
            'crust_section_cta_content_settings',
            [
                'label' => esc_html__('Content Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_cta_align',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'cta-left' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'cta-center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'cta-right'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'     => 'cta-left',
            ]
        );

        $this->add_control(
            'crust_cta_title',
            [
                'label'       => esc_html__('Title', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Call us at +12-34-5672789 or email@example.com', 'crust-core'),
                'dynamic'     => ['active' => true]
            ]
        );
        $this->add_control(
            'crust_cta_title_content_type',
            [
                'label'   => __('Content Type', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'content'  => __('Content', 'crust-core'),
                    'template' => __('Saved Templates', 'crust-core'),
                ],
                'default' => 'content',
            ]
        );

        $this->add_control(
            'crust_primary_templates',
            [
                'label'     => __('Choose Template', 'crust-core'),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->crust_core_get_page_templates(),
                'condition' => [
                    'crust_cta_title_content_type' => 'template',
                ],
            ]
        );
        $this->add_control(
            'crust_cta_content',
            [
                'label'       => esc_html__('Content', 'crust-core'),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default'     => esc_html__('We offer awesome designs with huge availabilities that help you create unlimited websites.', 'crust-core'),
                'separator'   => 'after',
                'condition'   => [
                    'crust_cta_title_content_type' => 'content'
                ]
            ]
        );

        $this->add_control(
            'crust_cta_show_icon',
            [
                'label'     => esc_html__('Show Icon', 'crust-core'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => __('yes', 'crust-core'),
                'label_off' => __('no', 'crust-core'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'crust_cta_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-bell-exclamation',
                    'library' => 'duotone',
                ],
                'condition'   => [
                    'crust_cta_show_icon' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_cta_show_button',
            [
                'label'     => esc_html__('Show Button', 'crust-core'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => __('yes', 'crust-core'),
                'label_off' => __('no', 'crust-core'),
                'default'   => 'yes'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_button_cta',
            [
                'label' => esc_html__('Button', 'crust-core'),
                'condition'   => [
                    'crust_cta_show_button' => 'yes'
                ]
            ]
        );

	    $this->add_control(
		    'crust_cta_block_btn',
		    [
			    'label'     => esc_html__('Block Button ?', 'crust-core'),
			    'type'      => Controls_Manager::SWITCHER,
			    'label_on'  => __('yes', 'crust-core'),
			    'label_off' => __('no', 'crust-core'),
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'btn_cta_hover_style',
		    [
			    'label'   => esc_html__('Hover Style', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    ''              => esc_html__('Default', 'crust-core'),
				    'btn-hyperion'  => esc_html__('Hyperion', 'crust-core'),
				    'btn-anthe'     => esc_html__('Anthe', 'crust-core'),
				    'btn-telesto'   => esc_html__('Telesto', 'crust-core'),
				    'btn-calypso'   => esc_html__('Calypso', 'crust-core'),
				    'btn-greip'     => esc_html__('Greip', 'crust-core'),
				    'btn-bestia'    => esc_html__('Bestia', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_control(
            'crust_cta_btn_text',
            [
                'label'       => esc_html__('Button Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Join us Now', 'crust-core'),
                'condition'   => [
                    'crust_cta_show_button' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_cta_btn_link',
            [
                'label'         => esc_html__('Button Link', 'crust-core'),
                'type'          => Controls_Manager::URL,
                'label_block'   => true,
                'default'       => [
                    'url'         => '#',
                    'is_external' => '',
                ],
                'show_external' => true,
                'condition'   => [
                    'crust_cta_show_button' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_cta_use_button_icon',
            [
                'label'     => esc_html__('Use Icon', 'crust-core'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => __('yes', 'crust-core'),
                'label_off' => __('no', 'crust-core'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'crust_cta_button_icon',
            [
                'label'            => esc_html__('Icon', 'elementor'),
                'type'             => Controls_Manager::ICONS,
                'default'          => [
                    'value'   => 'fad fa-bell',
                    'library' => 'duotone',
                ],
                'condition'   => [
                    'crust_cta_use_button_icon' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_cta_button_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'crust_cta_button_icon[value]!' => '',
                    'crust_cta_use_button_icon' => 'yes'
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_cta_button_icon_size',
            [
                'label'      => esc_html__('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'rem', 'em'],
                'default'    => [
                    'size' => '',
                    'unit' => 'rem',
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'crust_cta_button_icon[value]!' => '',
                    'crust_cta_use_button_icon' => 'yes'
                ],
                'selectors'  => [
                    '{{WRAPPER}} i.crust-btn-icon'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} img.crust-btn-icon' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        /** Styling **/
        $this->start_controls_section(
            'crust_section_cta_style_settings',
            [
                'label' => esc_html__('Call to Action Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_cta_bg',
                'types'     => ['classic', 'gradient'],
                'selector'  => '{{WRAPPER}} .crust-cta',
            ]
        );

        $this->add_responsive_control(
            'crust_cta_container_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_cta_container_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-cta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_cta_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-cta',
            ]
        );

        $this->add_control(
            'crust_cta_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_cta_shadow',
                'selector' => '{{WRAPPER}} .crust-cta',
            ]
        );
	    /**
	     * -------------------------------------------
	     * Tab Style (Cta Background  Dark)
	     * -------------------------------------------
	     */
	    $this->add_control(
		    'crust_cta_show_icon_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-cta',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cta_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-cta',
		    ]
	    );


        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Cta Title Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_cta_title_style_settings',
            [
                'label' => esc_html__('Color &amp; Typography ', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'crust_cta_title_heading',
            [
                'label' => esc_html__('Title Style', 'crust-core'),
                'type'  => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'crust_cta_title_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h4',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_cta_title_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_cta_title_typography',
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-title',
            ]
        );

	    $this->add_responsive_control(
		    'crust_cta_title_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-cta .crust-cta-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_cta_content_heading',
            [
                'label'     => esc_html__('Content Style', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'crust_cta_content_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_cta_content_typography',
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-text',
            ]
        );
	    $this->add_control(
		    'crust_section_cta_title_dark_style_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_cta_dark_title_color',
		    [
			    'label'     => esc_html__('Title Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_cta_dark_content_color',
		    [
			    'label'     => esc_html__('Content Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Button Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_cta_btn_style_settings',
            [
                'label' => esc_html__('Button Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition'   => [
                    'crust_cta_show_button' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_cta_btn_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_cta_btn_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_cta_btn_typography',
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn',
            ]
        );

        $this->add_responsive_control(
            'crust_cta_btn_icon_margin',
            [
                'label'      => esc_html__('Icon Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} i.crust-btn-icon'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} img.crust-btn-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_cta_button_tabs');

        // Normal State Tab
        $this->start_controls_tab('crust_cta_btn_normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_control(
            'crust_cta_btn_normal_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn' => 'color: {{VALUE}};',
                ],
                'default'   => '#fff'
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_btn_normal_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-cta-button .crust-btn:not(.btn-hyperion):not(.btn-bestia), 
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-hyperion:before,
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-anthe::before,
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_cat_btn_normal_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn',
            ]
        );

	    $this->add_control(
		    'crust_cta_btn_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_cta_button_shadow',
                'selector'  => '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn',
            ]
        );
	    $this->add_control(
		    'crust_cta_btn_normal_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_cta_btn_normal_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-button .crust-btn' => 'color: {{VALUE}};',
			    ],
			    'default'   => '#fff'
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_btn_normal_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn:not(.btn-hyperion):not(.btn-bestia), 
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-hyperion:before,
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-anthe::before,
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cat_btn_normal_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-button .crust-btn',
		    ]
	    );

	    $this->end_controls_tab();

        // Hover State Tab
        $this->start_controls_tab('crust_cta_btn_hover', ['label' => esc_html__('Hover', 'elementor')]);

        $this->add_control(
            'crust_cta_btn_hover_top',
            [
                'label'      => esc_html__('Margin Top', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'max' => 100,
                        'min' => -100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover' => 'transform: translateY({{SIZE}}{{UNIT}});-webkit-transform: translateY({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'crust_cta_btn_hover_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_btn_hover_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => '{{WRAPPER}} .crust-cta-button .crust-btn:not(.styled-btn):hover, 
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-hyperion,
					{{WRAPPER}} .crust-cta-button .crust-btn::before,
					{{WRAPPER}} .crust-btn:after, 
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-anthe:hover:before,
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg:before,
					{{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg:after',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cat_btn_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover',
		    ]
	    );

	    $this->add_control(
		    'crust_cta_btn_hover_border_radius',
		    [
			    'label'     => esc_html__('Border Radius', 'elementor'),
			    'type'      => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_cta_hover_button_shadow',
                'selector'  => '{{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover',
                'separator' => 'before'
            ]
        );
	    $this->add_control(
		    'crust_cta_btn_hover_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_cta_btn_hover_dark_text_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_btn_hover_dark_bg',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn:not(.styled-btn):hover, 
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-hyperion,
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn::before,
					body.crust-dark {{WRAPPER}} .crust-btn:after, 
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-anthe:hover:before,
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg:before,
					body.crust-dark {{WRAPPER}} .crust-cta-button .crust-btn.btn-bestia .bestia-bg:after',
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cat_btn_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-button .crust-btn:hover',
		    ]
	    );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Icon Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_cta_icon_style_settings',
            [
                'label'     => esc_html__('Icon Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition'   => [
                    'crust_cta_show_icon' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'crust_section_cta_icon_size',
            [
                'label'     => esc_html__('Font Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 60
                ],
                'range'     => [
                    'px' => [
                        'max' => 160,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-icon i'     => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-cta .crust-cta-icon img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_cta_icon_bg_size',
            [
                'label'     => __('Icon Background Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 300,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-icon i' => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',

                ]
            ]
        );

        $this->add_control(
            'crust_cta_icon_margin',
            [
                'label'     => esc_html__('Margin', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_cta_icon_style_controls');

        $this->start_controls_tab(
            'crust_cta_icon_normal',
            [
                'label' => esc_html__('Normal', 'elementor'),
            ]
        );

        $this->add_control(
            'crust_section_cta_icon_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#444',
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_cta_icon_bg_shape',
            [
                'label'        => esc_html__('Background Shape', 'crust-core'),
                'type'         => Controls_Manager::SELECT,
                'default'      => '',
                'label_block'  => false,
                'options'      => [
                    ''       => esc_html__('None', 'crust-core'),
                    'circle' => esc_html__('Circle', 'crust-core'),
                    'radius' => esc_html__('Radius', 'crust-core'),
                    'square' => esc_html__('Square', 'crust-core'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_cta_icon_bg_color',
                'types'     => ['classic', 'gradient'],
                'default'   => 'classic',
                'selector'  => '{{WRAPPER}} .crust-cta .crust-cta-icon i',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_cta_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-icon i'
            ]
        );

        $this->add_control(
            'crust_cta_icon_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta .crust-cta-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_cta_icon_shadow',
                'selector' => '{{WRAPPER}} .crust-cta .crust-cta-icon i',
            ]
        );

	    $this->add_control(
		    'crust_section_cta_icon_normal_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_section_cta_icon_normal_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#444',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-icon i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'      => 'crust_cta_icon_bg_dark_color',
			    'types'     => ['classic', 'gradient'],
			    'selector'  => 'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-icon i',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cta_icon_normal_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-cta .crust-cta-icon i'
		    ]
	    );

        $this->end_controls_tab();


        $this->start_controls_tab(
            'crust_cta_icon_hover',
            [
                'label' => esc_html__('Hover', 'elementor'),
            ]
        );

        $this->add_control(
            'crust_cta_icon_hover_color',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#4d4d4d',
                'selectors' => [
                    '{{WRAPPER}} .crust-cta:hover .crust-cta-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_cta_icon_hover_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-cta:hover .crust-cta-icon i' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'crust_cta_icon_bg_shape!' => 'none',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_cta_hover_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-cta:hover .crust-cta-icon i'
            ]
        );

        $this->add_control(
            'crust_cta_icon_hover_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .crust-cta:hover .crust-cta-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_cta_icon_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-cta:hover .crust-cta-icon i',
            ]
        );
	    $this->add_control(
		    'crust_section_cta_icon_hover_dark_head',
		    [
			    'label'     => esc_html__('Dark Mode', 'crust-core'),
			    'type'      => Controls_Manager::HEADING,

			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'crust_cta_icon_hover_dark_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#4d4d4d',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta:hover .crust-cta-icon i' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_cta_icon_hover_dark_bg_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-cta:hover .crust-cta-icon i' => 'background: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_cta_icon_bg_shape!' => 'none',
			    ]
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_cta_hover_dark_icon_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-cta:hover .crust-cta-icon i'
		    ]
	    );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $tag      = $settings['crust_cta_title_tag'];

        $iconclass = ( $settings['crust_cta_icon'] ) ? $settings['crust_cta_icon']['value'] : '';
        $iconwrap  = 'crust-cta-icon';
        $iconwrap .= ( '' !== $settings['crust_cta_icon_bg_shape'] ) ? ' crust-cta-icon-bg-' . $settings['crust_cta_icon_bg_shape'] : '';

        $cta_class  = 'crust-cta';
        $cta_class .= ' ' . $settings['crust_cta_align'];
	    $cta_class .= ( $settings['crust_cta_block_btn'] === 'yes' ) ? ' crust-cta-block-btn' : '';

        $html = '<div class="'.esc_attr($cta_class).'">';

            if( $settings['crust_cta_icon'] ){
                $html .= '<div class="'.esc_attr($iconwrap).'">';
                if (isset($settings['crust_cta_icon_new']['value']['url'])) {
                    $html .= '<img src="'.esc_url($settings['crust_cta_icon']['value']['url']).'" alt="'.esc_attr(get_post_meta($settings['crust_cta_icon']['value']['id'],
                            '_wp_attachment_image_alt', true)).'"/>';
                } else {
                    $html .= '<i class="'.esc_attr($iconclass).'"></i>';
                }
                $html .= '</div>';
            }

            $html .= '<div class="crust-cta-content">';
                $html .= '<'.$tag.' class="crust-cta-title">'.$settings['crust_cta_title'].'</'.$tag.'>';
                if ('content' == $settings['crust_cta_title_content_type']) {
                    $html .= '<div class="crust-cta-text">'.$settings['crust_cta_content'].'</div>';
                } elseif ('template' == $settings['crust_cta_title_content_type']) {
                    if ( ! empty($settings['crust_primary_templates'])) {
                        $crust_template_id = $settings['crust_primary_templates'];
                        $crust_frontend    = new Frontend;
                        $html .= $crust_frontend->get_builder_content($crust_template_id, true);
                    }
                }
            $html .= '</div>';

		    $btn_class = 'crust-btn';
		    $btn_class .= ( $settings['btn_cta_hover_style'] ) ? ' styled-btn' : '';
		    $btn_class .= ( $settings['btn_cta_hover_style'] ) ? ' ' . $settings['btn_cta_hover_style'] : '';

            if( $settings['crust_cta_show_button'] === 'yes' ){
                $target   = $settings['crust_cta_btn_link']['is_external'] ? ' target="_blank"' : '';
                $nofollow = $settings['crust_cta_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
                $html .= '<div class="crust-cta-button">';

                    $html .= '<a href="'.esc_url($settings['crust_cta_btn_link']['url']).'"'.$target.$nofollow.' class="'.$btn_class.'">';
			            $html .= ( $settings['btn_cta_hover_style'] == 'btn-bestia' ) ? '<b class="bestia-bg"></b>' : '';
			            $html .= "<span><span>";
	                        $html .= ( $settings['crust_cta_use_button_icon'] === 'yes' && $settings['crust_cta_button_icon_alignment'] == 'left') ? $this->render_btn_icon() : '';
	                        $html .= $settings['crust_cta_btn_text'];
	                        $html .= ( $settings['crust_cta_use_button_icon'] === 'yes' && $settings['crust_cta_button_icon_alignment'] == 'right') ? $this->render_btn_icon() : '';
	                    $html .= "</span></span>";
                    $html .= '</a>';
                $html .= '</div>';
            }


        $html .= '</div>';

        echo $html;

    }

    protected function render_btn_icon()
    {

        $settings   = $this->get_settings_for_display();
        $iconoutput = '';
        $icondir    = $settings['crust_cta_button_icon_alignment'];
        $iconclass  = ( $settings['crust_cta_button_icon']['value'] ) ? $settings['crust_cta_button_icon']['value'] : '';

        $this->add_render_attribute('crust_cta_button_icon',
            [
                'class' => ['crust-btn-icon', esc_attr($iconclass), 'crust-btn-icon-'.esc_attr($icondir)],
            ]
        );

        if (isset($settings['crust_cta_button_icon']['value']['url'])) {
            $iconoutput .= '<img src="'. esc_attr($settings['crust_cta_button_icon']['value']['url']) .'"'. $this->get_render_attribute_string("crust_cta_button_icon") .' alt="'.esc_attr(get_post_meta($settings['crust_cta_button_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'">';
        } else {
            $iconoutput .= ( ! empty($settings['crust_cta_button_icon']['value'])) ? '<i '. $this->get_render_attribute_string("crust_cta_button_icon") .'></i>' : '';
        }

        return $iconoutput;

    }

}
