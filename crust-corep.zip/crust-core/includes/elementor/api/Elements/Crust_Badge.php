<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Badge extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-badge';
    }

    public function get_title()
    {
        return esc_html__('Badge', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

	    /**
	     * Content Settings
	     */
	    $this->start_controls_section(
		    'crust_badge_content_settings',
		    [
			    'label' => esc_html__('Content Settings', 'crust-core')
		    ]
	    );

	    $this->add_control(
		    'badge_style',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    ''       => esc_html__('Default', 'crust-core'),
				    'main' => esc_html__('Primary Badge', 'crust-core'),
				    'alt' => esc_html__('Secondary Badge', 'crust-core'),
				    'gradient' => esc_html__('Gradient Badge', 'crust-core'),
				    'light' => esc_html__('Light Badge', 'crust-core'),
				    'minimal' => esc_html__('Minimal Badge', 'crust-core'),
			    ],
		    ]
	    );



	    $this->add_control(
		    'badge_content',
		    [
			    'label'       => esc_html__('Content', 'crust-core'),
			    'type'        => Controls_Manager::WYSIWYG,
			    'label_block' => true,
			    'default'     => esc_html__('Crust Badge Element', 'crust-core'),
			    'dynamic'     => ['action' => true]
		    ]
	    );

	    $this->add_control(
		    'link_url',
		    [
			    'label'         => esc_html__('Link', 'elementor'),
			    'type'          => Controls_Manager::URL,
			    'label_block'   => true,
			    'show_external' => true,
		    ]
	    );

	    $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_badge_style',
            [
                'label' => esc_html__('Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'badge_tag',
		    [
			    'label'       => esc_html__('HTML Tag', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'default'     => 'span',
			    'label_block' => false,
			    'options'     => [
				    'h1' => esc_html__('H1', 'crust-core'),
				    'h2' => esc_html__('H2', 'crust-core'),
				    'h3' => esc_html__('H3', 'crust-core'),
				    'h4' => esc_html__('H4', 'crust-core'),
				    'h5' => esc_html__('H5', 'crust-core'),
				    'h6' => esc_html__('H6', 'crust-core'),
				    'span' => esc_html__('span', 'crust-core'),
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'section_badge_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
				'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_badge_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-badge, {{WRAPPER}} .crust-badge a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->add_control(
		    'crust_badge_hover_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-badge:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );



	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_head_first_title_typography',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_badge_text_shadow',
			    'label'      => esc_html__('Text Shadow', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_control(
		    'use_shape',
		    [
			    'label' => esc_html__( 'Use Left Shape', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );

	    $this->add_control(
		    'use_line',
		    [
			    'label' => esc_html__( 'Use Left Line', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );

	    $this->add_control(
		    'use_right_line',
		    [
			    'label' => esc_html__( 'Use Right Line', 'crust-core' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'YES', 'crust-core' ),
			    'label_off'     => esc_html__( 'NO', 'crust-core' ),
			    'return_value'  => 'yes',
		    ]
	    );

////////////
	    $this->add_responsive_control(
		    'section_badge_dark_mode',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );


	    $this->add_control(
		    'crust_badge_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-badge ,body.crust-dark {{WRAPPER}} .crust-badge a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


	    $this->add_control(
		    'crust_badge_hover_dark_color',
		    [
			    'label'     => esc_html__('Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-badge:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );


////////////////////
	    $this->end_controls_section();

	    $this->start_controls_section(
		    'crust_section_badge_inner_style',
		    [
			    'label' => esc_html__('Badge Style', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );

        $this->add_responsive_control(
            'crust_badge_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_badge_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_badge_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );


	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_badge_border',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_control(
		    'crust_badge_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_badge_shadow',
			    'selector' => '{{WRAPPER}} .crust-badge',
		    ]
	    );

	    //////////
	    $this->add_responsive_control(
		    'crust_section_badge_dark_inner_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_badge_dark_bg',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-badge',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_badge_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-badge',
		    ]
	    );
		
        $this->end_controls_section();

	    // Line
	    $this->start_controls_section(
		    'badge_shape_styles',
		    [
			    'label' => esc_html__('Left Shape', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'use_shape' => 'yes'
			    ]
		    ]
	    );

	    $this->add_control(
		    'badge_shape_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .badge-shape path' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_shape_width',
		    [
			    'label' => esc_html__( 'Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-shape svg' => 'width: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_shape_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .badge-shape' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ]
		    ]
	    );

	    /**
	     * ----------------------------
	     *start page shape
	     * ---------------------------
	     */

	    $this->add_responsive_control(
		    'badge_shape_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'badge_shape_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .badge-shape path' => 'fill: {{VALUE}};',
			    ],
		    ]
	    );



	    /**
	     * ----------------------------
	     *end page shape
	     * ---------------------------
	     */

	    $this->end_controls_section();

	    // Line
	    $this->start_controls_section(
		    'badge_line_styles',
		    [
			    'label' => esc_html__('Left Line', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'use_line' => 'yes'
			    ]
		    ]
	    );

	    $this->add_control(
		    'badge_line_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_line_width',
		    [
			    'label' => esc_html__( 'Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'default' => [
				    'size' => 170,
				    'unit' => 'px',
			    ],
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'width: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_line_height',
		    [
			    'label' => esc_html__( 'Height', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'height: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_line_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_line_rotate',
		    [
			    'label' => __( 'Rotate', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'deg' => [
					    'min' => -360,
					    'max' => 360,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => [ 'deg' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-line' => 'transform: rotate({{SIZE}}deg)',
			    ],
		    ]
	    );
	    /**
	     * ----------------------------
	     *start left line
	     * ---------------------------
	     */
	    $this->add_responsive_control(
		    'badge_line_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'badge_line_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .badge-line' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    /**
	     * ----------------------------
	     *end left line
	     * ---------------------------
	     */

	    $this->end_controls_section();

	    // Line
	    $this->start_controls_section(
		    'badge_right_line_styles',
		    [
			    'label' => esc_html__('Right Line', 'crust-core'),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
				    'use_right_line' => 'yes'
			    ]
		    ]
	    );

	    $this->add_control(
		    'badge_right_line_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_right_line_width',
		    [
			    'label' => esc_html__( 'Width', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'default' => [
				    'size' => 170,
				    'unit' => 'px',
			    ],
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'width: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_right_line_height',
		    [
			    'label' => esc_html__( 'Height', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'px' => [
					    'min' => 0,
					    'max' => 1000,
				    ],
			    ],
			    'size_units' => [ 'px' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'height: {{SIZE}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_right_line_margin',
		    [
			    'label'      => esc_html__('Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_right_line_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'badge_right_line_rotate',
		    [
			    'label' => __( 'Rotate', 'crust-core' ),
			    'type' => Controls_Manager::SLIDER,
			    'range' => [
				    'deg' => [
					    'min' => -360,
					    'max' => 360,
					    'step' => 1,
				    ],
			    ],
			    'size_units' => [ 'deg' ],
			    'selectors' => [
				    '{{WRAPPER}} .badge-right-line' => 'transform: rotate({{SIZE}}deg)',
			    ],
		    ]
	    );
	    /**
	     * ----------------------------
	     *start right line
	     * ---------------------------
	     */
	    $this->add_responsive_control(
		    'badge_right_line_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'badge_right_line_dark_color',
		    [
			    'label'     => esc_html__('Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .badge-right-line' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    /**
	     * ----------------------------
	     *end right line
	     * ---------------------------
	     */


	    $this->end_controls_section();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();
	    $html = '';
	    $class = ( $settings['badge_style'] ) ? ' crust-badge-' . $settings['badge_style'] : '';
	    $target   = $settings['link_url']['is_external'] ? ' target="_blank"' : '';
	    $nofollow = $settings['link_url']['nofollow'] ? ' rel="nofollow"' : '';
	    $link     = ( $settings['link_url']['url'] ) ? $settings['link_url']['url'] : '';

	    $this->add_render_attribute(
		    'crust_badge',
		    [ 'class'  => [
		    	'crust-badge',
			    $class
			    ]
		    ]
	    );

	    if( $settings['badge_content'] ){
	    	$html .= ( $settings['use_line'] ) ? '<span class="badge-line"></span>' : '';
		    $html .= '<'.$settings['badge_tag']. ' ' . $this->get_render_attribute_string("crust_badge") .'>';
		        $html .= ( $settings['use_shape'] ) ? '<span class="badge-shape"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="30" viewBox="0 0 25 30"><path d="M0,0H25V18.947L0,30Z" fill="#b9d114"/></svg></span>' : '';
		        $html .= ( $link ) ? '<a href="'.esc_url($link).'"' . $target . $nofollow . '>' : '';
		            $html .= wp_kses( $settings['badge_content'], crust_allowed_tags() );
		        $html .= ( $link ) ? '</a>' : '';
		    $html .= '</'.$settings['badge_tag'].'>';
		    $html .= ( $settings['use_right_line'] ) ? '<span class="badge-right-line"></span>' : '';
		    echo $html;
	    }

    }

}
