<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;

class Crust_Hotspot extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-hotspot';
    }

    public function get_title()
    {
        return esc_html__('Image Hotspot', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    public function get_categories()
    {
        return ['crust'];
    }

	public function get_script_depends()
	{
		return ['crust-hotspot'];
	}

	public function get_style_depends()
	{
		do_action('enqueue_crust_assets','crust-hotspot', true, true);
		return ['crust-hotspot'];
	}

	protected function register_controls()
	{

		$this->start_controls_section(
			'crust_spot_img_settings',
			[
				'label' => esc_html__('Image', 'crust-core')
			]
		);

		$this->add_control(
			'spot_image', [
				'label'       => esc_html__('Image', 'crust-core'),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => CRUST_CORE_URI . '/includes/elementor/assets/images/placeholder.jpg',
				],
			]
		);

		$this->add_control(
			'img_map', [
				'label'       => '',
				'type'        => 'crust_hotspot_control',
			]
		);

		$this->add_control(
			'interactivity',
			[
				'label'     => esc_html__('Interactivity', 'elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'hover',
				'options'   => [
					'hover'  => esc_html__('Hover', 'crust-core'),
					'click' => esc_html__('Click', 'crust-core'),
					'none' => esc_html__('None', 'crust-core'),
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'crust_spot_wrap_settings',
			[
				'label' => esc_html__('Wrapper Style', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_wrap_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-hotspot',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_wrap_border',
				'selector' => '{{WRAPPER}} .crust-hotspot',
			]
		);

		$this->add_responsive_control(
			'spot_wrap_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-hotspot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'spot_wrap_box_shadow',
				'selector' => '{{WRAPPER}} .crust-hotspot',
			]
		);
		//////////////////
		$this->add_responsive_control(
			'crust_spot_wrap_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_wrap_dark_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_wrap_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot',
			]
		);
		//////////////////

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_spot_marker_settings',
			[
				'label' => esc_html__('Marker', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'crust_spot_marker_size',
			[
				'label'      => esc_html__('Size', 'crust-core'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
					'em' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .crust-hotspot .crust-hotspot-text' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_marker_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-text',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_marker_border',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-text',
			]
		);

		$this->add_responsive_control(
			'spot_marker_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-hotspot .crust-hotspot-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'spot_marker_box_shadow',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-text',
			]
		);
		/////////////////
		$this->add_responsive_control(
			'crust_spot_marker_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_marker_dark_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-text',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_marker_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-text',
			]
		);
		/////////////////

		$this->end_controls_section();

		$this->start_controls_section(
			'crust_spot_tip_settings',
			[
				'label' => esc_html__('Tooltip', 'crust-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'crust_spot_tip_title_color',
			[
				'label'     => esc_html__('Title Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-hotspot .crust-hotspot-Title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label'    => esc_html__('Title Typography', 'crust-core'),
				'name'     => 'crust_spot_tip_title_typography',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-Title',
			]
		);

		$this->add_control(
			'crust_spot_tip_content_color',
			[
				'label'     => esc_html__('Content Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-hotspot .crust-hotspot-Message' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label'    => esc_html__('Content Typography', 'crust-core'),
				'name'     => 'crust_spot_tip_content_typography',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-Message',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_tip_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_tip_border',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)',
			]
		);

		$this->add_responsive_control(
			'spot_tip_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'spot_tip_box_shadow',
				'selector' => '{{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)',
			]
		);
////////////////////
		$this->add_responsive_control(
			'crust_spot_tip_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'crust-core'),
				'type'       => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);

		$this->add_control(
			'crust_spot_tip_title_dark_color',
			[
				'label'     => esc_html__('Title Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-Title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_spot_tip_content_dark_color',
			[
				'label'     => esc_html__('Content Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-Message' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'spot_tip_dark_bg',
				'types'    => ['classic', 'gradient'],
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'spot_tip_dark_border',
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-hotspot .crust-hotspot-item > div:not(.crust-hotspot-text)',
			]
		);

///////////////////
		$this->end_controls_section();

	}

    protected function render()
    {

        $settings = $this->get_settings_for_display();
	    $img      = ( $settings['spot_image']['url'] ) ? '<img src="' . $settings['spot_image']['url'] . '">' : '';
	    $class    = 'crust-hotspot';

	    $html = '<div class="'.$class.'" data-action="'.$settings['interactivity'].'">';
		    $html .= $img;
		    $html .= '<input type="hidden" class="crust-hotspot-input" id="'.esc_attr($this->get_id()).'" value="'.$settings['img_map'].'" />';
	    $html .= '</div>';

	    echo $html;

    }

}
