<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Widget_Base;

class Crust_Menu extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-menu', false, true);
        return ['crust-menu'];
    }

    public function get_name()
    {
        return 'crust-menu';
    }

    public function get_title()
    {
        return esc_html__('Nav Menu', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-nav-menu';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_section_menu_content_settings',
            [
                'label' => esc_html__('General', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_menu',
            [
                'label'    => esc_html__('Select Menu', 'crust-core'),
                'type'     => Controls_Manager::SELECT,
                'options'  => crust_core_site_menus()
            ]
        );

	    $this->add_control(
		    'type',
		    [
			    'label'    => esc_html__('Type', 'crust-core'),
			    'type'     => Controls_Manager::SELECT,
			    'options'  => [
			    	'' => esc_html__('Horizontal', 'crust-core'),
				    'vertical' => esc_html__('Vertical', 'crust-core'),
			    ]
		    ]
	    );

        $this->add_responsive_control(
            'crust_menu_align',
            [
                'label'           => esc_html__('Alignment', 'elementor'),
                'type'            => Controls_Manager::CHOOSE,
                'options'         => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'flex-start'  => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'   => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-navigation' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
	                'type!' => 'vertical'
                ],
            ]
        );

	    $this->add_control(
		    'full_width_items',
		    [
			    'label' => __( 'Full Width Items ?', 'elementor' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on' => __( 'Yes', 'elementor' ),
			    'label_off' => __( 'No', 'elementor' ),
			    'condition' => [
				    'type!' => 'vertical'
			    ],
		    ]
	    );

	    $this->add_control(
		    'sticky_menu',
		    [
			    'label' => __( 'Sticky ?', 'elementor' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on' => __( 'Yes', 'elementor' ),
			    'label_off' => __( 'No', 'elementor' ),
			    'condition' => [
				    'type!' => 'vertical'
			    ],
		    ]
	    );

	    $this->add_control(
		    'use_global_menu',
		    [
			    'label' => __( 'Main Site Menu (Multisite only)', 'elementor' ),
			    'type' => Controls_Manager::SWITCHER,
			    'label_on' => __( 'Yes', 'elementor' ),
			    'label_off' => __( 'No', 'elementor' ),
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_menu_text_align',
		    [
			    'label'           => esc_html__('Text Align', 'elementor'),
			    'type'            => Controls_Manager::CHOOSE,
			    'options'         => [
				    'flex-start'  => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'   => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end' => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'condition' => [
				    'type' => 'vertical'
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li > a > span' => 'justify-content: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_menu_style',
            [
                'label' => esc_html__('Container', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'crust_menu_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-main-nav-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_menu_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-main-nav-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'crust_menu_background',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-main-nav-wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border:: get_type(),
            [
                'name'     => 'crust_menu_border',
                'selector' => '{{WRAPPER}} .crust-main-nav-wrap',
            ]
        );

        $this->add_control(
            'crust_menu_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-main-nav-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'crust_menu_box_shadow',
                'selector' => '{{WRAPPER}} .crust-main-nav-wrap',
            ]
        );

	    /**
	     *-------------------------------
	     *start container dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_section_menu_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_menu_dark_background',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-main-nav-wrap' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border:: get_type(),
		    [
			    'name'     => 'crust_menu_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-main-nav-wrap',
		    ]
	    );
	    /**
	     *-------------------------------
	     *end container dark
	     *-------------------------------
	     **/

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_section_menu_item_style',
            [
                'label' => esc_html__('Menu Item Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_menu_item_typography',
                'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li > a',
            ]
        );

        $this->add_responsive_control(
            'crust_menu_item_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-navigation > ul > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_menu_item_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-navigation > ul > li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_menu_tabs');

        $this->start_controls_tab('crust_menu_normal', ['label' => esc_html__('Normal', 'elementor')]);

        $this->add_group_control(
            Group_Control_Background:: get_type(),
            [
                'name'     => 'crust_menu_item_background',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li > a',
            ]
        );

        $this->add_control(
            'crust_menu_item_color',
            [
                'label'     => esc_html__('Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-site-navigation > ul > li > a' => 'color: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_menu_item_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li > a'
            ]
        );

        $this->add_control(
            'crust_menu_item_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-site-navigation > ul > li > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'menu_item_shadow',
                'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li > a',
            ]
        );

	    /**
	     *-------------------------------
	     *start container dark normal
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_section_menu_item_dark_normal_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_menu_item_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_menu_item_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a'
		    ]
	    );


	    /**
	     *-------------------------------
	     *end container dark normal
	     *-------------------------------
	     **/

        $this->end_controls_tab();

	    $this->start_controls_tab('crust_menu_active', ['label' => esc_html__('Active', 'crust-core')]);

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_menu_item_active_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				{{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_active_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-site-navigation > ul > li > a.active:before' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a' => 'color: {{VALUE}};',
				    '{{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a' => 'color: {{VALUE}};',
			    ],
			    'separator' => 'before',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_menu_item_active_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				{{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_border_active_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [ '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				{{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'menu_item_active_shadow',
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				{{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				{{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				{{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a',
		    ]
	    );
	    /**
	     *-------------------------------
	     *start container dark active
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_section_menu_item_dark_active_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_menu_item_active_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_active_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a.active:before' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a' => 'color: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_menu_item_active_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-parent > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-ancestor > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li > a.active,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current-menu-item > a,
				body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li.current_page_parent > a',
		    ]
	    );


	    /**
	     *-------------------------------
	     *end container dark active
	     *-------------------------------
	     **/

	    $this->end_controls_tab();

	    $this->start_controls_tab('crust_menu_hover', ['label' => esc_html__('Hover', 'elementor')]);

	    $this->add_control(
		    'crust_menu_item_hover_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li:hover > a' => 'color: {{VALUE}};',
			    ],
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_underline_color',
		    [
			    'label'     => esc_html__('Underline Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li > a > span:before' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_menu_item_hover_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li:hover > a',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_menu_item_hover_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li:hover > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_border_hover_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
			    	'{{WRAPPER}} .crust-site-navigation > ul > li:hover > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'menu_item_hover_shadow',
			    'selector' => '{{WRAPPER}} .crust-site-navigation > ul > li:hover > a',
		    ]
	    );
	    /**
	     *-------------------------------
	     *start container dark hover
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_section_menu_item_dark_hover_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background:: get_type(),
		    [
			    'name'     => 'crust_menu_item_hover_dark_background',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li:hover > a',
		    ]
	    );

	    $this->add_control(
		    'crust_menu_item_hover_dark_color',
		    [
			    'label'     => esc_html__('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li:hover > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_menu_item_hover_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation > ul > li:hover > a',
		    ]
	    );



	    /**
	     *-------------------------------
	     *end container dark hover
	     *-------------------------------
	     **/

	    $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Sub menu
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_submenu_style',
            [
                'label' => esc_html__('Sub Menu', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'crust_submenu_typography',
			    'selector' => '{{WRAPPER}} .crust-site-navigation li ul.sub-menu li,{{WRAPPER}} .crust-site-navigation li ul.sub-menu li a',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_submenu_wrap_item_padding',
		    [
			    'label'      => esc_html__('Wrapper Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_submenu_wrap_item_margin',
		    [
			    'label'      => esc_html__('Wrapper Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_submenu_bg_color',
            [
                'label'     => esc_html__('Wrapper BG Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box' => 'background-color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_submenu_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box'
		    ]
	    );

	    $this->add_control(
		    'crust_submenu_border_radius',
		    [
			    'label'      => esc_html__('Border Radius', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Box_Shadow:: get_type(),
		    [
			    'name'     => 'crust_submenu_shadow',
			    'selector' => '{{WRAPPER}} .crust-site-navigation li .crust-submenu-box',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_submenu_item_padding',
		    [
			    'label'      => esc_html__('Item Padding', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_submenu_item_margin',
		    [
			    'label'      => esc_html__('Item Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-site-navigation > ul > li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_submenu_color',
            [
                'label'     => esc_html__('Links Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-site-navigation ul.sub-menu li a' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_submenu_hover_color',
		    [
			    'label'     => esc_html__('Links Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-site-navigation ul.sub-menu li:hover > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_submenu_hover_bg_color',
		    [
			    'label'     => esc_html__('Background Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .crust-site-navigation ul.sub-menu li:hover > a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_control(
            'crust_submenu_divider_color',
            [
                'label'     => esc_html__('Divider Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-site-navigation li.mega-menu > .crust-submenu-wrap > .crust-submenu-box > ul.sub-menu > li' => 'border-right-color: {{VALUE}};',
                ],
            ]
        );
	    /**
	     *-------------------------------
	     *start submenu dark
	     *-------------------------------
	     **/
	    $this->add_responsive_control(
		    'crust_section_submenu_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_submenu_bg_dark_color',
		    [
			    'label'     => esc_html__('Wrapper BG Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation li .crust-submenu-box' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_submenu_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-site-navigation li .crust-submenu-box'
		    ]
	    );
	    $this->add_control(
		    'crust_submenu_dark_color',
		    [
			    'label'     => esc_html__('Links Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation ul.sub-menu li a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_submenu_hover_dark_color',
		    [
			    'label'     => esc_html__('Links Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation ul.sub-menu li:hover > a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_submenu_hover_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Hover Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation ul.sub-menu li:hover > a' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_submenu_divider_dark_color',
		    [
			    'label'     => esc_html__('Divider Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-site-navigation li.mega-menu > .crust-submenu-wrap > .crust-submenu-box > ul.sub-menu > li' => 'border-right-color: {{VALUE}};',
			    ],
		    ]
	    );


	    /**
	     *-------------------------------
	     *end submenu dark
	     *-------------------------------
	     **/


        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $menu     = $settings['crust_menu'];
	    $full     = (!empty( $settings['full_width_items'])) ? 'crust-full-menu' : '';
	    $vertical = ( $settings['type'] === 'vertical' ) ? 'crust-vertical-menu' : '';
	    $sticky = (!empty( $settings['sticky_menu'])) ? 'crust-sticky-menu' : '';
	    $html     = '';

	    $this->add_render_attribute(
		    'crust_nav_menu',
		    [
			    'id'    => 'crust-menu-' . esc_attr($this->get_id()),
			    'class' => ['crust-main-nav-wrap', esc_attr($full), esc_attr($vertical), esc_attr($sticky)],
		    ]
	    );

        if( $menu || $settings['use_global_menu'] === 'yes' ){

            if (class_exists('Crust_Custom_Menu')) {

	            if( is_multisite() && $settings['use_global_menu'] ){
		            switch_to_blog(1);
	            }

                $crust_menu = new \Crust_Custom_Menu();
                $html .= '<div '. $this->get_render_attribute_string("crust_nav_menu") .'>';
                    $html .= $crust_menu->crust_core_nav_menu([
                        'menu' => $menu,
	                    'echo' => false
                    ]);
                $html .= '</div>';

	            if( is_multisite() && $settings['use_global_menu'] ) {
		            restore_current_blog();
	            }

                echo $html;
            }

        }

    }

}
