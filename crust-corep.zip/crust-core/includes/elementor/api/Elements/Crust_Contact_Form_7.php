<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;

class Crust_Contact_Form_7 extends Widget_Base
{

    use \Crust_Core\Traits\Helper;
    
    public function get_name()
    {
        return 'crust-contact-form-7';
    }
    
    public function get_title()
    {
        return __('Contact Form 7', 'crust-core');
    }
    
    public function get_categories()
    {
        return ['crust'];
    }

    public function get_icon()
    {
        return 'eicon-mail';
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-contact-form-7', false, true);
        return ['crust-contact-form-7'];
    }

    protected function register_controls()
    {
        // Content Tab...
        if ( ! function_exists('wpcf7')) {
            $this->start_controls_section(
                'crust_plugin_warning',
                [
                    'label' => esc_html__('Warning!', 'crust-core'),
                ]
            );

            $this->add_control(
                'crust_plugin_warning_text',
                [
                    'type'            => Controls_Manager::RAW_HTML,
                    'raw'             => esc_html__('Contact Form 7 Plugin is not installed or activated. Please install and activate it first.', 'crust-core'),
                    'content_classes' => 'crust-warning',
                ]
            );

            $this->end_controls_section();
        } else {

            // General Settings...
            $this->start_controls_section(
                'section_general_settings',
                [
                    'label' => __('General Settings', 'crust-core'),
                ]
            );

            $this->add_control(
                'contact_form_list',
                [
                    'label'       => esc_html__('Select Form', 'crust-core'),
                    'type'        => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options'     => $this->crust_core_select_contact_form(),
                    'default'     => '0',
                ]
            );

            $this->add_control(
                'disable_wpautop',
                [
                    'label'        => esc_html__('Disable wpautop?', 'crust-core'),
                    'description'  => esc_html__('Prevent Contact form 7 from adding extra html tags', 'crust-core'),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => '',
                ]
            );

            $this->end_controls_section();

        }

        /*-----------------------------------------------------------------------------------*/
        /*    STYLE TAB
        /*-----------------------------------------------------------------------------------*/
        /**
         * Style Tab: Form Container
         * -------------------------------------------------
         */
        $this->start_controls_section(
            'section_container_style',
            [
                'label' => __('Form Container', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'crust_contact_form_background',
                'label'    => __('Background', 'crust-core'),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-contact-form',
            ]
        );

        $this->add_responsive_control(
            'crust_contact_form_alignment',
            [
                'label'       => esc_html__('Form Alignment', 'crust-core'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
                    '' => [
                        'title' => __('Default', 'crust-core'),
                        'icon'  => 'fa fa-ban',
                    ],
                    'left'    => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'  => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_contact_form_max_width',
            [
                'label'      => esc_html__('Form Max Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min' => 10,
                        'max' => 1500,
                    ],
                    'em' => [
                        'min' => 1,
                        'max' => 80,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form' => 'width: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_contact_form_margin',
            [
                'label'      => esc_html__('Form Margin', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_contact_form_padding',
            [
                'label'      => esc_html__('Form Padding', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'crust_contact_form_labels_color',
            [
                'label'     => __('Labels Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form' => 'color: {{VALUE}}',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name'     => 'labels_typography',
			    'selector' => '{{WRAPPER}} .crust-contact-form'
		    ]
	    );

        $this->add_control(
            'crust_contact_form_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'  => 'before',
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_contact_form_border',
                'selector' => '{{WRAPPER}} .crust-contact-form',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_contact_form_box_shadow',
                'selector' => '{{WRAPPER}} .crust-contact-form',
            ]
        );
	    /**
	     * Style Tab: Form Container Dark Mode
	     * -------------------------------------------------
	     */
	    $this->add_responsive_control(
		    'crust_contact_form_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_contact_form_dark_background',
			    'label'    => __('Background', 'crust-core'),
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-contact-form',
		    ]
	    );
	    $this->add_control(
		    'crust_contact_form_dark_labels_color',
		    [
			    'label'     => __('Labels Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_contact_dark_form_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-contact-form',
		    ]
	    );

        $this->end_controls_section();

        /**
         * Style Tab: Input & Textarea
         * -------------------------------------------------
         */
        $this->start_controls_section(
            'section_fields_style',
            [
                'label' => __('Input & Textarea', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('tabs_fields_style');

        $this->start_controls_tab(
            'tab_fields_normal',
            [
                'label' => __('Normal', 'elementor'),
            ]
        );

        $this->add_control(
            'field_bg',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'field_text_color',
            [
                'label'     => __('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'color: {{VALUE}}',
                ],

            ]
        );

        $this->add_responsive_control(
            'field_margin',
            [
                'label'      => __('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'field_padding',
            [
                'label'      => __('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_indent',
            [
                'label'      => __('Text Indent', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 60,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'text-indent: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'input_width',
            [
                'label'      => __('Input Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1200,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'textarea_width',
            [
                'label'      => __('Textarea Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1200,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-textarea' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'        => 'field_border',
                'label'       => __('Border', 'crust-core'),
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .crust-contact-form .wpcf7-text,{{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select',

            ]
        );

        $this->add_control(
            'field_radius',
            [
                'label'      => __('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-date, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'field_typography',
                'label'     => __('Typography', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select',

            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'field_box_shadow',
                'selector'  => '{{WRAPPER}} .crust-contact-form .wpcf7-text, {{WRAPPER}} .crust-contact-form .wpcf7-textarea, {{WRAPPER}} .crust-contact-form .wpcf7-select',

            ]
        );
	    /**
	     * Style Tab: Input & Textarea Normal Dark Mode
	     * -------------------------------------------------
	     */
	    $this->add_control(
		    'crust_contact_form_normal_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'field_dark_bg',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-text,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-date,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-textarea,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_control(
		    'field_text_dark_color',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-text,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-date,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-textarea,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-select,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-select' => 'color: {{VALUE}}',
			    ],

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'field_normal_dark_border',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',

			    'selector'    => 'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-text,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-date,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-textarea,body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-select',
		    ]
	    );


	    $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_fields_focus',
            [
                'label' => __('Focus', 'crust-core'),
            ]
        );

        $this->add_control(
            'field_bg_focus',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form input:focus, {{WRAPPER}} .crust-contact-form textarea:focus' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'        => 'input_border_focus',
                'label'       => __('Border', 'crust-core'),
                'placeholder' => '1px',
                'default'     => '1px',
                'selector'    => '{{WRAPPER}} .crust-contact-form input:focus, {{WRAPPER}} .crust-contact-form textarea:focus',

            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'focus_box_shadow',
                'selector'  => '{{WRAPPER}} .crust-contact-form input:focus, {{WRAPPER}} .crust-contact-form textarea:focus',

            ]
        );
	    /**
	     * Style Tab: Input & Textarea Focus Dark
	     * -------------------------------------------------
	     */
	    $this->add_control(
		    'crust_contact_form_focus_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'field_bg_dark_focus',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form input:focus,body.crust-dark {{WRAPPER}} .crust-contact-form textarea:focus' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'        => 'input_border_dark_focus',
			    'label'       => __('Border', 'crust-core'),
			    'placeholder' => '1px',
			    'selector'    => 'body.crust-dark {{WRAPPER}} .crust-contact-form input:focus,body.crust-dark {{WRAPPER}} .crust-contact-form textarea:focus',

		    ]
	    );

	    $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * Style Tab: Placeholder Section
         */
        $this->start_controls_section(
            'section_placeholder_style',
            [
                'label' => __('Placeholder', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'placeholder_switch',
            [
                'label'        => __('Show Placeholder', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'text_color_placeholder',
            [
                'label'     => __('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-form-control::-webkit-input-placeholder' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'placeholder_switch' => 'yes',
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'typography_placeholder',
                'label'     => __('Typography', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-contact-form .wpcf7-form-control::-webkit-input-placeholder',
                'condition' => [
                    'placeholder_switch' => 'yes',
                ],
            ]
        );
	    /**
	     * Style Tab: Placeholder Section Dark Mode
	     */
	    $this->add_control(
		    'text_color_placeholder_dark_head',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'dark_text_color_placeholder',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-form-control::-webkit-input-placeholder' => 'color: {{VALUE}}',
			    ],
			    'condition' => [
				    'placeholder_switch' => 'yes',
			    ],
		    ]
	    );

        $this->end_controls_section();
//
//        /**
//         * Style Tab: Radio & Checkbox
//         * -------------------------------------------------
//         */
//        $this->start_controls_section(
//            'section_radio_checkbox_color',
//            [
//                'label' => __('Radio & Checkbox color', 'crust-core'),
//                'tab'   => Controls_Manager::TAB_STYLE,
//            ]
//        );
//
//        $this->add_control(
//            'range_slider_color',
//            [
//                'label'     => __('Color', 'elementor'),
//                'type'      => Controls_Manager::COLOR,
//                'default'   => '',
//                'selectors' => [
//                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"], {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]' => 'background: {{VALUE}}',
//                ],
//            ]
//        );
//
//	    $this->end_controls_section();

        /**
         * Style Tab: Radio & Checkbox
         * -------------------------------------------------
         */
        $this->start_controls_section(
            'section_radio_checkbox_style',
            [
                'label' => __('Radio & Checkbox Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'custom_radio_checkbox',
            [
                'label'        => __('Custom Styles', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __('Yes', 'crust-core'),
                'label_off'    => __('No', 'crust-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_responsive_control(
            'radio_checkbox_size',
            [
                'label'      => __('Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'default'    => [
                    'size' => '15',
                    'unit' => 'px',
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 80,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"], {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
                ],
                'condition'  => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_radio_checkbox_style');

        $this->start_controls_tab(
            'radio_checkbox_normal',
            [
                'label'     => __('Normal', 'elementor'),
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'radio_checkbox_color',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:before, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:before' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'radio_checkbox_border_width',
            [
                'label'      => __('Border Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 15,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:before, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:before' => 'border-width: {{SIZE}}{{UNIT}}',
                ],
                'condition'  => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'radio_checkbox_border_color',
            [
                'label'     => __('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:before, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:before' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'checkbox_heading',
            [
                'label'     => __('Checkbox', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'checkbox_border_radius',
            [
                'label'      => __('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"], {{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'  => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'radio_heading',
            [
                'label'     => __('Radio Buttons', 'crust-core'),
                'type'      => Controls_Manager::HEADING,
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'radio_border_radius',
            [
                'label'      => __('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"], {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'  => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

	    /**
	     * Style Tab: Radio & Checkbox Normal Dark Mode
	     * -------------------------------------------------
	     */
	    $this->add_control(
		    'crust_normal_radio_checkbox_color_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
			    'condition'  => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );
	    $this->add_control(
		    'normal_radio_checkbox_dark_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"], body.crust-dark {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]' => 'background: {{VALUE}}',
			    ],
			    'condition' => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );
	    $this->add_control(
		    'normal_radio_checkbox_border_dark_color',
		    [
			    'label'     => __('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"], body.crust-dark {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]' => 'border-color: {{VALUE}}',
			    ],
			    'condition' => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'radio_checkbox_checked',
            [
                'label'     => __('Checked', 'crust-core'),
                'condition' => [
                    'custom_radio_checkbox' => 'yes',
                ],
            ]
        );

	    $this->add_control(
		    'radio_checkbox_fore_color',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:after, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:after' => 'color: {{VALUE}}',
			    ],
			    'condition' => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );

	    $this->add_control(
		    'radio_checkbox_color_checked',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:checked:before, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:checked:before' => 'background: {{VALUE}}',
			    ],
			    'condition' => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_checkbox_icon_size',
		    [
			    'label'      => esc_html__('Icon Size', 'crust-core'),
			    'type'       => Controls_Manager::SLIDER,
			    'default'    => [
				    'size' => 16,
				    'unit' => 'px',
			    ],
			    'size_units' => ['px'],
			    'range'      => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 100,
					    'step' => 1,
				    ],
			    ],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:after, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:after'   => 'font-size: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_checkbox_icon_margin',
		    [
			    'label'      => esc_html__('Icon Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors' => [
				    '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:after, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Text_Shadow::get_type(),
		    [
			    'name'     => 'crust_checkbox_icon_shadow',
			    'selector' => '{{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:after, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:after',
		    ]
	    );

	    $this->add_control(
		    'crust_checked_radio_checkbox_color_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'radio_checkbox_dark_color_checked',
		    [
			    'label'     => __('Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-custom-radio-checkbox input[type="checkbox"]:checked:before, {{WRAPPER}} .crust-custom-radio-checkbox input[type="radio"]:checked:before' => 'background: {{VALUE}}',
			    ],
			    'condition' => [
				    'custom_radio_checkbox' => 'yes',
			    ],
		    ]
	    );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        /**
         * Style Tab: Submit Button
         */
        $this->start_controls_section(
            'section_submit_button_style',
            [
                'label' => __('Submit Button', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'button_align',
	        [
		        'label'        => esc_html__('Alignment', 'elementor'),
		        'type'         => Controls_Manager::CHOOSE,
		        'options'      => [
                    '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
			        'flex-start'     => [
				        'title' => esc_html__('Left', 'crust-core'),
				        'icon'  => 'fa fa-align-left',
			        ],
			        'center' => [
				        'title' => esc_html__('Center', 'crust-core'),
				        'icon'  => 'fa fa-align-center',
			        ],
			        'flex-end'    => [
				        'title' => esc_html__('Right', 'crust-core'),
				        'icon'  => 'fa fa-align-right',
			        ],
		        ],
                'default'   => 'left',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-form-control.wpcf7-submit' => 'align-self: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_width_type',
            [
                'label'        => __('Width', 'elementor'),
                'type'         => Controls_Manager::SELECT,
                'options'      => [
                	''           => __('Default', 'crust-core'),
                    'full-width' => __('Full Width', 'crust-core'),
                    'custom'     => __('Custom', 'crust-core'),
                ],
            ]
        );

        $this->add_responsive_control(
            'button_width',
            [
                'label'      => __('Width', 'elementor'),
                'type'       => Controls_Manager::SLIDER,
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1200,
                        'step' => 1,
                    ],
                ],
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'width: {{SIZE}}{{UNIT}}',
                ],
                'condition'  => [
                    'button_width_type' => 'custom',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_button_style');

        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __('Normal', 'elementor'),
            ]
        );

        $this->add_control(
            'button_bg_color_normal',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_text_color_normal',
            [
                'label'     => __('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'button_border_normal',
                'label'    => __('Border', 'crust-core'),
                'default'  => '1px',
                'selector' => '{{WRAPPER}} .crust-contact-form .wpcf7-submit',
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label'      => __('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label'      => __('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_margin',
            [
                'label'      => __('Margin Top', 'crust-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'button_typography',
                'label'     => __('Typography', 'crust-core'),
                'selector'  => '{{WRAPPER}} .crust-contact-form .wpcf7-submit',
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'button_box_shadow',
                'selector'  => '{{WRAPPER}} .crust-contact-form .wpcf7-submit',
                'separator' => 'before',
            ]
        );
	    /**
	     * Style Tab: Submit Button Dark Mode Normal
	     */
	    $this->add_control(
		    'crust_normal_submit_button_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'button_bg_color_normal_dark',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control(
		    'button_text_color_normal_dark',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'button_border_normal_dark',
			    'label'    => __('Border', 'crust-core'),
			    'default'  => '1px',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit',
		    ]
	    );


	    $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'elementor'),
            ]
        );

        $this->add_control(
            'button_bg_color_hover',
            [
                'label'     => __('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_text_color_hover',
            [
                'label'     => __('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_border_color_hover',
            [
                'label'     => __('Border Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'border-color: {{VALUE}}',
                ],
            ]
        );
	    /**
	     * Style Tab: Submit Button Dark Mode Hover
	     */
	    $this->add_control(
		    'crust_hover_submit_button_dark',
		    [
			    'label'      => esc_html__('Dark Mode', 'crust-core'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );
	    $this->add_control(
		    'button_bg_color_hover_dark',
		    [
			    'label'     => __('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control(
		    'button_text_color_hover_dark',
		    [
			    'label'     => __('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control(
		    'button_border_color_hover_dark',
		    [
			    'label'     => __('Border Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-contact-form .wpcf7-submit:hover' => 'border-color: {{VALUE}}',
			    ],
		    ]
	    );


	    $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    protected function render()
    {
        if ( ! function_exists('wpcf7')) {
            return;
        }

        $settings = $this->get_settings_for_display();

        $class = 'crust-contact-form';

        if ( 'yes' === $settings['disable_wpautop'] ){
            add_filter('wpcf7_autop_or_not', '__return_false');
            $class .= ' crust-no-wpautop';
        }

        $this->add_render_attribute(
            'contact-form',
            'class',
            [
                $class,
                'crust-contact-form-' . esc_attr($this->get_id()),
            ]
        );

        if ($settings['placeholder_switch'] == 'yes') {
            $this->add_render_attribute('contact-form', 'class', 'placeholder-show');
        }

        if ($settings['custom_radio_checkbox'] == 'yes') {
            $this->add_render_attribute('contact-form', 'class', 'crust-custom-radio-checkbox');
        }

        if( $settings['button_width_type'] === 'full-width' ){
	        $this->add_render_attribute('contact-form', 'class', 'crust-contact-full-btn');
        }

        if ( ! empty($settings['contact_form_list'])) {
            $html = '<div class="crust-contact-form-7-wrapper">';
                $html .= '<div ' . $this->get_render_attribute_string('contact-form') . '>';

                    $html .= do_shortcode('[contact-form-7 id="' . $settings['contact_form_list'] . '" ]');

                $html .= '</div>';
            $html .= '</div>';

            echo $html;

        }
    }
}
