<?php
namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Widget_Base;

class Crust_Counter extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

	public function get_name() {
		return 'crust-counter';
	}

	public function get_title() {
		return esc_html__( 'Counter', 'crust-core' );
	}

	public function get_icon() {
		return 'eicon-counter';
	}

    public function get_script_depends() {
        return [ 'crust-counter' ];
    }

    public function get_style_depends() {
        do_action('enqueue_crust_assets','crust-counter', true, true);
        return [ 'crust-counter' ];
    }

    public function get_categories()
    {
        return ['crust'];
    }

	protected function register_controls() {

		$this->start_controls_section(
			'section_counter',
			[
				'label' => __( 'Counter', 'elementor' ),
			]
		);

		$this->add_control(
			'crust_counter_type',
			[
				'label'        => esc_html__('Type', 'crust-core'),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'left-icon-content',
				'label_block'  => false,
				'options'      => [
					'left-icon-content'   => esc_html__('Left Icon / Content', 'crust-core'),
					'right-icon-content'  => esc_html__('Right Icon / Content', 'crust-core'),
					'block-icon-content'  => esc_html__('Block Icon / Content', 'crust-core'),
					'content-icon-bottom' => esc_html__('Content / Bottom Icon', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'to_number',
			[
				'label' => __( 'Value', 'elementor' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 100,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'disable_decimals',
			[
				'label'        => esc_html__('Disable Decimals', 'crust-core'),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'prefix',
			[
				'label' => __( 'Prefix', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'placeholder' => 1,
			]
		);

		$this->add_control(
			'suffix',
			[
				'label' => __( 'Suffix', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'placeholder' => __( 'Plus', 'elementor' ),
			]
		);

        $this->crust_animations( 'counter_number' );

        $this->add_responsive_control(
            'counter_alignment',
            [
                'label'       => esc_html__('Alignment', 'elementor'),
                'type'        => Controls_Manager::CHOOSE,
                'options'     => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'flex-start' => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'flex-end'   => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'     => 'flex-start',
                'selectors' => [
	                '{{WRAPPER}} .crust-counter,{{WRAPPER}} .crust-counter-number-wrapper,{{WRAPPER}} .crust-counter-container' => 'justify-content: {{VALUE}};align-items: {{VALUE}};',
                    '{{WRAPPER}} .crust-counter.crust-block-icon' => 'align-items: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Counter Label', 'elementor' ),
				'placeholder' => __( 'Counter Label', 'elementor' ),
                'separator' => 'before'
			]
		);

		$this->add_control(
			'title_inline',
			[
				'label'         => esc_html__('Inline Title ?', 'crust-core'),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => esc_html__( 'YES', 'crust-core' ),
				'label_off'     => esc_html__( 'NO', 'crust-core' ),
				'return_value'  => 'yes',
				'default'       => 'yes',
			]
		);

		$this->add_control(
			'title_before',
			[
				'label'         => esc_html__('Before Number ?', 'crust-core'),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => esc_html__( 'YES', 'crust-core' ),
				'label_off'     => esc_html__( 'NO', 'crust-core' ),
				'return_value'  => 'yes',
			]
		);

        $this->crust_animations( 'counter_title' );




		$this->end_controls_section();

        $this->start_controls_section(
            'section_counter_icon',
            [
                'label' => __( 'Icon', 'elementor' ),
            ]
        );

        $this->add_control(
            'counter_icon',
            [
                'label' => esc_html__('Icon', 'elementor'),
                'type'  => Controls_Manager::ICONS,
            ]
        );

        $this->add_responsive_control(
            'counter_icon_size',
            [
                'label'      => esc_html__('Icon Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'rem', 'em'],
                'default'    => [
                    'size' => 40,
                    'unit' => 'px',
                ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'counter_icon[value]!' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-counter-icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-counter-icon img' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'counter_icon_block_alignment',
			[
				'label'       => esc_html__('Alignment', 'elementor'),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'' => [
						'title' => __('Default', 'crust-core'),
						'icon'  => 'fa fa-ban',
					],
					'flex-start' => [
						'title' => esc_html__('Left', 'crust-core'),
						'icon'  => 'eicon-h-align-left',
					],
					'center'     => [
						'title' => esc_html__('Center', 'crust-core'),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'   => [
						'title' => esc_html__('Right', 'crust-core'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'condition'     => [
					'crust_counter_type' => ['block-icon-content','content-icon-bottom'],
				],
				'selectors'   => [
					'{{WRAPPER}} .crust-counter.crust-block-icon-content .crust-counter-icon' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .crust-counter.crust-content-icon-bottom .crust-counter-icon' => 'align-self: {{VALUE}};justify-content: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'counter_icon_alignment',
            [
                'label'     => esc_html__('Icon Position', 'elementor'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__('Before', 'crust-core'),
                    'right' => esc_html__('After', 'crust-core'),
                ],
                'condition' => [
                    'counter_icon[value]!' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'counter_icon_indent',
            [
                'label'     => esc_html__('Icon Spacing', 'elementor'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 60,
                    ],
                ],
                'condition' => [
                    'counter_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-counter-icon-right' => 'margin-left: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-counter-icon-left'  => 'margin-right: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-counter.crust-block-icon .crust-counter-icon'  => 'margin-bottom: {{SIZE}}px;',
                ],
            ]
        );

        $this->crust_animations( 'counter_icon' );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_number',
            [
                'label' => __( 'Number', 'elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'number_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#19D0D6',
				'selectors' => [
					'{{WRAPPER}} .crust-counter-number-wrapper' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_number',
				'selector' => '{{WRAPPER}} .crust-counter-number-wrapper',
			]
		);

		$this->add_responsive_control(
			'crust_number_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter-number-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_dark_number',
			[
				'label'      => esc_html__('Dark mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'number_dark_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#19D0D6',
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter-number-wrapper' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'section_prefix',
            [
                'label' => __( 'Prefix', 'elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'prefix_color',
            [
                'label' => __( 'Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter-number-prefix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography_prefix',
                'selector' => '{{WRAPPER}} .crust-counter-number-prefix',
            ]
        );

		$this->add_responsive_control(
			'crust_prefix_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter-number-prefix' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'section_dark_prefix',
			[
				'label'      => esc_html__('Dark Mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'prefix_dark_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter-number-prefix' => 'color: {{VALUE}};',
				],
			]
		);



        $this->end_controls_section();

        $this->start_controls_section(
            'section_suffix',
            [
                'label' => __( 'Suffix', 'elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'suffix_color',
            [
                'label' => __( 'Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter-number-suffix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography_suffix',
                'selector' => '{{WRAPPER}} .crust-counter-number-suffix',
            ]
        );

		$this->add_responsive_control(
			'crust_suffix_margin',
			[
				'label'      => esc_html__('Margin', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter-number-suffix' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_dark_suffix',
			[
				'label'      => esc_html__('Dark Mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'suffix_dark_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter-number-suffix' => 'color: {{VALUE}};',
				],
			]
		);




        $this->end_controls_section();

		$this->start_controls_section(
			'number_title',
			[
				'label' => __( 'Title', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'crust_title_tag',
			[
				'label'       => esc_html__('HTML Tag', 'crust-core'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'div',
				'label_block' => false,
				'options'     => [
					'h1' => esc_html__('H1', 'crust-core'),
					'h2' => esc_html__('H2', 'crust-core'),
					'h3' => esc_html__('H3', 'crust-core'),
					'h4' => esc_html__('H4', 'crust-core'),
					'h5' => esc_html__('H5', 'crust-core'),
					'h6' => esc_html__('H6', 'crust-core'),
					'p' => esc_html__('p', 'crust-core'),
					'div' => esc_html__('div', 'crust-core'),
					'span' => esc_html__('span', 'crust-core'),
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .crust-counter-title' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'title_bg_color',
            [
                'label' => __( 'Background Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_title_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-counter-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_title_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-counter-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_title_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-counter-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_title',
				'selector' => '{{WRAPPER}} .crust-counter-title',
			]
		);


		$this->add_responsive_control(
			'number_dark_title',
			[
				'label'      => esc_html__('Dark Mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'title_dark_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_bg_dark_color',
			[
				'label' => __( 'Background Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter-title' => 'background-color: {{VALUE}};',
				],
			]
		);






		$this->end_controls_section();


        /**
         * -------------------------------------------
         * Tab Style (Icon Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_counter_icon_style_settings',
            [
                'label'     => esc_html__('Icon Style', 'crust-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'counter_icon[value]!' => '',
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_counter_icon_bg_size',
            [
                'label'     => __('Size', 'crust-core'),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 40,
                ],
                'range'     => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 300,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-counter .crust-counter-icon' => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
                    '{{WRAPPER}} .crust-counter-icon i' => 'line-height: {{SIZE}}px;'
                ]
            ]
        );

		$this->add_responsive_control(
			'crust_counter_icon_padding',
			[
				'label'      => esc_html__('Padding', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter .crust-counter-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);

        $this->add_responsive_control(
            'crust_counter_icon_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-counter .crust-counter-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->start_controls_tabs('crust_counter_icon_style_controls');

        $this->start_controls_tab(
            'crust_counter_icon_normal',
            [
                'label' => esc_html__('Normal', 'elementor'),
            ]
        );

        $this->add_control(
            'crust_counter_icon_color',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter .crust-counter-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'crust_counter_icon_bg_color',
                'types'     => ['classic', 'gradient'],
                'default'   => 'classic',
                'selector'  => '{{WRAPPER}} .crust-counter .crust-counter-icon',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_counter_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-counter .crust-counter-icon'
            ]
        );

		$this->add_responsive_control(
			'crust_counter_icon_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter .crust-counter-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_counter_icon_shadow',
                'selector' => '{{WRAPPER}} .crust-counter .crust-counter-icon',
            ]
        );



		$this->add_responsive_control(
			'crust_section_counter_icon_style_dark_settings',
			[
				'label'      => esc_html__('Dark Mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'crust_counter_icon_dark_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter .crust-counter-icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'crust_counter_icon_bg_dark_color',
				'types'     => ['classic', 'gradient'],
				'default'   => 'classic',
				'selector'  => 'body.crust-dark {{WRAPPER}} .crust-counter .crust-counter-icon',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_counter_icon_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-counter .crust-counter-icon'
			]
		);

        $this->end_controls_tab();


        $this->start_controls_tab(
            'crust_counter_icon_hover',
            [
                'label' => esc_html__('Hover', 'elementor'),
            ]
        );

        $this->add_control(
            'crust_counter_icon_hover_color',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter:hover .crust-counter-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_counter_icon_hover_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-counter:hover .crust-counter-icon' => 'background: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_counter_hover_icon_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-counter:hover .crust-counter-icon'
            ]
        );

		$this->add_responsive_control(
			'crust_counter_hover_icon_radius',
			[
				'label'      => esc_html__('Border Radius', 'elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .crust-counter:hover .crust-counter-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_counter_icon_hover_shadow',
                'selector' => '{{WRAPPER}} .crust-counter:hover .crust-counter-icon',
            ]
        );


		$this->add_responsive_control(
			'crust_counter_icon_dark_hover',
			[
				'label'      => esc_html__('Dark Mode', 'elementor'),
				'type'       => Controls_Manager::HEADING,
				'separator'   => 'before',

			]
		);
		$this->add_control(
			'crust_counter_icon_hover_dark_color',
			[
				'label'     => esc_html__('Icon Color', 'crust-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter:hover .crust-counter-icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'crust_counter_icon_hover_bg_dark_color',
			[
				'label'     => esc_html__('Background Color', 'elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'body.crust-dark {{WRAPPER}} .crust-counter:hover .crust-counter-icon' => 'background: {{VALUE}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'crust_counter_hover_icon_dark_border',
				'label'    => esc_html__('Border', 'crust-core'),
				'selector' => 'body.crust-dark {{WRAPPER}} .crust-counter:hover .crust-counter-icon'
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
		

	}

	protected function render()
    {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute( 'counter', [
			'class' => 'crust-counter-number odometer',
			'data-to-value' => $settings['to_number'],
		] );

		if( $settings['disable_decimals'] ){
			$this->add_render_attribute( 'counter', [
				'class' => 'odo-disable-commas',
			] );
		}

		$this->add_render_attribute( 'counter_title', 'class', 'crust-counter-title' );
        $this->crust_animation_attributes( 'counter_title' );



	    $wraper_class = ' crust-' . $settings['crust_counter_type'];

        $this->add_render_attribute( 'counter-wraper', 'class', [
            'crust-counter',
            $wraper_class
        ]);

	    if( $settings['title_before'] == 'yes' ){
		    $this->add_render_attribute( 'counter-wraper', 'class', 'crust-counter-title-first' );
	    }

        $this->add_render_attribute( 'counter_number', 'class', [
            'crust-counter-number-wrapper',
        ]);

	    $cont_class  = ( 'yes' === $settings['title_inline'] ) ? 'crust-title-inline' : '';

	    $this->add_render_attribute( 'counter_container', 'class', [
		    'crust-counter-container',
		    $cont_class
	    ]);

	    $title_tag = $settings['crust_title_tag'];

        $this->crust_animation_attributes( 'counter_number' );

        $iconoutput = '';
        $icondir    = $settings['counter_icon_alignment'];
        $iconclass  = 'crust-counter-icon';
        $iconclass .= ' crust-counter-icon-'.$icondir;

        $this->add_render_attribute( 'counter_icon', 'class', [
            $iconclass
        ]);

        $this->crust_animation_attributes( 'counter_icon' );

        if (isset($settings['counter_icon']['value']['url'])) {
            $iconoutput = '<div '. $this->get_render_attribute_string( 'counter_icon' ) .'><img src="'. esc_attr($settings['counter_icon']['value']['url']) .'" alt="'.esc_attr(get_post_meta($settings['counter_icon']['value']['id'], '_wp_attachment_image_alt', true)) .'"></div>';
        } else {
            $iconoutput = ( ! empty($settings['counter_icon']['value'])) ? '<div '. $this->get_render_attribute_string( 'counter_icon' ) .'><i class="'. esc_attr($settings['counter_icon']['value']) .'"></i></div>' : '';
        }

		$html = '<div '. $this->get_render_attribute_string( 'counter-wraper' ) .'>';

            $html .= ( $icondir === 'left' ) ? $iconoutput : '';

            $html .= '<div '.$this->get_render_attribute_string( 'counter_container' ).'>';

                $html .= '<div '. $this->get_render_attribute_string( 'counter_number' ) .'>';
                    $html .= '<span class="crust-counter-number-prefix">'. $settings['prefix'] .'</span>';
                    $html .= '<span '. $this->get_render_attribute_string( 'counter' ) .'></span>';
                    $html .= '<span class="crust-counter-number-suffix">'. $settings['suffix'] .'</span>';
                $html .= '</div>';

                $html .= ( $settings['title'] ) ? '<'.$title_tag. ' ' . $this->get_render_attribute_string( 'counter_title' ) .'>'. $settings['title'] .'</'.$title_tag.'>' : '';

            $html .= '</div>';

            $html .= ( $icondir === 'right' ) ? $iconoutput : '';

		$html .= '</div>';

		echo $html;

	}
}
