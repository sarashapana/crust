<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;

class Crust_Section_Divider extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_name()
    {
        return 'crust-section-divider';
    }

    public function get_title()
    {
        return esc_html__('Section Divider', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'crust_section_divider_content',
            [
                'label' => esc_html__('General Settings', 'crust-core'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

	    $this->crust_divider_settings();

        $this->end_controls_section();

    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();

	    $style = $settings['div_style'];
	    $layers = $settings['layers_no'];

	    $class = 'crust-divider';
	    $class .= ( 'yes' === $settings['flip_horizontal'] ) ? ' crust-horizontal-flip'  : '';
	    $class .= ( 'yes' === $settings['flip_vertical'] )   ? ' crust-vertical-flip'    : '';
	    $class .= ( 'yes' === $settings['full_width'] )      ? ' full-divider'           : '';
	    $class .= ( $style ) ? ' crust-divider-' . $style : '';

	    $f_col = ( $settings['layer_1_color'] === '' ) ? '#ff5b4a' : $settings['layer_1_color'];
	    $s_col = ( $settings['layer_2_color'] === '' ) ? '#2f39d3' : $settings['layer_2_color'];
	    $first_color = ( $style == 'style0' || $style == 'style1' ) ? $f_col : '';
	    $second_color = ( $style == 'style0' || $style == 'style1' ) ? $s_col : '';

	    $html = apply_filters('crust_ele_divider_site_markup',$style, $layers, $class, $first_color, $second_color);
		 echo $html;
    }
}
