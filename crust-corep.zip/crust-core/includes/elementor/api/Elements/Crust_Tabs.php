<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;
use \Elementor\Group_Control_Background;

class Crust_Tabs extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        do_action('enqueue_crust_assets','crust-tabs', true, true);
        return ['crust-tabs'];
    }

    public function get_style_depends()
    {
        return ['tabs'];
    }

    public function get_name()
    {
        return 'crust-tabs';
    }

    public function get_title()
    {
        return esc_html__('Tabs', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-tabs';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        /**
         * Tabs Settings
         */
        $this->start_controls_section(
            'crust_section_tabs_settings',
            [
                'label' => esc_html__('General Settings', 'crust-core'),
            ]
        );
        $this->add_control(
            'crust_tab_layout',
            [
                'label'       => esc_html__('Layout', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'crust-tabs-horizontal',
                'label_block' => false,
                'options'     => [
                    'crust-tabs-horizontal' => esc_html__('Horizontal', 'crust-core'),
                    'crust-tabs-vertical'   => esc_html__('Vertical', 'crust-core'),
                ],
            ]
        );

	    $this->add_control(
		    'mode',
		    [
			    'label'       => esc_html__('Style', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
			    'options'     => [
				    '' => esc_html__('Normal', 'crust-core'),
				    'creative'   => esc_html__('Creative', 'crust-core'),
			    ],
			    'condition'    => [
				    'crust_tab_layout' => 'crust-tabs-horizontal'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_tabs_sticky',
		    [
			    'label'        => esc_html__('Sticky ?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'return_value' => 'yes',
			    'condition'    => [
				    'crust_tab_layout' => 'crust-tabs-vertical'
			    ]
		    ]
	    );

        $this->add_control(
            'crust_tabs_full',
            [
                'label'        => esc_html__('Full Width', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'condition'    => [
                    'crust_tab_layout' => 'crust-tabs-horizontal'
                ]
            ]
        );

        $this->add_control(
            'crust_tabs_icon_show',
            [
                'label'        => esc_html__('Enable Icon', 'crust-core'),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'crust_tab_icon_position',
            [
                'label'       => esc_html__('Icon Position', 'elementor'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'crust-tab-inline-icon',
                'label_block' => false,
                'options'     => [
                    'crust-tab-top-icon'    => esc_html__('Block', 'crust-core'),
                    'crust-tab-inline-icon' => esc_html__('Inline', 'crust-core'),
                ],
                'condition'   => [
                    'crust_tabs_icon_show' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Tabs Content Settings
         */
        $this->start_controls_section(
            'crust_section_tabs_content_settings',
            [
                'label' => esc_html__('Content', 'crust-core'),
            ]
        );

	    $repeater = new \Elementor\Repeater();

	    $repeater->add_control(
		    'crust_tabs_tab_show_as_default', [
			    'label'        => __('Set as Default', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'inactive',
			    'return_value' => 'active',
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_icon_type', [
			    'label'       => esc_html__('Icon Type', 'crust-core'),
			    'type'        => Controls_Manager::CHOOSE,
			    'label_block' => false,
			    'options'     => [
				    'none'  => [
					    'title' => esc_html__('None', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'icon'  => [
					    'title' => esc_html__('Icon', 'elementor'),
					    'icon'  => 'fa fa-star',
				    ],
				    'image' => [
					    'title' => esc_html__('Image', 'crust-core'),
					    'icon'  => 'fa fa-picture-o',
				    ],
			    ],
			    'default'     => 'icon',
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_tab_title_icon', [
			    'label'            => esc_html__('Icon', 'elementor'),
			    'type'             => Controls_Manager::ICONS,
			    'default'          => [
				    'value'   => 'fas fa-home',
				    'library' => 'fa-solid',
			    ],
			    'condition'        => [
				    'crust_tabs_icon_type' => 'icon',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_tab_title_image', [
			    'label'     => esc_html__('Image', 'crust-core'),
			    'type'      => Controls_Manager::MEDIA,
			    'condition' => [
				    'crust_tabs_icon_type' => 'image',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_tab_title', [
			    'label'   => esc_html__('Tab Title', 'crust-core'),
			    'type'    => Controls_Manager::TEXT,
			    'default' => esc_html__('Tab Title', 'crust-core'),
			    'dynamic' => ['active' => true],
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_text_type', [
			    'label'   => __('Content Type', 'crust-core'),
			    'type'    => Controls_Manager::SELECT,
			    'options' => [
				    'content'  => __('Content', 'crust-core'),
				    'template' => __('Saved Templates', 'crust-core'),
			    ],
			    'default' => 'content',
		    ]
	    );

	    $repeater->add_control(
		    'crust_core_primary_templates', [
			    'label'     => __('Choose Template', 'crust-core'),
			    'type'      => Controls_Manager::SELECT,
			    'options'   => $this->crust_core_get_page_templates(),
			    'condition' => [
				    'crust_tabs_text_type' => 'template',
			    ],
		    ]
	    );

	    $repeater->add_control(
		    'crust_tabs_tab_content', [
			    'label'     => esc_html__('Tab Content', 'crust-core'),
			    'type'      => Controls_Manager::WYSIWYG,
			    'default'   => esc_html__(
				    'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio, neque qui velit. Magni dolorum quidem ipsam eligendi, totam, facilis laudantium cum accusamus ullam voluptatibus commodi numquam, error, est. Ea, consequatur.',
				    'crust-core'
			    ),
			    'dynamic'   => ['active' => true],
			    'condition' => [
				    'crust_tabs_text_type' => 'content',
			    ],
		    ]
	    );


        $this->add_control(
            'crust_tabs_tab',
            [
                'type'        => Controls_Manager::REPEATER,
                'seperator'   => 'before',
                'default'     => [
                    ['crust_tabs_tab_title' => esc_html__('Design', 'crust-core')],
                    ['crust_tabs_tab_title' => esc_html__('Development', 'crust-core')],
                    ['crust_tabs_tab_title' => esc_html__('Marketing', 'crust-core')],
                ],
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{crust_tabs_tab_title}}',
            ]
        );
        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style Tabs Generel Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_tabs_style_settings',
            [
                'label' => esc_html__('Tabs Wrapper Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_control(
		    'tab_position',
		    [
			    'label'       => esc_html__('Position', 'crust-core'),
			    'type'        => Controls_Manager::SELECT,
			    'label_block' => false,
				'default'     => 'top',
			    'options'     => [
				    'top'    => esc_html__('Top', 'crust-core'),
				    'bottom' => esc_html__('Bottom', 'crust-core'),
			    ],
			    'condition'    => [
				    'crust_tab_layout' => 'crust-tabs-horizontal'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_tabs_inline',
		    [
			    'label'        => esc_html__('Inline ?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_tabs_tab_alignment',
		    [
			    'label'       => esc_html__('Alignment', 'elementor'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
				    '' => [
					    'title' => __('Default', 'crust-core'),
					    'icon'  => 'fa fa-ban',
				    ],
				    'flex-start' => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'     => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'   => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors'   => [
				    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul' => 'justify-content: {{VALUE}};',
			    ],
			    'condition'  => [
				    'crust_tab_layout' => 'crust-tabs-horizontal',
				    'crust_tabs_inline!' => 'yes',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_tabs_tab_inline_alignment',
		    [
			    'label'       => esc_html__('Alignment', 'elementor'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
				    'flex-start' => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'     => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'   => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors'   => [
				    '{{WRAPPER}} .crust-tabs .crust-tabs-nav' => 'align-self: {{VALUE}};',
			    ],
			    'condition'  => [
				    'crust_tab_layout' => 'crust-tabs-horizontal',
				    'crust_tabs_inline' => 'yes',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'crust_tabs_vartical_alignment',
		    [
			    'label'       => esc_html__('Alignment', 'elementor'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
				    'flex-start' => [
					    'title' => esc_html__('Top', 'crust-core'),
					    'icon'  => 'fa fa-long-arrow-up',
				    ],
				    'center'     => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'fa fa-minus',
				    ],
				    'flex-end'   => [
					    'title' => esc_html__('Bottom', 'crust-core'),
					    'icon'  => 'fa fa-long-arrow-down',
				    ],
			    ],
			    'selectors'   => [
				    '{{WRAPPER}} .crust-tabs.crust-tabs-vertical' => 'align-items: {{VALUE}};',
			    ],
			    'condition'  => [
				    'crust_tab_layout' => 'crust-tabs-vertical',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_tabs_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_tabs_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_tabs_wrap_bgtype',
			    'types'    => ['classic', 'gradient'],
			    'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav'
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_tabs_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav',
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'crust_tabs_box_shadow',
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav',
            ]
        );
	    $this->add_responsive_control(
		    'crust_section_tabs_style_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_tabs_wrap_dark_bgtype',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav'
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_tabs_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav',
		    ]
	    );
        $this->end_controls_section();
        /**
         * -------------------------------------------
         * Tab Style Tabs Content Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_tabs_tab_style_settings',
            [
                'label' => esc_html__('Tab Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'crust_tabs_tab_li_alignment',
		    [
			    'label'       => esc_html__('Alignment', 'elementor'),
			    'type'        => Controls_Manager::CHOOSE,
			    'options'     => [
					'' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
				    'flex-start' => [
					    'title' => esc_html__('Left', 'crust-core'),
					    'icon'  => 'eicon-h-align-left',
				    ],
				    'center'     => [
					    'title' => esc_html__('Center', 'crust-core'),
					    'icon'  => 'eicon-h-align-center',
				    ],
				    'flex-end'   => [
					    'title' => esc_html__('Right', 'crust-core'),
					    'icon'  => 'eicon-h-align-right',
				    ],
			    ],
			    'selectors'   => [
				    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'justify-content: {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_tabs_tab_title_typography',
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li span.crust-tab-title',
                'fields_options' => [
	                'font_weight' => ['default' => '600'],
	                'font_family' => ['default' => 'Poppins'],
                ],
            ]
        );


        $this->add_responsive_control(
            'crust_tabs_title_width',
            [
                'label'      => __('Title Min Width', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs.crust-tabs-vertical .crust-tabs-nav > ul' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'crust_tab_layout' => 'crust-tabs-vertical',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_tabs_tab_icon_size',
            [
                'label'      => __('Icon Size', 'crust-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 200,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'crust_tabs_tab_icon_margin',
		    [
			    'label'      => esc_html__('Icon Margin', 'elementor'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li i, {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'crust_tabs_tab_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_tab_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('crust_tabs_header_tabs');
        // Normal State Tab
        $this->start_controls_tab('crust_tabs_header_normal', ['label' => esc_html__('Normal', 'elementor')]);
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'crust_tabs_tab_bgtype',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li'
            ]
        );
        $this->add_control(
            'crust_tabs_tab_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'crust_tabs_tab_icon_color',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_tabs_icon_show' => 'yes',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_tabs_tab_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li',
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_tab_border_radius',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_box_shadow',
			    'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_section_tabs_tab_style_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_control(
		    'crust_tabs_tab_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_tabs_tab_icon_dark_color',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_tabs_icon_show' => 'yes',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li',
		    ]
	    );
        $this->end_controls_tab();
        // Hover State Tab
        $this->start_controls_tab('crust_tabs_header_hover', ['label' => esc_html__('Hover', 'elementor')]);
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'crust_tabs_tab_bgtype_hover',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover'
            ]
        );
        $this->add_control(
            'crust_tabs_tab_text_color_hover',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#333',
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'crust_tabs_tab_icon_color_hover',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover > i' => 'color: {{VALUE}};'
                ],
                'condition' => [
                    'crust_tabs_icon_show' => 'yes',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_tabs_tab_border_hover',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover',
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_tab_border_radius_hover',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_box_shadow_hover',
			    'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_tabs_header_dark_hover',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_bgtype_dark_hover',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover'
		    ]
	    );
	    $this->add_control(
		    'crust_tabs_tab_text_color_dark_hover',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#333',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_tabs_tab_icon_color_dark_hover',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover > i' => 'color: {{VALUE}};'
			    ],
			    'condition' => [
				    'crust_tabs_icon_show' => 'yes',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_border_dark_hover',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li:hover',
		    ]
	    );
	    $this->end_controls_tab();
        // Active State Tab
        $this->start_controls_tab('crust_tabs_header_active', ['label' => esc_html__('Active', 'crust-core')]);
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'crust_tabs_tab_bgtype_active',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active, {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider'
            ]
        );
        $this->add_control(
            'crust_tabs_tab_text_color_active',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#333',
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li.active .crust-tab-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'crust_tabs_tab_icon_color_active',
            [
                'label'     => esc_html__('Icon Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#19D0D6',
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li.active > i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'crust_tabs_icon_show' => 'yes',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_tabs_tab_border_active',
                'label'    => esc_html__('Border', 'crust-core'),
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '0',
                            'right' => '0',
                            'bottom' => '3',
                            'left' => '0',
                            'isLinked' => false,
                        ],
                    ],
                    'color' => [
	                    'default'   => '#19D0D6',
                    ],
                ],
                'selector' => '{{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active, {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider',
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_tab_border_radius_active',
            [
                'label'      => esc_html__('Border Radius', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active, {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider'         => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_box_shadow_active',
			    'selector' => '{{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active, {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider',
		    ]
	    );
	    $this->add_responsive_control(
		    'crust_tabs_header_dark_active',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_bgtype_dark_active',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active,body.crust-dark  {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider'
		    ]
	    );
	    $this->add_control(
		    'crust_tabs_tab_text_color_dark_active',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#333',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li.active .crust-tab-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'crust_tabs_tab_icon_color_dark_active',
		    [
			    'label'     => esc_html__('Icon Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,

			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-nav > ul li.active > i' => 'color: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_tabs_icon_show' => 'yes',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_tabs_tab_border_dark_active',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'fields_options' => [
				    'border' => [

				    ],
				    'width' => [
					    'default' => [
						    'top' => '0',
						    'right' => '0',
						    'bottom' => '3',
						    'left' => '0',
						    'isLinked' => false,
					    ],
				    ],
				    'color' => [
				    ],
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs:not(.crust-tabs-creative) .crust-tabs-nav > ul li.active, {{WRAPPER}} .crust-tabs.crust-tabs-creative .crust-tabs-slider',
		    ]
	    );
        $this->end_controls_tab();
        $this->end_controls_tabs();




        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style Tabs Content Style
         * -------------------------------------------
         */
        $this->start_controls_section(
            'crust_section_tabs_tab_content_style_settings',
            [
                'label' => esc_html__('Content', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'adv_tabs_content_bg_color',
            [
                'label'     => esc_html__('Background Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'adv_tabs_content_bgtype',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-content > div'
            ]
        );
        $this->add_control(
            'adv_tabs_content_text_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_tabs_content_typography',
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-content > div',
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_content_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'crust_tabs_content_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_tabs_content_border',
                'label'    => esc_html__('Border', 'crust-core'),
                'selector' => '{{WRAPPER}} .crust-tabs .crust-tabs-content > div',
            ]
        );
	    $this->add_responsive_control(
		    'crust_tabs_content_radius',
		    [
			    'label'      => esc_html__('Border radius', 'crust-core'),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%'],
			    'selectors'  => [
				    '{{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'crust_tabs_content_shadow',
                'selector'  => '{{WRAPPER}} .crust-tabs .crust-tabs-content > div',
                'separator' => 'before',
            ]
        );

	    $this->add_responsive_control(
		    'crust_section_tabs_tab_content_style_dark_settings',
		    [
			    'label'      => esc_html__(' Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'   => 'before',

		    ]
	    );
	    $this->add_control(
		    'adv_tabs_content_bg_dark_color',
		    [
			    'label'     => esc_html__('Background Color', 'elementor'),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '',
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'adv_tabs_content_dark_bgtype',
			    'types'    => ['classic', 'gradient'],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-content > div'
		    ]
	    );
	    $this->add_control(
		    'adv_tabs_content_text_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-content > div' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_tabs_content_dark_border',
			    'label'    => esc_html__('Border', 'crust-core'),
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-tabs .crust-tabs-content > div',
		    ]
	    );
        $this->end_controls_section();

    }

    protected function render()
    {

        $settings             = $this->get_settings_for_display();
	    $tab_style            = ( $settings['mode'] && $settings['crust_tab_layout'] == 'crust-tabs-horizontal' ) ? ' crust-tabs-' . $settings['mode'] : '';
        $fulltabs             = ( 'yes' === $settings['crust_tabs_full'] ) ? 'crust-full-tabs' : '';
	    $sticktabs            = ( 'yes' === $settings['crust_tabs_sticky'] ) ? 'crust-sticky-tabs' : '';

        $this->add_render_attribute(
            'crust_core_tab_wrapper',
            [
                'id'         => "crust-tabs-{$this->get_id()}",
                'class'      => [
                    'crust-tabs',
                    $fulltabs,
	                $sticktabs,
	                $tab_style,
                    $settings['crust_tab_layout']
                ],
                'data-tabid' => $this->get_id(),
            ]
        );


        $this->add_render_attribute('crust_core_tab_icon_position', 'class', esc_attr($settings['crust_tab_icon_position']));

        $html = '<div '. $this->get_render_attribute_string('crust_core_tab_wrapper'). '>';

		$html .= ( $settings['tab_position'] == 'top' || $settings['crust_tab_layout'] == 'crust-tabs-vertical' ) ? $this->_render_nav() : '';

            $html .= '<div class="crust-tabs-content">';
                foreach ($settings['crust_tabs_tab'] as $tab) {
                    $html .= '<div class="crust-tab-element clearfix '. esc_attr($tab['crust_tabs_tab_show_as_default']) .'">';
                        if ('content' == $tab['crust_tabs_text_type']) {
                            $html .= do_shortcode($tab['crust_tabs_tab_content']);
                        } elseif ('template' == $tab['crust_tabs_text_type']){
                            if ( ! empty($tab['crust_core_primary_templates'])) {
                                $crust_core_template_id = $tab['crust_core_primary_templates'];
                                $crust_core_frontend    = new Frontend;
                                $html .= $crust_core_frontend->get_builder_content($crust_core_template_id, true);
                            }
                        }
                    $html .= ' </div >';
                }
            $html .= '</div>';

	        $html .= ( $settings['tab_position'] == 'bottom' ) ? $this->_render_nav() : '';

        $html .= '</div>';

        echo $html;

    }

	public function _render_nav(){

		$settings = $this->get_settings_for_display();

		$nav_class = 'crust-tabs-nav';
		$nav_class .= ( $settings['crust_tabs_inline'] === 'yes' ) ? ' crust-tabs-inline-nav' : '';

		$html = '<div class="'. esc_attr($nav_class) .'">';
		$html .= ( $settings['mode'] && $settings['crust_tab_layout'] == 'crust-tabs-horizontal' ) ? '<div class="crust-tabs-slider"></div>' : '';
		$html .= '<ul '. $this->get_render_attribute_string('crust_core_tab_icon_position').'>';
		foreach ($settings['crust_tabs_tab'] as $tab) {
			$html .= '<li class="crust-tab-item-li '. esc_attr($tab['crust_tabs_tab_show_as_default']).'">';
			if ($settings['crust_tabs_icon_show'] === 'yes'){
				if ($tab['crust_tabs_icon_type'] === 'icon'){
					if ($tab['crust_tabs_tab_title_icon']) {
						if (isset($tab['crust_tabs_tab_title_icon']['value']['url'])) {
							$html .= '<img src="' . $tab['crust_tabs_tab_title_icon']['value']['url'] . '"/>';
						} else {
							$html .= '<i class="' . $tab['crust_tabs_tab_title_icon']['value'] . '"></i>';
						}
					}
				} elseif ($tab['crust_tabs_icon_type'] === 'image') {
					$html .= '<img src="'. esc_attr($tab['crust_tabs_tab_title_image']['url']). '" alt="'. esc_attr(get_post_meta($tab['crust_tabs_tab_title_image']['id'], '_wp_attachment_image_alt', true)) .'">';
				}
			}
			$html .= '<span class="crust-tab-title">'. $tab['crust_tabs_tab_title'] .'</span>';
			$html .= '</li>';
		}
		$html .= '</ul>';
		$html .= '</div>';

		return $html;

	}

}
