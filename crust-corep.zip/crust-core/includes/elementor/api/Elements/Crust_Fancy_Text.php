<?php

namespace Crust_Core\Elements;

use \Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Widget_Base;
use \Elementor\Repeater;

class Crust_Fancy_Text extends Widget_Base
{

    use \Crust_Core\Traits\Helper;

    public function get_script_depends()
    {
        return ['crust-fancy-text'];
    }

    public function get_style_depends()
    {
        do_action('enqueue_crust_assets','crust-fancy-text', true, true);
        return ['animatedheadline', 'crust-fancy-text'];
    }

    public function get_name()
    {
        return 'crust-fancy-text';
    }

    public function get_title()
    {
        return esc_html__('Rotating Text', 'crust-core');
    }

    public function get_icon()
    {
        return 'eicon-animation-text';
    }

    public function get_categories()
    {
        return ['crust'];
    }

    protected function register_controls()
    {
        // Content Controls
        $this->start_controls_section(
            'crust_fancy_text_content',
            [
                'label' => esc_html__('Content', 'crust-core')
            ]
        );


        $this->add_control(
            'crust_fancy_text_prefix',
            [
                'label'       => esc_html__('Prefix', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__('Here is the ', 'crust-core'),
                'dynamic'     => ['active' => true]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'crust_text_strings',
            [
                'label'       => esc_html__('Strings', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => ['active' => true]
            ]
        );

        $this->add_control(
            'crust_fancy_text_strings',
            [
                'label'       => esc_html__('Strings', 'crust-core'),
                'type'        => Controls_Manager::REPEATER,
                'show_label'  => true,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ crust_text_strings }}}',
                'default'     => [
                    [
                        'crust_text_strings' => __('First string', 'crust-core'),
                    ],
                    [
                        'crust_text_strings' => __('Second string', 'crust-core'),
                    ],
                    [
                        'crust_text_strings' => __('Third string', 'crust-core'),
                    ]
                ],
            ]
        );

        $this->add_control(
            'crust_fancy_text_suffix',
            [
                'label'       => esc_html__('Suffix Text', 'crust-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__(' of the sentence.', 'crust-core'),
                'dynamic'     => ['active' => true]
            ]
        );

        $this->end_controls_section();

        // Settings Control
        $this->start_controls_section(
            'crust_fancy_text_settings',
            [
                'label' => esc_html__('Settings', 'crust-core')
            ]
        );

        $this->add_control(
            'crust_fancy_text_tag',
            [
                'label'       => esc_html__('HTML Tag', 'crust-core'),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'h3',
                'label_block' => false,
                'options'     => [
                    'h1' => esc_html__('H1', 'crust-core'),
                    'h2' => esc_html__('H2', 'crust-core'),
                    'h3' => esc_html__('H3', 'crust-core'),
                    'h4' => esc_html__('H4', 'crust-core'),
                    'h5' => esc_html__('H5', 'crust-core'),
                    'h6' => esc_html__('H6', 'crust-core'),
                    'div' => esc_html__('div', 'crust-core'),
                    'span' => esc_html__('span', 'crust-core'),
                    'p' => esc_html__('p', 'crust-core'),
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_fancy_text_alignment',
            [
                'label'     => esc_html__('Alignment', 'elementor'),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
	                '' => [
		                'title' => __('Default', 'crust-core'),
		                'icon'  => 'fa fa-ban',
	                ],
                    'left'   => [
                        'title' => esc_html__('Left', 'crust-core'),
                        'icon'  => 'eicon-h-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'crust-core'),
                        'icon'  => 'eicon-h-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__('Right', 'crust-core'),
                        'icon'  => 'eicon-h-align-right',
                    ],
                ],
                'default'   => 'center',
                'selectors' => [
	                '{{WRAPPER}} .crust-fancy-text-container,{{WRAPPER}} .ah-headline.slide' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_fancy_text_animation',
            [
                'label'   => esc_html__('Animation', 'crust-core'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'type',
                'options' => [
                    'type'        => esc_html__('Type', 'crust-core'),
                    'rotate-1'    => esc_html__('Rotate 1', 'crust-core'),
                    'rotate-2'    => esc_html__('Rotate 2', 'crust-core'),
                    'rotate-3'    => esc_html__('Rotate 3', 'crust-core'),
                    'loading-bar' => esc_html__('Loading Bar', 'crust-core'),
                    'slide'       => esc_html__('Slide', 'crust-core'),
                    'clip'        => esc_html__('Clip', 'crust-core'),
                    'zoom'        => esc_html__('Zoom', 'crust-core'),
                    'push'        => esc_html__('Push', 'crust-core'),
                    'scale'       => esc_html__('Scale', 'crust-core'),
                ],
            ]
        );

        $this->add_control(
            'crust_fancy_text_delay',
            [
                'label'   => esc_html__('Animation Delay', 'crust-core'),
                'type'    => Controls_Manager::NUMBER,
                'default' => '2500'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'crust_fancy_text_prefix_styles',
            [
                'label' => esc_html__('Prefix Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'crust_fancy_text_prefix_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-fancy-text-prefix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .crust-fancy-text-prefix',
            ]
        );
		////////////

	    $this->add_responsive_control(
		    'crust_fancy_text_prefix_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_fancy_text_prefix_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-fancy-text-prefix' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    ////////////


        $this->end_controls_section();


        $this->start_controls_section(
            'crust_fancy_text_strings_styles',
            [
                'label' => esc_html__('Fancy Text Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'crust_fancy_text_strings_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#19D0D6',
                'selectors' => [
                    '{{WRAPPER}} .crust-fancy-text-strings b' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'crust_fancy_strings_use_bg',
		    [
			    'label'        => __('Gradient ?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_fancy_strings_gradient',
			    'types'    => ['gradient'],
			    'condition' => [
				    'crust_fancy_strings_use_bg' => 'yes'
			    ],
			    'selector' => '{{WRAPPER}} .crust-fancy-text-strings b',
		    ]
	    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'crust_fancy_text_strings_typography',
                'selector' => '{{WRAPPER}} .crust-fancy-text-strings b',
            ]
        );

        $this->add_control(
            'crust_fancy_text_strings_bg_color',
            [
                'label'     => esc_html__('Background', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .crust-fancy-text-strings b' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'crust_fancy_loading_bar_color',
            [
                'label'     => esc_html__('Loading Bar Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ah-headline.loading-bar .ah-words-wrapper::after' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'crust_fancy_text_animation' => 'loading-bar'
                ]
            ]
        );

        $this->add_control(
            'crust_fancy_cursor_color',
            [
                'label'     => esc_html__('Cursor Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .ah-headline.type .ah-words-wrapper::after' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .ah-headline.clip .ah-words-wrapper::after' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'crust_fancy_text_animation' => ['type','clip']
                ]
            ]
        );

        $this->add_responsive_control(
            'crust_fancy_text_strings_padding',
            [
                'label'      => esc_html__('Padding', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-fancy-text-strings b' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'crust_fancy_text_strings_margin',
            [
                'label'      => esc_html__('Margin', 'elementor'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .crust-fancy-text-strings b' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'crust_fancy_text_strings_border',
                'selector' => '{{WRAPPER}} .crust-fancy-text-strings b',
            ]
        );


        $this->add_control(
            'crust_fancy_text_strings_border_radius',
            [
                'label'     => esc_html__('Border Radius', 'elementor'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crust-fancy-text-strings b' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		////////////////
	    $this->add_responsive_control(
		    'crust_fancy_text_strings_dark_styles',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator'=>'before',

		    ]
	    );

	    $this->add_control(
		    'crust_fancy_text_strings_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-fancy-text-strings b' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_fancy_strings_use_dark_bg',
		    [
			    'label'        => __('Gradient ?', 'crust-core'),
			    'type'         => Controls_Manager::SWITCHER,
			    'default'      => 'no',
			    'label_on'     => __('Yes', 'crust-core'),
			    'label_off'    => __('No', 'crust-core'),
			    'return_value' => 'yes',
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
			    'name'     => 'crust_fancy_strings_dark_gradient',
			    'types'    => ['gradient'],
			    'condition' => [
				    'crust_fancy_strings_use_bg' => 'yes'
			    ],
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-fancy-text-strings b',
		    ]
	    );


	    $this->add_control(
		    'crust_fancy_text_strings_bg_dark_color',
		    [
			    'label'     => esc_html__('Background', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-fancy-text-strings b' => 'background: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'crust_fancy_loading_bar_dark_color',
		    [
			    'label'     => esc_html__('Loading Bar Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .ah-headline.loading-bar .ah-words-wrapper::after' => 'background: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_fancy_text_animation' => 'loading-bar'
			    ]
		    ]
	    );

	    $this->add_control(
		    'crust_fancy_cursor_dark_color',
		    [
			    'label'     => esc_html__('Cursor Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .ah-headline.type .ah-words-wrapper::after' => 'background: {{VALUE}};',
				    'body.crust-dark {{WRAPPER}} .ah-headline.clip .ah-words-wrapper::after' => 'background: {{VALUE}};',
			    ],
			    'condition' => [
				    'crust_fancy_text_animation' => ['type','clip']
			    ]
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name'     => 'crust_fancy_text_strings_dark_border',
			    'selector' => 'body.crust-dark {{WRAPPER}} .crust-fancy-text-strings b',
		    ]
	    );

	    ///////////////


        $this->end_controls_section();


        $this->start_controls_section(
            'crust_fancy_text_suffix_styles',
            [
                'label' => esc_html__('Suffix Style', 'crust-core'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'crust_fancy_text_suffix_color',
            [
                'label'     => esc_html__('Text Color', 'crust-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .crust-fancy-text-suffix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'ending_typography',
                'selector' => '{{WRAPPER}} .crust-fancy-text-suffix',
            ]
        );
		////////////
	    $this->add_responsive_control(
		    'crust_fancy_text_suffix_dark_style',
		    [
			    'label'      => esc_html__('Dark Mode', 'elementor'),
			    'type'       => Controls_Manager::HEADING,
			    'separator' => 'before',

		    ]
	    );
	    $this->add_control(
		    'crust_fancy_text_suffix_dark_color',
		    [
			    'label'     => esc_html__('Text Color', 'crust-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    'body.crust-dark {{WRAPPER}} .crust-fancy-text-suffix' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    ////////////


        $this->end_controls_section();
    }

    protected function render()
    {
        $settings   = $this->get_settings_for_display();
        $tag        = $settings['crust_fancy_text_tag'];

        $this->add_render_attribute('fancy-text', 'class', 'crust-fancy-text-container');
        $this->add_render_attribute('fancy-text', 'data-fancy-text-id', esc_attr($this->get_id()));
        $this->add_render_attribute('fancy-text', 'data-fancy-text-animation', $settings['crust_fancy_text_animation']);
        $this->add_render_attribute('fancy-text', 'data-fancy-text-delay', $settings['crust_fancy_text_delay']);

	    $fancy_class = 'crust-fancy-text-strings ah-words-wrapper';
	    $fancy_class .= ( $settings['crust_fancy_strings_use_bg'] === 'yes' && $settings['crust_fancy_strings_gradient_background'] !== '' ) ? ' crust-gradient-fancy' : '';

        $html = '<div id="crust-fancy-text-'.esc_attr($this->get_id()).'" '.$this->get_render_attribute_string('fancy-text').'>';
            $html .= '<'.$tag.' class="ah-headline">';
                if ( ! empty($settings['crust_fancy_text_prefix'])) {
                    $html .= '<span class="crust-fancy-text-prefix">'.wp_kses_post($settings['crust_fancy_text_prefix']).' </span>';
                }

                if ($settings['crust_fancy_text_animation'] != 'fancy') {
	                $html .= '<span class="'. $fancy_class .'">';
                        $i = 0;
                        foreach ($settings['crust_fancy_text_strings'] as $item) {
                            $cls = ($i == 0) ? ' class="is-visible"' : '';
                            $html .= '<b'.$cls.'>' . $item['crust_text_strings'] . '</b>';
                            $i++;
                        }

                    $html .= '</span>';
                }

                if ( ! empty($settings['crust_fancy_text_suffix'])) {
                    $html .= '<span class="crust-fancy-text-suffix"> '.wp_kses_post($settings['crust_fancy_text_suffix']).'</span>';
                }
            $html .= '</'.$tag.'>';
        $html .= '</div>';

        echo $html;

    }

    public function fancy_text($settings)
    {
        $fancy_text = array();
        foreach ($settings as $item) {
            if ( ! empty($item['crust_text_strings'])) {
                $fancy_text[] = $item['crust_text_strings'];
            }
        }
        $fancy_text = implode("|", $fancy_text);

        return $fancy_text;
    }

    protected function content_template() { }
}
