<?php

if ( ! defined('ABSPATH')) { exit('Access Denied.'); }

class Crust_Panel_Settings
{

    public static function options()
    {

        $settings = [
            [
                'id'      => 'crust_intro',
                'title'   => '',
                'type'    => 'image',
                'section' => 'general',
                'src'     => CRUST_URI . '/lib/admin/assets/img/intro.jpg',
                'link'    => 'https://crust.winsomethemes.com',
                'class'   => 'half-section'
            ],
	        [
		        'id'      => 'crust_server',
		        'title'   => esc_html__('Server Requirements', 'crust'),
		        'type'    => 'servers',
		        'section' => 'general',
		        'icon'    => 'dashicons dashicons-buddicons-pm',
		        'class'   => 'half-section'
	        ],
            [
                'id'      => 'crust_support',
                'title'   => esc_html__('Need Help?', 'crust'),
                'desc'    => esc_html__('Stuck with something? Get help from the community on Themeforest item page support tab. In case of emergency, get in touch directly on winsomethemes.com website.', 'crust'),
                'type'    => 'label',
                'section' => 'general',
                'icon'    => 'dashicons dashicons-buddicons-pm',
                'link'    => 'https://themeforest.net/item/crust-multipurpose-wordpress-theme/31864303/support',
                'btntxt'  => esc_html__('Get Support', 'crust'),
                'class'   => 'half-section'
            ],
            [
                'id'      => 'crust_docs',
                'title'   => esc_html__('Documentation', 'crust'),
                'desc'    => esc_html__('Get started by spending some time with the documentation to get familiar with our theme. Build awesome websites for you or your clients with ease.', 'crust'),
                'type'    => 'label',
                'section' => 'general',
                'icon'    => 'dashicons dashicons-media-document',
                'link'    => 'https://crust.winsomethemes.com/docs',
                'btntxt'  => esc_html__('Documentation', 'crust'),
                'class'   => 'half-section'
            ],
            [
                'id'      => 'crust_newsletters',
                'title'   => esc_html__('Signup to our Newsletter', 'crust'),
                'desc'    => esc_html__('Get access to the latest News from WinsomeThemes. We promise to never send you Spam!.', 'crust'),
                'type'    => 'label',
                'section' => 'general',
                'icon'    => 'dashicons dashicons-email',
                'link'    => 'https://www.winsomethemes.com',
                'btntxt'  => esc_html__('Sign Up', 'crust'),
                'class'   => 'half-section'
            ],
            [
                'id'      => 'crust_review',
                'title'   => esc_html__('Enjoyed Our Theme ?', 'crust'),
                'desc'    => esc_html__('Loved the options and the design ?, Time to encourage us present more features and new things you will love, just give us the 5 stars, it is easy ;).', 'crust'),
                'type'    => 'label',
                'section' => 'general',
                'icon'    => 'dashicons dashicons-heart',
                'link'    => 'https://themeforest.net/downloads',
                'btntxt'  => esc_html__('Leave a Review', 'crust'),
                'class'   => 'half-section'
            ],

	        // Plugins...
	        [
		        'id'      => 'crust_plugins',
		        'type'    => 'notice',
		        'section' => 'plugins',
		        'class'   => 'lg-section',
		        'inplgn'  => true

	        ],

	        // Demo Import...
	        [
		        'id'      => 'crust_core_demo_import',
		        'type'    => 'notice',
		        'section' => 'templates',
		        'class'   => 'lg-section crust-templates-section',
		        'inplgn'  => true
	        ],


        ];

        return $settings;
    }

}

new Crust_Panel_Settings();
