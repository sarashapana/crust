<?php

if ( ! defined('ABSPATH')) { exit('Access Denied.'); }

class Crust_Admin_Panel
{

    public $settings = [];
    public $sections = [];
    public $fields   = [];

    public function __construct()
    {

    	$this->init();
        add_action( 'admin_menu',               [$this, 'admin_page'] );
        add_action( 'admin_enqueue_scripts',    [$this, 'enqueue_scripts'] );
        add_action( 'admin_notices',            [$this, 'admin_notice'] );
        add_action( 'admin_init',               [$this, 'register_settings'] );
        register_setting( 'crust_options', 'crust_options', [ $this, 'validate_settings' ] );
        if ( ! get_option( 'crust_options' ) ) {
            $this->initialize_settings();
        }

    }

    public function init()
    {

        require_once get_parent_theme_file_path( 'lib/admin/options.php' );
        $this->settings = Crust_Panel_Settings::options();
        $this->sections = [
            'general'   => '<i class="dashicons dashicons-admin-home"></i>' . esc_html__( 'General', 'crust' ),
            'templates' => '<i class="dashicons dashicons-admin-appearance"></i>' . esc_html__( 'Templates', 'crust' ),
            'plugins'   => '<i class="dashicons dashicons-admin-plugins"></i>' . esc_html__( 'Plugins', 'crust' ),
        ];

    }

    public function initialize_settings()
    {

        $default_settings = [];
        foreach ( $this->settings as $setting ) {
            if ( isset( $setting['std'] ) ) {
                $default_settings[$setting['id']] = $setting['std'];
            }
        }
        update_option( 'crust_options', $default_settings );

    }

    public function admin_page()
    {

        $name = esc_html__( 'Crust', 'crust' );
        add_theme_page( $name, $name, 'manage_options', 'crust-options', [ $this, 'display_page' ] );

    }

    public function admin_notice()
    {

        if ( ! class_exists( 'Crust_Core' ) ) {
            echo '<div class="crust-install-notice notice notice-info is-dismissible">';
	            echo '<div class="crust-notice-img"><img src="' . esc_url( CRUST_URI . "/lib/admin/assets/img/logo.png" ) . '" alt="' . esc_attr__( 'Crust', 'crust' ) . '"></div>';
	            echo '<div class="crust-notice-text">';
		            echo '<div class="crust-notice-left">';
                        echo '<h4>' . esc_html__( 'Crust Core Required!', 'crust' ) . '</h4>';
                        echo '<p>' . esc_html__( 'Crust Theme requires Crust Core Plugin to be installed and activated to get all theme features.', 'crust' ) . '</p>';
	                echo '</div>';
	                echo '<div class="crust-notice-right">';
		                echo '<a href="' . esc_url( admin_url() . 'themes.php?page=tgmpa-install-plugins' ) . '" class="button crust-button sm-btn">' . esc_html__( 'Install Crust Core Plugin', 'crust' ) . '</a>';
	                echo '</div>';
	            echo '</div>';
            echo '</div>';
        }

    }

    public function register_settings()
    {

        foreach ( $this->sections as $slug => $title ) {
            add_settings_section( $slug, $title, [ $this, 'display_section' ], 'crust-options' );
        }
        foreach ( $this->settings as $setting ) {
            $this->create_setting( $setting );
        }

    }

    public function create_setting( $args = [] )
    {

        $defaults = [
            'id'      => '',
            'title'   => '',
            'desc'    => '',
            'std'     => '',
            'icon'    => '',
            'btntxt'  => '',
            'inplgn'  => '',
            'type'    => 'text',
            'src'     => '',
            'link'    => '',
            'group'   => '',
            'parent'  => '',
            'section' => '',
            'choices' => [],
            'class'   => '',
        ];

        extract( wp_parse_args( $args, $defaults ) );

        $field_args = [
            'type'    => $type,
            'id'      => $id,
            'title'   => $title,
            'desc'    => $desc,
            'std'     => $std,
            'icon'    => $icon,
            'btntxt'  => $btntxt,
            'inplgn'  => $inplgn,
            'src'     => $src,
            'link'    => $link,
            'group'   => $group,
            'parent'  => $parent,
            'choices' => $choices,
            'section' => $section,
            'class'   => $class,
        ];

        add_settings_field($id, $title, [$this, 'display_field'], 'crust-options', $section, $field_args);

    }

    public function display_page()
    {

        $logo = CRUST_URI . '/lib/admin/assets/img/logo.png';

        if ( isset( $_GET[ 'settings-updated' ] ) && $_GET[ 'settings-updated' ] == true ) {
            echo '<div class="new-upd updated fade"><p>' . esc_html__( 'Theme options updated.', 'crust' ) . '</p></div>';
            settings_errors( 'crust_theme_options' );
        }

        echo '<div class="crust-opts-wrap" data-url="' . esc_url( admin_url() ) . '">';
	        echo '<form action="options.php" method="post" enctype="multipart/form-data" class="main-options-form">';
		        settings_fields( 'crust_options' );
		        echo '<div class="crust-opts-header">';
			        echo '<div class="crust-header-left">';
			            echo '<h2 class="title"><img src="'.esc_url($logo).'" title="' . esc_attr__('Crust Options', 'crust') . '"></h2>';
			        echo '</div>';
			        echo '<div class="crust-header-right">';
				        echo '<div class="form-btns">';
				            echo '<button type="submit" class="button crust-button crust-save-btn"><i class="dashicons dashicons-format-aside"></i>' . esc_html__('Save Settings', 'crust') . '</button>';
				        echo '</div>';
			        echo '</div>';
		        echo '</div>';
		        echo '<div class="crust-tabs">';
			        echo '<ul class="crust-tabs-nav">';
				        foreach ( $this->sections as $slug => $section ) {
				            echo '<li class="' . esc_attr( $slug ) . '"><a href="#' . esc_attr( $slug ) . '">' . $section . '</a></li>';
				        }
			        echo '</ul>';

			        echo '<div class="crust-tabs-wrap">';
			            $this->settings_sections( $_GET[ 'page' ] );
			        echo '</div>';

		        echo '</div>';
	        echo '</form>';
        echo '</div>';
    }

    public function settings_sections( $page )
    {
    	
        global $wp_settings_sections, $wp_settings_fields;

        if ( ! isset( $wp_settings_sections[ $page ] ) ) {
            return;
        }

        foreach ( (array)$wp_settings_sections[ $page ] as $section ) {
            if ( $section['callback'] ) {
                call_user_func( $section[ 'callback' ], $section );
            }

            if ( ! isset( $wp_settings_fields ) || ! isset( $wp_settings_fields[ $page ] ) || ! isset( $wp_settings_fields[ $page][$section[ 'id' ] ] )) {
                continue;
            }
            echo '<div class="crust-tabs-panel" id="' . esc_attr( $section[ 'id' ] ) . '">';
                $this->settings_fields( $page, $section[ 'id' ] );
            echo '</div>';
        }
        
    }

    public function settings_fields($page, $section)
    {
    	
        global $wp_settings_fields;
        if ( ! isset($wp_settings_fields[$page][$section])) {
            return;
        }

        echo '<div class="section-wrap">';

	        foreach ( (array)$wp_settings_fields[ $page ][ $section ] as $field ) {
	            call_user_func( $field[ 'callback' ], $field[ 'args' ] );
	        }

        echo '</div>';
        
    }

    public function validate_settings($input)
    {
        
        if ( isset( $_POST[ 'reset' ] ) ) {
            return $this->crust_get_default_values();
        } else {
            return $input;
        }
        
    }

    public function display_section($section) { }

    public function display_field( $args = [] )
    {
        
    	extract( $args );

        $option = get_option('crust_options');
        if ( class_exists('Crust_Core_Admin' ) && $args['inplgn'] === true ) {
            // Do other staff here...
        } else {
            switch ( $args['type'] ) {
                case 'label':
                    echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
                        $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );
                    echo '</div>';
                    break;

                case 'checkbox':
                    echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
                        $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );
	                    echo '<div class="crust-toggle">';
		                    echo '<input class="crust-hidden-check" type="hidden" id="' . esc_attr( $args['id'] ) . '" name="crust_options[' . esc_attr( $args['id'] ) . ']" value="' . sanitize_text_field( $option[ $args['id'] ] ) . '" />';
		                    echo '<input class="crust-checkbox check_change" id="' . esc_attr( $args['id'] ) . '_check" type="checkbox" />';
		                    echo '<label for="' . esc_attr( $args['id'] ) . '_check" class="crust-switch-label"><span class="crust-switch-inner"></span><span class="crust-switch"></span></label>';
	                    echo '</div>';
                    echo '</div>';
                    break;

                case 'templates':
                    echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
                        $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );

                        echo '<div class="crust-import-message"></div>';

                        echo '<div class="crust-top-import-icons">';
                            echo '<span class="crust-demo-loading-notice">'.esc_html__('This may take few minutes depending on the demo file size, so please dont worry!!', 'crust').'</span>';
                            echo '<span class="crust-demo-loader"><i class="dashicons dashicons-update"></i></span>';
                            echo '<span class="crust-import-success"><i class="dashicons dashicons-yes"></i></span>';
                        echo '</div>';

                        echo '<div class="crust-import-box">';

                            if( class_exists( 'Crust_Core' ) ){
								$crust_importer = new Crust_Demo_Importer;
	                            $crust_importer->add_templates_markup();
                            } else {
                            	echo '<div class="crust-plugins-missing-notice">'. esc_html__( 'Please Install Crust Core Plugin.', 'crust' ) .'</div>';
                            }

                        echo '</div>';

                    echo '</div>';

                    break;

                case 'plugins':
                    echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
	                    $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );
	                    echo '<div class="crust-field-plugin">';
		                    foreach ($args['choices'] as $value) {
		                        if( class_exists( 'Crust_Core') ){
				                    crust_core_check_plugins($value);
			                    }
		                    }
	                    echo '</div>';
                    echo '</div>';
                    break;

	            case 'servers':
		            echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
			            $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );
			            echo '<div class="crust-server-plugin">';
		                    $this->crust_server_reqs();
			            echo '</div>';
		            echo '</div>';
		            break;

                case 'image':
                    echo '<div class="crust-field ' . esc_attr( $args['class'] ) . '">';
	                    $this->field_output( $args['title'], $args['desc'], $args['icon'], $args['btntxt'], $args['link'] );
	                    echo '<div class="crust-field-image">';
	                        echo '<a href="' . esc_url( $args['link'] ) . '"><img alt="'.esc_attr__( 'Crust Theme', 'crust').'" src="' . esc_url( $args['src'] ) . '" /></a>';
	                    echo '</div>';
                    echo '</div>';
                    break;

                case 'notice':
                    echo '<div class="crust-field-notice crust-field ' . esc_attr( $args['class'] ) . '">';
                        echo '<div class="crust-notice-icon"><i class="dashicons dashicons-admin-generic"></i><i class="dashicons dashicons-warning abs-icn"></i></div>';
                        echo '<div class="crust-notice-content">Please install Crust Core Plugin to enable this feature.</div>';
                        echo '<a href="' . esc_url( admin_url() . 'themes.php?page=tgmpa-install-plugins' ) . '" class="button crust-button sm-btn">' . esc_html__('Install Plugins', 'crust') . '</a>';
                    echo '</div>';
                    break;

            }
        }
    }

    public function field_output( $title, $desc, $icon, $btntxt, $link )
    {

        if ( ! empty( $title ) || ! empty( $icn ) ) {
            echo '<header class="section-header">';
	            if ( isset( $icon ) && $icon != '' ) {
	                echo '<div class="crust-header-icon"><i class="' . $icon . '"></i></div>';
	            }
	            if ( ! empty( $title ) ) {
	                echo '<h4>' . $title . '</h4>';
	            }
            echo '</header>';
        }

        if ( ! empty( $desc ) || ! empty( $btntxt ) ) {
            echo '<div class="section-desc">';
            if ( ! empty( $desc ) ) {
                echo '<p>' . $desc . '</p>';
            }
            if ( ! empty( $btntxt ) ) {
                echo '<a target="_blank" href="' . $link . '" class="button crust-button sm-btn">' . $btntxt . '</a>';
            }
            echo '</div>';
        }

    }

    public function crust_get_server_status(){

	    $status = [];
	    $up_dir = wp_upload_dir();
	    $write  = wp_is_writable($up_dir['basedir'].'/');

	    array_push($status, [
		    'label'  => esc_html__('Writable uploads directory', 'crust'),
		    'status' => $write,
	    ]);

	    $memory_limit = ini_get('memory_limit');
	    $mem_limit_act = wp_convert_hr_to_bytes($memory_limit);
	    $mem_limit = $mem_limit_act >= 268435456;

	    array_push($status, [
		    'label'  => esc_html__('Memory limit (256MB)', 'crust'),
		    'status' => $mem_limit,
	    ]);

	    $up_max_size = ini_get('upload_max_filesize');
	    $up_max_size_act = wp_convert_hr_to_bytes($up_max_size);
	    $up_max = $up_max_size_act >= 67108864;

	    array_push($status, [
		    'label'  => esc_html__('Upload max filesize (64MB)', 'crust'),
		    'status' => $up_max,
	    ]);

	    $post_max_size = ini_get('post_max_size');
	    $post_max_size_act = wp_convert_hr_to_bytes($post_max_size);
	    $post_max = ($post_max_size_act >= 67108864);

	    array_push($status, [
		    'label'  => esc_html__('Post max size (64MB)', 'crust'),
		    'status' => $post_max,
	    ]);

	    $max_input_vars = ini_get('max_input_vars');
	    $max_input = $max_input_vars >= 3000;

	    array_push($status, [
		    'label'  => esc_html__('Max input vars (3000)', 'crust'),
		    'status' => $max_input,
	    ]);

	    $max_exec_time = ini_get('max_execution_time');
	    $max_exec = $max_exec_time >= 100;

	    array_push($status, [
		    'label'  => esc_html__('Max execution time (100s)', 'crust'),
		    'status' => $max_exec,
	    ]);

	    return $status;
    }

	public function crust_server_reqs(){
		$server_status = $this->crust_get_server_status();
		if( current_user_can( 'switch_themes' ) ) {
			foreach ($server_status as $key => $value) { ?>
				<div class="crust-status-item">
					<span class=crust-status-label><?php echo esc_html($value['label']); ?></span>
					<?php if($value['status']){ ?>
						<img alt="<?php echo esc_attr__( 'Success', 'crust' ); ?>" src="<?php echo esc_url(CRUST_URI . '/lib/admin/assets/img/check.png'); ?>"  />
					<?php }else{ ?>
						<img alt="<?php echo esc_attr__( 'Error', 'crust' ); ?>" src="<?php echo esc_url(CRUST_URI . '/lib/admin/assets/img/error.png'); ?>"  />
					<?php } ?>
				</div>
				<?php
			}
		} else { ?>
			<p><?php echo esc_html__('Please login to view the server status.', 'crust') ?></p>
		<?php }
	}

    public function enqueue_scripts()
    {
        wp_enqueue_style( 'crust-panel', CRUST_URI . '/lib/admin/assets/css.css' );
        wp_enqueue_script( 'crust-panel', CRUST_URI . '/lib/admin/assets/script.js', ['jquery'], null, true );

    }

}

new Crust_Admin_Panel();