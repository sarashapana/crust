<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

add_action( 'crust_post_thumbnail', 'crust_post_thumbnail_markup' );
    function crust_post_thumbnail_markup( $img_size )
    {
        global $post;
        $img_class  = 'crust-post-media';
        $media_on   = crust_mod('arc_media_on', '1');
	    $meta_video = get_post_meta($post->ID, 'meta_post_video', true);
	    $meta_audio = get_post_meta($post->ID, 'meta_post_audio', true);
	    $blg_style  = crust_blog_settings()['layout'];
	    $media_clasc = crust_blog_settings()['media'];
	    $img_class .= ( $media_clasc === true ) ? ' crust-classic-style' : '';
	    $img_class .= ' crust-format-' . get_post_format();

        if ( $media_on == true ) {

            if( has_post_format([ 'video', 'audio', 'link', 'quote' ] ) ){

                if( has_post_format('video') && ! is_singular() ){
                    echo '<div class="' . esc_attr($img_class) . '">';
                    do_action('theme_oembed_videos');
                        crust_media_styles();
                    echo '</div>';
                }

                if( has_post_format('audio') && ! is_singular() ){
                    echo '<div class="' . esc_attr($img_class) . '">';
	                do_action('theme_oembed_videos');
                        crust_media_styles();
                    echo '</div>';
                }

            } else {


                if ( get_the_post_thumbnail() ) {

                    echo '<div class="' . esc_attr($img_class) . '">';
                        echo '<div class="crust-media-meta">';
                            if ( crust_mod( 'arc_date_on', '1' ) == '1' && $blg_style !== 'list' ) {
                                echo '<span class="crust-meta-date"><i class="fad fa-calendar"></i><span><span class="crust-meta-month">' . esc_html(get_the_time('M')) . '</span><span>' . esc_html(get_the_time('j, Y')) . '</span></span></span>';
                            }
                            do_action('crust_listing_cat');
                        echo '</div>';

                        if( $meta_video ){
                            echo '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($meta_video).'" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fa fa-play"></i></a></div>';
                        } else if( $meta_audio ){
                            echo '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($meta_audio).'" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fad fa-music"></i></a></div>';
                        }

                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="crust-post-thumbnail">';
                            echo get_the_post_thumbnail($post->ID, $img_size, '');
                        echo '</a>';

                        crust_media_styles();

                    echo '</div>';

                } else if( $meta_video ){

                    echo '<div class="' . esc_attr($img_class) . '">';
                     do_action('crust_single_media',$meta_video);
                        crust_media_styles();
                    echo '</div>';

                } else if( $meta_audio ){

                    echo '<div class="' . esc_attr($img_class) . '">';
                        apply_filters('crust_post_audio',$meta_audio);
                        crust_media_styles();
                    echo '</div>';

                }

            }

        }
    }


if ( ! function_exists( 'crust_media_styles' ) ){
    function crust_media_styles()
    {
	    $blg_style = crust_blog_settings()['layout'];

	    if( $blg_style !== 'list' ){
		    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 200" preserveAspectRatio="none" class="crust-post-thumb-divider"><path class="crust-base-fill" d="M-0.1-0.1l1920,199.9H-0.1V-0.1z"></path><g><path class="crust-div-1-bottom" d="M0,0l937,97.6L0.2,199.9L0,0z"></path></g></svg>';
	    } else{
		    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 200" preserveAspectRatio="none" class="crust-post-thumb-divider"><path class="crust-base-fill" d="M1919.9,199.8H-0.1l1920-199.9V199.8z"></path><g><path class="crust-div-1-bottom" d="M1919.6,199.9L1295.6,65l624.2-65L1919.6,199.9z"></path></g></svg>';
	    }

	    if ( crust_mod( 'arc_author_on', '1' ) == '1' && $blg_style === 'list' ) {
		    do_action('crust_author_by_post');
	    }
    }
}

add_action('crust_single_media','crust_single_media_markup');
	function crust_single_media_markup()
	{
		global $post;
		$post_type = get_post_type();
		$img_class  = 'crust-single-media';
		$media_on   = ( $post_type === CRUST_PORTFOLIO ) ? crust_mod('portfolio_single_media', true) : crust_mod('singl_media_on', true);
		$meta_video = get_post_meta($post->ID, 'meta_post_video', true);
		$meta_audio = get_post_meta($post->ID, 'meta_post_audio', true);

		if ( $media_on == true ) {

            if( has_post_format([ 'video', 'audio', 'link', 'quote' ] ) ){
                if( has_post_format('video') && ! is_singular() ){
                    echo '<div class="' . esc_attr($img_class) . '">';
	                do_action('theme_oembed_videos');
                    echo '</div>';
                }
                if( has_post_format('audio') && ! is_singular() ){
                    echo '<div class="' . esc_attr($img_class) . '">';
	                do_action('theme_oembed_videos');
                    echo '</div>';
                }

            } else {

                if ( get_the_post_thumbnail() ) {
                    echo '<div class="' . esc_attr($img_class) . '">';
                        if( $meta_video ){
                            echo '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($meta_video).'" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fa fa-play"></i></a></div>';
                        } else if( $meta_audio ){
                            echo '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($meta_audio).'" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fad fa-music"></i></a></div>';
                        }
                        echo get_the_post_thumbnail($post->ID, 'full', '');
                    echo '</div>';

                } else if( $meta_video ){
                    echo '<div class="' . esc_attr($img_class) . '">';
	                apply_filters('Crust_post_video',$meta_video);
                    echo '</div>';
                } else if( $meta_audio ){
                    echo '<div class="' . esc_attr($img_class) . '">';
	               apply_filters('crust_post_audio',$meta_audio);
                    echo '</div>';
                }

            }

		}


	}


function crust_is_youtube_url($url)
{
	return preg_match("#^https?://(?:www\.)?youtube.com#", $url);
}

add_filter( 'crust_post_video', 'crust_post_video_markup' );
	function crust_post_video_markup( $video )
	{
	    if( crust_is_youtube_url( $video ) ){
	        $vid_ID = substr($video, strrpos($video, '/') + 1);
		    return '<embed src="'.esc_url($video).'?autoplay=1&playlist='.$vid_ID.'&mute=1&enablejsapi=0&controls=0&showinfo=0&loop=1&modestbranding=1" frameborder="0" allow="autoplay"></embed>';
        } else {
		    return '<video autoplay loop muted src="'.esc_url($video).'" playsinline></video>';
        }

	}


add_filter( 'crust_post_audio', 'crust_post_audio_markup' );
function crust_post_audio_markup( $audio ) {
	return do_shortcode('[audio src="'.esc_url($audio).'"]');
}


add_filter('crust_post_media','crust_post_media_markup');
function crust_post_media_markup ( $img_size ){
    global $post;
    $video = get_post_meta($post->ID, 'meta_post_video', true);
    $audio = get_post_meta($post->ID, 'meta_post_audio', true);

	$html = '<div class="crust-entry-thumbnail">';

        if ( get_the_post_thumbnail() ) {

            if( $video ){
	            $html .= '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($video).'" class="mfp-zoom-in" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fa fa-play"></i></a></div>';
            } else if( $audio ){
	            $html .= '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($audio).'" class="mfp-zoom-in" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fad fa-music"></i></a></div>';
            }

	        $html .= '<a href="' . esc_url(get_the_permalink()) . '" class="crust-post-thumbnail">';
	        $html .= get_the_post_thumbnail($post->ID, $img_size, '');
	        $html .= '</a>';

        } else if( $video ){
	        $html .= apply_filters('crust_post_video',$video);
        } else if( $audio ){
            apply_filters('crust_post_audio',$audio);
        }

	$html .= '</div>';

	return $html;

}

add_filter('crust_post_thumb','crust_post_thumb_markup');
function crust_post_thumb_markup ( $img_size ){
	global $post;
	$video = get_post_meta($post->ID, 'meta_post_video', true);
	$audio = get_post_meta($post->ID, 'meta_post_audio', true);

	$html = '<div class="crust-entry-thumbnail">';

	if ( get_the_post_thumbnail() ) {

		if( $video ){
			$html .= '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($video).'" class="mfp-zoom-in" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fa fa-play"></i></a></div>';
		} else if( $audio ){
			$html .= '<div class="crust-play-media mfp-pop mfp-iframe"><a href="'.esc_url($audio).'" class="mfp-zoom-in" data-effect="mfp-zoom-in" data-pop-type="iframe"><i class="fad fa-music"></i></a></div>';
		}

		$html .= '<a href="' . esc_url(get_the_permalink()) . '" class="crust-post-thumbnail">';
		$html .= get_the_post_thumbnail($post->ID, $img_size, '');
		$html .= '</a>';

	} else if( $video ){
		$html .= apply_filters('crust_post_video',$video);
	} else if( $audio ){
		apply_filters('crust_post_audio',$audio);
	}

	$html .= '</div>';

    return $html;

}

add_action( 'theme_oembed_videos', 'theme_oembed_videos_markup' );
function theme_oembed_videos_markup() {

	global $post;

	if ( $post && $post->post_content ) {

		global $shortcode_tags;
		// Make a copy of global shortcode tags - we'll temporarily overwrite it.
		$theme_shortcode_tags = $shortcode_tags;

		// The shortcodes we're interested in.
		$shortcode_tags = [
			'video' => $theme_shortcode_tags['video'],
			'embed' => $theme_shortcode_tags['embed'],
			'audio' => $theme_shortcode_tags['audio'],
		];
		// Get the absurd shortcode regexp.
		$video_regex = '#' . get_shortcode_regex() . '#i';

		// Restore global shortcode tags.
		$shortcode_tags = $theme_shortcode_tags;

		$pattern_array = [ $video_regex ];

		// Get the patterns from the embed object.
		if ( ! function_exists( '_wp_oembed_get_object' ) ) {
			include ABSPATH . WPINC . '/class-oembed.php';
		}
		$oembed = _wp_oembed_get_object();
		$pattern_array = array_merge( $pattern_array, array_keys( $oembed->providers ) );

		// Or all the patterns together.
		$pattern = '#(' . array_reduce( $pattern_array, function ( $carry, $item ) {
				if ( strpos( $item, '#' ) === 0 ) {
					// Assuming '#...#i' regexps.
					$item = substr( $item, 1, -2 );
				} else {
					// Assuming glob patterns.
					$item = str_replace( '*', '(.+)', $item );
				}
				return $carry ? $carry . ')|('  . $item : $item;
			} ) . ')#is';

		// Simplistic parse of content line by line.
		$lines = explode( "\n", $post->post_content );
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( preg_match( $pattern, $line, $matches ) ) {
				if ( strpos( $matches[0], '[' ) === 0 ) {
					echo do_shortcode( $matches[0] );
				} else {
					echo wp_oembed_get( $matches[0] );
				}
			}
		}
	}
}

add_action( 'crust_post_icon', 'crust_post_icon_markup' );
function crust_post_icon_markup() {
	$post_format = get_post_format();
	echo '<li class="Crust-post-icon">';

	switch ($post_format) {
		case 'gallery':
			echo '<i class="fa fa-camera" title="' . esc_attr__('Gallery', 'crust') . '"></i>';
			break;

		case 'link':
			echo '<i class="fa fa-link" title="' . esc_attr__('Link', 'crust') . '"></i>';
			break;

		case 'image':
			echo '<i class="fa fa-image" title="' . esc_attr__('Image', 'crust') . '"></i>';
			break;

		case 'quote':
			echo '<i class="fa fa-quote-left" title="' . esc_attr__('Quote', 'crust') . '"></i>';
			break;

		case 'status':
			echo '<i class="fa fa-refresh" title="' . esc_attr__('Status', 'crust') . '"></i>';
			break;

		case 'audio':
			echo '<i class="fa fa-music" title="' . esc_attr__('Status', 'crust') . '"></i>';
			break;

		case 'video':
			echo '<i class="fa fa-video-camera" title="' . esc_attr__('Status', 'crust') . '"></i>';
			break;

		case 'chat':
			echo '<i class="fa fa-comments-o" title="' . esc_attr__('Chat', 'crust') . '"></i>';
			break;

		case 'aside':
			echo '<i class="fa fa-eyedropper" title="' . esc_attr__('Aside', 'crust') . '"></i>';
			break;

		default:
			echo '<i class="fa fa-book" title="' . esc_attr__('Standard', 'crust') . '"></i>';
			break;
	}

	echo '</li>';

}

add_action('crust_post_title', 'crust_post_title_markup');
function crust_post_title_markup( $title_on ) {
	if ( $title_on == '1' ) {
		echo '<h4 class="Crust-post-title"><a href="'. esc_url(get_the_permalink()) .'">' . get_the_title() . '</a></h4>';
	}
}

add_action('crust_portfolio_title','crust_portfolio_title_markup');
	function crust_portfolio_title_markup()
	{
		$title_on = crust_mod( 'portfolio_item_title_on', '1');
		if ( $title_on == '1' ) {
            echo '<h5 class="crust-post-title"><a href="'. esc_url(get_the_permalink()) .'">' . get_the_title() . '</a></h5>';
		}
	}


add_action('crust_single_post_title','crust_single_post_title_markup');
function crust_single_post_title_markup() {
    $title_on = crust_mod( 'singl_titl_on', '1' );
    if ( $title_on == '1' ) {
        echo '<h2 class="crust-single-title">' . single_post_title('', false) . '</h2>';
    }
}


if ( ! function_exists('crust_global_more')) {
    function crust_global_more()
    {
        return false;
    }
    add_filter('excerpt_more', 'crust_global_more');
    add_filter('the_content_more_link', 'crust_global_more');
}

if ( ! function_exists('crust_get_content_format')) {
    function crust_get_content_format()
    {
        $excerpt_on = crust_mod('arc_excerpt_on', '1' );
        $format_on  = crust_mod('arc_format_on', '' );
        $content    = get_the_content();
        $content    = apply_filters('the_content', $content);
        $content    = str_replace(']]>', ']]&gt;', $content);
        $length     = crust_mod('arc_excerpt_length', 35);
	    $blg_style  = crust_blog_settings()['layout'];

        echo '<div class="crust-entry-content">';

            if ( crust_mod( 'arc_date_on', '1' ) == '1' && $blg_style === 'list' ) {
                echo '<span class="crust-meta-date"><i class="fad fa-calendar"></i>' . esc_html(get_the_time('M j, Y')) . '</span>';
            }

	        $title_on = crust_mod( 'arc_titl_on', '1' );
            do_action('crust_post_title', $title_on);

            if ( $format_on == false ) {
                if ( $excerpt_on == 1 && $length !== '' ) {
                    echo wp_trim_words( $content, $length, crust_global_more() );
                }
            } else {
                if ( ! has_excerpt()) {
                    if( is_search() ){
	                    echo wp_trim_words( $content, $length, crust_global_more() );
                    } else {
	                    $content = the_content();
                    }

                } else {
                    $content = the_excerpt();
                }
            }

            if ( $format_on == true || $excerpt_on == 1 ) {
                do_action('crust_mini_pager');
            }

        echo '</div>';

	    do_action('crust_post_meta');
    }
}

add_filter('Crust-post-chat', 'Crust_post_chat_markup');
function Crust_post_chat_markup($content) {
	$output = '<ul class="Crust-post-chat">';
	$rows   = preg_split("/(\r?\n)+|(<br\s*\/?>\s*)+/", $content);
	$i      = 0;

	foreach ($rows as $row) {
		if (strpos($row, ':')) {
			$row_split = explode(':', trim($row), 2);
			$author    = strip_tags(trim($row_split[0]));
			$text      = trim($row_split[1]);

			$output .= '<li class="Crust-chat-row row-' . ($i % 2 ? 'odd' : 'even') . '">';
			$output .= '<span class="Crust-chat-author ' . sanitize_html_class(strtolower("chat-author-{$author}")) . '"><i class="icmon-bubbles3"></i> <cite class="Crust-auth-name">' . $author . '</cite>' . ':' . '</span>' . $text;
			$output .= '</li>';

			$i++;
		} else {
			$output .= $row;
		}
	}

	$output .= '</ul>';

	return $output;
}

add_action('crust_sticky_post','crust_sticky_post_markup');
    function crust_sticky_post_markup()
    {
        if (is_sticky() && is_home() && ! is_paged()) {
            echo '<span class="crust-post-sticky" title="' . esc_attr__('Featured', 'crust') . '"><i class="fa fa-sticky-note-o"></i></span>';
        }
}

add_action('crust_post_meta', 'crust_post_meta_markup');
function crust_post_meta_markup()
{
    global $post;
        if ( crust_mod('arc_icon_on') == '1'
             || crust_mod('arc_comments_on', '1') == '1'
             || crust_mod('arc_more_on', true ) == true ) {

            echo '<div class="crust-bottom-arch-meta">';

                if ( crust_mod('arc_icon_on') == '1' || crust_mod('arc_comments_on', '1') == '1'){
                    echo '<ul class="crust-post-meta">';

                    if ( crust_mod( 'arc_icon_on' ) == '1' ){
                       do_action('crust_post_icon');
                    }

                    if ( ! is_search() && crust_mod('arc_comments_on', '1') == '1' ) {
                        if ( ! post_password_required() )  {
                            echo '<li class="meta-comments"><i class="fad fa-comment-lines primary-color"></i>';
                                comments_popup_link( 0, esc_html__( '1 Comment', 'crust' ), esc_html__( '% Comments', 'crust' ) );
                            echo '</li>';
                        }
                    }

                    echo '</ul>';
                }

                if( crust_mod('arc_more_on', true ) == true ){
	                $more_on   = crust_mod('arc_more_on', true );
	                $more_text = crust_mod('archive_more_text', esc_html__('Read More', 'crust'));
	                if ( true === $more_on ) {
		                echo '<div class="crust-more-container"><a class="crust-post-readmore-btn" href="' . esc_url(get_permalink($post->ID)) . '">' . esc_html($more_text) . '<span class="crust-btn-icon-wrap"><i class="fad fa-long-arrow-right primary-color"></i><span class="crust-dots-wrap"><i></i><i></i><i></i></span></span></a></div>';
	                }
                }

            echo '</div>';
        }
    }

if ( ! function_exists('crust_portfolio_post_cat')) {
	function crust_portfolio_post_cat( $cat_id )
	{

        echo '<ul class="crust-portfolio-cat">';

		    $categories = get_the_terms( $cat_id, CRUST_PORTFOLIO . '_categories' );
		    if( $categories ){
			    foreach ( $categories as $category ) {
				    echo '<li><a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a></li>';
			    }
            }

        echo '</ul>';

	}
}

if ( ! function_exists('crust_portfolio_image')) {
	function crust_portfolio_image( $post_id )
	{
		$img_class = 'crust-post-media';
		$meta_video = get_post_meta($post_id, 'meta_post_video', true);
		$meta_audio = get_post_meta($post_id, 'meta_post_audio', true);

		$svg = '<div class="crust-port-svg-wrap"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 200" preserveAspectRatio="none"><path class="crust-base-fill" d="M-0.1-0.1l1920,199.9H-0.1V-0.1z"></path></svg></div>';

        if ( has_post_thumbnail() ) {
            echo '<div class="' . esc_attr( $img_class ) . '">';
                if( ( crust_mod( 'portfolio_item_link_on', '1') == '1' || crust_mod( 'portfolio_item_zoom_on', '1') == '1')
                    && crust_mod( 'portfolio_item_style', 'card' ) !== 'hoverer' ){
                    crust_portfolio_box_links( $post_id );
                }
	            echo wp_kses( $svg, crust_allowed_tags() );
                if ( get_the_post_thumbnail() ) {
                    echo '<a href="' . esc_url(get_the_permalink()) . '" class="crust-post-thumbnail">';
                        echo get_the_post_thumbnail($post_id, 'full', '');
                    echo '</a>';
                }
            echo '</div>';
        } else if( $meta_video ){
	        echo '<div class="' . esc_attr( $img_class ) . '">';
                if( ( crust_mod( 'portfolio_item_link_on', '1') == '1' || crust_mod( 'portfolio_item_zoom_on', '1') == '1')
                    && crust_mod( 'portfolio_item_style', 'card' ) !== 'hoverer' ){
                    crust_portfolio_box_links( $post_id );
                }
	            echo wp_kses( $svg, crust_allowed_tags() );
	            echo '<div class="crust-entry-thumbnail">';
                apply_filters( 'crust_post_video', $meta_video);
                echo '</div>';
	        echo '</div>';
        } else if( $meta_audio ){
	        echo '<div class="' . esc_attr( $img_class ) . '">';
                if( ( crust_mod( 'portfolio_item_link_on', '1') == '1' || crust_mod( 'portfolio_item_zoom_on', '1') == '1')
                    && crust_mod( 'portfolio_item_style', 'card' ) !== 'hoverer' ){
                    crust_portfolio_box_links( $post_id );
                }
	            echo wp_kses( $svg, crust_allowed_tags() );
                echo '<div class="crust-entry-thumbnail">';
	               apply_filters('crust_post_audio',$meta_audio);
	            echo '</div>';
	        echo '</div>';
        }
	}
}

if ( ! function_exists('crust_portfolio_box_links')) {
	function crust_portfolio_box_links( $post_id )
	{

		echo '<div class="crust-portfolio-hover-box">';

            if( crust_mod( 'portfolio_item_zoom_on', '1') == '1' ){
                echo '<a class="crust-portfolio-hover-zoom" href="' . esc_url( get_the_post_thumbnail_url( $post_id, 'full' ) ) . '"><i class="fad fa-search"></i></a>';
            }

            if( crust_mod( 'portfolio_item_link_on', '1') == '1' ){
                echo '<a class="crust-portfolio-hover-link" href="' . esc_url( get_permalink( $post_id ) ) . '"><i class="fad fa-link"></i></a>';
            }

		echo '</div>';

	}
}

add_action('crust_author_meta','crust_author_meta_markup');
    function crust_author_meta_markup()
    {
	    $crust_auther_id = get_the_author_meta( 'ID' );
        echo '<span class="crust-author-meta">';
            echo get_avatar( $crust_auther_id, '25', '' );
            echo '<a href="' . esc_url( get_author_posts_url( $crust_auther_id ) ) . '" rel="author">';
                echo get_the_author();
            echo '</a>';
        echo '</span>';
    }

add_action('crust_author_by_post','crust_author_by_post_markup');
function crust_author_by_post_markup()
    {
        global $post;
	    $crust_author_id = $post->post_author;
        echo '<div class="crust-author-by">';
            echo '<a href="' . esc_url( get_author_posts_url( $crust_author_id ) ) . '" rel="author">';
                echo get_avatar( $crust_author_id, '60', '' );
                echo '<span>' . get_the_author_meta( 'display_name', $crust_author_id ) . '</span>';
            echo '</a>';
        echo '</div>';
}

if ( ! function_exists('crust_mini_author_meta')) {
    function crust_mini_author_meta()
    {
        $crust_auther_id = get_the_author_meta( 'ID' );
        echo '<li class="crust-author-meta">';
            echo '<i class="fad fa-user primary-color"></i>';
            echo '<a href="' . esc_url( get_author_posts_url( $crust_auther_id ) ) . '" rel="author">';
                echo get_the_author();
            echo '</a>';
        echo '</li>';
    }
}

add_action('crust_mini_pager','crust_mini_pager_markup');
    function crust_mini_pager_markup()
    {
        $crust_min_pager = wp_link_pages([
            'before'      => '<div class="clearfix"></div><div class="crust-sub-pager"><span class="crust-page-links-title">' . esc_html__('Pages:', 'crust') . '</span>',
            'after'       => '</div>',
            'link_before' => '<span>',
            'link_after'  => '</span>',
        ]);

        return $crust_min_pager;
    }


add_action('crust_single_category','crust_single_category_markup');
    function crust_single_category_markup(){
        global $post;
        if ( crust_mod('singl_cat_on', true ) == true ) {
            if ( in_array('category', get_object_taxonomies(get_post_type())) ) {
                echo '<li class="crust-post-cat">' . get_the_category_list() . '</li>';
            }
        }
    }

if( ! function_exists( 'crust_single_media_category' ) ){
    function crust_single_media_category(){
        global $post;
        $class = 'crust-post-cat';
        if ( is_single() && crust_mod('singl_cat_on', '1' ) == '1' ) {
            if ( in_array('category', get_object_taxonomies(get_post_type())) ) {
                return '<div class="'.esc_attr($class).'">' . get_the_category_list() . '</div>';
            }
        } else if ( crust_mod( 'arc_cat_on', '1' ) == '1' ) {
            $categories = get_the_category();
            if ( ! empty( $categories ) ) {
                return '<div class="'.esc_attr($class).'"><a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a></div>';
            }
        }
    }
}

if( ! function_exists( 'crust_single_category_alt' ) ){
	function crust_single_category_alt(){
		global $post;
		$class = 'crust-post-cat';
		if ( is_single() && crust_mod('singl_cat_on', '1' ) == '1' ) {
			if ( in_array('category', get_object_taxonomies(get_post_type())) ) {
				return '<div class="'.esc_attr($class).'">' . get_the_category_list() . '</div>';
			}
		} else if ( crust_mod( 'arc_cat_on', '1' ) == '1' ) {
			$categories = get_the_category();
			if ( ! empty( $categories ) ) {
				return '<div class="'.esc_attr($class).'"><a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a></div>';
			}
		}
	}
}
//single
add_action('crust_post_meta_single','crust_post_meta_single_markup');
    function crust_post_meta_single_markup()
    {
        global $post;

        echo '<ul class="crust-post-meta">';

            if ( crust_mod('singl_icon_on', false) == true ) {
	            do_action('crust_post_icon');
            }

            if ( crust_mod( 'singl_date_on', true ) == true ) {
                echo '<li class="crust-meta-date"><i class="fad fa-calendar"></i><span>' . esc_html(get_the_date()) . '</span></li>';
            }

	        do_action('crust_single_category');

	        if (crust_mod('singl_author_on', true) == true || crust_mod('singl_comments_on', true) == true ||
	            current_user_can('editor') || current_user_can('administrator')) {
	            echo '<li class="crust-meta-right">';
                    if (crust_mod('singl_author_on', true) == true) {
                        do_action('crust_author_meta');
                    }

                    $num_comments = get_comments_number();
                    if (crust_mod('singl_comments_on', true) == true) {
                        if ($num_comments == 0) {
                            $comments = '0 ' . esc_html__(' Comments', 'crust');
                        } elseif ($num_comments > 1) {
                            $comments = $num_comments . ' ' . esc_html__('Comments', 'crust');
                        } else {
                            $comments = '1 ' . esc_html__('Comment', 'crust');
                        }
                        echo '<span><i class="fad fa-comments-alt"></i><a href="' . esc_url(get_comments_link()) . '">' . $comments . '</a></span>';
                    }

                    if (current_user_can('editor') || current_user_can('administrator')) {
                        echo '<span class="crust-entry-edit-link"><i class="fad fa-edit"></i><a href="' . esc_url(get_edit_post_link($post->ID)) . '">' . esc_html__('Edit', 'crust') . '</a></span>';
                    }
                echo '</li>';

            }

        echo '</ul>';
    }


if ( ! function_exists('crust_post_full_meta_single')) {
    function crust_post_full_meta_single()
    {
        global $post;

        echo '<ul class="crust-post-meta">';

            if (crust_mod('singl_icon_on', true) == true) {
           do_action('crust_post_icon');
            }

            if (crust_mod('singl_date_on', true) == true) {
                echo '<li class="crust-meta-date">' . esc_html(get_the_date()) . '</li>';
            }

            $num_comments = get_comments_number();
            if (crust_mod('singl_comments_on', true) == true) {
                if ($num_comments == 0) {
                    $comments = '0 ' .esc_html__('Comments', 'crust');
                } elseif ($num_comments > 1) {
                    $comments = $num_comments . ' ' . esc_html__('Comments', 'crust');
                } else {
                    $comments = '1 ' . esc_html__('Comment', 'crust');
                }
                echo '<li><i class="fa fa-comment-alt"></i><a href="' . esc_url(get_comments_link()) . '">' . $comments . '</a></li>';
            }

            if (current_user_can('editor') || current_user_can('administrator')) {
                echo '<li class="crust-entry-edit-link"><i class="fad fa-edit"></i><a href="' . esc_url(get_edit_post_link($post->ID)) . '">' . esc_html__('Edit', 'crust') . '</a></li>';
            }

        echo '</ul>';
    }
}

if ( ! function_exists('crust_single_cats')) {
    function crust_single_cats()
    {
        if (crust_mod('singl_cat_on', true) == true) {
            if (in_array('category', get_object_taxonomies(get_post_type()))) {
                echo get_the_category_list();
            }
        }
    }
}

if ( ! function_exists('crust_single_title')) {
    function crust_single_title()
    {
        if (crust_mod('singl_date_on', true) == true) {
            echo '<div class="crust-meta-date">' . esc_html(get_the_date()) . '</div>';
        }
        if (crust_mod('singl_title_on', true) == true) {
            if (get_post_format() == 'link') {
                echo get_the_title();
            } else {
                ?>
                <h2 class="crust-single-title"><?php the_title(); ?></h2><?php
            }
        }
    }
}

if ( ! function_exists('crust_single_sticky')) {
    function crust_single_sticky()
    {
        if (is_sticky()) {
            echo '<span class="crust-post-sticky" title="' . esc_attr__('Featured', 'crust') . '"><i class="fa fa-sticky-note-o"></i></span>';
        }
    }
}

add_action('crust_single_author_box','crust_single_author_box_markup');
    function crust_single_author_box_markup()
    {
        global $post, $wp_query;
        $curauth    = $wp_query->get_queried_object();
        $first_name = get_the_author_meta('first_name', $post->post_author);
        $last_name  = get_the_author_meta('last_name', $post->post_author);
        if ( ! empty($first_name) || ! empty($last_name)) {
            $display_name = $first_name . ' ' . $last_name;
        } else {
            $display_name = get_the_author_meta('display_name', $post->post_author);
        }

        $user_description = get_the_author_meta('user_description', $post->post_author);
        $user_url         = get_author_posts_url(get_the_author_meta('ID'));

        if ( $user_description ) {
            echo '<div class="crust-post-block crust-author-info">';
                echo '<div class="crust-author-avatar">';
                    echo '<a href="' . esc_url($user_url) . '" rel="author">';
                        echo get_avatar(get_the_author_meta('user_email'), 100);
                    echo '</a>';
                echo '</div>';
                echo '<div class="crust-author-description">';
                    echo '<h5 class="crust-author-name"><a href="' . esc_url($user_url) . '" rel="author">' . esc_html($display_name) . '</a></h5>';
                    echo esc_html($user_description);
                    if( class_exists( 'Crust_Core' ) ){
                        if( get_the_author_meta('fb_crust', $post->post_author) || get_the_author_meta('tw_crust', $post->post_author)
                        || get_the_author_meta('in_crust', $post->post_author) || get_the_author_meta('yt_crust', $post->post_author)
                        || get_the_author_meta('ln_crust', $post->post_author) ){
	                        echo '<ul class="crust-author-box-socials">';
                                if( get_the_author_meta('fb_crust', $post->post_author) ){
                                    echo '<li><a href="'.esc_url( get_the_author_meta('fb_crust', $post->post_author) ).'"><i class="fab fa-facebook"></i></a></li>';
                                }
                                if( get_the_author_meta('tw_crust', $post->post_author) ){
                                    echo '<li><a href="'.esc_url( get_the_author_meta('tw_crust', $post->post_author) ).'"><i class="fab fa-twitter"></i></a></li>';
                                }
                                if( get_the_author_meta('in_crust', $post->post_author) ){
                                    echo '<li><a href="'.esc_url( get_the_author_meta('in_crust', $post->post_author) ).'"><i class="fab fa-instagram"></i></a></li>';
                                }
                                if( get_the_author_meta('yt_crust', $post->post_author) ){
                                    echo '<li><a href="'.esc_url( get_the_author_meta('yt_crust', $post->post_author) ).'"><i class="fab fa-youtube"></i></a></li>';
                                }
                                if( get_the_author_meta('ln_crust', $post->post_author) ){
                                    echo '<li><a href="'.esc_url( get_the_author_meta('ln_crust', $post->post_author) ).'"><i class="fab fa-linkedin"></i></a></li>';
                                }
	                        echo '</ul>';
                        }
                    }
                echo '</div>';

            echo '</div>';
        }
    }

add_action('crust_single_prevnext','crust_single_prevnext_markup');
    function crust_single_prevnext_markup()
    {

        $next_post = get_next_post();
        $previous_post = get_previous_post();

        echo '<div class="crust-post-block crust-nav-single">';

        if ($previous_post) {
            $prev_bg = get_the_post_thumbnail_url($previous_post->ID, 'thumbnail');
            $prev_tag = ( $prev_bg ) ? '<div class="crust-nav-img"><img alt="'.esc_attr__( 'Previous Article', 'crust').'" src="'.$prev_bg.'" /></div>' : '';
            echo '<div class="nav-previous">' . get_previous_post_link( '%link', '<span><i class="fas fa-angle-left"></i>'. esc_html__( 'Previous Article', 'crust') .'</span><span class="post-title">%title</span>').'</div>';
        }

        if ($next_post) {
            $nxt_bg = get_the_post_thumbnail_url($next_post->ID, 'thumbnail');
	        $nxt_tag = ( $nxt_bg ) ? '<div class="crust-nav-img"><img alt="'.esc_attr__( 'Next Article', 'crust').'" src="'.$nxt_bg.'" /></div>' : '';
            echo '<div class="nav-next">'. get_next_post_link( '%link', '<span>'. esc_html__( 'Next Article', 'crust') .'<i class="fas fa-angle-right"></i></span><span class="post-title">%title</span>').'</div>';
        }

        echo '</div>';
    }


add_action('crust_single_tags','crust_single_tags_markup');
    function crust_single_tags_markup()
    {
        if (crust_mod('singl_tags_on', true) == true) {
            if (get_the_tags()) { ?>
                <div class="crust-post-block crust-single-tags">
                    <div class="crust-tags-list">
                        <?php the_tags(null, ''); ?>
                    </div>
                </div>
            <?php }
        }
    }

add_action('crust_single_content','crust_single_content_markup');
    function crust_single_content_markup()
    {
        if (crust_mod('singl_content_on', true) == true) {
            if ( ! is_single() && (is_search() || has_excerpt())) { ?>

                <div class="entry-summary"><?php the_excerpt(); ?></div>

            <?php } else { ?>

                <div class="crust-single-content"><?php the_content(); ?></div>

            <?php }
        }
    }

add_action('crust_page_content','crust_page_content_markup');
	function crust_page_content_markup()
	{

        if ( ! is_single() && (is_search() || has_excerpt())) {

            the_excerpt();

        } else {

            the_content();
        }
    }



add_action('crust_single_share','crust_single_share_markup');
    function crust_single_share_markup()
    {
        $pg_type = 'single';
        if (class_exists('Crust_Core')) {
            echo '<div class="crust-post-block crust-share-block">';
	            echo '<div class="crust-share-wrap"><i class="primary-color fad fa-share"></i><span class="crust-share-title">' . esc_html__('Share Article', 'crust') . '</span>';
                    crust_blog_share($pg_type);
                echo '</div><div class="crust-social-permalink"><input class="crust-share-permalink" type="text" name="crust-share-copy" value="" readonly="" aria-label="'.esc_attr__( 'Copy Link' , 'crust' ).'"><span class="crust-copy-permalink fad fa-copy primary-color"></span><span class="crust-copied">'. esc_html__( 'Copied', 'crust' ) .'</span></div>';
            echo '</div>';
        }
    }


add_action('crust_get_post_page_url','crust_get_post_page_url_markup');
	function crust_get_post_page_url_markup() {
		if( 'page' == get_option( 'show_on_front' ) ) {
			return get_permalink( get_option('page_for_posts' ) );
		} else {
			return home_url();
		}
	}


add_action('crust_paging_nav','crust_paging_nav_markup');
    function crust_paging_nav_markup()
    {
        global $wp_query;
        if ($wp_query->max_num_pages < 2) {
            return;
        }
        $big  = 999999999;
        $args = [
            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format'    => '?paged=%#%',
            'current'   => max( 1, get_query_var( 'paged' ) ),
            'total'     => $wp_query->max_num_pages,
            'type'      => 'list',
            'prev_text' => '<i class="fad fa-long-arrow-left"></i>',
            'next_text' => '<i class="fad fa-long-arrow-right"></i>'
        ];

        $pg_pos = crust_mod( 'archive_pager_align', 'center' );
        $p_type = crust_mod( 'archive_pager', 'numeric' );
        $lodtxt = crust_mod( 'archive_load_text', esc_html__( 'Load More', 'crust' ) );

        if ( $p_type == "numeric" ) { ?>
            <div class="crust-pager <?php echo esc_attr( $pg_pos ); ?>">
                <?php echo paginate_links( $args ); ?>
            </div>
        <?php } elseif ( $p_type == "oldnew" ) { ?>
            <ul class="crust-pager pager oldnew">
                <li class="previous"><?php next_posts_link( '<span><i class="fad fa-long-arrow-left primary-color"></i></span> ' . esc_html__( 'Older Posts', 'crust' ) ) ?></li>
                <li class="next"><?php previous_posts_link( esc_html__('Newer Posts', 'crust') . ' <span><i class="fad fa-long-arrow-right primary-color"></i></span>' ) ?></li>
            </ul>
        <?php } elseif ($p_type == "load") {
            $perm = (get_option('permalink_structure')) ? '/page/' : '&paged='; ?>
            <div class="crust-pager loadmore">
                <span class="hidden blgurl" data-pag="<?php echo esc_attr( $perm ); ?>"><?php echo crust_get_post_page_url(); ?></span>
                <a href="#" class="crust-loadmore-btn"><?php echo esc_html( $lodtxt ); ?> <span class="crust_preloader"><i class="primary-color fad fa-spinner-third"></i></span></a>
                <div class="hidden pgnum"><?php echo esc_html( $wp_query->max_num_pages ) ?></div>
                <div class="load_msg"><?php echo esc_html__( 'No More Posts To Show !!', 'crust' ) ?></div>
            </div>
        <?php }
}

add_action('crust_portfolio_paging_nav','crust_portfolio_paging_nav_markup');
	function crust_portfolio_paging_nav_markup( $crust_portfolio_query )
	{
		if ( $crust_portfolio_query->max_num_pages < 2 ) {
			return;
		}
		$big  = 999999999;
		$paged = get_query_var( 'paged' );
		$args = [
			'base'           => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'         => '?paged=%#%',
			'current'        => max( 1, get_query_var( 'paged' ) ),
			'total'          => $crust_portfolio_query->max_num_pages,
			'type'           => 'list',
			'prev_text'      => '<i class="fad fa-long-arrow-left"></i>',
			'next_text'      => '<i class="fad fa-long-arrow-right"></i>'
		];

		$pg_pos = crust_mod( 'archive_pager_align', 'center' );
		$p_type = crust_mod( 'archive_pager', 'numeric' );
		$lodtxt = crust_mod( 'archive_load_text', esc_html__( 'Load More', 'crust' ) );

		if ( $p_type == "numeric" ) { ?>

            <div class="crust-pager <?php echo esc_attr( $pg_pos ); ?>">
				<?php echo paginate_links( $args ); ?>
            </div>

		<?php } elseif ( $p_type == "oldnew" ) { ?>

            <ul class="crust-pager pager oldnew">
                <li class="previous"><?php next_posts_link( '<span><i class="fad fa-long-arrow-left primary-color"></i></span> ' . esc_html__( 'Older Posts', 'crust' ) ) ?></li>
                <li class="next"><?php previous_posts_link( esc_html__( 'Newer Posts', 'crust' ) . ' <span><i class="fad fa-long-arrow-right primary-color"></i></span>' ) ?></li>
            </ul>

		<?php } elseif ( $p_type == "load" ) {

			$perm = ( get_option( 'permalink_structure' ) ) ? '/page/' : '&paged='; ?>
            <div class="crust-pager loadmore">
                <span class="hidden blgurl" data-pag="<?php echo esc_attr( $perm ); ?>"><?php echo crust_get_post_page_url(); ?></span>
                <a href="#" class="btn bold btn-lg btn-hover-shad"><?php echo esc_html( $lodtxt ); ?> <span class="crust_preloader"><i class="primary-color fad fa-spinner-third"></i></span></a>
                <div class="hidden pgnum"><?php echo esc_html( $crust_portfolio_query->max_num_pages ) ?></div>
                <div class="load_msg"><?php echo esc_html__('No More Posts To Show !!', 'crust') ?></div>
            </div>

		<?php }

		wp_reset_postdata();
	}


if ( ! function_exists('crust_portfolio_posts_per_page')) {
	function crust_portfolio_posts_per_page( $query ) {
		if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'portfolio' ) ) {
			$query->set( 'posts_per_page', crust_mod( 'portfolio_pages_num', '10' ) );
		}
	}

	add_action( 'pre_get_posts', 'crust_portfolio_posts_per_page' );
}

if ( ! function_exists('crust_move_pagination')) {
    function crust_move_pagination($content)
    {
        if (is_single()) {
            $pagination = wp_link_pages(
                [
                    'before'      => '<div class="clearfix"></div><div class="crust-sub-pager"><span class="crust-page-links-title">' . esc_html__('Pages:', 'crust') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                    'echo'        => 0,
                ]
            );
            $content .= $pagination;
            return $content;
        }

        return $content;
    }

    add_filter( 'the_content', 'crust_move_pagination', 1 );
}

add_action('crust_related_posts','crust_related_posts_markup');
    function crust_related_posts_markup()
    {
        global $post;
        $crust_tags = wp_get_post_tags($post->ID);

	    $related_num = crust_mod( 'related_number', 3);
	    $related_col = crust_mod( 'related_colums', 3);
	    $related_img = crust_mod( 'related_img', 'large' );

	    $wrap_class = 'crust-related-wrap';
	    $wrap_class .= ( $related_col !== 'auto' ) ? ' crust-related-columns-' . $related_col : ' crust-related-columns-auto';

        if ($crust_tags) {
            $crust_tag_ids = [];

            foreach ($crust_tags as $crust_individual_tag) {
                $crust_tag_ids[] = $crust_individual_tag->term_id;
            }

            $args = [
                'tag__in'             => $crust_tag_ids,
                'post__not_in'        => [$post->ID],
                'showposts'           => $related_num,
                'ignore_sticky_posts' => 1
            ];

            $crust_related_query = new wp_query($args);

            if ($crust_related_query->have_posts()) {
                echo '<div class="crust-post-block crust-related-posts">';
                    echo '<h3 class="crust-inner-heading">' . esc_html__('You may also like', 'crust') . '</h3>';
                    echo '<div class="'.$wrap_class.'">';
                    while ($crust_related_query->have_posts()) {
                        $crust_related_query->the_post();
                        echo '<div class="crust-related-item">';
                            if( has_post_thumbnail( $post->ID ) ){
	                            echo '<div class="crust-related-overlay" style="background-image: url('.esc_url(get_the_post_thumbnail_url($post->ID, $related_img, '')).')"></div>';
                            }

                            //crust_post_thumbnail( $related_img );
                            echo '<div class="crust-related-cover">';
                                echo '<h5 class="crust-related-link">' . '<a href="' . esc_url(get_the_permalink()) . '" rel="bookmark">' . esc_html(get_the_title()) . '</a>' . '</h5>';
                                echo '<div class="crust-related-date"><i class="fad fa-calendar-alt"></i>' . get_the_date() . '</div>';
                            echo '</div>';
                        echo '</div>';
                    }
                    echo '</div>';
                echo '</div>';
            }

            wp_reset_postdata();
        }
    }


if ( ! function_exists('crust_author_widget')) {
    function crust_author_widget()
    {
        global $post, $wp_query;
        $curauth    = $wp_query->get_queried_object();
        $first_name = get_the_author_meta('first_name', $post->post_author);
        $last_name  = get_the_author_meta('last_name', $post->post_author);
        if ( ! empty($first_name) || ! empty($last_name)) {
            $display_name = $first_name . ' ' . $last_name;
        } else {
            $display_name = get_the_author_meta('display_name', $post->post_author);
        }

        $user_description = get_the_author_meta('user_description', $post->post_author);
        $user_url         = get_author_posts_url(get_the_author_meta('ID'));

        echo '<div class="crust_author_info">';
            echo '<div class="author-avatar">';
                echo '<a href="' . esc_url($user_url) . '" rel="author">';
                    echo get_avatar(get_the_author_meta('user_email'), 100);
                echo '</a>';
            echo '</div>';
            echo '<h5 class="author-name"><a href="' . esc_url($user_url) . '" rel="author">' . esc_html($display_name) . '</a></h5>';
            echo '<div class="author-description">';
                echo esc_html($user_description);
            echo '</div>';
        echo '</div>';
    }
}
