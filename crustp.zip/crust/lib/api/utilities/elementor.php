<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

use Elementor\Plugin;

add_filter( 'crust_elementor_page_title', 'crust_elementor_page_title' );
if ( ! function_exists( 'crust_elementor_page_title' ) ) {
    function crust_elementor_page_title( $val )
    {
        if ( defined( 'ELEMENTOR_VERSION' ) ) {
            $current_doc = Plugin::instance()->documents->get( get_the_ID() );
            if ( $current_doc && 'yes' === $current_doc->get_settings( 'hide_title' ) ) {
                $val = false;
            }
        }
        return $val;
    }
}

add_action('elementor/theme/register_locations', 'crust_elementor_locations');
function crust_elementor_locations( $elementor_theme_manager )
{
	$elementor_theme_manager->register_all_core_location();
}

add_action( 'template_redirect', 'crust_elementor_full_width' );
function crust_elementor_full_width()
{

    global $post;
    $elementor_template = ( ! empty( $post->ID ) ) ? get_post_meta( $post->ID, '_elementor_template_type', true ) : 'page';
    $post_type = get_post_type();

    if ( $elementor_template === 'section' || $post_type === 'crust_modules' || $post_type === 'crust_header' || $post_type === 'crust_footer' )
    {
        // Remove everything...
        remove_action( 'crust_header_markup', 'crust_header_template' );
        remove_action( 'crust_footer_markup', 'crust_footer_template' );
        remove_action( 'crust_title_markup', 'crust_page_title_template' );
        remove_action('crust_sidebar_markup', 'crust_sidebar_template');
        //remove_action( 'crust_content_markup', 'crust_content_template' );

        // Add the elementor content...
        add_action( 'crust_content_markup', 'crust_elementor_post_content' );
    }

}
