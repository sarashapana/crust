<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

class Crust_Enqueue_Styles
{

    public function __construct()
    {
        add_action( 'wp_enqueue_scripts', [$this, 'crust_enqueue_styles'] );
        if( !class_exists('Crust_Core') ){
	        add_action( 'wp_enqueue_scripts', [$this, 'crust_enqueue_default_styles'] );
        }
    }

    public function crust_enqueue_styles()
    {

        $crust_css = ( did_action('elementor/loaded') ) ? ['elementor-frontend'] : '';
        // CSS Files
	    wp_register_style('crust-font-awesome-icons', '//pro.fontawesome.com/releases/v5.15.2/css/all.css', '', null);
		wp_register_style('crust-uicons',    CRUST_URI . '/lib/assets/icons/uicons-regular-rounded.css', '', null);

        wp_register_style('crust-common',        CRUST_URI . '/lib/assets/css/common.css', $crust_css, null);
        wp_register_style('crust-frontend',      CRUST_URI . '/lib/assets/css/frontend.css', ['crust-common'], null);
        wp_register_style('crust-woocommerce',   CRUST_URI . '/lib/assets/css/vendor/woo.css', ['crust-common'], null);

        wp_enqueue_style('crust-font-awesome-icons');
	    wp_enqueue_style('crust-uicons');
        wp_enqueue_style('crust-common');
        wp_enqueue_style('crust-frontend');

        if(class_exists('Woocommerce')) {
            wp_enqueue_style('crust-woocommerce');
        }

        if ( class_exists( 'Crust_Customizer' ) ) {
            wp_add_inline_style('crust-frontend', self::crust_custom_css());
        }

        // JS files...
        if (is_singular() && comments_open() && get_option('thread_comments') == "1") {
            wp_enqueue_script('comment-reply');
        }

        if( class_exists( 'Woocommerce' ) ){
	        wp_register_script( 'crust-woocommerce',    CRUST_URI . '/lib/assets/js/vendor/woo.js', ['jquery'], null, true);
	        wp_register_script( 'jquery-cookie',        CRUST_URI . '/lib/assets/js/vendor/jquery.cookie.js', ['jquery'], null);
	        wp_localize_script( 'crust-woocommerce', 'crust_woo', [ 'ajaxurl' => admin_url( 'admin-ajax.php' ) ] );
            wp_enqueue_script( 'crust-woocommerce' );
	        wp_enqueue_script( 'jquery-cookie' );
        }

	    wp_register_script( 'crust-script',         CRUST_URI . '/lib/assets/js/script.js', ['jquery'], null, true);
        wp_enqueue_script( 'crust-script' );

    }

	public function crust_enqueue_default_styles() {
		wp_enqueue_style( 'crust-default-fonts', $this->crust_default_styles(), [], '1.0.0' );
		wp_enqueue_style( 'crust-fjb3cfn-font', '//use.typekit.net/fjb3cfn.css', [], '1.0.0' );
	}


    public function crust_default_styles(){
	    $font_url = add_query_arg( 'family', urlencode( 'Lexend:400,500,600&subset=latin,latin-ext' ), "//fonts.googleapis.com/css" );
	    return $font_url;
    }

    public function crust_custom_css()
    {

    	// Custom Meta Boxes Styling...
        $crust_css     = '';
	    $body_bg       = crust_meta( 'body_bg');
	    $body_bg_col   = crust_meta( 'body_bg_color');
	    $body_bg_pos   = crust_meta( 'body_bg_position');
	    $body_bg_rep   = crust_meta( 'body_bg_repeat');
	    $body_bg_siz   = crust_meta( 'body_bg_size');
	    $body_bg_atc   = crust_meta( 'body_bg_attach');
	    $fixed_offset  = crust_option( 'fixed_offset', '' );
	    
	    if ( $body_bg || $body_bg_col ) {
	    	
		    $bodm_id = ( $body_bg ) ? preg_replace( '/[^\d]/', '', $body_bg ) : '';
		    $bodm_src = ( $bodm_id ) ? wp_get_attachment_image_src( $bodm_id,'full' ) : '';
		    
		    $crust_css .= "body{";
		        $crust_css .= ( $body_bg_col ) ? "background-color: ".$body_bg_col." !important;" : "";
		        $crust_css .= ( $body_bg )     ? "background-image: url('".esc_url( $bodm_src[0])."') !important;" : '';
			    $crust_css .= ( $body_bg_rep ) ? "background-repeat: ".$body_bg_rep." !important;" : "";
			    $crust_css .= ( $body_bg_siz ) ? "background-size: ".$body_bg_siz." !important;" : "";
			    $crust_css .= ( $body_bg_pos ) ? "background-position: ".$body_bg_pos." !important;" : "";
			    $crust_css .= ( $body_bg_atc != '' ) ? "background-attachment: ".$body_bg_atc." !important;" : "";
		    $crust_css .= "}";
	    }

	    if( $fixed_offset ){
		    $crust_css .= ".crust-site-header.crust-fixed-head{";
		        $crust_css .= "top: ".$fixed_offset."px !important;";
		    $crust_css .= "}";
	    }

	    return str_replace(': ', ':', str_replace(';}', '}', str_replace('; ', ';', str_replace(' }', '}', str_replace(' {', '{', str_replace('{ ', '{', str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), "",
	        preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $crust_css))))))));

    }

}

new Crust_Enqueue_Styles();
