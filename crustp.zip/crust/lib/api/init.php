<?php

class Crust_Init {

	public function __construct()
	{

		$this->define_constants();

		add_action( 'after_setup_theme',    [ $this, 'crust_setup_theme' ], 3 );
		add_action( 'init',                 [ $this, 'crust_load_files' ], 1 );
		add_action( 'widgets_init',         [ $this, 'crust_theme_sidebars' ] );

		add_filter( 'get_search_form',      [ $this, 'crust_get_search_form' ] );

	}

	public function define_constants()
	{
		defined('CRUST_DIR') or define('CRUST_DIR', get_template_directory());
		defined('CRUST_URI') or define('CRUST_URI', get_template_directory_uri());
		defined( 'CRUST_API_URL' ) or define( 'CRUST_API_URL', 'https://dev.winsomethemes.com/crust' );
		defined('CRUST_PORTFOLIO') or define('CRUST_PORTFOLIO', 'portfolio');
	}

	public function crust_setup_theme()
	{

		add_theme_support('title-tag');
		add_theme_support('post-thumbnails');
		add_theme_support('automatic-feed-links');
		add_theme_support('html5', ['comment-list', 'comment-form', 'search-form', 'gallery', 'caption','script', 'style']);
		add_theme_support('post-formats', ['aside', 'image', 'video', 'audio', 'quote', 'link', 'gallery', 'status', 'chat']);

		if ( ! isset($content_width)) {
			$content_width = crust_mod('site_width', 1140);
		}

		load_theme_textdomain( 'crust', CRUST_DIR . '/lib/languages' );

		register_nav_menus([
			'primary' => esc_html__('Primary Menu', 'crust'),
		]);

		if ( is_admin() ) {
			require get_parent_theme_file_path('lib/admin/init.php');
			require get_parent_theme_file_path('lib/admin/tgmpa/tgm-plugins.php');
		}

		do_action( 'crust_init' );

	}

	public function crust_load_files()
	{

		require get_parent_theme_file_path('lib/api/utilities/assets.php');
		require get_parent_theme_file_path('lib/api/utilities/actions.php');
		require get_parent_theme_file_path('lib/api/utilities/formats.php');

		if ( did_action('elementor/loaded') && class_exists( '\Elementor\Plugin' ) ) {
			require get_parent_theme_file_path('lib/api/utilities/elementor.php');
		}

		if( class_exists( 'Woocommerce' ) ) {
			require get_parent_theme_file_path ('lib/api/utilities/woocommerce.php');
		}
	}

	public function crust_theme_sidebars()
	{

		$sidebars = [
			'sidebar-1'      => esc_html__('Primary SideBar', 'crust'),
			'sidebar-2'      => esc_html__('Secondary SideBar', 'crust'),
			'footer-widgets' => esc_html__('Footer Widgets', 'crust'),
			'sub-footer'     => esc_html__('Sub Footer', 'crust'),
			'shop-sidebar'     => esc_html__('Shop Sidebar', 'crust'),
		];

		foreach ( $sidebars as $sidebar => $value ) {
			register_sidebar(
				[
					'name'          => $value,
					'id'            => sanitize_title( $sidebar ),
					'before_widget' => '<div class="crust-widget %2$s">',
					'after_widget'  => '</div>',
				]
			);
		}

	}

	public function crust_get_search_form()
	{
		get_template_part( 'lib/templates/parts/searchform' );
		return false;
	}

}

new Crust_Init();