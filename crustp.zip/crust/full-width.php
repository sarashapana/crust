<?php
/*
Template Name: Full Page Template
Template Post Type: post, page, product, portfolio
*/

get_header();
do_action( 'crust_posts_loop' );
get_footer();
