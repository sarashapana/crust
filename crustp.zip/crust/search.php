<?php

get_header();
do_action('crust_site_search');
get_footer();
