<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

get_header();
do_action( 'crust_index' );
get_footer();
