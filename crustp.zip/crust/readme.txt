/*
  Theme Name:   Crust
  Theme URI:    https://crust.winsomethemes.com
  Author:       WinsomeThemes
  Author URI:   https://www.winsomethemes.com
  Description:  Crust - Creative MultiPurpose WordPress Theme.
  Version:      1.0.0
  License:      GNU General Public License v2 or later
  License URI:  http://www.gnu.org/licenses/gpl-2.0.html
  Tags:         right-sidebar, left-sidebar, custom-header, custom-background, custom-menu, theme-options, translation-ready
  Text Domain:  crust
  Tested up to: 5.8
  Requires PHP: 7.0
*/