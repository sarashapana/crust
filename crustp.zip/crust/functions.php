<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require get_parent_theme_file_path('lib/api/init.php');

// get current page ID..
if ( ! function_exists('crust_page_id')) {
    function crust_page_id()
    {
        global $post;
        $crust_page_id = '';
        if ( ( get_option( 'show_on_front' ) && get_option( 'page_for_posts' ) && is_home() ) ) {
            $crust_page_id = get_option( 'page_for_posts' );
        } else {
            if ( isset( $post ) && ! is_search() ) {
                $crust_page_id = $post->ID;
            }
            if ( class_exists( 'Woocommerce' ) ) {
                if ( is_shop() || is_tax( 'product_cat' ) || is_tax( 'product_tag' ) ) {
                    $crust_page_id = get_option( 'woocommerce_shop_page_id' );
                }
            }
        }

        return $crust_page_id;
    }
}

if ( ! function_exists('crust_mod') ) {
    function crust_mod( $option, $default = '' )
    {
        return ( class_exists( 'Crust_Customizer') ) ? Kirki::get_option( Crust_Customizer::$config_id, $option ) : get_theme_mod( $option, $default );
    }
}

if ( ! function_exists('crust_meta')) {
    function crust_meta( $option ) {
        $post_type = get_post_type();

        if ( is_search() ) {
            return '';
        } else {
            if( class_exists( 'Crust_Core' ) ) {

                if ( is_archive() && $post_type == CRUST_PORTFOLIO ) {
                    $port_id = get_page_by_path( 'portfolio' );
                    if( !$port_id ){
                        return;
                    }
                    return get_post_meta( $port_id->ID, $option,true );
                } else {
                    return get_post_meta( crust_page_id(), $option,true );
                }

            } else {
                return '';
            }
        }
    }
}

if ( ! function_exists('crust_option')) {
    function crust_option( $mod, $default )
    {
        return ( crust_meta( $mod ) == '' ) ? crust_mod( $mod, $default ) : crust_meta( $mod );
    }
}


// Custom Page Title..
if ( ! function_exists('crust_custom_page_title')) {
    function crust_custom_page_title()
    {
        global $post;
        $post_type = get_post_type();
        $post_type_slug = '';
        if ($post_type) {
            $post_type_data = get_post_type_object($post_type);
            $post_type_slug = (is_array($post_type_data)) ? $post_type_data->rewrite['slug'] : '';
        }

        $page_title = '';

        if (is_front_page() && !is_home()) {
            $page_title .= esc_html__('Home Page', 'crust');
        } elseif (is_front_page() && is_home()) {
            $page_title = esc_html__('Blog', 'crust');
        } elseif (is_home()) {
            $page_title = get_the_title(get_option('page_for_posts', true));
        } elseif (is_search()) {
            $page_title .= get_search_query();
        } elseif (is_author()) {
            $page_title .= crust_author_title();
        } elseif (is_tag()) {
            $page_title .= single_tag_title('', false);
        } elseif (is_archive()) {
            if ( is_day() ) {
                $page_title .= get_the_date('j F Y');
            } elseif (is_month()) {
                $page_title .= get_the_date('F Y');
            } elseif (is_year()) {
                $page_title .= get_the_date('Y');
            } elseif (class_exists('Woocommerce') && is_woocommerce() && (is_product() || is_shop()) && ! is_search()) {
                $page_title = woocommerce_page_title(false);
            } elseif (class_exists('Woocommerce') && is_product_category()) {
                $page_title = single_cat_title('', false);
            } elseif ( 'post' == get_post_type() ) {
                $page_title = single_cat_title('', false);
            } elseif ( $post_type_slug == get_post_type() ) {
                $page_title = single_cat_title('', false);
            } elseif ( class_exists( 'Crust_Core' ) && CRUST_PORTFOLIO === $post_type && is_tax(CRUST_PORTFOLIO. '_categories') ) {
                $page_title = single_term_title('', false);
            } elseif ( class_exists( 'Crust_Core' ) && CRUST_PORTFOLIO === $post_type ) {
                $page_title = esc_html__('Portfolio', 'crust');
            } else {
                $page_title = get_the_title();
            }
        } elseif (class_exists('Woocommerce') && is_woocommerce() && (is_shop()) && ! is_search()) {
            if ( ! is_product()) {
                $page_title = woocommerce_page_title(false);
            }
        } else {
            $page_title = get_the_title();
        }

        return $page_title;
    }
}

// Allowed tags..
if ( ! function_exists('crust_allowed_tags')) {
    function crust_allowed_tags()
    {
        global $allowedtags;

        $attrs = [
            'style'               => [],
            'id'                  => [],
            'src'                 => [],
            'alt'                 => [],
            'title'               => [],
            'data-toggle'         => [],
            'data-trigger'        => [],
            'data-placement'      => [],
            'data-content'        => [],
            'data-original-title' => [],
            'href'                => [],
            'class'               => [],
	        'xmlns'               => [],
	        'viewBox'             => [],
	        'preserveAspectRatio' => [],
	        'd'                   => []
        ];

        $allowedtags['span']   = $attrs;
        $allowedtags['div']    = $attrs;
	    $allowedtags['ul']     = $attrs;
	    $allowedtags['li']     = $attrs;
        $allowedtags['p']      = $attrs;
        $allowedtags['img']    = $attrs;
        $allowedtags['b']      = $attrs;
        $allowedtags['i']      = $attrs;
        $allowedtags['strong'] = $attrs;
        $allowedtags['a']      = $attrs;
        $allowedtags['u']      = $attrs;
	    $allowedtags['svg']    = $attrs;
	    $allowedtags['path']   = $attrs;

        return $allowedtags;
    }
}

if ( ! function_exists( 'crust_get_id_by_slug' ) ) {
    function crust_get_id_by_slug( $page_slug ) {
        $page = get_page_by_path( $page_slug );
        if ( $page ) {
            return $page->ID;
        } else {
            return null;
        }
    }
}

if ( ! function_exists('crust_author_title')) {
    function crust_author_title()
    {
        global $wp_query;
        $current_user = $wp_query->get_queried_object();
        $firstname    = $current_user->user_firstname;
        $lastname     = $current_user->user_lastname;
        $loginname    = $current_user->user_login;
        $user_name    = $loginname;
        if (isset( $firstname ) && ! empty( $firstname )) {
            $user_name = $firstname . ' ' . $lastname;
        }

        return $user_name;
    }
}

// Get all registered sidebars..
if ( ! function_exists( 'crust_get_sidebars' ) ) {
    function crust_get_sidebars() {
        global $wp_registered_sidebars;
        $sidebars   = [];
        $crst_bars  = get_option('crust_sidebars');

        foreach($wp_registered_sidebars as $id => $sidebar){
            $sidebars[$id] = $sidebar['name'];
        }

        if( $crst_bars ){
            foreach($crst_bars as $crst_id => $crst_bar){
                $sidebars['crust_core_custom_sidebar_'.$crst_id] = $crst_bar;
            }
        }

        return $sidebars;
    }
}

// Check for Active sidebar..
if( ! function_exists( 'crust_active_sidebar' ) ) {
    function crust_active_sidebar()
    {
        $active_bar = false;
        if( is_active_sidebar('sidebar-1') || is_active_sidebar('sidebar-2') ) {
            $active_bar = true;
        }

        return $active_bar;

    }
}

// Main Theme Settings..
if( ! function_exists( 'crust_blog_settings' ) ){
	function crust_blog_settings()
	{

		$vars = [];
		$layout  = crust_mod( 'archive_style', 'classic' );
		$columns = crust_mod('blog_columns', '2');
		$media   = crust_mod('img_archive_classic', true);
		$bar     = ( crust_meta('sidebar_position' ) === '' ) ? crust_mod( 'archive_sidebar', 'right' ) : crust_meta( 'sidebar_position' );

		// Inintialize URL to the variable
		$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$url_components = parse_url($url);
		if( isset($url_components['query']) && $url_components['query'] ){
			parse_str($url_components['query'], $params);
			if( isset($params['layout']) && $params['layout'] ){
				$layout = $params['layout'];
			}
			if( isset($params['columns']) && $params['columns'] ){
				$columns = $params['columns'];
			}
			if( isset($params['bar']) && $params['bar'] ){
				$bar = $params['bar'];
			}
			if( isset($params['media']) && $params['media'] ){
				$media = $params['media'];
			}
		}

		$vars['layout']  = $layout;
		$vars['columns'] = $columns;
		$vars['bar']     = $bar;
		$vars['media']   = $media;

		return $vars;

	}
}

if( ! function_exists( 'crust_single_settings' ) ){
	function crust_single_settings()
	{

		$vars = [];
		$sidebar = '';
		$post_type = get_post_type();

		if( class_exists('Crust_Core') ) {
			if ( 'page' !== $post_type ) {
				if ( CRUST_PORTFOLIO === $post_type ) {
					$sidebar = ( crust_meta( 'sidebar_position' ) === '' ) ? crust_mod( 'portfolio_sidebar' ) : crust_meta( 'sidebar_position' );
				} else {
					$sidebar = ( crust_meta( 'sidebar_position' ) === '' ) ? crust_mod( 'single_sidebar' ) : crust_meta( 'sidebar_position' );
				}
			} else {
				$sidebar = ( crust_meta( 'sidebar_position' ) === '' ) ? crust_mod( 'page_sidebar' ) : crust_meta( 'sidebar_position' );
			}
		} else {
			$sidebar = 'right';
		}

		// Inintialize URL to the variable
		$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$url_components = parse_url($url);
		if( isset($url_components['query']) && $url_components['query'] ){
			parse_str($url_components['query'], $params);
			if( isset($params['bar']) && $params['bar'] ){
				$sidebar = $params['bar'];
			}
		}

		$vars['bar'] = $sidebar;
		return $vars;

	}
}

if( ! function_exists( 'crust_woo_settings' ) ){
	function crust_woo_settings()
	{

		$vars = [];
		$sidebar = $woo_bar = '';
		$style = crust_mod('woo_item_style');
		$shadow = crust_mod('gallery_shadow');

		if ( is_singular( 'product' ) ) {
			$sidebar = ( crust_meta('meta_sidebar_position') === '' ) ? crust_mod('woo_single_bar_dir') : crust_meta('meta_sidebar_position');
			$woo_bar = ( crust_meta('meta_sidebar_select') === '' )   ? crust_mod('woo_single_sidebar') : crust_meta('meta_sidebar_select');
		} else if( class_exists('Woocommerce') && is_woocommerce() ) {
			$sidebar = ( crust_meta('meta_sidebar_position') === '' ) ? crust_mod('woo_bar_dir') : crust_meta('meta_sidebar_position');
			$woo_bar = ( crust_meta('meta_sidebar_select') === '' )   ? crust_mod('woo_sidebar', 'sidebar-1') : crust_meta('meta_sidebar_select');
		}

		// Inintialize URL to the variable
		$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$url_components = parse_url($url);
		if( isset($url_components['query']) && $url_components['query'] ){
			parse_str($url_components['query'], $params);
			if( isset($params['bar']) && $params['bar'] ){
				$sidebar = $params['bar'];
			}

			if( isset($params['shadow']) && $params['shadow'] ){
				$shadow = $params['shadow'];
			}

			if( isset($params['style']) && $params['style'] ){
				$style = $params['style'];
			}
		}

		$vars['bar'] = $sidebar;
		$vars['shadow'] = $shadow;
		$vars['woo_bar'] = $woo_bar;
		$vars['style'] = $style;

		return $vars;

	}
}

if( ! function_exists( 'crust_portfolio_settings' ) ){
	function crust_portfolio_settings()
	{

		$vars = [];
		$bar = crust_mod('portfolio_archive_sidebar', 'none');
		$layout = crust_mod( 'portfolio_archive_style', 'grid' );
		$item  = ( crust_mod( 'portfolio_item_style', 'card' ) == '' ) ? ' card' : ' ' . crust_mod( 'portfolio_item_style', 'card' );
		$columns = crust_mod( 'portfolio_columns', '3' );

		// Inintialize URL to the variable
		$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$url_components = parse_url($url);
		if( isset($url_components['query']) && $url_components['query'] ){
			parse_str($url_components['query'], $params);
			if( isset($params['bar']) && $params['bar'] ){
				$bar = $params['bar'];
			}
			if( isset($params['item']) && $params['item'] ){
				$item = $params['item'];
			}
			if( isset($params['layout']) && $params['layout'] ){
				$layout = $params['layout'];
			}
			if( isset($params['columns']) && $params['columns'] ){
				$columns = $params['columns'];
			}
		}

		$vars['bar'] = $bar;
		$vars['layout'] = $layout;
		$vars['item'] = $item;
		$vars['columns'] = $columns;
		return $vars;

	}
}


